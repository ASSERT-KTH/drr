import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("1969-365T16:00:00-08:00", "GregorianChronology[America/Los_Angeles]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        java.lang.String str10 = illegalFieldValueException8.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException8.getDurationFieldType();
        java.lang.String str12 = illegalFieldValueException8.getIllegalValueAsString();
        java.lang.String str13 = illegalFieldValueException8.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-365T16:00:00-08:00" + "'", str13.equals("1969-365T16:00:00-08:00"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str9 = gregorianChronology8.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology13 = gregorianChronology8.withZone(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = gregorianChronology8.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime7.toMutableDateTime(chronology14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withLocale(locale17);
//        java.lang.String str19 = dateTime7.toString(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-W01-4T00:00:00.052Z" + "'", str19.equals("1970-W01-4T00:00:00.052Z"));
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long27 = zeroIsMaxDateTimeField13.roundHalfEven((long) (-2));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-100L) + "'", long27 == (-100L));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = cachedDateTimeZone9.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        long long16 = cachedDateTimeZone9.convertLocalToUTC((-100L), false, 0L);
        java.lang.String str18 = cachedDateTimeZone9.getName((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone9.getUncachedZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-200L) + "'", long16 == (-200L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.100" + "'", str18.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        try {
//            int[] intArray8 = gregorianChronology0.get(readablePeriod5, (-3100L), (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
//        boolean boolean6 = dateTime1.isBefore((long) 2000);
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
//        int int9 = dateTime1.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long16 = fixedDateTimeZone14.nextTransition((long) (byte) 1);
//        long long18 = fixedDateTimeZone14.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        int int24 = fixedDateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        long long26 = fixedDateTimeZone14.convertUTCToLocal((long) 2);
//        org.joda.time.DateTime dateTime27 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.DateTime dateTime29 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.Chronology chronology30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime1.toDateTime(chronology30);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2000L + "'", long18 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 102L + "'", long26 == 102L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) '4');
        int int14 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.hourOfDay();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 78425692, (-3578800L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 82004492L + "'", long2 == 82004492L);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        java.lang.String str3 = property2.getAsString();
//        org.joda.time.DurationField durationField4 = property2.getRangeDurationField();
//        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970-01-03T00:00:00.152+00:00:00.100", "+00:00:00.100");
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology48);
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology53);
//        int int55 = dateTime54.getCenturyOfEra();
//        org.joda.time.DateTime.Property property56 = dateTime54.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime52.get(dateTimeFieldType57);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, dateTimeFieldType57, 59, (int) (short) -1, (int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, (java.lang.Number) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType57, 47, 4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder69.appendHourOfHalfday((int) (byte) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(21);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1969, (-1), (int) (byte) 10, 200, 22, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 69, 21, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for  must be in the range [21,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str4 = gregorianChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = gregorianChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        int int13 = dateTime12.getCenturyOfEra();
//        org.joda.time.DateTime.Property property14 = dateTime12.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType15);
//        boolean boolean17 = zeroIsMaxDateTimeField16.isLenient();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime21 = dateTime19.plusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime23 = dateTime21.withHourOfDay(0);
//        org.joda.time.DateTime dateTime25 = dateTime21.withEra(1);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        int[] intArray30 = new int[] { ' ', (short) 0, (short) 100 };
//        int int31 = zeroIsMaxDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDateTime26, intArray30);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDateTime26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[]" + "'", str4.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86400 + "'", int31 == 86400);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendMinuteOfDay(22);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.minus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime12 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(52);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear(200);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str15 = dateTime13.toString(dateTimeFormatter14);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusMonths(22);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T00:00:00.152+00:00:00.100" + "'", str15.equals("T00:00:00.152+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
//        boolean boolean6 = dateTime1.isBefore((long) 2000);
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
//        int int9 = dateTime1.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long16 = fixedDateTimeZone14.nextTransition((long) (byte) 1);
//        long long18 = fixedDateTimeZone14.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        int int24 = fixedDateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        long long26 = fixedDateTimeZone14.convertUTCToLocal((long) 2);
//        org.joda.time.DateTime dateTime27 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.DateTime dateTime29 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime dateTime30 = dateTime29.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2000L + "'", long18 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 102L + "'", long26 == 102L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.year();
//        int int49 = dateTimeFormatter48.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter48.withDefaultYear(0);
//        org.joda.time.format.DateTimeParser dateTimeParser52 = dateTimeFormatter48.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder47.append(dateTimeParser52);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2000 + "'", int49 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeParser52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.minus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime12 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        int int11 = dateTime10.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
//        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
//        org.joda.time.DateTime dateTime19 = property17.setCopy(20);
//        org.joda.time.DateTime dateTime20 = property17.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
//        int int27 = dateTime20.get(dateTimeField26);
//        boolean boolean28 = dateTime20.isAfterNow();
//        int int29 = dateTime20.getYearOfCentury();
//        org.joda.time.DateTime dateTime31 = dateTime20.plusMonths((int) (short) 0);
//        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) dateTime31);
//        java.lang.String str34 = fixedDateTimeZone4.getNameKey(200020L);
//        long long36 = fixedDateTimeZone4.previousTransition((long) 23156);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 70 + "'", int29 == 70);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "960" + "'", str34.equals("960"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 23156L + "'", long36 == 23156L);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        int int12 = dateTime11.getCenturyOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        int int15 = dateTime9.get(dateTimeFieldType14);
//        org.joda.time.DateTime.Property property16 = dateTime4.property(dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "1");
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("887");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("887");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime12 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        int int3 = property2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("47", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) (short) -1);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("100", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
//        java.util.Locale locale20 = null;
//        try {
//            long long21 = zeroIsMaxDateTimeField13.set(1560556821716L, "-01:00", locale20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-01:00\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.dayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 10, 78440644, (-10), (int) (byte) 1, 86400, 152);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("47", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long8 = iSOChronology0.getDateTimeMillis(10, 200, (int) (byte) 1, 47, 86399999, 23156, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendTimeZoneName();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(59897L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology6);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T00:00:00.152+00:00:00.100" + "'", str2.equals("T00:00:00.152+00:00:00.100"));
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        int int28 = dateTime27.getCenturyOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.minuteOfHour();
//        org.joda.time.DateTime dateTime30 = property29.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay31 = dateTime30.toYearMonthDay();
//        int int32 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay31);
//        long long35 = zeroIsMaxDateTimeField13.add(0L, (int) (short) 0);
//        java.lang.String str37 = zeroIsMaxDateTimeField13.getAsShortText(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(yearMonthDay31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86400 + "'", int32 == 86400);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "86400" + "'", str37.equals("86400"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str8 = gregorianChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology12 = gregorianChronology7.withZone(dateTimeZone11);
//        org.joda.time.Chronology chronology13 = gregorianChronology7.withUTC();
//        org.joda.time.DateTime dateTime14 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        int int15 = gregorianChronology7.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.Chronology chronology18 = gregorianChronology7.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[]" + "'", str8.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
//        boolean boolean6 = dateTime1.isBefore((long) 2000);
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
//        int int9 = dateTime1.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long16 = fixedDateTimeZone14.nextTransition((long) (byte) 1);
//        long long18 = fixedDateTimeZone14.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        int int24 = fixedDateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        long long26 = fixedDateTimeZone14.convertUTCToLocal((long) 2);
//        org.joda.time.DateTime dateTime27 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusHours((int) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2000L + "'", long18 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 102L + "'", long26 == 102L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusYears((int) ' ');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
//        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfEra(1);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
//        int int31 = dateTime30.getCenturyOfEra();
//        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
//        org.joda.time.DateTime dateTime33 = property32.getDateTime();
//        org.joda.time.LocalDate localDate34 = dateTime33.toLocalDate();
//        int int35 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
//        long long38 = zeroIsMaxDateTimeField13.addWrapField(0L, 152);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 86400 + "'", int35 == 86400);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 152000L + "'", long38 == 152000L);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        try {
//            long long11 = dividedDateTimeField9.roundHalfFloor((long) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendMinuteOfHour(2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendDayOfMonth((int) (short) 0);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap55 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendTimeZoneName(strMap55);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long15 = fixedDateTimeZone13.nextTransition((long) (byte) 1);
//        long long17 = fixedDateTimeZone13.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
//        int int23 = fixedDateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        java.lang.String str24 = fixedDateTimeZone13.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        long long28 = fixedDateTimeZone13.nextTransition((long) 19);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2000L + "'", long17 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 19L + "'", long28 == 19L);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.Interval interval4 = property3.toInterval();
//        try {
//            org.joda.time.DateTime dateTime6 = property3.setCopy("");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(interval4);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        int int11 = dateTime10.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
//        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
//        int int16 = fixedDateTimeZone4.getStandardOffset((-300L));
//        long long18 = fixedDateTimeZone4.previousTransition((long) 1);
//        long long20 = fixedDateTimeZone4.convertUTCToLocal(200020L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 200120L + "'", long20 == 200120L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DurationField durationField10 = property7.getDurationField();
        org.joda.time.DateTime dateTime11 = property7.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder0.appendSecondOfDay(86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder0.appendTwoDigitYear((-1), false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(3800);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str9 = gregorianChronology8.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone12);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withEra(59);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        int int28 = dateTime27.getCenturyOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.minuteOfHour();
//        org.joda.time.DateTime dateTime30 = property29.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay31 = dateTime30.toYearMonthDay();
//        int int32 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay31);
//        long long34 = zeroIsMaxDateTimeField13.roundHalfFloor(0L);
//        int int35 = zeroIsMaxDateTimeField13.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(yearMonthDay31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86400 + "'", int32 == 86400);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-100L) + "'", long34 == (-100L));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 86400 + "'", int35 == 86400);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) (byte) 100, locale5);
//        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", (java.lang.Object) str6);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2000L, dateTimeZone3);
        boolean boolean7 = dateTimeZone3.isStandardOffset(0L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 86400, dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        int int15 = dateTimeFormatter14.getDefaultYear();
//        org.joda.time.Chronology chronology16 = dateTimeFormatter14.getChronolgy();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZone(dateTimeZone17);
//        org.joda.time.LocalDate localDate20 = dateTimeFormatter14.parseLocalDate("86400");
//        int int21 = zeroIsMaxDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDate20);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2000 + "'", int15 == 2000);
//        org.junit.Assert.assertNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        java.lang.String str14 = dividedDateTimeField9.getAsText(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
//        try {
//            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 100, 0, (int) (byte) 100, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(152);
        dateTimeFormatterBuilder2.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        int int11 = dateTime10.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
//        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
//        org.joda.time.DateTime dateTime19 = property17.setCopy(20);
//        org.joda.time.DateTime dateTime20 = property17.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
//        int int27 = dateTime20.get(dateTimeField26);
//        boolean boolean28 = dateTime20.isAfterNow();
//        int int29 = dateTime20.getYearOfCentury();
//        org.joda.time.DateTime dateTime31 = dateTime20.plusMonths((int) (short) 0);
//        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) dateTime31);
//        long long35 = fixedDateTimeZone4.adjustOffset((-2880L), true);
//        long long38 = fixedDateTimeZone4.adjustOffset(0L, true);
//        long long40 = fixedDateTimeZone4.nextTransition((long) (byte) 10);
//        long long42 = fixedDateTimeZone4.previousTransition(100200L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str44 = gregorianChronology43.toString();
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology43.getZone();
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology48 = gregorianChronology43.withZone(dateTimeZone47);
//        org.joda.time.Chronology chronology49 = gregorianChronology43.withUTC();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology43.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology43.year();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone56 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long58 = fixedDateTimeZone56.nextTransition((long) (byte) 1);
//        long long60 = fixedDateTimeZone56.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology61);
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        org.joda.time.DateTime dateTime65 = dateTime62.withPeriodAdded(readablePeriod63, (int) '4');
//        int int66 = fixedDateTimeZone56.getOffset((org.joda.time.ReadableInstant) dateTime65);
//        java.lang.String str67 = fixedDateTimeZone56.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology68 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, (org.joda.time.DateTimeZone) fixedDateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone69 = gregorianChronology43.getZone();
//        long long71 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone69, (long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 70 + "'", int29 == 70);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2880L) + "'", long35 == (-2880L));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100200L + "'", long42 == 100200L);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "GregorianChronology[]" + "'", str44.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2000L + "'", long60 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology68);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("887");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str5 = gregorianChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology4.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology9 = gregorianChronology4.withZone(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = gregorianChronology4.withUTC();
//        org.joda.time.DateTime dateTime11 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths((int) (short) -1);
//        boolean boolean16 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property17 = dateTime11.hourOfDay();
//        boolean boolean19 = property17.equals((java.lang.Object) 2000);
//        org.joda.time.DateTime dateTime20 = property17.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfEra((int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str24 = gregorianChronology23.toString();
//        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology23.getZone();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology28 = gregorianChronology23.withZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime22.withChronology((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTime.Property property32 = dateTime31.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        long long34 = property32.getDifferenceAsLong(readableInstant33);
//        long long35 = property32.remainder();
//        org.joda.time.DateTime dateTime36 = property32.roundHalfCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTime dateTime40 = dateTime38.plusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime42 = dateTime38.plusDays(2);
//        long long43 = property32.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime42);
//        boolean boolean44 = gregorianChronology23.equals((java.lang.Object) property32);
//        boolean boolean45 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology23);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[]" + "'", str5.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "GregorianChronology[]" + "'", str24.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 152L + "'", long35 == 152L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-2880L) + "'", long43 == (-2880L));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        java.lang.String str6 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withCenturyOfEra(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str10 = gregorianChronology9.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime8.toMutableDateTime(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-001T00:00:00Z" + "'", str6.equals("1970-001T00:00:00Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[]" + "'", str10.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(0);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str23 = dateTimeZone21.getName((long) (-1));
//        org.joda.time.DateTime dateTime24 = dateTime19.toDateTime(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-01:00" + "'", str23.equals("-01:00"));
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
//        int int30 = zeroIsMaxDateTimeField13.getMaximumValue((long) 69);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = zeroIsMaxDateTimeField13.getAsShortText((long) 152, locale32);
//        long long36 = zeroIsMaxDateTimeField13.add(897L, 59);
//        long long38 = zeroIsMaxDateTimeField13.roundCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86400 + "'", int30 == 86400);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "86400" + "'", str33.equals("86400"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 59897L + "'", long36 == 59897L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 900L + "'", long38 == 900L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField16.getMaximumTextLength(locale25);
//        int int27 = offsetDateTimeField16.getMinimumValue();
//        long long29 = offsetDateTimeField16.roundHalfEven((long) (-2));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2L) + "'", long29 == (-2L));
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendMinuteOfHour(2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendHourOfDay(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendTwoDigitWeekyear(22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendSecondOfDay((int) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) '4');
        int int14 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime13);
        int int16 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        long long67 = remainderDateTimeField65.remainder((long) 3800);
//        org.joda.time.DurationField durationField68 = remainderDateTimeField65.getRangeDurationField();
//        long long70 = remainderDateTimeField65.roundCeiling((long) 52);
//        org.joda.time.DurationField durationField71 = remainderDateTimeField65.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField65, dateTimeFieldType72);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3900L + "'", long67 == 3900L);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2678399900L + "'", long70 == 2678399900L);
//        org.junit.Assert.assertNotNull(durationField71);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = zeroIsMaxDateTimeField13.getLeapAmount((long) 78440644);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = zeroIsMaxDateTimeField13.getAsShortText(36142071043476440L, locale17);
//        boolean boolean20 = zeroIsMaxDateTimeField13.isLeap(70L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "38676" + "'", str18.equals("38676"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
//        long long32 = preciseDateTimeField27.roundFloor((long) 4);
//        long long34 = preciseDateTimeField27.remainder((long) 999);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4L + "'", long32 == 4L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.append(dateTimeFormatter47);
//        dateTimeFormatterBuilder48.clear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendMonthOfYear(1439);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendLiteral("-01:00");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendLiteral("23156");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder55.appendHalfdayOfDayText();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str30 = gregorianChronology29.toString();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology29.getZone();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology34 = gregorianChronology29.withZone(dateTimeZone33);
//        org.joda.time.Chronology chronology35 = gregorianChronology29.withUTC();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology29.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology37);
//        int int39 = dateTime38.getCenturyOfEra();
//        org.joda.time.DateTime.Property property40 = dateTime38.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField42 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType41);
//        long long45 = zeroIsMaxDateTimeField42.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology46);
//        int int48 = dateTime47.getCenturyOfEra();
//        org.joda.time.DateTime.Property property49 = dateTime47.minuteOfHour();
//        org.joda.time.DateTime dateTime50 = property49.getDateTime();
//        org.joda.time.LocalDate localDate51 = dateTime50.toLocalDate();
//        int[] intArray55 = new int[] { 20, 69 };
//        int[] intArray57 = zeroIsMaxDateTimeField42.add((org.joda.time.ReadablePartial) localDate51, (-10), intArray55, (int) (short) 0);
//        int int58 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[]" + "'", str30.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 20 + "'", int39 == 20);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 200020L + "'", long45 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 20 + "'", int48 == 20);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 86400 + "'", int58 == 86400);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        boolean boolean14 = zeroIsMaxDateTimeField13.isLenient();
//        int int15 = zeroIsMaxDateTimeField13.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", (java.lang.Number) 2019, number2, (java.lang.Number) 1.0d);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
//        long long32 = preciseDateTimeField27.roundFloor((long) 4);
//        long long35 = preciseDateTimeField27.addWrapField((long) (-1), 0);
//        java.util.Locale locale38 = null;
//        try {
//            long long39 = preciseDateTimeField27.set(0L, "2019-06-15T21:47:21.682Z", locale38);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T21:47:21.682Z\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4L + "'", long32 == 4L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-365T16:00:00-08:00", "100", (int) 'a', 200);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.lang.String str11 = cachedDateTimeZone9.getName((long) 100);
//        java.lang.String str13 = cachedDateTimeZone9.getNameKey((long) (short) 10);
//        long long15 = cachedDateTimeZone9.previousTransition((long) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str17 = gregorianChronology16.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology21 = gregorianChronology16.withZone(dateTimeZone20);
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withUTC();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str25 = gregorianChronology24.toString();
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology24.getZone();
//        org.joda.time.Chronology chronology27 = gregorianChronology24.withUTC();
//        org.joda.time.DateTime dateTime28 = dateTime23.withChronology((org.joda.time.Chronology) gregorianChronology24);
//        int int29 = dateTime28.getSecondOfMinute();
//        boolean boolean31 = dateTime28.isBefore((-8L));
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime28.toYearMonthDay();
//        boolean boolean33 = cachedDateTimeZone9.equals((java.lang.Object) dateTime28);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "960" + "'", str13.equals("960"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[]" + "'", str17.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[]" + "'", str25.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "960", 200, (int) (short) 0);
        long long7 = fixedDateTimeZone4.adjustOffset(200120L, true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 200120L + "'", long7 == 200120L);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        int int30 = preciseDateTimeField27.getDifference(4L, (long) 0);
//        int int31 = preciseDateTimeField27.getRange();
//        int int33 = preciseDateTimeField27.getMinimumValue(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86400000 + "'", int31 == 86400000);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTime dateTime12 = dateTime9.minus((long) (short) 100);
//        org.joda.time.DateTime.Property property13 = dateTime9.weekyear();
//        org.joda.time.DateTime.Property property14 = dateTime9.dayOfMonth();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property14.getAsShortText(locale15);
//        org.joda.time.DurationField durationField17 = property14.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNull(durationField17);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
//        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusMonths((int) (short) -1);
//        int int20 = property15.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime22 = property15.addToCopy(0);
//        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (byte) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        int int12 = dateTime11.getCenturyOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        int int15 = dateTime9.get(dateTimeFieldType14);
//        org.joda.time.DateTime.Property property16 = dateTime4.property(dateTimeFieldType14);
//        org.joda.time.DateTime dateTime18 = property16.addWrapFieldToCopy(0);
//        int int19 = property16.get();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.Interval interval4 = property3.toInterval();
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval4);
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(interval4);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str3 = dateTimeZone1.getName((long) (-1));
        java.lang.String str4 = dateTimeZone1.getID();
        int int6 = dateTimeZone1.getOffsetFromLocal(23359L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:00" + "'", str3.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:00" + "'", str4.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-3600000) + "'", int6 == (-3600000));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        int int12 = dateTime11.getCenturyOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType14);
//        long long18 = zeroIsMaxDateTimeField15.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
//        int int21 = dateTime20.getCenturyOfEra();
//        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
//        org.joda.time.DateTime dateTime23 = property22.getDateTime();
//        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
//        int[] intArray28 = new int[] { 20, 69 };
//        int[] intArray30 = zeroIsMaxDateTimeField15.add((org.joda.time.ReadablePartial) localDate24, (-10), intArray28, (int) (short) 0);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 200020L + "'", long18 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str4 = gregorianChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = gregorianChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        int int13 = dateTime12.getCenturyOfEra();
//        org.joda.time.DateTime.Property property14 = dateTime12.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType15);
//        long long19 = zeroIsMaxDateTimeField16.addWrapField((long) 20, 200);
//        int int20 = zeroIsMaxDateTimeField16.getMaximumValue();
//        java.lang.String str21 = zeroIsMaxDateTimeField16.getName();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology22);
//        int int24 = dateTime23.getCenturyOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime23.minuteOfHour();
//        org.joda.time.DateTime dateTime26 = property25.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
//        int[] intArray28 = new int[] {};
//        int int29 = zeroIsMaxDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay27, intArray28);
//        boolean boolean30 = zeroIsMaxDateTimeField16.isLenient();
//        long long33 = zeroIsMaxDateTimeField16.add((long) (byte) 0, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str35 = gregorianChronology34.toString();
//        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology34.getZone();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology39 = gregorianChronology34.withZone(dateTimeZone38);
//        org.joda.time.Chronology chronology40 = gregorianChronology34.withUTC();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology34.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
//        int int44 = dateTime43.getCenturyOfEra();
//        org.joda.time.DateTime.Property property45 = dateTime43.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType46);
//        long long50 = zeroIsMaxDateTimeField47.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology51);
//        int int53 = dateTime52.getCenturyOfEra();
//        org.joda.time.DateTime.Property property54 = dateTime52.minuteOfHour();
//        org.joda.time.DateTime dateTime55 = property54.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay56 = dateTime55.toYearMonthDay();
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = zeroIsMaxDateTimeField47.getAsText((org.joda.time.ReadablePartial) yearMonthDay56, 1970, locale58);
//        long long62 = zeroIsMaxDateTimeField47.add((long) (short) 0, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology63);
//        int int65 = dateTime64.getCenturyOfEra();
//        org.joda.time.DateTime.Property property66 = dateTime64.minuteOfHour();
//        org.joda.time.DateTime dateTime67 = property66.getDateTime();
//        org.joda.time.LocalDate localDate68 = dateTime67.toLocalDate();
//        int int69 = zeroIsMaxDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate68);
//        int int70 = zeroIsMaxDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate68);
//        int[] intArray72 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate68, 1560808042990L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[]" + "'", str4.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 200020L + "'", long19 == 200020L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86400 + "'", int20 == 86400);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "minuteOfHour" + "'", str21.equals("minuteOfHour"));
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400 + "'", int29 == 86400);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1000L) + "'", long33 == (-1000L));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "GregorianChronology[]" + "'", str35.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 20 + "'", int44 == 20);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 200020L + "'", long50 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 20 + "'", int53 == 20);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(yearMonthDay56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1970" + "'", str59.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 21000L + "'", long62 == 21000L);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 20 + "'", int65 == 20);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(localDate68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 86400 + "'", int69 == 86400);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(intArray72);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        java.lang.String str5 = iSOChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[-01:00]" + "'", str4.equals("ISOChronology[-01:00]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[-01:00]" + "'", str5.equals("ISOChronology[-01:00]"));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        long long67 = remainderDateTimeField65.remainder((long) 3800);
//        org.joda.time.DurationField durationField68 = remainderDateTimeField65.getRangeDurationField();
//        long long70 = remainderDateTimeField65.roundCeiling((long) 52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology71);
//        org.joda.time.DateTime.Property property73 = dateTime72.minuteOfDay();
//        org.joda.time.DateTime dateTime75 = property73.setCopy(20);
//        org.joda.time.DateTime dateTime76 = property73.withMinimumValue();
//        long long77 = property73.remainder();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property73.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField65, dateTimeFieldType78);
//        int int81 = remainderDateTimeField65.getMaximumValue((long) (-10));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3900L + "'", long67 == 3900L);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2678399900L + "'", long70 == 2678399900L);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 152L + "'", long77 == 152L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 34 + "'", int81 == 34);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("1969-365T16:00:00-08:00", "GregorianChronology[America/Los_Angeles]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        java.lang.String str10 = illegalFieldValueException8.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException8.getDurationFieldType();
        java.lang.Number number12 = illegalFieldValueException8.getUpperBound();
        java.lang.Throwable[] throwableArray13 = illegalFieldValueException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long15 = fixedDateTimeZone13.nextTransition((long) (byte) 1);
//        long long17 = fixedDateTimeZone13.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
//        int int23 = fixedDateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        java.lang.String str24 = fixedDateTimeZone13.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.Chronology chronology26 = zonedChronology25.withUTC();
//        try {
//            long long34 = zonedChronology25.getDateTimeMillis((int) (byte) -1, 19, 0, 52, (int) (byte) 0, 86399999, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2000L + "'", long17 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        int[] intArray26 = new int[] { 20, 69 };
//        int[] intArray28 = zeroIsMaxDateTimeField13.add((org.joda.time.ReadablePartial) localDate22, (-10), intArray26, (int) (short) 0);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = zeroIsMaxDateTimeField13.getAsText(897L, locale30);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "86400" + "'", str31.equals("86400"));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 59, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillis(0L);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, 1439);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        int int11 = dateTime10.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
//        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
//        long long18 = fixedDateTimeZone4.convertLocalToUTC(35L, false, (long) 47);
//        java.util.TimeZone timeZone19 = fixedDateTimeZone4.toTimeZone();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = fixedDateTimeZone4.getShortName((long) 86400, locale21);
//        long long25 = fixedDateTimeZone4.convertLocalToUTC((long) '4', true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-65L) + "'", long18 == (-65L));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.100" + "'", str22.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-48L) + "'", long25 == (-48L));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays(21);
        org.joda.time.DateTime dateTime6 = dateTime4.plus(23156L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
//        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
//        boolean boolean17 = property15.equals((java.lang.Object) 2000);
//        org.joda.time.DateTime dateTime18 = property15.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfEra((int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str22 = gregorianChronology21.toString();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime20.withChronology((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant31 = null;
//        long long32 = property30.getDifferenceAsLong(readableInstant31);
//        long long33 = property30.remainder();
//        org.joda.time.DateTime dateTime34 = property30.roundHalfCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.DateTime dateTime38 = dateTime36.plusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime40 = dateTime36.plusDays(2);
//        long long41 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime40);
//        boolean boolean42 = gregorianChronology21.equals((java.lang.Object) property30);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.minuteOfDay();
//        org.joda.time.DateTime dateTime47 = property45.setCopy(20);
//        org.joda.time.DateTime dateTime48 = property45.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter51.withChronology((org.joda.time.Chronology) iSOChronology52);
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.minuteOfHour();
//        int int55 = dateTime48.get(dateTimeField54);
//        boolean boolean56 = dateTime48.isAfterNow();
//        int int57 = dateTime48.getYearOfCentury();
//        org.joda.time.DateTime.Property property58 = dateTime48.yearOfCentury();
//        int int59 = property30.compareTo((org.joda.time.ReadableInstant) dateTime48);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[]" + "'", str22.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 152L + "'", long33 == 152L);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2880L) + "'", long41 == (-2880L));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 70 + "'", int57 == 70);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.era();
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfSecond();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsShortText(locale8);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "152" + "'", str9.equals("152"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) '4');
        int int14 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = fixedDateTimeZone4.isFixed();
        int int17 = fixedDateTimeZone4.getOffset((long) 86399999);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear(200);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str15 = dateTime13.toString(dateTimeFormatter14);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusMonths(22);
//        int int18 = dateTime13.getDayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T00:00:00.152+00:00:00.100" + "'", str15.equals("T00:00:00.152+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendMinuteOfHour(2000);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder52.appendTimeZoneOffset("ISOChronology[UTC]", true, 0, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
//        int int30 = zeroIsMaxDateTimeField13.getMaximumValue((long) 69);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = zeroIsMaxDateTimeField13.getAsShortText((long) 152, locale32);
//        long long36 = zeroIsMaxDateTimeField13.add(897L, 59);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str38 = gregorianChronology37.toString();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology42 = gregorianChronology37.withZone(dateTimeZone41);
//        org.joda.time.Chronology chronology43 = gregorianChronology37.withUTC();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology37.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
//        int int47 = dateTime46.getCenturyOfEra();
//        org.joda.time.DateTime.Property property48 = dateTime46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField50 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField44, dateTimeFieldType49);
//        long long53 = zeroIsMaxDateTimeField50.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology54);
//        int int56 = dateTime55.getCenturyOfEra();
//        org.joda.time.DateTime.Property property57 = dateTime55.minuteOfHour();
//        org.joda.time.DateTime dateTime58 = property57.getDateTime();
//        org.joda.time.LocalDate localDate59 = dateTime58.toLocalDate();
//        int[] intArray63 = new int[] { 20, 69 };
//        int[] intArray65 = zeroIsMaxDateTimeField50.add((org.joda.time.ReadablePartial) localDate59, (-10), intArray63, (int) (short) 0);
//        java.util.Locale locale66 = null;
//        try {
//            java.lang.String str67 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate59, locale66);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86400 + "'", int30 == 86400);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "86400" + "'", str33.equals("86400"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 59897L + "'", long36 == 59897L);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GregorianChronology[]" + "'", str38.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 20 + "'", int47 == 20);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200020L + "'", long53 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 20 + "'", int56 == 20);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.era();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime4.withDurationAdded(readableDuration7, 20);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((int) '4');
//        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded((long) (byte) 1, 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
//        long long16 = zeroIsMaxDateTimeField13.roundFloor(0L);
//        long long18 = zeroIsMaxDateTimeField13.remainder(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-100L) + "'", long16 == (-100L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.minus(readableDuration9);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime13 = dateTime5.minusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear((-1));
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillis((long) 47);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, 10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 172800052L + "'", long11 == 172800052L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.DateTime.Property property3 = dateTime1.centuryOfEra();
        boolean boolean4 = dateTime1.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        long long67 = remainderDateTimeField65.remainder((long) 3800);
//        org.joda.time.DurationField durationField68 = remainderDateTimeField65.getRangeDurationField();
//        long long70 = remainderDateTimeField65.roundCeiling((long) 52);
//        int int73 = remainderDateTimeField65.getDifference((long) 20, 897L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3900L + "'", long67 == 3900L);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2678399900L + "'", long70 == 2678399900L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        int int19 = dateTime18.getCenturyOfEra();
//        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = property20.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
//        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
//        int int30 = zeroIsMaxDateTimeField13.getMaximumValue((long) 69);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = zeroIsMaxDateTimeField13.getAsShortText((long) 152, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
//        int int36 = dateTime35.getCenturyOfEra();
//        org.joda.time.DateTime.Property property37 = dateTime35.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.DurationField durationField39 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str41 = gregorianChronology40.toString();
//        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology40.getZone();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology45 = gregorianChronology40.withZone(dateTimeZone44);
//        org.joda.time.Chronology chronology46 = gregorianChronology40.withUTC();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology40.dayOfWeek();
//        org.joda.time.DurationField durationField48 = gregorianChronology40.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField49 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType38, durationField39, durationField48);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField13, dateTimeFieldType38, 69);
//        org.joda.time.DurationField durationField52 = zeroIsMaxDateTimeField13.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86400 + "'", int30 == 86400);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "86400" + "'", str33.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "GregorianChronology[]" + "'", str41.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(durationField52);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", (java.lang.Number) 2019, number2, (java.lang.Number) 1.0d);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 2019 for org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported must not be larger than 1.0" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 2019 for org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported must not be larger than 1.0"));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
//        long long19 = zeroIsMaxDateTimeField13.roundHalfCeiling((-2880L));
//        java.lang.String str21 = zeroIsMaxDateTimeField13.getAsShortText((long) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = zeroIsMaxDateTimeField13.getType();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3100L) + "'", long19 == (-3100L));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "86400" + "'", str21.equals("86400"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        java.lang.String str10 = property7.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekOfWeekyear" + "'", str10.equals("weekOfWeekyear"));
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillis(0L);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        int int8 = dateTime7.getWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(21, 21, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str9 = gregorianChronology8.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
//        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        int int13 = dateTime12.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withHourOfDay((-2));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        org.joda.time.DurationFieldType durationFieldType28 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField30 = new org.joda.time.field.ScaledDurationField(durationField11, durationFieldType28, 999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField16.getMaximumTextLength(locale25);
//        org.joda.time.DurationField durationField27 = offsetDateTimeField16.getRangeDurationField();
//        int int29 = offsetDateTimeField16.getLeapAmount((long) 21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: Value null for GregorianChronology[America/Los_Angeles] must be in the range [10,0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        long long11 = cachedDateTimeZone9.nextTransition(0L);
//        boolean boolean12 = cachedDateTimeZone9.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime18 = property15.addToCopy((int) (byte) 1);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(86400);
//        int int21 = cachedDateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime18.withDurationAdded(readableDuration22, 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
//        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        long long11 = cachedDateTimeZone9.nextTransition(0L);
//        boolean boolean12 = cachedDateTimeZone9.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime18 = property15.addToCopy((int) (byte) 1);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(86400);
//        int int21 = cachedDateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = cachedDateTimeZone9.getName(900L, locale24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.100" + "'", str25.equals("+00:00:00.100"));
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        long long67 = remainderDateTimeField65.remainder((long) 3800);
//        org.joda.time.DurationField durationField68 = remainderDateTimeField65.getRangeDurationField();
//        long long70 = remainderDateTimeField65.roundCeiling((long) 52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology71);
//        org.joda.time.DateTime.Property property73 = dateTime72.minuteOfDay();
//        org.joda.time.DateTime dateTime75 = property73.setCopy(20);
//        org.joda.time.DateTime dateTime76 = property73.withMinimumValue();
//        long long77 = property73.remainder();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property73.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField65, dateTimeFieldType78);
//        try {
//            long long82 = dividedDateTimeField79.addWrapField(0L, 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3900L + "'", long67 == 3900L);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2678399900L + "'", long70 == 2678399900L);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 152L + "'", long77 == 152L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
//        org.joda.time.DurationField durationField31 = preciseDateTimeField27.getRangeDurationField();
//        int int32 = preciseDateTimeField27.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime4.withSecondOfMinute(4);
        boolean boolean9 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder48.append(dateTimeFormatter49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder53.appendYear(194, 86399999);
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology57.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology59);
//        org.joda.time.DateTime.Property property61 = dateTime60.minuteOfDay();
//        org.joda.time.DateTime dateTime63 = dateTime60.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology64);
//        int int66 = dateTime65.getCenturyOfEra();
//        org.joda.time.DateTime.Property property67 = dateTime65.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property67.getFieldType();
//        int int69 = dateTime63.get(dateTimeFieldType68);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, dateTimeFieldType68, 59, (int) (short) -1, (int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, (java.lang.Number) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder53.appendDecimal(dateTimeFieldType68, 1, (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(gregorianChronology64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 20 + "'", int66 == 20);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("47", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(47, 'a', 70, 10, 69, true, 86399999);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder13.setFixedSavings("weekOfWeekyear", 999);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.roundHalfFloor((-3100L));
//        org.joda.time.DurationField durationField22 = offsetDateTimeField16.getLeapDurationField();
//        try {
//            long long25 = offsetDateTimeField16.add((-3599900L), 999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82801158 for minuteOfHour must be in the range [59,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3100L) + "'", long21 == (-3100L));
//        org.junit.Assert.assertNull(durationField22);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
//        org.joda.time.DateTime dateTime6 = property5.getDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.minus((-200010L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((-3600000), 4, 86400000, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400000 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property2.getAsText(locale7);
//        int int9 = property2.getMinimumValue();
//        org.joda.time.DateTime dateTime10 = property2.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property2.addToCopy(3900L);
//        org.joda.time.Interval interval13 = property2.toInterval();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(interval13);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        int int5 = property3.getMaximumValue();
//        java.lang.String str6 = property3.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[]" + "'", str1.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        int int13 = dividedDateTimeField9.getMinimumValue();
//        int int14 = dividedDateTimeField9.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
//        long long32 = preciseDateTimeField27.roundFloor((long) 4);
//        org.joda.time.DurationField durationField33 = preciseDateTimeField27.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4L + "'", long32 == 4L);
//        org.junit.Assert.assertNotNull(durationField33);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
//        boolean boolean15 = zeroIsMaxDateTimeField13.isSupported();
//        long long18 = zeroIsMaxDateTimeField13.getDifferenceAsLong(200120L, (long) 34);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 200L + "'", long18 == 200L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
//        java.lang.String str18 = zeroIsMaxDateTimeField13.getName();
//        long long20 = zeroIsMaxDateTimeField13.roundCeiling((long) (byte) -1);
//        boolean boolean22 = zeroIsMaxDateTimeField13.isLeap(0L);
//        long long25 = zeroIsMaxDateTimeField13.add((long) 200, (int) (short) 100);
//        int int26 = zeroIsMaxDateTimeField13.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "minuteOfHour" + "'", str18.equals("minuteOfHour"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 900L + "'", long20 == 900L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100200L + "'", long25 == 100200L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86400 + "'", int26 == 86400);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str5 = dateTimeZone4.toString();
        org.joda.time.Chronology chronology6 = iSOChronology0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:00" + "'", str5.equals("-01:00"));
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long29 = preciseDateTimeField27.roundFloor((long) 86399999);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 86399999L + "'", long29 == 86399999L);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        int int30 = preciseDateTimeField27.getDifference(4L, (long) 0);
//        int int31 = preciseDateTimeField27.getMinimumValue();
//        int int33 = preciseDateTimeField27.get(1560635225692L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
//        long long36 = dateTime35.getMillis();
//        org.joda.time.LocalDateTime localDateTime37 = dateTime35.toLocalDateTime();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = preciseDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDateTime37, 100, locale39);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 78425692 + "'", int33 == 78425692);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "100" + "'", str40.equals("100"));
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
//        org.joda.time.DateTime dateTime21 = property19.setCopy(20);
//        org.joda.time.DateTime dateTime22 = property19.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) iSOChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.minuteOfHour();
//        int int29 = dateTime22.get(dateTimeField28);
//        boolean boolean30 = dateTime22.isAfterNow();
//        int int31 = dateTime22.getYearOfCentury();
//        org.joda.time.DateTime dateTime33 = dateTime22.plusMonths((int) (short) 0);
//        boolean boolean34 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime16.withYearOfEra((int) (short) 10);
//        org.joda.time.DurationFieldType durationFieldType37 = null;
//        try {
//            org.joda.time.DateTime dateTime39 = dateTime36.withFieldAdded(durationFieldType37, 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 70 + "'", int31 == 70);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        long long3 = property2.remainder();
//        int int4 = property2.getMaximumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = dateTime7.getCenturyOfEra();
//        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
//        int int11 = property9.getMaximumValue();
//        org.joda.time.DurationField durationField12 = property9.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
//        org.joda.time.DateTime dateTime17 = property15.setCopy(20);
//        org.joda.time.DateTime dateTime18 = property15.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) iSOChronology22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.minuteOfHour();
//        int int25 = dateTime18.get(dateTimeField24);
//        boolean boolean26 = dateTime18.isAfterNow();
//        int int27 = dateTime18.getYearOfCentury();
//        org.joda.time.DateTime dateTime29 = dateTime18.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTime.Property property32 = dateTime31.minuteOfDay();
//        org.joda.time.DateTime dateTime34 = property32.setCopy(20);
//        org.joda.time.DateTime dateTime35 = property32.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter36.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withChronology((org.joda.time.Chronology) iSOChronology39);
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.minuteOfHour();
//        int int42 = dateTime35.get(dateTimeField41);
//        boolean boolean43 = dateTime35.isAfterNow();
//        int int44 = dateTime35.getYearOfCentury();
//        org.joda.time.DateTime dateTime46 = dateTime35.plusMonths((int) (short) 0);
//        boolean boolean47 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime46);
//        int int48 = property9.compareTo((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder50.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder50.appendTwoDigitWeekyear(47, false);
//        boolean boolean55 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int4, (java.lang.Object) false);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 152L + "'", long3 == 152L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1439 + "'", int4 == 1439);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 70 + "'", int27 == 70);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 70 + "'", int44 == 70);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
//        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        long long6 = gregorianChronology0.add((long) ' ', 0L, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        int int10 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long18 = fixedDateTimeZone16.nextTransition((long) (byte) 1);
        long long20 = fixedDateTimeZone16.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int23 = cachedDateTimeZone21.getOffset((long) (byte) 100);
        org.joda.time.Chronology chronology24 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.DurationField durationField25 = gregorianChronology2.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(durationField25);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str7 = gregorianChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = gregorianChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.secondOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime4.toDateTime((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTimeISO();
//        int int16 = dateTime15.getEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTime dateTime15 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime5.plus((long) '4');
//        org.joda.time.DateTime dateTime19 = dateTime5.plusMillis(59);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime5.minus(readablePeriod20);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
        org.joda.time.DateTime dateTime7 = dateTime3.withEra(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 1);
        java.util.Locale locale10 = null;
        java.util.Calendar calendar11 = dateTime7.toCalendar(locale10);
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(calendar11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField16.getMaximumTextLength(locale25);
//        org.joda.time.DurationField durationField27 = offsetDateTimeField16.getRangeDurationField();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
//        int int31 = dateTime30.getCenturyOfEra();
//        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
//        org.joda.time.DateTime dateTime33 = property32.roundHalfFloorCopy();
//        int int34 = property32.getMaximumValue();
//        org.joda.time.DurationField durationField35 = property32.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.minuteOfDay();
//        org.joda.time.DateTime dateTime40 = property38.setCopy(20);
//        org.joda.time.DateTime dateTime41 = property38.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter42.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.minuteOfHour();
//        int int48 = dateTime41.get(dateTimeField47);
//        boolean boolean49 = dateTime41.isAfterNow();
//        int int50 = dateTime41.getYearOfCentury();
//        org.joda.time.DateTime dateTime52 = dateTime41.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology53);
//        org.joda.time.DateTime.Property property55 = dateTime54.minuteOfDay();
//        org.joda.time.DateTime dateTime57 = property55.setCopy(20);
//        org.joda.time.DateTime dateTime58 = property55.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter59.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = dateTimeFormatter61.withChronology((org.joda.time.Chronology) iSOChronology62);
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology62.minuteOfHour();
//        int int65 = dateTime58.get(dateTimeField64);
//        boolean boolean66 = dateTime58.isAfterNow();
//        int int67 = dateTime58.getYearOfCentury();
//        org.joda.time.DateTime dateTime69 = dateTime58.plusMonths((int) (short) 0);
//        boolean boolean70 = dateTime52.isEqual((org.joda.time.ReadableInstant) dateTime69);
//        int int71 = property32.compareTo((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property32.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType72, (int) '#');
//        int int77 = offsetDateTimeField16.get((long) (-10));
//        long long79 = offsetDateTimeField16.remainder(1560556821716L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 59 + "'", int34 == 59);
//        org.junit.Assert.assertNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 70 + "'", int50 == 70);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNotNull(iSOChronology62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 70 + "'", int67 == 70);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 86400049 + "'", int77 == 86400049);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = cachedDateTimeZone9.nextTransition(0L);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone13.getUncachedZone();
        long long16 = cachedDateTimeZone13.nextTransition(2678399900L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2678399900L + "'", long16 == 2678399900L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTime dateTime17 = property15.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        int int68 = dividedDateTimeField9.getDifference((long) 194, (long) (byte) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology48);
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology53);
//        int int55 = dateTime54.getCenturyOfEra();
//        org.joda.time.DateTime.Property property56 = dateTime54.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime52.get(dateTimeFieldType57);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, dateTimeFieldType57, 59, (int) (short) -1, (int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, (java.lang.Number) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType57, 47, 4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology70);
//        org.joda.time.DateTime.Property property72 = dateTime71.minuteOfDay();
//        org.joda.time.DateTime dateTime74 = property72.setCopy(20);
//        org.joda.time.DateTime dateTime75 = property72.withMinimumValue();
//        org.joda.time.DurationField durationField76 = property72.getDurationField();
//        org.joda.time.DateTime dateTime77 = property72.roundHalfFloorCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str79 = gregorianChronology78.toString();
//        org.joda.time.DateTimeZone dateTimeZone80 = gregorianChronology78.getZone();
//        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology83 = gregorianChronology78.withZone(dateTimeZone82);
//        org.joda.time.Chronology chronology84 = gregorianChronology78.withUTC();
//        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology78.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology86 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology86);
//        int int88 = dateTime87.getCenturyOfEra();
//        org.joda.time.DateTime.Property property89 = dateTime87.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = property89.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField91 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField85, dateTimeFieldType90);
//        org.joda.time.DateTime.Property property92 = dateTime77.property(dateTimeFieldType90);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException96 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType90, (java.lang.Number) 200020L, (java.lang.Number) 1560556821716L, (java.lang.Number) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder98 = dateTimeFormatterBuilder69.appendFixedSignedDecimal(dateTimeFieldType90, 52);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(durationField76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(gregorianChronology78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "GregorianChronology[]" + "'", str79.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone80);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertNotNull(chronology83);
//        org.junit.Assert.assertNotNull(chronology84);
//        org.junit.Assert.assertNotNull(dateTimeField85);
//        org.junit.Assert.assertNotNull(gregorianChronology86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 20 + "'", int88 == 20);
//        org.junit.Assert.assertNotNull(property89);
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//        org.junit.Assert.assertNotNull(property92);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder98);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField16.getMaximumTextLength(locale25);
//        int int27 = offsetDateTimeField16.getMinimumValue();
//        long long29 = offsetDateTimeField16.roundHalfFloor((long) 1970);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1970L + "'", long29 == 1970L);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
//        org.joda.time.DateTime dateTime8 = dateTime4.minusHours(0);
//        boolean boolean9 = dateTime4.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T00:00:00+00:00:00.100" + "'", str2.equals("T00:00:00+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = property4.setCopy(20);
        org.joda.time.DateTime dateTime7 = property4.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.minuteOfHour();
        int int14 = dateTime7.get(dateTimeField13);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType5, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
//        org.joda.time.DateTime dateTime6 = dateTime1.minusDays((int) (byte) 1);
//        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis(69);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
//        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
//        int int16 = dateTime9.getYear();
//        org.joda.time.DateTime.Property property17 = dateTime9.dayOfYear();
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        long long19 = property17.getDifferenceAsLong(readableInstant18);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("887");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("887");
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission3.newPermissionCollection();
        jodaTimePermission3.checkGuard((java.lang.Object) 10.0d);
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
//        java.lang.String str18 = zeroIsMaxDateTimeField13.getName();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int int20 = zeroIsMaxDateTimeField13.getMinimumValue(readablePartial19);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        int[] intArray25 = new int[] { 4, 2019 };
//        try {
//            int[] intArray27 = zeroIsMaxDateTimeField13.addWrapField(readablePartial21, 57600, intArray25, 22);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57600");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "minuteOfHour" + "'", str18.equals("minuteOfHour"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.Interval interval4 = property3.toInterval();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2000L, dateTimeZone8);
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
//        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime();
//        long long13 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        int int14 = dateTime10.getYearOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(interval4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long15 = fixedDateTimeZone13.nextTransition((long) (byte) 1);
//        long long17 = fixedDateTimeZone13.nextTransition((long) 2000);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
//        int int23 = fixedDateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        java.lang.String str24 = fixedDateTimeZone13.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str28 = gregorianChronology27.toString();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology32 = gregorianChronology27.withZone(dateTimeZone31);
//        org.joda.time.Chronology chronology33 = gregorianChronology27.withUTC();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology27.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
//        int int37 = dateTime36.getCenturyOfEra();
//        org.joda.time.DateTime.Property property38 = dateTime36.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField34, dateTimeFieldType39);
//        boolean boolean41 = zeroIsMaxDateTimeField40.isLenient();
//        int int44 = zeroIsMaxDateTimeField40.getDifference((long) 4, 98L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
//        long long47 = dateTime46.getMillis();
//        org.joda.time.LocalDateTime localDateTime48 = dateTime46.toLocalDateTime();
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = zeroIsMaxDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDateTime48, 86400, locale50);
//        long long53 = gregorianChronology26.set((org.joda.time.ReadablePartial) localDateTime48, (long) (-10));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2000L + "'", long17 == 2000L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[]" + "'", str28.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20 + "'", int37 == 20);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "86400" + "'", str51.equals("86400"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 52L + "'", long53 == 52L);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = property4.getMaximumValue();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        int int20 = dateTime13.get(dateTimeField19);
//        boolean boolean21 = dateTime13.isAfterNow();
//        int int22 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
//        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        int int37 = dateTime30.get(dateTimeField36);
//        boolean boolean38 = dateTime30.isAfterNow();
//        int int39 = dateTime30.getYearOfCentury();
//        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
//        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder48.append(dateTimeFormatter49);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.format.DateTimePrinter dateTimePrinter54 = dateTimeFormatter53.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder52.append(dateTimePrinter54);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder55.appendDayOfWeekText();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimePrinter54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime4.minusHours(0);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfEra();
        int int10 = dateTime4.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime4.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
//        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
//        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
//        long long19 = zeroIsMaxDateTimeField13.roundHalfEven(3800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3799900L + "'", long19 == 3799900L);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        long long24 = offsetDateTimeField16.getDifferenceAsLong(10L, 200020L);
//        int int25 = offsetDateTimeField16.getMinimumValue();
//        int int27 = offsetDateTimeField16.getLeapAmount(23359L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-200010L) + "'", long24 == (-200010L));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
//        org.joda.time.DateTime dateTime6 = dateTime1.minusDays((int) (byte) 1);
//        int int7 = dateTime6.getDayOfWeek();
//        int int8 = dateTime6.getYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField16.getMaximumTextLength(locale25);
//        org.joda.time.DurationField durationField27 = offsetDateTimeField16.getRangeDurationField();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
//        int int31 = dateTime30.getCenturyOfEra();
//        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
//        org.joda.time.DateTime dateTime33 = property32.roundHalfFloorCopy();
//        int int34 = property32.getMaximumValue();
//        org.joda.time.DurationField durationField35 = property32.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.minuteOfDay();
//        org.joda.time.DateTime dateTime40 = property38.setCopy(20);
//        org.joda.time.DateTime dateTime41 = property38.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter42.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.minuteOfHour();
//        int int48 = dateTime41.get(dateTimeField47);
//        boolean boolean49 = dateTime41.isAfterNow();
//        int int50 = dateTime41.getYearOfCentury();
//        org.joda.time.DateTime dateTime52 = dateTime41.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology53);
//        org.joda.time.DateTime.Property property55 = dateTime54.minuteOfDay();
//        org.joda.time.DateTime dateTime57 = property55.setCopy(20);
//        org.joda.time.DateTime dateTime58 = property55.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter59.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = dateTimeFormatter61.withChronology((org.joda.time.Chronology) iSOChronology62);
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology62.minuteOfHour();
//        int int65 = dateTime58.get(dateTimeField64);
//        boolean boolean66 = dateTime58.isAfterNow();
//        int int67 = dateTime58.getYearOfCentury();
//        org.joda.time.DateTime dateTime69 = dateTime58.plusMonths((int) (short) 0);
//        boolean boolean70 = dateTime52.isEqual((org.joda.time.ReadableInstant) dateTime69);
//        int int71 = property32.compareTo((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property32.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType72, (int) '#');
//        int int77 = offsetDateTimeField16.get((long) (-10));
//        org.joda.time.DurationField durationField78 = offsetDateTimeField16.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 59 + "'", int34 == 59);
//        org.junit.Assert.assertNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 70 + "'", int50 == 70);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNotNull(iSOChronology62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 70 + "'", int67 == 70);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 86400049 + "'", int77 == 86400049);
//        org.junit.Assert.assertNull(durationField78);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
//        long long21 = offsetDateTimeField16.remainder((long) 4);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField16.getAsText(100, locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField16.getAsText((long) (short) 10, locale26);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "69" + "'", str27.equals("69"));
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
//        long long18 = offsetDateTimeField16.roundFloor((long) 19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
//        long long25 = fixedDateTimeZone23.nextTransition((long) (byte) 1);
//        long long27 = fixedDateTimeZone23.nextTransition((long) 2000);
//        java.util.TimeZone timeZone28 = fixedDateTimeZone23.toTimeZone();
//        try {
//            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) offsetDateTimeField16, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 19L + "'", long18 == 19L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2000L + "'", long27 == 2000L);
//        org.junit.Assert.assertNotNull(timeZone28);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        java.util.Locale locale67 = null;
//        java.lang.String str68 = dividedDateTimeField9.getAsText(1970, locale67);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1970" + "'", str68.equals("1970"));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime14 = dateTime7.minusDays(86399999);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        int int5 = dateTime4.getCenturyOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
//        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str14 = gregorianChronology13.toString();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        int int32 = dateTime31.getCenturyOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime34 = property33.getDateTime();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
//        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
//        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        int int49 = dateTime48.getCenturyOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str54 = gregorianChronology53.toString();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
//        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
//        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
//        java.util.Locale locale66 = null;
//        int int67 = remainderDateTimeField65.getMaximumTextLength(locale66);
//        long long70 = remainderDateTimeField65.addWrapField(10L, 0);
//        int int71 = remainderDateTimeField65.getDivisor();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 35 + "'", int71 == 35);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DurationField durationField5 = property2.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        int int10 = dateTime4.get(dateTimeFieldType9);
//        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str13 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
//        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
//        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
//        boolean boolean31 = preciseDateTimeField27.isLenient();
//        org.joda.time.DurationField durationField32 = preciseDateTimeField27.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(durationField32);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        boolean boolean4 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfDay();
//        org.joda.time.DateTime dateTime22 = property20.setCopy(20);
//        org.joda.time.DateTime dateTime23 = property20.withMinimumValue();
//        org.joda.time.DurationField durationField24 = property20.getDurationField();
//        org.joda.time.DateTime dateTime25 = property20.roundHalfFloorCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str27 = gregorianChronology26.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology26.getZone();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology31 = gregorianChronology26.withZone(dateTimeZone30);
//        org.joda.time.Chronology chronology32 = gregorianChronology26.withUTC();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology26.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
//        int int36 = dateTime35.getCenturyOfEra();
//        org.joda.time.DateTime.Property property37 = dateTime35.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField33, dateTimeFieldType38);
//        org.joda.time.DateTime.Property property40 = dateTime25.property(dateTimeFieldType38);
//        boolean boolean41 = dateTime5.isSupported(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[]" + "'", str27.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//    }
//}

