import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.plusWeeks((int) ' ');
        org.joda.time.LocalTime localTime9 = dateTime1.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday(10);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder2.toPrinter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long12 = buddhistChronology8.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField13, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField15.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long32 = buddhistChronology28.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology28.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology27, dateTimeField33, 0);
        long long37 = skipUndoDateTimeField35.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatterBuilder38.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long46 = buddhistChronology42.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology42.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology41, dateTimeField47, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder38.appendShortText(dateTimeFieldType50);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField52 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder18.appendSignedDecimal(dateTimeFieldType50, 10, 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField57 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType50, 39, 6);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType50, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1097L + "'", long12 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1097L + "'", long32 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1000L + "'", long37 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1097L + "'", long46 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property10 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime12.withEra(0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withFields(readablePartial17);
        org.joda.time.DateTime dateTime20 = dateTime16.minusHours(10);
        int int21 = property10.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime23 = dateTime16.minusYears(39);
        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime26.withEra(0);
        org.joda.time.DateTime.Property property31 = dateTime26.yearOfEra();
        org.joda.time.DateTime dateTime33 = dateTime26.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property34 = dateTime26.millisOfSecond();
        org.joda.time.DateTime.Property property35 = dateTime26.monthOfYear();
        org.joda.time.DateTime dateTime36 = dateTime26.withLaterOffsetAtOverlap();
        int int37 = property24.compareTo((org.joda.time.ReadableInstant) dateTime36);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        boolean boolean31 = unsupportedDateTimeField28.isLenient();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
        try {
            long long34 = unsupportedDateTimeField28.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(durationField32);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test005");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfSecond((int) '#');
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime13.withEra(0);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.withFields(readablePartial18);
//        java.lang.Object obj20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(obj20, dateTimeZone21);
//        int int23 = mutableDateTime22.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        java.lang.Object obj25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj25, dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
//        java.lang.String str31 = dateTimeZone29.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        java.lang.Object obj33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(obj33, dateTimeZone34);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime35);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology36.getZone();
//        java.lang.String str39 = dateTimeZone37.getName((long) (byte) 0);
//        long long41 = dateTimeZone29.getMillisKeepLocal(dateTimeZone37, (long) (byte) 100);
//        mutableDateTime22.setZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime43 = dateTime19.withZoneRetainFields(dateTimeZone37);
//        long long47 = dateTimeZone37.convertLocalToUTC((-61838467621999L), true, (long) 59);
//        org.joda.time.DateTime dateTime48 = dateTime7.withZone(dateTimeZone37);
//        java.lang.String str50 = dateTimeZone37.getShortName((-210693873600000L));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordinated Universal Time" + "'", str39.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61838467621999L) + "'", long47 == (-61838467621999L));
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UTC" + "'", str50.equals("UTC"));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 2000);
        long long10 = offsetDateTimeField8.roundHalfFloor(100L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = buddhistChronology0.add(readablePeriod13, (long) (byte) 0, 12);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(40, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long4 = buddhistChronology0.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 39);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusMillis((int) (byte) 0);
//        int int19 = dateTime16.getEra();
//        org.joda.time.YearMonthDay yearMonthDay20 = dateTime16.toYearMonthDay();
//        java.lang.String str21 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) yearMonthDay20);
//        int[] intArray23 = buddhistChronology0.get((org.joda.time.ReadablePartial) yearMonthDay20, 28800006L);
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology0.minuteOfDay();
//        java.lang.Object obj26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime(obj26, dateTimeZone27);
//        int int29 = mutableDateTime28.getMonthOfYear();
//        int int30 = mutableDateTime28.getMinuteOfHour();
//        mutableDateTime28.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime28.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime34 = property33.roundCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = buddhistChronology35.seconds();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology35.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 2000);
//        java.util.Locale locale40 = null;
//        int int41 = offsetDateTimeField39.getMaximumTextLength(locale40);
//        java.lang.String str42 = offsetDateTimeField39.toString();
//        int int43 = mutableDateTime34.get((org.joda.time.DateTimeField) offsetDateTimeField39);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
//        boolean boolean45 = skipDateTimeField44.isSupported();
//        try {
//            long long48 = skipDateTimeField44.set(0L, 5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for dayOfMonth must be in the range [2001,2031]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1097L + "'", long4 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(yearMonthDay20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0010-06" + "'", str21.equals("0010-06"));
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str42.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2001 + "'", int43 == 2001);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 39);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.PreciseDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = buddhistChronology0.millis();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        try {
            long long34 = unsupportedDateTimeField28.remainder((-210693873600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        mutableDateTime1.add(readableDuration2, (int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime1.copy();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
//        int int7 = property6.get();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("16");
//        java.lang.String str2 = jodaTimePermission1.getName();
//        java.lang.String str3 = jodaTimePermission1.toString();
//        java.lang.String str4 = jodaTimePermission1.getName();
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
//        int int8 = mutableDateTime7.getMonthOfYear();
//        mutableDateTime7.setTime((long) (byte) 100);
//        int int11 = mutableDateTime7.getSecondOfMinute();
//        boolean boolean12 = jodaTimePermission1.equals((java.lang.Object) mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16" + "'", str2.equals("16"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"16\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"16\")"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "16" + "'", str4.equals("16"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        int int5 = mutableDateTime3.getMinuteOfHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 28800006L);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) buddhistChronology6);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 3, (org.joda.time.Chronology) buddhistChronology6, locale12, (java.lang.Integer) 2, (int) (byte) -1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long21 = buddhistChronology17.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology17.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField22, 0);
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        boolean boolean26 = skipUndoDateTimeField24.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField24);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipUndoDateTimeField24.getAsShortText((-1969), locale29);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = skipUndoDateTimeField24.getAsText(readablePartial31, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1097L + "'", long21 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-1969" + "'", str30.equals("-1969"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(75737116799L);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getLeapDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long31 = buddhistChronology27.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime45 = dateTime43.plusMillis((int) (byte) 0);
        int int46 = dateTime43.getEra();
        org.joda.time.YearMonthDay yearMonthDay47 = dateTime43.toYearMonthDay();
        java.lang.String str48 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) yearMonthDay47);
        int[] intArray50 = buddhistChronology27.get((org.joda.time.ReadablePartial) yearMonthDay47, 28800006L);
        java.util.Locale locale52 = null;
        java.lang.String str53 = zeroIsMaxDateTimeField25.getAsText((org.joda.time.ReadablePartial) yearMonthDay47, (int) (byte) 1, locale52);
        long long55 = zeroIsMaxDateTimeField25.roundHalfCeiling(20070L);
        int int57 = zeroIsMaxDateTimeField25.getMinimumValue((-61838467521999L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1097L + "'", long31 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0010-06" + "'", str48.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1" + "'", str53.equals("1"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 20000L + "'", long55 == 20000L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(0L);
//        java.util.Locale locale12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = property7.set("16", locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property7.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime15 = property7.roundHalfEven();
//        mutableDateTime15.setMinuteOfDay(40);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.dayOfYear();
//        boolean boolean20 = mutableDateTime15.isBefore(175799L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.era();
//        mutableDateTime2.addSeconds(39);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.secondOfMinute();
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        long long8 = property6.getDifferenceAsLong(readableInstant7);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        int int5 = mutableDateTime3.getMinuteOfHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 28800006L);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) buddhistChronology6);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 3, (org.joda.time.Chronology) buddhistChronology6, locale12, (java.lang.Integer) 2, (int) (byte) -1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long21 = buddhistChronology17.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology17.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField22, 0);
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        boolean boolean26 = skipUndoDateTimeField24.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField24);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipUndoDateTimeField24.getAsShortText((-1969), locale29);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long35 = buddhistChronology31.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter36.withPivotYear((java.lang.Integer) 39);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology45);
//        org.joda.time.DateTime dateTime49 = dateTime47.plusMillis((int) (byte) 0);
//        int int50 = dateTime47.getEra();
//        org.joda.time.YearMonthDay yearMonthDay51 = dateTime47.toYearMonthDay();
//        java.lang.String str52 = dateTimeFormatter36.print((org.joda.time.ReadablePartial) yearMonthDay51);
//        int[] intArray54 = buddhistChronology31.get((org.joda.time.ReadablePartial) yearMonthDay51, 28800006L);
//        int int55 = skipUndoDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay51);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1097L + "'", long21 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-1969" + "'", str30.equals("-1969"));
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1097L + "'", long35 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(yearMonthDay51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0010-06" + "'", str52.equals("0010-06"));
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 59 + "'", int55 == 59);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"dayOfMonth/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(4, 4);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        long long10 = dateTimeZone5.getMillisKeepLocal(dateTimeZone8, (long) '4');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 14640052L + "'", long10 == 14640052L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDayOfMonth((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay((int) 'a', 38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long7 = buddhistChronology3.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField8, 0);
        long long12 = skipUndoDateTimeField10.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatterBuilder13.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long21 = buddhistChronology17.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology17.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField22, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipUndoDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType25);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType25);
        int int30 = zeroIsMaxDateTimeField27.getDifference((long) 2, (long) 2000);
        java.util.Locale locale32 = null;
        java.lang.String str33 = zeroIsMaxDateTimeField27.getAsShortText(10, locale32);
        long long35 = zeroIsMaxDateTimeField27.roundCeiling(20006L);
        boolean boolean36 = jodaTimePermission1.equals((java.lang.Object) zeroIsMaxDateTimeField27);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1097L + "'", long7 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1000L + "'", long12 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1097L + "'", long21 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10" + "'", str33.equals("10"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 21000L + "'", long35 == 21000L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        java.lang.String str6 = skipUndoDateTimeField5.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 0);
        int int18 = dateTime15.getEra();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime15.toYearMonthDay();
        int int20 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField5.getType();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfMonth" + "'", str6.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long15 = buddhistChronology11.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology11.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField16, 0);
        long long20 = skipUndoDateTimeField18.roundCeiling((long) 4);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField18.getAsText((int) (byte) -1, locale22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusMillis((int) (byte) 0);
        int int38 = dateTime35.getEra();
        org.joda.time.YearMonthDay yearMonthDay39 = dateTime35.toYearMonthDay();
        java.lang.String str40 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) yearMonthDay39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipUndoDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay39, 39, locale42);
        long long46 = skipUndoDateTimeField18.set((long) 1969, 39);
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipUndoDateTimeField18.getAsShortText((long) (-1969), locale48);
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField18, 960);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1097L + "'", long15 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1000L + "'", long20 == 1000L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1" + "'", str23.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0010-06" + "'", str40.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "39" + "'", str43.equals("39"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 39969L + "'", long46 == 39969L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "58" + "'", str49.equals("58"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        int int6 = offsetDateTimeField4.getLeapAmount(100L);
        long long9 = offsetDateTimeField4.add((long) 2, 5961600400L);
        long long11 = offsetDateTimeField4.roundCeiling(690L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 515082274560000002L + "'", long9 == 515082274560000002L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86400000L + "'", long11 == 86400000L);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2, false);
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
//        int int8 = mutableDateTime7.getMonthOfYear();
//        int int9 = mutableDateTime7.getMinuteOfHour();
//        mutableDateTime7.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime7.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime15 = property12.add(0L);
//        java.util.Locale locale17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = property12.set("16", locale17);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property12.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType19, 2, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendEraText();
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder22.appendTimeZoneOffset("00100601", true, 2922795, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        int int28 = zeroIsMaxDateTimeField25.getDifference((long) 2, (long) 2000);
        long long31 = zeroIsMaxDateTimeField25.getDifferenceAsLong((-61838467621999L), (-61838640421948L));
        int int32 = zeroIsMaxDateTimeField25.getMinimumValue();
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField34 = buddhistChronology33.seconds();
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology33.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 2000);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) (short) 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long45 = buddhistChronology41.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology41.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField46, 0);
        long long50 = skipUndoDateTimeField48.roundHalfEven((long) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter51.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology60 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime61 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology60);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology60);
        org.joda.time.DateTime dateTime64 = dateTime62.plusMillis((int) (byte) 0);
        int int65 = dateTime62.getEra();
        org.joda.time.YearMonthDay yearMonthDay66 = dateTime62.toYearMonthDay();
        java.lang.String str67 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) yearMonthDay66);
        int[] intArray69 = new int[] { (short) 0 };
        int int70 = skipUndoDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay66, intArray69);
        java.util.Locale locale71 = null;
        java.lang.String str72 = offsetDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay66, locale71);
        org.joda.time.chrono.BuddhistChronology buddhistChronology79 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime80 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology79);
        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology79);
        org.joda.time.DateTime dateTime83 = dateTime81.plusMillis((int) (byte) 0);
        int int84 = dateTime81.getEra();
        org.joda.time.YearMonthDay yearMonthDay85 = dateTime81.toYearMonthDay();
        java.util.Locale locale86 = null;
        java.lang.String str87 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) yearMonthDay85, locale86);
        int int88 = zeroIsMaxDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay85);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 172799L + "'", long31 == 172799L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1097L + "'", long45 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(buddhistChronology60);
        org.junit.Assert.assertNotNull(mutableDateTime61);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0010-06" + "'", str67.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "1" + "'", str72.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology79);
        org.junit.Assert.assertNotNull(mutableDateTime80);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay85);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1" + "'", str87.equals("1"));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 60 + "'", int88 == 60);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone5.getName(20006L, locale24);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"BuddhistChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DurationField durationField10 = buddhistChronology6.months();
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
//        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(obj0, dateTimeZone6);
//        mutableDateTime20.setTime(5L);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfHour((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test041");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        int int24 = dateTimeZone5.getOffsetFromLocal((long) (byte) 100);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.set((int) (byte) 0);
//        java.lang.Object obj7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, dateTimeZone8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        int int11 = mutableDateTime9.getMinuteOfHour();
//        mutableDateTime9.setMillis((long) '4');
//        mutableDateTime9.setSecondOfDay(10);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime9.add(readableDuration16);
//        int int18 = mutableDateTime9.getMonthOfYear();
//        int int19 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        java.lang.Object obj21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime(obj21, dateTimeZone22);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime23);
//        org.joda.time.Chronology chronology25 = gJChronology24.withUTC();
//        org.joda.time.Chronology chronology26 = gJChronology24.withUTC();
//        mutableDateTime9.setChronology((org.joda.time.Chronology) gJChronology24);
//        mutableDateTime9.setYear(9);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField28.getDurationField();
        try {
            long long34 = unsupportedDateTimeField28.set((long) 35, "12:00:00 AM UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        int int9 = skipUndoDateTimeField8.getMinimumValue();
        boolean boolean10 = skipUndoDateTimeField8.isSupported();
        int int11 = skipUndoDateTimeField8.getMaximumValue();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField28.getLeapDurationField();
        try {
            int int33 = unsupportedDateTimeField28.getMinimumValue((long) 42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNull(durationField31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        java.lang.Number number28 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 100.0d, (java.lang.Number) 1L, number28);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long35 = buddhistChronology31.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology31.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology30, dateTimeField36, 0);
        long long40 = skipUndoDateTimeField38.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatterBuilder41.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long49 = buddhistChronology45.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology45.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField50, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipUndoDateTimeField52.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder41.appendShortText(dateTimeFieldType53);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField38, dateTimeFieldType53);
        java.lang.Number number58 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 100.0d, (java.lang.Number) 1L, number58);
        illegalFieldValueException29.addSuppressed((java.lang.Throwable) illegalFieldValueException59);
        java.lang.String str61 = illegalFieldValueException29.toString();
        illegalFieldValueException29.prependMessage("");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1097L + "'", long35 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1000L + "'", long40 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(buddhistChronology44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1097L + "'", long49 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for secondOfMinute must not be smaller than 1" + "'", str61.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for secondOfMinute must not be smaller than 1"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendHourOfHalfday(10);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.append(dateTimePrinter12, dateTimeParser14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
        org.joda.time.DateTime.Property property20 = dateTime17.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder15.appendFixedSignedDecimal(dateTimeFieldType21, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfSecond((int) '#');
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime13.withEra(0);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.withFields(readablePartial18);
//        java.lang.Object obj20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(obj20, dateTimeZone21);
//        int int23 = mutableDateTime22.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        java.lang.Object obj25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj25, dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
//        java.lang.String str31 = dateTimeZone29.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        java.lang.Object obj33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(obj33, dateTimeZone34);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime35);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology36.getZone();
//        java.lang.String str39 = dateTimeZone37.getName((long) (byte) 0);
//        long long41 = dateTimeZone29.getMillisKeepLocal(dateTimeZone37, (long) (byte) 100);
//        mutableDateTime22.setZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime43 = dateTime19.withZoneRetainFields(dateTimeZone37);
//        long long47 = dateTimeZone37.convertLocalToUTC((-61838467621999L), true, (long) 59);
//        org.joda.time.DateTime dateTime48 = dateTime7.withZone(dateTimeZone37);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordinated Universal Time" + "'", str39.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61838467621999L) + "'", long47 == (-61838467621999L));
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(0L);
//        java.lang.Object obj11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(obj11, dateTimeZone12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        int int15 = mutableDateTime13.getMinuteOfHour();
//        mutableDateTime13.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime13.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime19 = property18.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime20 = property18.roundHalfCeiling();
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime10, (org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        java.lang.Object obj23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(obj23, dateTimeZone24);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) mutableDateTime25);
//        org.joda.time.Chronology chronology27 = gJChronology26.withUTC();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.withZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime29.withEra(0);
//        org.joda.time.DateTime.Property property34 = dateTime29.yearOfEra();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime38 = dateTime29.plusSeconds(1);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        java.lang.Object obj40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime(obj40, dateTimeZone41);
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) mutableDateTime42);
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology43.getZone();
//        java.lang.String str46 = dateTimeZone44.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        java.lang.Object obj48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime(obj48, dateTimeZone49);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone47, (org.joda.time.ReadableInstant) mutableDateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = gJChronology51.getZone();
//        java.lang.String str54 = dateTimeZone52.getName((long) (byte) 0);
//        long long56 = dateTimeZone44.getMillisKeepLocal(dateTimeZone52, (long) (byte) 100);
//        org.joda.time.DateTime dateTime57 = dateTime29.toDateTime(dateTimeZone44);
//        org.joda.time.Chronology chronology58 = gJChronology26.withZone(dateTimeZone44);
//        org.joda.time.DateTime dateTime59 = mutableDateTime10.toDateTime(dateTimeZone44);
//        mutableDateTime10.setYear(0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Coordinated Universal Time" + "'", str46.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Coordinated Universal Time" + "'", str54.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(dateTime59);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        int int5 = mutableDateTime3.getMinuteOfHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 28800006L);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) buddhistChronology6);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 3, (org.joda.time.Chronology) buddhistChronology6, locale12, (java.lang.Integer) 2, (int) (byte) -1);
//        org.joda.time.Chronology chronology16 = dateTimeParserBucket15.getChronology();
//        long long17 = dateTimeParserBucket15.computeMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendHourOfHalfday(10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatterBuilder18.toPrinter();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long28 = buddhistChronology24.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology24.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology23, dateTimeField29, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField31.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendLiteral(' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendMillisOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder38.appendHourOfHalfday(2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long48 = buddhistChronology44.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology44.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology43, dateTimeField49, 0);
//        long long53 = skipUndoDateTimeField51.roundCeiling((long) 4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder54.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatterBuilder54.toFormatter();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipUndoDateTimeField65.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder54.appendShortText(dateTimeFieldType66);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, dateTimeFieldType66);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder42.appendText(dateTimeFieldType66);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder34.appendSignedDecimal(dateTimeFieldType66, 10, 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField73 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField31, dateTimeFieldType66);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType66, 39, 6);
//        dateTimeParserBucket15.saveField(dateTimeFieldType66, (int) '#');
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3L + "'", long17 == 3L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1097L + "'", long28 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(buddhistChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1097L + "'", long48 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1000L + "'", long53 == 1000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(buddhistChronology57);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
//        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(julianChronology22);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendPattern("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = buddhistChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.Chronology chronology5 = gJChronology4.withUTC();
        org.joda.time.DurationField durationField6 = gJChronology4.months();
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("16");
        mutableDateTime1.setHourOfDay(1);
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.toMutableDateTime();
        org.joda.time.Instant instant5 = mutableDateTime4.toInstant();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 75737116799L, (java.lang.Number) 6314719046399997L, (java.lang.Number) 28800100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property10 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime12 = dateTime1.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
//        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = buddhistChronology22.seconds();
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology22.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology22.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendLiteral(' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMillisOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendHourOfHalfday(2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long42 = buddhistChronology38.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology38.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology37, dateTimeField43, 0);
//        long long47 = skipUndoDateTimeField45.roundCeiling((long) 4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder48.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatterBuilder48.toFormatter();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long56 = buddhistChronology52.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology52.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology51, dateTimeField57, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = skipUndoDateTimeField59.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType60);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField45, dateTimeFieldType60);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder36.appendText(dateTimeFieldType60);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder28.appendSignedDecimal(dateTimeFieldType60, 10, 100);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField26, dateTimeFieldType60, (int) (short) 100);
//        long long70 = remainderDateTimeField68.roundHalfEven(172886399997L);
//        long long72 = remainderDateTimeField68.roundFloor((long) 12);
//        int int73 = remainderDateTimeField68.getDivisor();
//        boolean boolean74 = buddhistChronology21.equals((java.lang.Object) remainderDateTimeField68);
//        long long76 = remainderDateTimeField68.remainder((long) 42);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(buddhistChronology37);
//        org.junit.Assert.assertNotNull(buddhistChronology38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1097L + "'", long42 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1000L + "'", long47 == 1000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1097L + "'", long56 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 157766400000L + "'", long70 == 157766400000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 42L + "'", long76 == 42L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property10 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime12.withEra(0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withFields(readablePartial17);
        org.joda.time.DateTime dateTime20 = dateTime16.minusHours(10);
        int int21 = property10.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime23 = dateTime16.minusYears(39);
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) 1);
        int int26 = dateTime23.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 2000);
        long long7 = offsetDateTimeField5.roundHalfFloor(100L);
        boolean boolean8 = offsetDateTimeField5.isSupported();
        long long10 = offsetDateTimeField5.remainder((long) 6);
        java.lang.String str11 = offsetDateTimeField5.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long17 = buddhistChronology13.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology13.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology12, dateTimeField18, 0);
        long long22 = skipUndoDateTimeField20.roundCeiling((long) 4);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField20.getAsText((int) (byte) -1, locale24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology35);
        org.joda.time.DateTime dateTime39 = dateTime37.plusMillis((int) (byte) 0);
        int int40 = dateTime37.getEra();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime37.toYearMonthDay();
        java.lang.String str42 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) yearMonthDay41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay41, 39, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay41, 3, locale47);
        int[] intArray50 = buddhistChronology0.get((org.joda.time.ReadablePartial) yearMonthDay41, (long) '#');
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        try {
            int[] intArray53 = buddhistChronology0.get(readablePeriod51, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6L + "'", long10 == 6L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "dayOfMonth" + "'", str11.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1097L + "'", long17 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1000L + "'", long22 == 1000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-1" + "'", str25.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0010-06" + "'", str42.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "39" + "'", str45.equals("39"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "3" + "'", str48.equals("3"));
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) ' ', false);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendWeekOfWeekyear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        mutableDateTime1.add(readableDuration2, (int) (byte) 100);
        try {
            mutableDateTime1.setDayOfMonth(98);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 98 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        long long6 = offsetDateTimeField4.roundHalfFloor(100L);
        boolean boolean7 = offsetDateTimeField4.isSupported();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = buddhistChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 2000);
        long long14 = offsetDateTimeField12.roundHalfFloor(100L);
        boolean boolean15 = offsetDateTimeField12.isSupported();
        long long17 = offsetDateTimeField12.remainder((long) 6);
        java.lang.String str18 = offsetDateTimeField12.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long24 = buddhistChronology20.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology20.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology19, dateTimeField25, 0);
        long long29 = skipUndoDateTimeField27.roundCeiling((long) 4);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipUndoDateTimeField27.getAsText((int) (byte) -1, locale31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology42);
        org.joda.time.DateTime dateTime46 = dateTime44.plusMillis((int) (byte) 0);
        int int47 = dateTime44.getEra();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
        java.lang.String str49 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) yearMonthDay48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay48, 39, locale51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay48, 3, locale54);
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) yearMonthDay48, (int) '4', locale57);
        int int59 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 6L + "'", long17 == 6L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dayOfMonth" + "'", str18.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1097L + "'", long24 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1000L + "'", long29 == 1000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-1" + "'", str32.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0010-06" + "'", str49.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "39" + "'", str52.equals("39"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "3" + "'", str55.equals("3"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "52" + "'", str58.equals("52"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2031 + "'", int59 == 2031);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1097L + "'", long4 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
//        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
//        try {
//            org.joda.time.Instant instant21 = new org.joda.time.Instant((java.lang.Object) dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withEra(1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(readableInterval8);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.secondOfMinute();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant(400L);
//        boolean boolean9 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) instant8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long15 = buddhistChronology11.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology11.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField16, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField18.getType();
//        int int20 = mutableDateTime2.get(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1097L + "'", long15 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long49 = remainderDateTimeField46.addWrapField(5184000097L, 20070);
        long long51 = remainderDateTimeField46.roundCeiling(5184000097L);
        long long53 = remainderDateTimeField46.roundHalfEven((long) (byte) -1);
        long long56 = remainderDateTimeField46.getDifferenceAsLong(0L, (long) 69);
        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime64 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology63);
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology63);
        org.joda.time.DateTime dateTime67 = dateTime65.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime69 = dateTime67.plusYears((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder70.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatterBuilder70.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology73 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology74 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long78 = buddhistChronology74.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField79 = buddhistChronology74.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField81 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology73, dateTimeField79, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = skipUndoDateTimeField81.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder70.appendShortText(dateTimeFieldType82);
        int int84 = dateTime69.get(dateTimeFieldType82);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType82);
        int int86 = dividedDateTimeField85.getMinimumValue();
        long long88 = dividedDateTimeField85.remainder((long) 5);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2214259200097L + "'", long49 == 2214259200097L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 31536000000L + "'", long51 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology63);
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(buddhistChronology73);
        org.junit.Assert.assertNotNull(buddhistChronology74);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1097L + "'", long78 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-2922686) + "'", int86 == (-2922686));
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 5L + "'", long88 == 5L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test072");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        java.lang.Object obj20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(obj20, dateTimeZone21);
//        int int23 = mutableDateTime22.getMonthOfYear();
//        int int24 = mutableDateTime22.getMinuteOfHour();
//        mutableDateTime22.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime22.hourOfDay();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime22.centuryOfEra();
//        boolean boolean29 = gregorianChronology19.equals((java.lang.Object) mutableDateTime22);
//        try {
//            long long34 = gregorianChronology19.getDateTimeMillis(2, 2922795, 99, 38);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922795 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((int) (short) 100, locale8);
        long long11 = offsetDateTimeField4.roundHalfFloor((long) 31);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        java.lang.Number number28 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 100.0d, (java.lang.Number) 1L, number28);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long35 = buddhistChronology31.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology31.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology30, dateTimeField36, 0);
        long long40 = skipUndoDateTimeField38.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatterBuilder41.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long49 = buddhistChronology45.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology45.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField50, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipUndoDateTimeField52.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder41.appendShortText(dateTimeFieldType53);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField38, dateTimeFieldType53);
        java.lang.Number number58 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 100.0d, (java.lang.Number) 1L, number58);
        illegalFieldValueException29.addSuppressed((java.lang.Throwable) illegalFieldValueException59);
        java.lang.Throwable[] throwableArray61 = illegalFieldValueException29.getSuppressed();
        java.lang.Number number62 = illegalFieldValueException29.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1097L + "'", long35 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1000L + "'", long40 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(buddhistChronology44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1097L + "'", long49 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 100.0d + "'", number62.equals(100.0d));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(obj13, dateTimeZone14);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
//        java.lang.String str19 = dateTimeZone17.getName((long) (byte) 0);
//        long long21 = dateTimeZone9.getMillisKeepLocal(dateTimeZone17, (long) (byte) 100);
//        long long25 = dateTimeZone9.convertLocalToUTC((long) 6, true, (long) (byte) 100);
//        org.joda.time.Chronology chronology26 = julianChronology1.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology27 = julianChronology1.withUTC();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((-259200000L), (org.joda.time.Chronology) julianChronology1, locale28);
//        java.lang.Integer int30 = dateTimeParserBucket29.getOffsetInteger();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 6L + "'", long25 == 6L);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNull(int30);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        boolean boolean33 = unsupportedDateTimeField28.isLenient();
        java.lang.String str34 = unsupportedDateTimeField28.getName();
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField28.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "secondOfMinute" + "'", str34.equals("secondOfMinute"));
        org.junit.Assert.assertNull(durationField35);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 2000);
        long long7 = offsetDateTimeField5.roundHalfFloor(100L);
        boolean boolean8 = offsetDateTimeField5.isSupported();
        long long10 = offsetDateTimeField5.roundHalfCeiling((long) 2000);
        boolean boolean12 = offsetDateTimeField5.isLeap((long) (short) 1);
        long long14 = offsetDateTimeField5.roundFloor((long) 6);
        boolean boolean16 = offsetDateTimeField5.isLeap(3L);
        long long19 = offsetDateTimeField5.add((long) (byte) 1, 0L);
        try {
            mutableDateTime0.setRounding((org.joda.time.DateTimeField) offsetDateTimeField5, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getLeapDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long31 = buddhistChronology27.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime45 = dateTime43.plusMillis((int) (byte) 0);
        int int46 = dateTime43.getEra();
        org.joda.time.YearMonthDay yearMonthDay47 = dateTime43.toYearMonthDay();
        java.lang.String str48 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) yearMonthDay47);
        int[] intArray50 = buddhistChronology27.get((org.joda.time.ReadablePartial) yearMonthDay47, 28800006L);
        java.util.Locale locale52 = null;
        java.lang.String str53 = zeroIsMaxDateTimeField25.getAsText((org.joda.time.ReadablePartial) yearMonthDay47, (int) (byte) 1, locale52);
        long long55 = zeroIsMaxDateTimeField25.roundHalfCeiling(20070L);
        int int57 = zeroIsMaxDateTimeField25.get((long) 5);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1097L + "'", long31 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0010-06" + "'", str48.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1" + "'", str53.equals("1"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 20000L + "'", long55 == 20000L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 60 + "'", int57 == 60);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        java.lang.Object obj11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(obj11, dateTimeZone12);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime13);
//        org.joda.time.Chronology chronology15 = gJChronology14.withUTC();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.withZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime17.withEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime17.yearOfEra();
//        org.joda.time.DateTime dateTime24 = dateTime17.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime17.plusSeconds(1);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        java.lang.Object obj28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(obj28, dateTimeZone29);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) mutableDateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology31.getZone();
//        java.lang.String str34 = dateTimeZone32.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        java.lang.Object obj36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime(obj36, dateTimeZone37);
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, (org.joda.time.ReadableInstant) mutableDateTime38);
//        org.joda.time.DateTimeZone dateTimeZone40 = gJChronology39.getZone();
//        java.lang.String str42 = dateTimeZone40.getName((long) (byte) 0);
//        long long44 = dateTimeZone32.getMillisKeepLocal(dateTimeZone40, (long) (byte) 100);
//        org.joda.time.DateTime dateTime45 = dateTime17.toDateTime(dateTimeZone32);
//        org.joda.time.Chronology chronology46 = gJChronology14.withZone(dateTimeZone32);
//        try {
//            org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) property9, (org.joda.time.Chronology) gJChronology14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Coordinated Universal Time" + "'", str42.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(chronology46);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 100, (int) (short) 0);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        long long27 = zeroIsMaxDateTimeField25.roundHalfEven((long) ' ');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.secondOfMinute();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant(400L);
//        boolean boolean9 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) instant8);
//        org.joda.time.Instant instant10 = new org.joda.time.Instant();
//        org.joda.time.Instant instant11 = instant10.toInstant();
//        org.joda.time.Instant instant13 = instant11.withMillis((long) 3);
//        boolean boolean14 = instant11.isAfterNow();
//        int int15 = instant8.compareTo((org.joda.time.ReadableInstant) instant11);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        int int2 = dateTimeFormatter1.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("PST", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime2.toMutableDateTimeISO();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        mutableDateTime10.add(readableDuration11, (int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime10.copy();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime10.minuteOfHour();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = buddhistChronology17.seconds();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 2000);
//        java.util.Locale locale22 = null;
//        int int23 = offsetDateTimeField21.getMaximumTextLength(locale22);
//        int int26 = offsetDateTimeField21.getDifference((long) (byte) -1, 10L);
//        int int28 = offsetDateTimeField21.getMaximumValue(0L);
//        long long31 = offsetDateTimeField21.add((long) 'a', 60);
//        try {
//            mutableDateTime10.setRounding((org.joda.time.DateTimeField) offsetDateTimeField21, (-2922686));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: -2922686");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2031 + "'", int28 == 2031);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5184000097L + "'", long31 == 5184000097L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone5.getName(20006L, locale24);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 69");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        long long35 = unsupportedDateTimeField28.getDifferenceAsLong((long) (short) 1, (long) (-28800000));
        boolean boolean36 = unsupportedDateTimeField28.isSupported();
        java.lang.String str37 = unsupportedDateTimeField28.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800001L + "'", long35 == 28800001L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        long long27 = skipUndoDateTimeField8.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long33 = buddhistChronology29.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology29.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology28, dateTimeField34, 0);
        long long38 = skipUndoDateTimeField36.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatterBuilder39.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long47 = buddhistChronology43.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology43.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology42, dateTimeField48, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = skipUndoDateTimeField50.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder39.appendShortText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, dateTimeFieldType51);
        org.joda.time.DurationField durationField54 = zeroIsMaxDateTimeField53.getLeapDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long59 = buddhistChronology55.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = dateTimeFormatter60.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology69 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime70 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology69);
        org.joda.time.DateTime dateTime73 = dateTime71.plusMillis((int) (byte) 0);
        int int74 = dateTime71.getEra();
        org.joda.time.YearMonthDay yearMonthDay75 = dateTime71.toYearMonthDay();
        java.lang.String str76 = dateTimeFormatter60.print((org.joda.time.ReadablePartial) yearMonthDay75);
        int[] intArray78 = buddhistChronology55.get((org.joda.time.ReadablePartial) yearMonthDay75, 28800006L);
        java.util.Locale locale80 = null;
        java.lang.String str81 = zeroIsMaxDateTimeField53.getAsText((org.joda.time.ReadablePartial) yearMonthDay75, (int) (byte) 1, locale80);
        java.util.Locale locale83 = null;
        java.lang.String str84 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay75, 2, locale83);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1097L + "'", long33 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1000L + "'", long38 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1097L + "'", long47 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNull(durationField54);
        org.junit.Assert.assertNotNull(buddhistChronology55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1097L + "'", long59 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(buddhistChronology69);
        org.junit.Assert.assertNotNull(mutableDateTime70);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0010-06" + "'", str76.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1" + "'", str81.equals("1"));
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "2" + "'", str84.equals("2"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
        java.lang.String str7 = offsetDateTimeField4.toString();
        long long9 = offsetDateTimeField4.roundFloor(172882800097L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str7.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 172800000000L + "'", long9 == 172800000000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
        long long67 = skipUndoDateTimeField65.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder68.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long76 = buddhistChronology72.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology72.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology71, dateTimeField77, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendShortText(dateTimeFieldType80);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField82 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField65, dateTimeFieldType80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType80);
        int int85 = remainderDateTimeField46.getMaximumValue();
        long long87 = remainderDateTimeField46.roundHalfCeiling((-61838439243999L));
        long long89 = remainderDateTimeField46.roundHalfFloor(86400000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1000L + "'", long67 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(buddhistChronology71);
        org.junit.Assert.assertNotNull(buddhistChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1097L + "'", long76 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 99 + "'", int85 == 99);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-61851772800000L) + "'", long87 == (-61851772800000L));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.001", "12:00:00 AM UTC", (-28378000), 39);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210693873600000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39 + "'", int6 == 39);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
        long long67 = skipUndoDateTimeField65.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder68.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long76 = buddhistChronology72.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology72.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology71, dateTimeField77, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendShortText(dateTimeFieldType80);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField82 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField65, dateTimeFieldType80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType80);
        long long87 = dividedDateTimeField84.addWrapField((-61838467521999L), 7);
        int int89 = dividedDateTimeField84.get(115199999L);
        long long92 = dividedDateTimeField84.set(39969L, 1999);
        int int94 = dividedDateTimeField84.get((long) 57600000);
        java.util.Locale locale96 = null;
        java.lang.String str97 = dividedDateTimeField84.getAsShortText(4010L, locale96);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1000L + "'", long67 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(buddhistChronology71);
        org.junit.Assert.assertNotNull(buddhistChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1097L + "'", long76 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-39748147521999L) + "'", long87 == (-39748147521999L));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 25 + "'", int89 == 25);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 6229342368039969L + "'", long92 == 6229342368039969L);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 25 + "'", int94 == 25);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "25" + "'", str97.equals("25"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeFormatter6);
        int int8 = dateTimeFormatter6.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2000 + "'", int8 == 2000);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28801000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("16");
        mutableDateTime1.setHourOfDay(1);
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.toMutableDateTime();
        org.joda.time.Instant instant5 = mutableDateTime4.toInstant();
        org.joda.time.Instant instant7 = instant5.plus((long) 0);
        org.joda.time.DateTime dateTime8 = instant5.toDateTimeISO();
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant5);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61662294000000L) + "'", long9 == (-61662294000000L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-28799900L), (-28800000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra(23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        mutableDateTime1.add(readableDuration2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        mutableDateTime1.add(readableDuration5, (int) (byte) -1);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        java.lang.Object obj22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj22, dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime24);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
//        java.lang.String str28 = dateTimeZone26.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        java.lang.Object obj30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime(obj30, dateTimeZone31);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) mutableDateTime32);
//        org.joda.time.DateTimeZone dateTimeZone34 = gJChronology33.getZone();
//        java.lang.String str36 = dateTimeZone34.getName((long) (byte) 0);
//        long long38 = dateTimeZone26.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.Chronology chronology40 = iSOChronology20.withZone(dateTimeZone26);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
//        org.joda.time.Chronology chronology42 = gregorianChronology19.withZone(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Coordinated Universal Time" + "'", str36.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(chronology42);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
//        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = gregorianChronology19.equals(obj20);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        int int27 = skipUndoDateTimeField8.get((-2001L));
        long long29 = skipUndoDateTimeField8.remainder((-75737116800000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 57 + "'", int27 == 57);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField11, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
//        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(obj0, dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField8.getDurationField();
        long long14 = skipUndoDateTimeField8.add(1560340858467L, 38);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560340896467L + "'", long14 == 1560340896467L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-28378000", false);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, 39969L, 4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField28.toString();
        java.util.Locale locale34 = null;
        try {
            long long35 = unsupportedDateTimeField28.set(10L, "ISOChronology[America/Los_Angeles]", locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime1.plusSeconds(1);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
        org.joda.time.DurationField durationField12 = property11.getLeapDurationField();
        try {
            org.joda.time.DateTime dateTime14 = property11.setCopy((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(durationField12);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        int int6 = mutableDateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        java.lang.Object obj8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(obj8, dateTimeZone9);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        java.lang.String str14 = dateTimeZone12.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(obj16, dateTimeZone17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
//        java.lang.String str22 = dateTimeZone20.getName((long) (byte) 0);
//        long long24 = dateTimeZone12.getMillisKeepLocal(dateTimeZone20, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone12);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.withZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime30.withEra(0);
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withMillisOfSecond((int) (byte) 100);
//        org.joda.time.DateTime dateTime40 = dateTime36.withMillisOfSecond((int) '#');
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZone(dateTimeZone43);
//        org.joda.time.DateTime dateTime46 = dateTime42.withEra(0);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.withFields(readablePartial47);
//        java.lang.Object obj49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime(obj49, dateTimeZone50);
//        int int52 = mutableDateTime51.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        java.lang.Object obj54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime(obj54, dateTimeZone55);
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, (org.joda.time.ReadableInstant) mutableDateTime56);
//        org.joda.time.DateTimeZone dateTimeZone58 = gJChronology57.getZone();
//        java.lang.String str60 = dateTimeZone58.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        java.lang.Object obj62 = null;
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime(obj62, dateTimeZone63);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, (org.joda.time.ReadableInstant) mutableDateTime64);
//        org.joda.time.DateTimeZone dateTimeZone66 = gJChronology65.getZone();
//        java.lang.String str68 = dateTimeZone66.getName((long) (byte) 0);
//        long long70 = dateTimeZone58.getMillisKeepLocal(dateTimeZone66, (long) (byte) 100);
//        mutableDateTime51.setZone(dateTimeZone66);
//        org.joda.time.DateTime dateTime72 = dateTime48.withZoneRetainFields(dateTimeZone66);
//        long long76 = dateTimeZone66.convertLocalToUTC((-61838467621999L), true, (long) 59);
//        org.joda.time.DateTime dateTime77 = dateTime36.withZone(dateTimeZone66);
//        java.lang.String str79 = dateTimeZone66.getShortName(1560398409961L);
//        org.joda.time.DateTime dateTime80 = dateTime27.toDateTime(dateTimeZone66);
//        int int81 = dateTime27.getWeekyear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00" + "'", str60.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "+00:00" + "'", str68.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-61838467621999L) + "'", long76 == (-61838467621999L));
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "+00:00" + "'", str79.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1970 + "'", int81 == 1970);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime5.minusHours(10);
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((int) '#');
        org.joda.time.DateTime dateTime13 = dateTime9.withYearOfEra(2001);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundCeiling();
//        int int9 = property7.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundCeiling();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withEra(1);
//        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfWeek((int) (byte) 1);
//        boolean boolean19 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        mutableDateTime10.add(readableDuration20, 2031);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600000, 'a', 12, 0, 0, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("ISOChronology[America/Los_Angeles]", 42, 2, 0, '#', 40, 2031, (int) '4', true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone22 = dateTimeZoneBuilder19.toDateTimeZone("2001", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHalfdayOfDayText();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime5.withEra(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime11.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendFixedDecimal(dateTimeFieldType16, 2);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        int int7 = property6.get();
        java.lang.String str8 = property6.getName();
        java.util.Locale locale10 = null;
        org.joda.time.DateTime dateTime11 = property6.setCopy("39", locale10);
        org.joda.time.DateTime dateTime13 = property6.addWrapFieldToCopy(2031);
        org.joda.time.DateTime dateTime14 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.Chronology chronology6 = gJChronology5.withUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime8.withEra(0);
        org.joda.time.DateTime.Property property13 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime8.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime8.plusSeconds(1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        java.lang.Object obj19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(obj19, dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        java.lang.String str25 = dateTimeZone23.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        java.lang.Object obj27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime(obj27, dateTimeZone28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) mutableDateTime29);
        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology30.getZone();
        java.lang.String str33 = dateTimeZone31.getName((long) (byte) 0);
        long long35 = dateTimeZone23.getMillisKeepLocal(dateTimeZone31, (long) (byte) 100);
        org.joda.time.DateTime dateTime36 = dateTime8.toDateTime(dateTimeZone23);
        org.joda.time.Chronology chronology37 = gJChronology5.withZone(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField38 = gJChronology5.minuteOfDay();
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket(1560343175601L, (org.joda.time.Chronology) gJChronology5, locale39, (java.lang.Integer) 2031, (int) (short) 10);
        org.joda.time.Chronology chronology43 = gJChronology5.withUTC();
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(chronology43);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.001", "12:00:00 AM UTC", (-28378000), 39);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28378000) + "'", int6 == (-28378000));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        java.lang.String str9 = dateTimeZone7.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        java.lang.Object obj11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(obj11, dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getName((long) (byte) 0);
        long long19 = dateTimeZone7.getMillisKeepLocal(dateTimeZone15, (long) (byte) 100);
        long long23 = dateTimeZone7.convertLocalToUTC((long) 6, true, (long) (byte) 100);
        try {
            org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology$LimitDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 6L + "'", long23 == 6L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.withEra(0);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfEra();
        int int8 = property7.get();
        java.lang.String str9 = property7.getName();
        java.util.Locale locale11 = null;
        org.joda.time.DateTime dateTime12 = property7.setCopy("39", locale11);
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        java.lang.Object obj15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(obj15, dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
        java.lang.String str21 = dateTimeZone19.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        java.lang.Object obj23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(obj23, dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology26.getZone();
        java.lang.String str29 = dateTimeZone27.getName((long) (byte) 0);
        long long31 = dateTimeZone19.getMillisKeepLocal(dateTimeZone27, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long40 = buddhistChronology36.add((long) 'a', 100L, (int) (byte) 10);
        java.util.Locale locale41 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 39, (org.joda.time.Chronology) buddhistChronology36, locale41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        java.lang.Object obj44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime(obj44, dateTimeZone45);
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) mutableDateTime46);
        org.joda.time.Chronology chronology48 = gJChronology47.withUTC();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = dateTime50.withZone(dateTimeZone51);
        org.joda.time.DateTime dateTime54 = dateTime50.withEra(0);
        org.joda.time.DateTime.Property property55 = dateTime50.yearOfEra();
        org.joda.time.DateTime dateTime57 = dateTime50.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime59 = dateTime50.plusSeconds(1);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        java.lang.Object obj61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime(obj61, dateTimeZone62);
        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, (org.joda.time.ReadableInstant) mutableDateTime63);
        org.joda.time.DateTimeZone dateTimeZone65 = gJChronology64.getZone();
        java.lang.String str67 = dateTimeZone65.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        java.lang.Object obj69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.MutableDateTime mutableDateTime71 = new org.joda.time.MutableDateTime(obj69, dateTimeZone70);
        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (org.joda.time.ReadableInstant) mutableDateTime71);
        org.joda.time.DateTimeZone dateTimeZone73 = gJChronology72.getZone();
        java.lang.String str75 = dateTimeZone73.getName((long) (byte) 0);
        long long77 = dateTimeZone65.getMillisKeepLocal(dateTimeZone73, (long) (byte) 100);
        org.joda.time.DateTime dateTime78 = dateTime50.toDateTime(dateTimeZone65);
        org.joda.time.Chronology chronology79 = gJChronology47.withZone(dateTimeZone65);
        dateTimeParserBucket42.setZone(dateTimeZone65);
        java.lang.String str81 = dateTimeZone65.toString();
        org.joda.time.Chronology chronology82 = iSOChronology33.withZone(dateTimeZone65);
        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        long long86 = dateTimeZone65.getMillisKeepLocal(dateTimeZone84, 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "00390101T000000.097Z" + "'", str13.equals("00390101T000000.097Z"));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00" + "'", str29.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1097L + "'", long40 == 1097L);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(gJChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "+00:00" + "'", str67.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology72);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "+00:00" + "'", str75.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100L + "'", long77 == 100L);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "-28378000" + "'", str81.equals("-28378000"));
        org.junit.Assert.assertNotNull(chronology82);
        org.junit.Assert.assertNotNull(dateTimeZone84);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-10L) + "'", long86 == (-10L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField28.getRangeDurationField();
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField28.getLeapDurationField();
        try {
            int int37 = unsupportedDateTimeField28.get(28800006L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNull(durationField35);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test119");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(0L);
//        mutableDateTime10.addMonths(6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.withEra(0);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime9 = dateTime2.minusSeconds((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays(0);
        org.joda.time.DateTime.Property property17 = dateTime14.weekOfWeekyear();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime19.withEra(0);
        org.joda.time.DateTime.Property property24 = dateTime19.yearOfEra();
        org.joda.time.DateTime dateTime26 = dateTime19.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property27 = dateTime19.millisOfSecond();
        boolean boolean28 = property17.equals((java.lang.Object) property27);
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12/31/69" + "'", str12.equals("12/31/69"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-28378000", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeFormatter6);
        boolean boolean8 = dateTimeFormatter6.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        java.lang.String str6 = property4.toString();
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("16");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getName();
        java.lang.Object obj5 = null;
        jodaTimePermission1.checkGuard(obj5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16" + "'", str2.equals("16"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"16\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"16\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "16" + "'", str4.equals("16"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
        long long67 = skipUndoDateTimeField65.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder68.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long76 = buddhistChronology72.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology72.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology71, dateTimeField77, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendShortText(dateTimeFieldType80);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField82 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField65, dateTimeFieldType80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType80);
        long long87 = dividedDateTimeField84.addWrapField((-61838467521999L), 7);
        int int89 = dividedDateTimeField84.get(115199999L);
        long long92 = dividedDateTimeField84.set((long) 38, (int) (short) 1);
        long long95 = dividedDateTimeField84.add((long) 99, 98);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1000L + "'", long67 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(buddhistChronology71);
        org.junit.Assert.assertNotNull(buddhistChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1097L + "'", long76 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-39748147521999L) + "'", long87 == (-39748147521999L));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 25 + "'", int89 == 25);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-75737116799962L) + "'", long92 == (-75737116799962L));
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 309258172800099L + "'", long95 == 309258172800099L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.secondOfDay();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((-61838640421948L), (org.joda.time.Chronology) buddhistChronology1, locale5, (java.lang.Integer) 0);
        long long9 = dateTimeParserBucket7.computeMillis(false);
        int int10 = dateTimeParserBucket7.getOffset();
        dateTimeParserBucket7.setOffset(23);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket7.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61838640421948L) + "'", long9 == (-61838640421948L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test128");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 2000);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField13.getMaximumTextLength(locale14);
//        java.lang.String str16 = offsetDateTimeField13.toString();
//        int int17 = mutableDateTime8.get((org.joda.time.DateTimeField) offsetDateTimeField13);
//        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
//        int int19 = offsetDateTimeField13.getOffset();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2001 + "'", int17 == 2001);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2000 + "'", int19 == 2000);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        java.lang.Object obj9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        mutableDateTime22.addWeekyears(0);
        org.joda.time.ReadableDuration readableDuration25 = null;
        mutableDateTime22.add(readableDuration25);
        try {
            mutableDateTime22.setDate((-292275054), 40, 40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfDay((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DurationField durationField3 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 0);
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        int int6 = mutableDateTime4.getMinuteOfHour();
//        mutableDateTime4.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundHalfEven();
//        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime1.yearOfEra();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime1.withSecondOfMinute(1999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1999 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 2000);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField13.getMaximumTextLength(locale14);
//        java.lang.String str16 = offsetDateTimeField13.toString();
//        int int17 = mutableDateTime8.get((org.joda.time.DateTimeField) offsetDateTimeField13);
//        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField13.getAsText(57600000, locale20);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2001 + "'", int17 == 2001);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57600000" + "'", str21.equals("57600000"));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone5.getName(0L, locale9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime12.withEra(0);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTimeISO();
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime17, (-1969));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        int int5 = mutableDateTime3.getMinuteOfHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 28800006L);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) buddhistChronology6);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 3, (org.joda.time.Chronology) buddhistChronology6, locale12, (java.lang.Integer) 2, (int) (byte) -1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long21 = buddhistChronology17.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology17.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField22, 0);
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        boolean boolean26 = skipUndoDateTimeField24.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField24);
//        long long29 = skipDateTimeField27.roundHalfEven(77137921382376999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1097L + "'", long21 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 77137921382377000L + "'", long29 == 77137921382377000L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("DateTimeField[secondOfMinute]", (java.lang.Number) 100L, (java.lang.Number) 1L, (java.lang.Number) 172799L);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for DateTimeField[secondOfMinute] must be in the range [1,172799]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for DateTimeField[secondOfMinute] must be in the range [1,172799]"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        boolean boolean31 = unsupportedDateTimeField28.isLenient();
        boolean boolean32 = unsupportedDateTimeField28.isLenient();
        java.util.Locale locale33 = null;
        try {
            int int34 = unsupportedDateTimeField28.getMaximumTextLength(locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        int int5 = mutableDateTime3.getMinuteOfHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 28800006L);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) buddhistChronology6);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 3, (org.joda.time.Chronology) buddhistChronology6, locale12, (java.lang.Integer) 2, (int) (byte) -1);
//        org.joda.time.Chronology chronology16 = dateTimeParserBucket15.getChronology();
//        java.lang.Object obj17 = dateTimeParserBucket15.saveState();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(obj17);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.set((int) (byte) 0);
//        java.lang.Object obj7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, dateTimeZone8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        int int11 = mutableDateTime9.getMinuteOfHour();
//        mutableDateTime9.setMillis((long) '4');
//        mutableDateTime9.setSecondOfDay(10);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime9.add(readableDuration16);
//        int int18 = mutableDateTime9.getMonthOfYear();
//        int int19 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        java.lang.Object obj21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime(obj21, dateTimeZone22);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime23);
//        org.joda.time.Chronology chronology25 = gJChronology24.withUTC();
//        org.joda.time.Chronology chronology26 = gJChronology24.withUTC();
//        mutableDateTime9.setChronology((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.DurationField durationField28 = gJChronology24.hours();
//        org.joda.time.DurationField durationField29 = gJChronology24.halfdays();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology24.hourOfHalfday();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = gJChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusHours((int) (byte) -1);
        int int10 = dateTime5.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(1969, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendYearOfCentury((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendHourOfHalfday(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendFractionOfMinute((int) (byte) -1, 1999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField28.toString();
        boolean boolean32 = unsupportedDateTimeField28.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = gJChronology5.equals(obj6);
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) gJChronology5, locale8, (java.lang.Integer) (-1));
//        dateTimeParserBucket10.setOffset((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
//        java.lang.String str20 = dateTimeZone18.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        java.lang.Object obj22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj22, dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime24);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
//        java.lang.String str28 = dateTimeZone26.getName((long) (byte) 0);
//        long long30 = dateTimeZone18.getMillisKeepLocal(dateTimeZone26, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
//        java.lang.Object obj33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(obj33, dateTimeZone34);
//        int int36 = mutableDateTime35.getMonthOfYear();
//        int int37 = mutableDateTime35.getMinuteOfHour();
//        mutableDateTime35.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime35.hourOfDay();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime35.centuryOfEra();
//        boolean boolean42 = gregorianChronology32.equals((java.lang.Object) mutableDateTime35);
//        boolean boolean43 = dateTimeParserBucket10.restoreState((java.lang.Object) mutableDateTime35);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime35.secondOfDay();
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(property44);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long13 = buddhistChronology9.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField14, 0);
        long long18 = skipUndoDateTimeField16.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatterBuilder19.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long27 = buddhistChronology23.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology23.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology22, dateTimeField28, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipUndoDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType31);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        boolean boolean36 = dateTimeFormatter35.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder7.appendOptional(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1097L + "'", long13 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1000L + "'", long18 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1097L + "'", long27 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        long long50 = remainderDateTimeField46.remainder(1560340856305L);
        int int51 = remainderDateTimeField46.getDivisor();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 14040056305L + "'", long50 == 14040056305L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        int int7 = property6.get();
        java.lang.String str8 = property6.getName();
        java.util.Locale locale10 = null;
        org.joda.time.DateTime dateTime11 = property6.setCopy("39", locale10);
        org.joda.time.DateTime dateTime12 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.hourOfDay();
        org.joda.time.DurationField durationField10 = buddhistChronology6.months();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology6.clockhourOfDay();
        org.joda.time.Chronology chronology12 = buddhistChronology6.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        long long28 = zeroIsMaxDateTimeField25.addWrapField((long) 6, 2000);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = zeroIsMaxDateTimeField25.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 20006L + "'", long28 == 20006L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfSecond(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long25 = buddhistChronology21.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology21.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology20, dateTimeField26, 0);
        long long30 = skipUndoDateTimeField28.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatterBuilder31.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long39 = buddhistChronology35.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology35.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology34, dateTimeField40, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField42.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder31.appendShortText(dateTimeFieldType43);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType43, 10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 97, (java.lang.Number) 57600097L, (java.lang.Number) 21937366);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1097L + "'", long25 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1000L + "'", long30 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1097L + "'", long39 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusHours((int) (byte) -1);
        org.joda.time.Instant instant10 = dateTime5.toInstant();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 59, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusHours((int) (byte) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.year();
        org.joda.time.DateTime dateTime11 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withSecondOfMinute(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600000, 'a', 12, 0, 0, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset((int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder8.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(438825600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 438825600000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendDayOfYear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendYearOfEra(3, (int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendSecondOfMinute((-2922686));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        int int9 = skipUndoDateTimeField8.getMinimumValue();
        boolean boolean10 = skipUndoDateTimeField8.isSupported();
        java.lang.String str11 = skipUndoDateTimeField8.getName();
        int int12 = skipUndoDateTimeField8.getMinimumValue();
        long long15 = skipUndoDateTimeField8.add(10L, 4);
        int int17 = skipUndoDateTimeField8.getLeapAmount(1560340856305L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long23 = buddhistChronology19.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology19.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField24, 0);
        long long28 = skipUndoDateTimeField26.roundCeiling((long) 4);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField26.getAsText((int) (byte) -1, locale30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime45 = dateTime43.plusMillis((int) (byte) 0);
        int int46 = dateTime43.getEra();
        org.joda.time.YearMonthDay yearMonthDay47 = dateTime43.toYearMonthDay();
        java.lang.String str48 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) yearMonthDay47);
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipUndoDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay47, 39, locale50);
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay47, (int) (byte) 100, locale53);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "secondOfMinute" + "'", str11.equals("secondOfMinute"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4010L + "'", long15 == 4010L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1097L + "'", long23 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1000L + "'", long28 == 1000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0010-06" + "'", str48.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "39" + "'", str51.equals("39"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "100" + "'", str54.equals("100"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 2000);
        long long10 = offsetDateTimeField8.roundHalfFloor(100L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = buddhistChronology0.add(readablePeriod13, (long) (byte) 0, 12);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone18 = buddhistChronology0.getZone();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        long long35 = unsupportedDateTimeField28.getDifferenceAsLong((long) (short) 1, (long) (-28800000));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800001L + "'", long35 == 28800001L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipUndoDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long25 = buddhistChronology21.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology21.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology20, dateTimeField26, 0);
        long long30 = skipUndoDateTimeField28.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatterBuilder31.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long39 = buddhistChronology35.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology35.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology34, dateTimeField40, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField42.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder31.appendShortText(dateTimeFieldType43);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType43, 10, 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField50 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType43);
        int int52 = zeroIsMaxDateTimeField50.getLeapAmount(59400L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1097L + "'", long25 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1000L + "'", long30 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1097L + "'", long39 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.secondOfDay();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((-61838640421948L), (org.joda.time.Chronology) buddhistChronology1, locale5, (java.lang.Integer) 0);
        java.lang.Integer int8 = dateTimeParserBucket7.getPivotYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8.equals(0));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField28.getDurationField();
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField28.getAsText(0, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundHalfEven(172886399997L);
        long long50 = remainderDateTimeField46.roundHalfEven(0L);
        long long52 = remainderDateTimeField46.remainder(1L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 157766400000L + "'", long48 == 157766400000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 1);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
        try {
            org.joda.time.DateTime dateTime28 = dateTime24.withDate(1, (-292275054), 38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime2.toMutableDateTimeISO();
//        int int9 = mutableDateTime8.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.millisOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
//        java.lang.String str20 = dateTimeZone18.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        java.lang.Object obj22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj22, dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime24);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
//        java.lang.String str28 = dateTimeZone26.getName((long) (byte) 0);
//        long long30 = dateTimeZone18.getMillisKeepLocal(dateTimeZone26, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.Chronology chronology32 = iSOChronology12.withZone(dateTimeZone18);
//        org.joda.time.Chronology chronology33 = buddhistChronology10.withZone(dateTimeZone18);
//        mutableDateTime8.setZoneRetainFields(dateTimeZone18);
//        int int35 = mutableDateTime8.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 600 + "'", int35 == 600);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.DurationField durationField6 = property4.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNull(durationField6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) 1);
        int int11 = dateTime10.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) (byte) -1);
        java.lang.String str11 = skipUndoDateTimeField8.toString();
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField8.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str11.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime1.plusSeconds(1);
        int int11 = dateTime1.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 1);
        boolean boolean25 = gregorianChronology23.equals((java.lang.Object) 175799L);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology23.getZone();
        int int27 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.withEra(0);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime9 = dateTime2.minusSeconds((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12/31/69" + "'", str12.equals("12/31/69"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime1.plusSeconds(1);
        org.joda.time.DateTime.Property property11 = dateTime1.minuteOfHour();
        org.joda.time.DateTime.Property property12 = dateTime1.monthOfYear();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1970);
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("16");
        mutableDateTime1.setHourOfDay(1);
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.toMutableDateTime();
        org.joda.time.Instant instant5 = mutableDateTime4.toInstant();
        org.joda.time.MutableDateTime mutableDateTime6 = instant5.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundCeiling();
//        int int9 = property7.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundCeiling();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withEra(1);
//        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfWeek((int) (byte) 1);
//        boolean boolean19 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime10.addMinutes(0);
//        try {
//            mutableDateTime10.setMillisOfSecond(1999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1999 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        try {
            long long31 = unsupportedDateTimeField28.roundFloor((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property4.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime10 = property4.addToCopy((-61838467622000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -61838467622000 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(28800000L, dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(4, 0, 50, 0, (int) (short) -1, 99, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 1);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        java.lang.Object obj25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj25, dateTimeZone26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
        java.lang.String str31 = dateTimeZone29.getName((long) (byte) 0);
        boolean boolean32 = gregorianChronology23.equals((java.lang.Object) dateTimeZone29);
        org.joda.time.DurationField durationField33 = gregorianChronology23.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis((int) (byte) 0);
        int int11 = dateTime8.getEra();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime8.withDurationAdded(readableDuration12, 1969);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.DateTime dateTime17 = dateTime8.withFieldAdded(durationFieldType15, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test186");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.joda.time.DurationField durationField9 = property7.getRangeDurationField();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.getMutableDateTime();
//        long long11 = property7.remainder();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(20070, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20070 + "'", int2 == 20070);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        try {
            long long33 = unsupportedDateTimeField28.set(0L, 1999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 39);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, dateTimeZone5);
        mutableDateTime7.setMillisOfDay(2000);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property10.roundCeiling();
        int int12 = mutableDateTime11.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        java.lang.String str30 = unsupportedDateTimeField28.toString();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long38 = buddhistChronology34.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology48);
        org.joda.time.DateTime dateTime52 = dateTime50.plusMillis((int) (byte) 0);
        int int53 = dateTime50.getEra();
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime50.toYearMonthDay();
        java.lang.String str55 = dateTimeFormatter39.print((org.joda.time.ReadablePartial) yearMonthDay54);
        int[] intArray57 = buddhistChronology34.get((org.joda.time.ReadablePartial) yearMonthDay54, 28800006L);
        try {
            int[] intArray59 = unsupportedDateTimeField28.addWrapField((org.joda.time.ReadablePartial) timeOfDay32, 57600000, intArray57, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1097L + "'", long38 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0010-06" + "'", str55.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        java.lang.Object obj9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone18);
        mutableDateTime19.addWeekyears(1962);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 2000);
        long long10 = offsetDateTimeField8.roundHalfFloor(100L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType13);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        boolean boolean31 = unsupportedDateTimeField28.isLenient();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
        try {
            int int34 = unsupportedDateTimeField28.getMinimumValue((long) 50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
        long long67 = skipUndoDateTimeField65.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder68.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long76 = buddhistChronology72.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology72.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology71, dateTimeField77, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendShortText(dateTimeFieldType80);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField82 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField65, dateTimeFieldType80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType80);
        java.util.Locale locale86 = null;
        java.lang.String str87 = remainderDateTimeField46.getAsShortText((int) (short) -1, locale86);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1000L + "'", long67 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(buddhistChronology71);
        org.junit.Assert.assertNotNull(buddhistChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1097L + "'", long76 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "-1" + "'", str87.equals("-1"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.DateTime dateTime9 = property6.addToCopy(6);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test196");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        java.lang.String str8 = property7.getAsString();
//        org.joda.time.MutableDateTime mutableDateTime9 = property7.roundFloor();
//        mutableDateTime9.addWeekyears((-1969));
//        mutableDateTime9.setDate((long) 3);
//        int int14 = mutableDateTime9.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 2000);
        long long10 = offsetDateTimeField8.roundHalfFloor(100L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = buddhistChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 2000);
        long long19 = offsetDateTimeField17.roundHalfFloor(100L);
        boolean boolean20 = offsetDateTimeField17.isSupported();
        long long22 = offsetDateTimeField17.remainder((long) 6);
        java.lang.String str23 = offsetDateTimeField17.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long29 = buddhistChronology25.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology25.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology24, dateTimeField30, 0);
        long long34 = skipUndoDateTimeField32.roundCeiling((long) 4);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField32.getAsText((int) (byte) -1, locale36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology47);
        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 0);
        int int52 = dateTime49.getEra();
        org.joda.time.YearMonthDay yearMonthDay53 = dateTime49.toYearMonthDay();
        java.lang.String str54 = dateTimeFormatter38.print((org.joda.time.ReadablePartial) yearMonthDay53);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipUndoDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay53, 39, locale56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay53, 3, locale59);
        int int61 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay53);
        int int63 = skipUndoDateTimeField12.get((long) 20);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 6L + "'", long22 == 6L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "dayOfMonth" + "'", str23.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1097L + "'", long29 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1000L + "'", long34 == 1000L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-1" + "'", str37.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(buddhistChronology47);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0010-06" + "'", str54.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "39" + "'", str57.equals("39"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "3" + "'", str60.equals("3"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2001 + "'", int61 == 2001);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2001 + "'", int63 == 2001);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test198");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long9 = buddhistChronology5.add((long) 'a', 100L, (int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(1969, (int) (short) 10, 2, (int) (byte) 10, (int) (short) 10, (org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime13.withEra(0);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(readableDuration18);
//        org.joda.time.DateTime.Property property20 = dateTime19.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime21.toTimeOfDay();
//        int int23 = property20.compareTo((org.joda.time.ReadablePartial) timeOfDay22);
//        int[] intArray25 = buddhistChronology5.get((org.joda.time.ReadablePartial) timeOfDay22, 0L);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1097L + "'", long9 == 1097L);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        int int6 = mutableDateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        java.lang.Object obj8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(obj8, dateTimeZone9);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        java.lang.String str14 = dateTimeZone12.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(obj16, dateTimeZone17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
//        java.lang.String str22 = dateTimeZone20.getName((long) (byte) 0);
//        long long24 = dateTimeZone12.getMillisKeepLocal(dateTimeZone20, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone12);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.withZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime30.withEra(0);
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withMillisOfSecond((int) (byte) 100);
//        org.joda.time.DateTime dateTime40 = dateTime36.withMillisOfSecond((int) '#');
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZone(dateTimeZone43);
//        org.joda.time.DateTime dateTime46 = dateTime42.withEra(0);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.withFields(readablePartial47);
//        java.lang.Object obj49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime(obj49, dateTimeZone50);
//        int int52 = mutableDateTime51.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        java.lang.Object obj54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime(obj54, dateTimeZone55);
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, (org.joda.time.ReadableInstant) mutableDateTime56);
//        org.joda.time.DateTimeZone dateTimeZone58 = gJChronology57.getZone();
//        java.lang.String str60 = dateTimeZone58.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        java.lang.Object obj62 = null;
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime(obj62, dateTimeZone63);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, (org.joda.time.ReadableInstant) mutableDateTime64);
//        org.joda.time.DateTimeZone dateTimeZone66 = gJChronology65.getZone();
//        java.lang.String str68 = dateTimeZone66.getName((long) (byte) 0);
//        long long70 = dateTimeZone58.getMillisKeepLocal(dateTimeZone66, (long) (byte) 100);
//        mutableDateTime51.setZone(dateTimeZone66);
//        org.joda.time.DateTime dateTime72 = dateTime48.withZoneRetainFields(dateTimeZone66);
//        long long76 = dateTimeZone66.convertLocalToUTC((-61838467621999L), true, (long) 59);
//        org.joda.time.DateTime dateTime77 = dateTime36.withZone(dateTimeZone66);
//        java.lang.String str79 = dateTimeZone66.getShortName(1560398409961L);
//        org.joda.time.DateTime dateTime80 = dateTime27.toDateTime(dateTimeZone66);
//        org.joda.time.DateTime dateTime82 = dateTime80.withWeekyear(20070);
//        org.joda.time.DateTime dateTime84 = dateTime82.withWeekyear(7);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00" + "'", str60.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "+00:00" + "'", str68.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-61838467621999L) + "'", long76 == (-61838467621999L));
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "+00:00" + "'", str79.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(dateTime84);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneOffset("16", "100", true, 16, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        long long32 = unsupportedDateTimeField28.add(0L, 42);
        long long35 = unsupportedDateTimeField28.getDifferenceAsLong((long) (short) 1, (long) (-28800000));
        boolean boolean36 = unsupportedDateTimeField28.isSupported();
        try {
            int int38 = unsupportedDateTimeField28.getMaximumValue((long) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 42L + "'", long32 == 42L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800001L + "'", long35 == 28800001L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("100");
        int int2 = mutableDateTime1.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        int int6 = offsetDateTimeField4.getLeapAmount(100L);
        long long8 = offsetDateTimeField4.roundHalfEven(6L);
        java.lang.String str10 = offsetDateTimeField4.getAsShortText((long) (-1));
        int int12 = offsetDateTimeField4.getLeapAmount(172799L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = buddhistChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 2000);
        long long20 = offsetDateTimeField18.roundHalfFloor(100L);
        boolean boolean21 = offsetDateTimeField18.isSupported();
        long long23 = offsetDateTimeField18.remainder((long) 6);
        java.lang.String str24 = offsetDateTimeField18.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long30 = buddhistChronology26.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology26.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology25, dateTimeField31, 0);
        long long35 = skipUndoDateTimeField33.roundCeiling((long) 4);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField33.getAsText((int) (byte) -1, locale37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology48);
        org.joda.time.DateTime dateTime52 = dateTime50.plusMillis((int) (byte) 0);
        int int53 = dateTime50.getEra();
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime50.toYearMonthDay();
        java.lang.String str55 = dateTimeFormatter39.print((org.joda.time.ReadablePartial) yearMonthDay54);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipUndoDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay54, 39, locale57);
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay54, 3, locale60);
        int[] intArray63 = buddhistChronology13.get((org.joda.time.ReadablePartial) yearMonthDay54, (long) '#');
        org.joda.time.chrono.BuddhistChronology buddhistChronology65 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long69 = buddhistChronology65.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter70.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology79 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime80 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology79);
        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology79);
        org.joda.time.DateTime dateTime83 = dateTime81.plusMillis((int) (byte) 0);
        int int84 = dateTime81.getEra();
        org.joda.time.YearMonthDay yearMonthDay85 = dateTime81.toYearMonthDay();
        java.lang.String str86 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) yearMonthDay85);
        int[] intArray88 = buddhistChronology65.get((org.joda.time.ReadablePartial) yearMonthDay85, 28800006L);
        try {
            int[] intArray90 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) yearMonthDay54, 50, intArray88, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2031" + "'", str10.equals("2031"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 6L + "'", long23 == 6L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfMonth" + "'", str24.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1097L + "'", long30 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1000L + "'", long35 == 1000L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-1" + "'", str38.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0010-06" + "'", str55.equals("0010-06"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "39" + "'", str58.equals("39"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "3" + "'", str61.equals("3"));
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(buddhistChronology65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1097L + "'", long69 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(buddhistChronology79);
        org.junit.Assert.assertNotNull(mutableDateTime80);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "0010-06" + "'", str86.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray88);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        java.lang.String str8 = dateTimeZone6.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getName((long) (byte) 0);
        long long18 = dateTimeZone6.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 1);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(julianChronology24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DurationField durationField2 = iSOChronology0.weeks();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
        java.lang.String str7 = offsetDateTimeField4.toString();
        long long10 = offsetDateTimeField4.add((-61662294000000L), (long) 2031);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str7.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61486815600000L) + "'", long10 == (-61486815600000L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 39);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, dateTimeZone5);
        mutableDateTime7.setMillisOfDay(2000);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.hourOfDay();
        boolean boolean11 = mutableDateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long5 = julianChronology0.getDateTimeMillis(365, (int) (byte) 100, 2031, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-1969));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        java.lang.Object obj9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        java.lang.Object obj25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj25, dateTimeZone26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
        java.lang.String str31 = dateTimeZone29.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        java.lang.Object obj33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(obj33, dateTimeZone34);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime35);
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology36.getZone();
        java.lang.String str39 = dateTimeZone37.getName((long) (byte) 0);
        long long41 = dateTimeZone29.getMillisKeepLocal(dateTimeZone37, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
        org.joda.time.Chronology chronology43 = iSOChronology23.withZone(dateTimeZone29);
        java.util.Locale locale45 = null;
        java.lang.String str46 = dateTimeZone29.getShortName(10L, locale45);
        org.joda.time.Chronology chronology47 = iSOChronology22.withZone(dateTimeZone29);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology47);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test214");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(0L);
//        org.joda.time.MutableDateTime mutableDateTime11 = property7.roundHalfFloor();
//        java.util.Locale locale12 = null;
//        int int13 = property7.getMaximumTextLength(locale12);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long20 = buddhistChronology16.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology16.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, 0);
        long long25 = skipUndoDateTimeField23.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long34 = buddhistChronology30.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology30.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField35, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType38, 10, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType38, (int) (short) 100);
        long long48 = remainderDateTimeField46.roundCeiling((long) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long62 = buddhistChronology58.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology58.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology57, dateTimeField63, 0);
        long long67 = skipUndoDateTimeField65.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder68.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long76 = buddhistChronology72.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology72.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology71, dateTimeField77, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendShortText(dateTimeFieldType80);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField82 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField65, dateTimeFieldType80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType80);
        long long87 = dividedDateTimeField84.addWrapField((-61838467521999L), 7);
        int int89 = dividedDateTimeField84.get(115199999L);
        long long92 = dividedDateTimeField84.set(39969L, 1999);
        int int94 = dividedDateTimeField84.get((long) 57600000);
        org.joda.time.DurationField durationField95 = dividedDateTimeField84.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1097L + "'", long20 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1000L + "'", long25 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1097L + "'", long34 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31536000000L + "'", long48 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1097L + "'", long62 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1000L + "'", long67 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(buddhistChronology71);
        org.junit.Assert.assertNotNull(buddhistChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1097L + "'", long76 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-39748147521999L) + "'", long87 == (-39748147521999L));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 25 + "'", int89 == 25);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 6229342368039969L + "'", long92 == 6229342368039969L);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 25 + "'", int94 == 25);
        org.junit.Assert.assertNull(durationField95);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendCenturyOfEra(4, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday(99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHourOfHalfday(10);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatterBuilder9.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        boolean boolean15 = dateTimeFormatter14.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.append(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis(25, 6, 25, 6, 69, 57600000, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime4);
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology5.equals(obj6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) gJChronology5, locale8, (java.lang.Integer) (-1));
        int int11 = dateTimeParserBucket10.getOffset();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime13.withEra(0);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.minus(readableDuration18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime22 = dateTime19.plusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property23 = dateTime19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        java.util.Locale locale26 = null;
        dateTimeParserBucket10.saveField(dateTimeFieldType24, "Pacific Daylight Time", locale26);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = buddhistChronology29.seconds();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 2000);
        long long35 = offsetDateTimeField33.roundHalfFloor((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, (org.joda.time.DateTimeField) offsetDateTimeField33);
        dateTimeParserBucket10.saveField((org.joda.time.DateTimeField) offsetDateTimeField33, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = buddhistChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 2000);
        long long13 = offsetDateTimeField11.roundHalfFloor((long) (short) 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        long long24 = skipUndoDateTimeField22.roundHalfEven((long) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology34);
        org.joda.time.DateTime dateTime38 = dateTime36.plusMillis((int) (byte) 0);
        int int39 = dateTime36.getEra();
        org.joda.time.YearMonthDay yearMonthDay40 = dateTime36.toYearMonthDay();
        java.lang.String str41 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) yearMonthDay40);
        int[] intArray43 = new int[] { (short) 0 };
        int int44 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay40, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay40, locale45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay40, locale47);
        long long50 = offsetDateTimeField4.roundCeiling((long) 2001);
        long long53 = offsetDateTimeField4.set(0L, "2002");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0010-06" + "'", str41.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 86400000L + "'", long53 == 86400000L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField28.toString();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime37 = dateTime33.withEra(0);
        org.joda.time.DateTime.Property property38 = dateTime33.yearOfEra();
        org.joda.time.YearMonthDay yearMonthDay39 = dateTime33.toYearMonthDay();
        try {
            int int40 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(yearMonthDay39);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getLeapDurationField();
        try {
            long long34 = unsupportedDateTimeField28.roundHalfCeiling((long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(0);
        int int12 = dateTime11.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours(38);
        org.joda.time.DateTime dateTime16 = dateTime14.minusYears((-1));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test225");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfMonth();
//        int int5 = property4.getMinimumValueOverall();
//        java.lang.Object obj6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj6, dateTimeZone7);
//        int int9 = mutableDateTime8.getMonthOfYear();
//        mutableDateTime8.setTime((long) (byte) 100);
//        int int12 = mutableDateTime8.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
//        java.lang.String str20 = dateTimeZone18.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        java.lang.Object obj22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj22, dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime24);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
//        java.lang.String str28 = dateTimeZone26.getName((long) (byte) 0);
//        long long30 = dateTimeZone18.getMillisKeepLocal(dateTimeZone26, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone18);
//        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.withZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime40 = dateTime36.withEra(0);
//        org.joda.time.ReadableDuration readableDuration41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readableDuration41);
//        org.joda.time.DateTime dateTime44 = dateTime42.withMillisOfSecond((int) (byte) 100);
//        org.joda.time.DateTime dateTime46 = dateTime42.withMillisOfSecond((int) '#');
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.withZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime52 = dateTime48.withEra(0);
//        org.joda.time.ReadablePartial readablePartial53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.withFields(readablePartial53);
//        java.lang.Object obj55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime(obj55, dateTimeZone56);
//        int int58 = mutableDateTime57.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        java.lang.Object obj60 = null;
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime(obj60, dateTimeZone61);
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone59, (org.joda.time.ReadableInstant) mutableDateTime62);
//        org.joda.time.DateTimeZone dateTimeZone64 = gJChronology63.getZone();
//        java.lang.String str66 = dateTimeZone64.getName((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        java.lang.Object obj68 = null;
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime(obj68, dateTimeZone69);
//        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone67, (org.joda.time.ReadableInstant) mutableDateTime70);
//        org.joda.time.DateTimeZone dateTimeZone72 = gJChronology71.getZone();
//        java.lang.String str74 = dateTimeZone72.getName((long) (byte) 0);
//        long long76 = dateTimeZone64.getMillisKeepLocal(dateTimeZone72, (long) (byte) 100);
//        mutableDateTime57.setZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime78 = dateTime54.withZoneRetainFields(dateTimeZone72);
//        long long82 = dateTimeZone72.convertLocalToUTC((-61838467621999L), true, (long) 59);
//        org.joda.time.DateTime dateTime83 = dateTime42.withZone(dateTimeZone72);
//        java.lang.String str85 = dateTimeZone72.getShortName(1560398409961L);
//        org.joda.time.DateTime dateTime86 = dateTime33.toDateTime(dateTimeZone72);
//        int int87 = dateTime86.getYear();
//        int int88 = property4.compareTo((org.joda.time.ReadableInstant) dateTime86);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "+00:00" + "'", str66.equals("+00:00"));
//        org.junit.Assert.assertNotNull(gJChronology71);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "+00:00" + "'", str74.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 100L + "'", long76 == 100L);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-61838467621999L) + "'", long82 == (-61838467621999L));
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "+00:00" + "'", str85.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTime86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1970 + "'", int87 == 1970);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(5, 25, (int) (byte) 100, 0, 0, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.secondOfDay();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((-61838640421948L), (org.joda.time.Chronology) buddhistChronology1, locale5, (java.lang.Integer) 0);
        long long9 = dateTimeParserBucket7.computeMillis(false);
        int int10 = dateTimeParserBucket7.getOffset();
        dateTimeParserBucket7.setOffset(23);
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 53);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61838640421948L) + "'", long9 == (-61838640421948L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test228");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        int int4 = mutableDateTime2.getMinuteOfHour();
//        mutableDateTime2.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime2.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.parse("16");
//        mutableDateTime10.setHourOfDay(1);
//        boolean boolean13 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
//        mutableDateTime10.setMinuteOfDay(53);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getLeapDurationField();
        boolean boolean31 = unsupportedDateTimeField28.isLenient();
        boolean boolean32 = unsupportedDateTimeField28.isLenient();
        try {
            int int34 = unsupportedDateTimeField28.getLeapAmount((-2001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        java.lang.Object obj9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj9, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getName((long) (byte) 0);
        long long17 = dateTimeZone5.getMillisKeepLocal(dateTimeZone13, (long) (byte) 100);
        long long21 = dateTimeZone5.convertLocalToUTC((long) 6, true, (long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        mutableDateTime22.add((long) 'a');
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        long long6 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        long long9 = offsetDateTimeField4.add(400L, 69);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField4.getMaximumShortTextLength(locale10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5961600400L + "'", long9 == 5961600400L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test232");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 0);
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        int int6 = mutableDateTime4.getMinuteOfHour();
//        mutableDateTime4.setMillis((long) '4');
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundHalfEven();
//        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
//        long long14 = property12.remainder();
//        try {
//            org.joda.time.DateTime dateTime16 = property12.setCopy("UnsupportedDateTimeField");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UnsupportedDateTimeField\" for yearOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getLeapDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long32 = buddhistChronology28.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology28.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology27, dateTimeField33, 0);
        long long37 = skipUndoDateTimeField35.roundHalfEven((long) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology47);
        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 0);
        int int52 = dateTime49.getEra();
        org.joda.time.YearMonthDay yearMonthDay53 = dateTime49.toYearMonthDay();
        java.lang.String str54 = dateTimeFormatter38.print((org.joda.time.ReadablePartial) yearMonthDay53);
        int[] intArray56 = new int[] { (short) 0 };
        int int57 = skipUndoDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay53, intArray56);
        int[] intArray58 = new int[] {};
        int int59 = zeroIsMaxDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay53, intArray58);
        boolean boolean60 = zeroIsMaxDateTimeField25.isSupported();
        int int62 = zeroIsMaxDateTimeField25.getLeapAmount(42L);
        java.util.Locale locale64 = null;
        java.lang.String str65 = zeroIsMaxDateTimeField25.getAsShortText((long) (-28378000), locale64);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1097L + "'", long32 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(buddhistChronology47);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0010-06" + "'", str54.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2" + "'", str65.equals("2"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        boolean boolean4 = mutableDateTime2.equals((java.lang.Object) '#');
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        mutableDateTime2.add(readablePeriod5, (-1));
        int int8 = mutableDateTime2.getEra();
        java.lang.String str10 = mutableDateTime2.toString("365");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "365" + "'", str10.equals("365"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        mutableDateTime1.add(readableDuration2, (int) (byte) 100);
        boolean boolean6 = mutableDateTime1.isAfter((long) ' ');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime1.add(readablePeriod7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(57600097);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime10.toYearMonthDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra(2);
        org.joda.time.Instant instant14 = dateTime13.toInstant();
        java.util.GregorianCalendar gregorianCalendar15 = dateTime13.toGregorianCalendar();
        try {
            org.joda.time.DateTime dateTime19 = dateTime13.withDate(600, 31, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long19 = buddhistChronology15.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology15.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType23);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        try {
            long long30 = unsupportedDateTimeField28.roundFloor((-2001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1097L + "'", long19 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(400L);
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long8 = buddhistChronology4.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime10.withEra(0);
        org.joda.time.DateTime.Property property15 = dateTime10.yearOfEra();
        boolean boolean16 = buddhistChronology4.equals((java.lang.Object) dateTime10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long22 = buddhistChronology18.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology18.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField23, 0);
        long long27 = skipUndoDateTimeField25.roundCeiling((long) 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatterBuilder28.toFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long36 = buddhistChronology32.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField37, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField39.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder28.appendShortText(dateTimeFieldType40);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField42 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, dateTimeFieldType40);
        java.lang.Number number45 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 100.0d, (java.lang.Number) 1L, number45);
        org.joda.time.DateTime.Property property47 = dateTime10.property(dateTimeFieldType40);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = dateTime49.withZone(dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime49.withEra(0);
        org.joda.time.DateTime.Property property54 = dateTime49.yearOfEra();
        org.joda.time.DateTime dateTime56 = dateTime49.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime58 = dateTime49.plusSeconds(1);
        org.joda.time.DateTime.Property property59 = dateTime49.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.DateTime.Property property61 = dateTime10.property(dateTimeFieldType60);
        org.joda.time.DateTime dateTime63 = dateTime2.withField(dateTimeFieldType60, 38);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1097L + "'", long8 == 1097L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1097L + "'", long22 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1000L + "'", long27 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1097L + "'", long36 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime63);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 2000);
        long long6 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        long long8 = offsetDateTimeField4.roundCeiling(42L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("16");
        mutableDateTime1.setHourOfDay(1);
        mutableDateTime1.setDayOfYear(1);
        mutableDateTime1.addYears((int) (byte) 10);
        java.util.Date date8 = mutableDateTime1.toDate();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long5 = buddhistChronology1.add((long) 'a', 100L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withPivotYear((java.lang.Integer) 39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((int) (byte) 10, 6, (int) (short) 1, (int) (short) 1, (int) (byte) 1, (int) (short) 1, (org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.DateTime dateTime24 = dateTime22.plusMillis((int) (byte) 0);
        int int25 = dateTime22.getEra();
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        java.lang.String str27 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) yearMonthDay26);
        int[] intArray29 = new int[] { (short) 0 };
        int int30 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay26, intArray29);
        int int32 = skipUndoDateTimeField8.getMaximumValue((-1L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1097L + "'", long5 == 1097L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0010-06" + "'", str27.equals("0010-06"));
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 59 + "'", int32 == 59);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test244");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.setTime((long) (byte) 100);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundFloor();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime5.minusHours(10);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime5.minus(readablePeriod10);
        java.lang.Object obj12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(obj12, dateTimeZone13);
        int int15 = mutableDateTime14.getRoundingMode();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        java.lang.Object obj17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(obj17, dateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology20.getZone();
        java.lang.String str23 = dateTimeZone21.getName((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        java.lang.Object obj25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj25, dateTimeZone26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
        java.lang.String str31 = dateTimeZone29.getName((long) (byte) 0);
        long long33 = dateTimeZone21.getMillisKeepLocal(dateTimeZone29, (long) (byte) 100);
        mutableDateTime14.setZone(dateTimeZone29);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime(dateTimeZone29);
        boolean boolean38 = dateTimeZone29.isStandardOffset(864000010L);
        java.lang.String str39 = dateTimeZone29.getID();
        org.joda.time.DateTime dateTime40 = dateTime11.withZoneRetainFields(dateTimeZone29);
        java.lang.String str41 = dateTimeZone29.getID();
        java.lang.String str42 = dateTimeZone29.getID();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "-28378000" + "'", str39.equals("-28378000"));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-28378000" + "'", str41.equals("-28378000"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-28378000" + "'", str42.equals("-28378000"));
    }
}

