import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (byte) 100, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period4.withFieldAdded(durationFieldType5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        try {
            org.joda.time.Period period7 = period5.minusMillis((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int[] intArray10 = gregorianChronology2.get(readablePartial8, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        long long6 = dateTimeZone3.convertLocalToUTC((long) (-1), false);
//        org.joda.time.PeriodType periodType7 = null;
//        try {
//            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) long6, periodType7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean7 = gregorianChronology4.equals((java.lang.Object) periodType6);
        try {
            org.joda.time.Period period8 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560628423938L + "'", long0 == 1560628423938L);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3L) + "'", long2 == (-3L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) ' ', (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 42 + "'", int3 == 42);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        try {
            org.joda.time.DurationFieldType durationFieldType11 = period5.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        java.lang.String str2 = periodType1.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WeeksNoWeeks" + "'", str2.equals("WeeksNoWeeks"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        try {
            org.joda.time.Period period7 = period5.withMonths((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        try {
            org.joda.time.Minutes minutes31 = period30.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 42, 520, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 42);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        try {
            long long14 = gregorianChronology4.getDateTimeMillis((int) '#', (int) 'a', (int) (short) 10, 42, (int) (byte) -1, 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        boolean boolean5 = periodType2.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Pacific Standard Time' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PeriodType[YearWeekDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        int int4 = period1.getYears();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology3.add(readablePeriod5, (long) (-1), 0);
        org.joda.time.DurationField durationField9 = gregorianChronology3.halfdays();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5044L + "'", long2 == 5044L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = gregorianChronology16.add(readablePeriod18, (long) (-1), 0);
        org.joda.time.DurationField durationField22 = gregorianChronology16.halfdays();
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) gregorianChronology2, (org.joda.time.Chronology) gregorianChronology16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusWeeks((int) (short) -1);
        try {
            org.joda.time.Hours hours12 = period9.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PeriodType[YearWeekDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 0, (long) 42);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Period period2 = new org.joda.time.Period((-3L), (long) (short) 100);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period7.plusMillis(520);
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        java.lang.String str11 = mutablePeriod10.toString();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.520S" + "'", str11.equals("PT0.520S"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
//        int int2 = periodType1.size();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        try {
//            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) dateTimeZone0, periodType1, (org.joda.time.Chronology) iSOChronology10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(10L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period22 = period15.withPeriodType(periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType21);
        int[] intArray24 = period23.getValues();
        try {
            gregorianChronology2.validate(readablePartial7, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusWeeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period9.toString(periodFormatter12);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P1YT0.032S" + "'", str13.equals("P1YT0.032S"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 10);
        org.joda.time.Period period3 = period1.withWeeks(0);
        int int4 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType9, 42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 520, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560628423938L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        try {
            long long12 = gregorianChronology2.getDateTimeMillis((int) (short) 1, 100, (int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType11 = periodType10.withMillisRemoved();
        java.lang.String str12 = periodType10.getName();
        try {
            org.joda.time.Period period13 = period5.withPeriodType(periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Seconds" + "'", str12.equals("Seconds"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 'a');
        int int2 = period1.getMillis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) (byte) 1, periodType2, (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        int int47 = period38.getYears();
        org.joda.time.Period period49 = period38.withMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(period49);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period7.plusMillis(520);
        org.joda.time.Duration duration10 = period7.toStandardDuration();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        boolean boolean22 = period4.equals((java.lang.Object) periodType18);
        org.joda.time.PeriodType periodType23 = null;
        try {
            org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) boolean22, periodType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology3.add(readablePeriod5, (long) (-1), 0);
        org.joda.time.DurationField durationField9 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology12.add(readablePeriod14, (long) (-1), 0);
        org.joda.time.DurationField durationField18 = gregorianChronology12.halfdays();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField9, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.Period period8 = new org.joda.time.Period(100, (int) 'a', (int) '4', (int) '#', (-1), 0, (int) (byte) 100, (int) 'a');
        org.joda.time.Period period10 = period8.minusMonths((int) (short) -1);
        int int11 = period10.getSeconds();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.plusMonths(0);
        org.joda.time.Period period8 = period6.plusYears(1);
        org.joda.time.Minutes minutes9 = period6.toStandardMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        try {
            long long13 = gregorianChronology2.getDateTimeMillis((-1L), (int) (short) 1, (int) (byte) 100, 97, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) -1, (int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 10, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone3.getName((long) '4', locale8);
//        org.joda.time.LocalDateTime localDateTime10 = null;
//        try {
//            boolean boolean11 = dateTimeZone3.isLocalDateTimeGap(localDateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) weeks20);
        try {
            org.joda.time.Days days22 = period9.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, (int) (short) 100, 42, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray8 = new int[] { 1, 0 };
        try {
            iSOChronology0.validate(readablePartial5, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(intArray8);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        java.lang.String str12 = dateTimeZone10.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.Chronology chronology18 = iSOChronology13.withZone(dateTimeZone17);
//        boolean boolean19 = gregorianChronology4.equals((java.lang.Object) dateTimeZone17);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        try {
            org.joda.time.Period period7 = period5.withMonths((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        java.util.TimeZone timeZone14 = dateTimeZone12.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        try {
            long long13 = gregorianChronology2.getDateTimeMillis((int) (byte) 1, (int) '4', 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 2440588L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) periodType1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) chronology10, periodType12);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((-100), (-1), 10, (int) '4', (int) (byte) 100, 0, 0, (-1), periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.PeriodType periodType47 = period38.getPeriodType();
        int int48 = period38.getMinutes();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        int int16 = fixedDateTimeZone4.getOffset(100L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 42 + "'", int16 == 42);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Days days13 = period12.toStandardDays();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(days13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.Period period6 = period3.minusDays((int) ' ');
        org.joda.time.Period period8 = period3.minusMonths(10);
        org.joda.time.Period period10 = period3.plusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[YearWeekDayTime]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[YearWeekDayTime]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        java.lang.String str3 = periodType1.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WeeksNoWeeks" + "'", str3.equals("WeeksNoWeeks"));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.Chronology chronology12 = iSOChronology7.withZone(dateTimeZone11);
//        org.joda.time.DurationField durationField13 = iSOChronology7.weeks();
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("+00:00:00.100", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "P1YT0.032S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology6.clockhourOfDay();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
//        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
//        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
//        org.joda.time.Minutes minutes31 = period28.toStandardMinutes();
//        org.joda.time.Period period33 = period28.minusSeconds(0);
//        int[] intArray35 = iSOChronology22.get((org.joda.time.ReadablePeriod) period33, (long) 'a');
//        try {
//            iSOChronology6.validate(readablePartial14, intArray35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(minutes31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 5044L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210430958400000L) + "'", long1 == (-210430958400000L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 0, 0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.Weeks weeks18 = period13.toStandardWeeks();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period20 = period13.withPeriodType(periodType19);
        try {
            org.joda.time.Period period21 = new org.joda.time.Period((int) (short) -1, 97, (int) (short) 0, 100, (int) (short) -1, (int) (byte) 1, (int) (short) 0, (int) (byte) 100, periodType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(weeks18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (-100), periodType3);
        try {
            org.joda.time.Period period7 = period5.minusMonths((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, (int) (byte) -1, (int) '4', (int) ' ', (int) '#', (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "WeeksNoWeeks");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        try {
//            long long22 = zonedChronology14.getDateTimeMillis((int) 'a', 10, (int) (short) 0, (int) (byte) 10, (int) (byte) -1, (int) (short) 1, 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        java.lang.String str5 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        try {
//            long long31 = iSOChronology6.getDateTimeMillis((long) '#', 0, (-100), 0, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        org.joda.time.Period period3 = period1.minusDays(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        try {
            long long10 = gregorianChronology2.getDateTimeMillis((int) (byte) -1, (-100), 97, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period7, (java.lang.Object) false);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) chronology12, periodType14);
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        org.joda.time.Period period33 = new org.joda.time.Period((long) ' ');
        int[] intArray35 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period33, (long) 0);
        org.joda.time.Period period37 = period33.withYears((int) (short) 1);
        org.joda.time.Weeks weeks38 = period33.toStandardWeeks();
        org.joda.time.Period period39 = period27.plus((org.joda.time.ReadablePeriod) weeks38);
        org.joda.time.Period period40 = period17.withFields((org.joda.time.ReadablePeriod) period27);
        org.joda.time.Period period42 = period17.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.Period period48 = new org.joda.time.Period((long) ' ');
        int[] intArray50 = gregorianChronology45.get((org.joda.time.ReadablePeriod) period48, (long) 0);
        org.joda.time.Period period52 = period48.withYears((int) (short) 1);
        org.joda.time.Weeks weeks53 = period48.toStandardWeeks();
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period55 = period48.withPeriodType(periodType54);
        org.joda.time.Period period56 = period42.minus((org.joda.time.ReadablePeriod) period48);
        int int57 = period48.getYears();
        org.joda.time.Weeks weeks58 = period48.toStandardWeeks();
        org.joda.time.Period period59 = new org.joda.time.Period((java.lang.Object) weeks58);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.Period period64 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology63);
        org.joda.time.Period period65 = period64.toPeriod();
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.ReadableDuration readableDuration67 = null;
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone68, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone71 = gregorianChronology70.getZone();
        org.joda.time.Period period73 = new org.joda.time.Period((long) ' ');
        int[] intArray75 = gregorianChronology70.get((org.joda.time.ReadablePeriod) period73, (long) 0);
        org.joda.time.Period period77 = period73.withYears((int) (short) 1);
        org.joda.time.Weeks weeks78 = period73.toStandardWeeks();
        org.joda.time.PeriodType periodType79 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period80 = period73.withPeriodType(periodType79);
        org.joda.time.Period period81 = new org.joda.time.Period(readableInstant66, readableDuration67, periodType79);
        org.joda.time.PeriodType periodType82 = org.joda.time.DateTimeUtils.getPeriodType(periodType79);
        boolean boolean83 = period65.equals((java.lang.Object) periodType79);
        org.joda.time.ReadableInstant readableInstant84 = null;
        org.joda.time.Duration duration85 = period65.toDurationTo(readableInstant84);
        org.joda.time.DateTimeZone dateTimeZone86 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology88 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone86, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone89 = gregorianChronology88.getZone();
        org.joda.time.PeriodType periodType90 = org.joda.time.PeriodType.minutes();
        boolean boolean91 = gregorianChronology88.equals((java.lang.Object) periodType90);
        org.joda.time.Period period92 = new org.joda.time.Period(readableInstant60, (org.joda.time.ReadableDuration) duration85, periodType90);
        org.joda.time.Period period93 = new org.joda.time.Period((java.lang.Object) weeks58, periodType90);
        org.joda.time.Period period94 = period7.withPeriodType(periodType90);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(weeks38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(weeks53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(weeks58);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(period77);
        org.junit.Assert.assertNotNull(weeks78);
        org.junit.Assert.assertNotNull(periodType79);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(periodType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(duration85);
        org.junit.Assert.assertNotNull(gregorianChronology88);
        org.junit.Assert.assertNotNull(dateTimeZone89);
        org.junit.Assert.assertNotNull(periodType90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(period94);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.plusMonths(0);
        org.joda.time.Period period8 = period6.plusYears(1);
        int int9 = period8.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        int[] intArray16 = period15.getValues();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology19);
        org.joda.time.Period period21 = period20.negated();
        org.joda.time.Period period23 = period20.plusMonths(0);
        org.joda.time.Period period24 = period15.minus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period23.plusDays(1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getShortName((long) (short) 1, locale21);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628447856L + "'", long1 == 1560628447856L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
//        long long23 = cachedDateTimeZone18.previousTransition(1560628423938L);
//        int int25 = cachedDateTimeZone18.getStandardOffset(1560628423938L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560628423938L + "'", long23 == 1560628423938L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0, (java.lang.Number) 9L, (java.lang.Number) 1560628423938L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) '#');
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.Period period21 = period4.withPeriodType(periodType18);
        org.joda.time.PeriodType periodType22 = periodType18.withWeeksRemoved();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560628423938L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560628423938");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Period period4 = new org.joda.time.Period((-1), (int) (short) -1, 0, (int) (byte) 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 1);
        org.joda.time.Period period3 = period1.withYears((int) '4');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable throwable4 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        try {
            long long12 = gregorianChronology2.getDateTimeMillis((int) (byte) -1, (-100), 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 10, (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Period period14 = period5.withMonths((-100));
        org.joda.time.Period period16 = period5.withDays(0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        int[] intArray16 = period15.getValues();
        org.joda.time.Period period18 = period15.minusYears((int) '4');
        int int19 = period18.getMinutes();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "P100WT0.520S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) weeks20);
        org.joda.time.Period period23 = period21.minusSeconds((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period21.toDurationTo(readableInstant24);
        try {
            org.joda.time.Duration duration26 = period21.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        try {
            org.joda.time.Period period7 = period5.withHours(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.dayOfWeek();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis((int) (byte) 10, (int) (byte) -1, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        try {
//            long long21 = zonedChronology14.getDateTimeMillis(0L, (int) '#', (int) (byte) 0, (int) (byte) 0, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.plusMonths(0);
        org.joda.time.Period period8 = period6.withSeconds(0);
        org.joda.time.Period period10 = period6.plusWeeks((int) (short) 10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-3191L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.499963067d + "'", double1 == 2440587.499963067d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        long long3 = dateTimeZone1.convertUTCToLocal((long) (short) -1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        int int5 = dateTimeZone1.getOffset(readableInstant4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2L) + "'", long3 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        illegalFieldValueException2.prependMessage("Coordinated Universal Time");
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        int int12 = fixedDateTimeZone4.getStandardOffset((long) 1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.yearOfEra();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        try {
//            long long12 = iSOChronology6.set(readablePartial10, (-42L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.Period period15 = period12.minusMonths(97);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-3191L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
//        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.dayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-4190400001L), (java.lang.Number) (-1L), (java.lang.Number) 28800032L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 110, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        long long8 = fixedDateTimeZone4.convertLocalToUTC(0L, true, 28800009L);
        long long10 = fixedDateTimeZone4.nextTransition((long) 97);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-42L) + "'", long8 == (-42L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.Period period1 = new org.joda.time.Period((-4190400001L));
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        int int27 = cachedDateTimeZone25.getOffset(28799999L);
//        org.joda.time.Chronology chronology28 = iSOChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        int int6 = fixedDateTimeZone4.getOffset((long) ' ');
        int int8 = fixedDateTimeZone4.getStandardOffset(1560628447856L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 42 + "'", int6 == 42);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        int int47 = period38.getYears();
        org.joda.time.Weeks weeks48 = period38.toStandardWeeks();
        org.joda.time.Period period49 = new org.joda.time.Period((java.lang.Object) weeks48);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology53);
        org.joda.time.Period period55 = period54.toPeriod();
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone58, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology60.getZone();
        org.joda.time.Period period63 = new org.joda.time.Period((long) ' ');
        int[] intArray65 = gregorianChronology60.get((org.joda.time.ReadablePeriod) period63, (long) 0);
        org.joda.time.Period period67 = period63.withYears((int) (short) 1);
        org.joda.time.Weeks weeks68 = period63.toStandardWeeks();
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period70 = period63.withPeriodType(periodType69);
        org.joda.time.Period period71 = new org.joda.time.Period(readableInstant56, readableDuration57, periodType69);
        org.joda.time.PeriodType periodType72 = org.joda.time.DateTimeUtils.getPeriodType(periodType69);
        boolean boolean73 = period55.equals((java.lang.Object) periodType69);
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.Duration duration75 = period55.toDurationTo(readableInstant74);
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone76, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone79 = gregorianChronology78.getZone();
        org.joda.time.PeriodType periodType80 = org.joda.time.PeriodType.minutes();
        boolean boolean81 = gregorianChronology78.equals((java.lang.Object) periodType80);
        org.joda.time.Period period82 = new org.joda.time.Period(readableInstant50, (org.joda.time.ReadableDuration) duration75, periodType80);
        org.joda.time.Period period83 = new org.joda.time.Period((java.lang.Object) weeks48, periodType80);
        try {
            org.joda.time.Period period85 = period83.minusHours(33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(weeks48);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(weeks68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(duration75);
        org.junit.Assert.assertNotNull(gregorianChronology78);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(periodType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
//        org.joda.time.DurationField durationField9 = iSOChronology6.centuries();
//        java.lang.String str10 = iSOChronology6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        boolean boolean22 = period4.equals((java.lang.Object) periodType18);
        org.joda.time.Period period24 = period4.withMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WeeksNoWeeks" + "'", str3.equals("WeeksNoWeeks"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported"));
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        try {
//            long long21 = zonedChronology14.getDateTimeMillis(97L, 0, (int) (byte) -1, 0, 97);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.DurationField durationField26 = iSOChronology6.halfdays();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
//        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.Period period16 = new org.joda.time.Period();
//        org.joda.time.Period period18 = period16.plusYears(1);
//        org.joda.time.Period period20 = period16.minusMonths(42);
//        org.joda.time.Period period21 = period15.minus((org.joda.time.ReadablePeriod) period16);
//        org.joda.time.Period period23 = period21.withDays((int) (short) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(period20);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(period23);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Period period8 = period5.plusMonths(0);
        org.joda.time.Period period10 = period8.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Period period21 = new org.joda.time.Period((long) ' ');
        int[] intArray23 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, (long) 0);
        org.joda.time.Minutes minutes24 = period21.toStandardMinutes();
        boolean boolean25 = fixedDateTimeZone15.equals((java.lang.Object) period21);
        org.joda.time.Period period27 = period21.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType29 = period21.getFieldType(1);
        int int30 = period8.indexOf(durationFieldType29);
        int int31 = period1.indexOf(durationFieldType29);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(minutes24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported", "PT0.520S");
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long13 = dateTimeZone3.convertLocalToUTC((long) 'a', false);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800097L + "'", long13 == 28800097L);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.Period period6 = period3.minusDays((int) ' ');
        org.joda.time.Period period8 = period3.plusSeconds((int) (short) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.DurationFieldType durationFieldType32 = null;
        boolean boolean33 = period30.isSupported(durationFieldType32);
        org.joda.time.Period period35 = period30.minusDays((int) (byte) 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(period35);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a');
//        int[] intArray29 = iSOChronology6.get((org.joda.time.ReadablePeriod) period27, (long) ' ');
//        org.joda.time.DurationField durationField30 = iSOChronology6.days();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertNotNull(durationField30);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Period period21 = new org.joda.time.Period((long) ' ');
        int[] intArray23 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, (long) 0);
        org.joda.time.Period period25 = period21.withYears((int) (short) 1);
        org.joda.time.Weeks weeks26 = period21.toStandardWeeks();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period28 = period21.withPeriodType(periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType27);
        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
        org.joda.time.PeriodType periodType31 = periodType30.withMinutesRemoved();
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) periodType30);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(weeks26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        boolean boolean6 = period3.equals((java.lang.Object) iSOChronology4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        int int8 = periodType7.size();
        org.joda.time.PeriodType periodType9 = periodType7.withWeeksRemoved();
        org.joda.time.Period period10 = period3.normalizedStandard(periodType9);
        int int11 = period10.getDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.dayOfWeek();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            long long12 = gregorianChronology2.set(readablePartial10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 2440587L, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.DurationFieldType durationFieldType32 = null;
        boolean boolean33 = period30.isSupported(durationFieldType32);
        org.joda.time.Period period35 = period30.minusMinutes((int) (byte) 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        java.lang.String str5 = lenientChronology4.toString();
//        org.joda.time.Chronology chronology6 = lenientChronology4.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str5.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period12.getFieldTypes();
        boolean boolean14 = periodType1.equals((java.lang.Object) durationFieldTypeArray13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology17);
        org.joda.time.Period period19 = period18.negated();
        org.joda.time.Period period21 = period18.plusMonths(0);
        org.joda.time.Period period23 = period21.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
        org.joda.time.Period period34 = new org.joda.time.Period((long) ' ');
        int[] intArray36 = gregorianChronology31.get((org.joda.time.ReadablePeriod) period34, (long) 0);
        org.joda.time.Minutes minutes37 = period34.toStandardMinutes();
        boolean boolean38 = fixedDateTimeZone28.equals((java.lang.Object) period34);
        org.joda.time.Period period40 = period34.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType42 = period34.getFieldType(1);
        int int43 = period21.indexOf(durationFieldType42);
        int int44 = periodType1.indexOf(durationFieldType42);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField46 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType42, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(minutes37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        int int15 = fixedDateTimeZone13.getOffset((long) ' ');
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.Chronology chronology19 = zonedChronology16.withZone(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology16.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 42 + "'", int15 == 42);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.dayOfWeek();
        try {
            long long17 = gregorianChronology2.getDateTimeMillis((int) (short) -1, (int) ' ', 33, 10, (int) (byte) -1, (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        int int2 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) '#');
        org.joda.time.Period period6 = period4.plusWeeks(10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.dayOfWeek();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField26, (int) (short) 1, 0, (int) (short) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        boolean boolean22 = period4.equals((java.lang.Object) periodType18);
        org.joda.time.PeriodType periodType23 = periodType18.withHoursRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 33, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period16 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DurationField durationField18 = iSOChronology15.seconds();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period5, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Period period21 = period19.plusMinutes((int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        boolean boolean3 = dateTimeZone1.isStandardOffset(10L);
        long long6 = dateTimeZone1.adjustOffset(0L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period22 = period15.withPeriodType(periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType21);
        java.lang.String str24 = periodType21.toString();
        try {
            org.joda.time.Period period25 = new org.joda.time.Period((int) (short) -1, (-1), (int) (byte) 100, 0, 0, (-100), 97, 1, periodType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PeriodType[YearWeekDayTime]" + "'", str24.equals("PeriodType[YearWeekDayTime]"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, (int) '#', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", (java.lang.Number) 110, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0d);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        java.lang.String str15 = zonedChronology14.toString();
//        try {
//            long long23 = zonedChronology14.getDateTimeMillis(110, (int) (byte) 100, 10, 8, (-1), (int) (byte) -1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str15.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(28800097L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.833334456d + "'", double1 == 2440587.833334456d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int22 = unsupportedDurationField19.getDifference((long) (short) 0, 3499L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(33, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str3.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gregorianChronology2.minutes();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType15, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
//        long long21 = cachedDateTimeZone18.previousTransition((-3191L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone18, (int) (byte) 1);
//        java.lang.String str25 = cachedDateTimeZone18.getNameKey(28799999L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3191L) + "'", long21 == (-3191L));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) chronology11, periodType13);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.Period period22 = new org.joda.time.Period((long) ' ');
        int[] intArray24 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period22, (long) 0);
        org.joda.time.Period period26 = period22.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Period period36 = period32.withYears((int) (short) 1);
        org.joda.time.Weeks weeks37 = period32.toStandardWeeks();
        org.joda.time.Period period38 = period26.plus((org.joda.time.ReadablePeriod) weeks37);
        org.joda.time.Period period39 = period16.withFields((org.joda.time.ReadablePeriod) period26);
        boolean boolean40 = gregorianChronology2.equals((java.lang.Object) period16);
        org.joda.time.Weeks weeks41 = period16.toStandardWeeks();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(weeks37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(weeks41);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported", "WeeksNoWeeks");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Period period2 = new org.joda.time.Period((-2L), 2440588L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            long long22 = unsupportedDurationField19.getMillis(110);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(4190400101L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4190400111L + "'", long2 == 4190400111L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        boolean boolean6 = period3.equals((java.lang.Object) iSOChronology4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        int int8 = periodType7.size();
        org.joda.time.PeriodType periodType9 = periodType7.withWeeksRemoved();
        org.joda.time.Period period10 = period3.normalizedStandard(periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 0, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [32,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        int int2 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1560628447856L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2458650L + "'", long1 == 2458650L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(520, (int) (byte) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3499L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 349900L + "'", long2 == 349900L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        java.lang.String str17 = periodType16.getName();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "YearWeekDayTime" + "'", str17.equals("YearWeekDayTime"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-3191L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("WeeksNoWeeks", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology6.yearOfEra();
//        java.lang.String str14 = iSOChronology6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str14.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            long long23 = unsupportedDurationField19.getValueAsLong((-3191L), 28800097L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period12.minusMillis((int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        int int27 = period23.getWeeks();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.Period period33 = period23.minus((org.joda.time.ReadablePeriod) period30);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Duration duration35 = period30.toDurationTo(readableInstant34);
        org.joda.time.Period period36 = period17.withFields((org.joda.time.ReadablePeriod) period30);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT0S" + "'", str32.equals("PT0S"));
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(duration35);
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 520, "Pacific Standard Time");
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
//        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
//        long long9 = durationField6.subtract(0L, (int) '4');
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-136774800000L) + "'", long9 == (-136774800000L));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        long long4 = durationField1.subtract(2440588L, (int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2440588L + "'", long4 == 2440588L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
//        boolean boolean23 = cachedDateTimeZone18.equals((java.lang.Object) 0.0d);
//        long long25 = cachedDateTimeZone18.nextTransition((-2L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2L) + "'", long25 == (-2L));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) 33, number2, (java.lang.Number) 100L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            long long23 = unsupportedDurationField19.add((long) 8, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType20, "PeriodType[YearWeekDayTimeNoMinutes]");
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        java.lang.String str12 = periodType11.toString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[Standard]" + "'", str12.equals("PeriodType[Standard]"));
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long20 = cachedDateTimeZone18.previousTransition(0L);
//        java.lang.String str22 = cachedDateTimeZone18.getNameKey(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28805044L + "'", long17 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.secondOfMinute();
        try {
            long long14 = gregorianChronology2.getDateTimeMillis((int) (byte) -1, 33, (int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        int int15 = fixedDateTimeZone13.getOffset((long) ' ');
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.Chronology chronology19 = zonedChronology16.withZone(dateTimeZone18);
//        try {
//            long long25 = zonedChronology16.getDateTimeMillis((long) 100, 0, (int) (byte) 100, 0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 42 + "'", int15 == 42);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        long long37 = preciseDurationField34.add((-3L), (int) (short) 100);
        try {
            long long40 = preciseDurationField34.getDifferenceAsLong(349900L, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3L) + "'", long37 == (-3L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.Weeks weeks14 = period12.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(weeks14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT0S");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Period period14 = period5.withMonths((-100));
        org.joda.time.Period period16 = period14.plusYears((int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (byte) 0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period13.getFieldTypes();
        boolean boolean15 = periodType2.equals((java.lang.Object) durationFieldTypeArray14);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology18);
        org.joda.time.Period period20 = period19.negated();
        org.joda.time.Period period22 = period19.plusMonths(0);
        org.joda.time.Period period24 = period22.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology32.getZone();
        org.joda.time.Period period35 = new org.joda.time.Period((long) ' ');
        int[] intArray37 = gregorianChronology32.get((org.joda.time.ReadablePeriod) period35, (long) 0);
        org.joda.time.Minutes minutes38 = period35.toStandardMinutes();
        boolean boolean39 = fixedDateTimeZone29.equals((java.lang.Object) period35);
        org.joda.time.Period period41 = period35.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType43 = period35.getFieldType(1);
        int int44 = period22.indexOf(durationFieldType43);
        int int45 = periodType2.indexOf(durationFieldType43);
        int int46 = period1.indexOf(durationFieldType43);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(minutes38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            int int23 = unsupportedDurationField19.getDifference((long) '4', (long) 520);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.withMonths(0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period11.getFieldTypes();
        boolean boolean13 = periodType0.equals((java.lang.Object) durationFieldTypeArray12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology16);
        org.joda.time.Period period18 = period17.negated();
        org.joda.time.Period period20 = period17.plusMonths(0);
        org.joda.time.Period period22 = period20.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        org.joda.time.Period period33 = new org.joda.time.Period((long) ' ');
        int[] intArray35 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period33, (long) 0);
        org.joda.time.Minutes minutes36 = period33.toStandardMinutes();
        boolean boolean37 = fixedDateTimeZone27.equals((java.lang.Object) period33);
        org.joda.time.Period period39 = period33.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType41 = period33.getFieldType(1);
        int int42 = period20.indexOf(durationFieldType41);
        int int43 = periodType0.indexOf(durationFieldType41);
        org.joda.time.PeriodType periodType44 = periodType0.withHoursRemoved();
        int int45 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(minutes36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        org.joda.time.Period period17 = period15.minusHours((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        org.joda.time.Period period10 = period5.minusSeconds(0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period5.toDurationFrom(readableInstant11);
        org.joda.time.Period period14 = period5.minusHours(0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology7);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Period period17 = new org.joda.time.Period((long) ' ');
        int[] intArray19 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period17, (long) 0);
        org.joda.time.Period period21 = period17.withYears((int) (short) 1);
        org.joda.time.Weeks weeks22 = period17.toStandardWeeks();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period24 = period17.withPeriodType(periodType23);
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType23);
        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType23);
        boolean boolean27 = period9.equals((java.lang.Object) periodType23);
        boolean boolean28 = lenientChronology4.equals((java.lang.Object) boolean27);
        boolean boolean30 = lenientChronology4.equals((java.lang.Object) "hi!");
        org.joda.time.Chronology chronology31 = lenientChronology4.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(weeks22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period3 = period2.toPeriod();
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.Weeks weeks14 = period9.toStandardWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = period9.withPeriodType(periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.PeriodType periodType19 = periodType18.withMinutesRemoved();
        java.lang.String str20 = periodType19.toString();
        org.joda.time.Period period21 = period1.normalizedStandard(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str20.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(4190400001L, 28799999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4161600002L + "'", long2 == 4161600002L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            long long23 = unsupportedDurationField19.getValueAsLong(28800032L, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DurationField durationField12 = gregorianChronology9.hours();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        boolean boolean14 = gregorianChronology4.equals((java.lang.Object) durationField13);
        org.joda.time.DurationField durationField15 = gregorianChronology4.days();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        java.lang.String str5 = lenientChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone24.getUncachedZone();
//        long long27 = cachedDateTimeZone24.nextTransition(28800032L);
//        org.joda.time.DateTimeZone dateTimeZone28 = cachedDateTimeZone24.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        boolean boolean32 = dateTimeZone30.isStandardOffset(28800032L);
//        long long34 = cachedDateTimeZone24.getMillisKeepLocal(dateTimeZone30, 4190400101L);
//        org.joda.time.Chronology chronology35 = lenientChronology4.withZone(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str5.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28799999L + "'", long21 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28805044L + "'", long23 == 28805044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800032L + "'", long27 == 28800032L);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4190400001L + "'", long34 == 4190400001L);
//        org.junit.Assert.assertNotNull(chronology35);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(42);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-42) + "'", int1 == (-42));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        boolean boolean17 = period15.isSupported(durationFieldType16);
//        org.joda.time.Period period19 = period15.withHours(0);
//        org.joda.time.DurationFieldType durationFieldType20 = null;
//        int int21 = period15.get(durationFieldType20);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
//        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
//        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
//        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
//        org.joda.time.Period period38 = period32.withMillis(97);
//        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
//        int int41 = period15.indexOf(durationFieldType40);
//        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
//        boolean boolean45 = decoratedDurationField44.isPrecise();
//        long long47 = decoratedDurationField44.getMillis(2440588L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(minutes35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(durationFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 105433401600000L + "'", long47 == 105433401600000L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        int int11 = period6.size();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        java.lang.Class<?> wildcardClass2 = periodType1.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period((-3191L), 10L, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int22 = unsupportedDurationField19.getValue(4190400001L, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationTo(readableInstant16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType19 = periodType18.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.Period period25 = new org.joda.time.Period((long) ' ');
        int[] intArray27 = gregorianChronology22.get((org.joda.time.ReadablePeriod) period25, (long) 0);
        org.joda.time.Period period29 = period25.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray30 = period29.getFieldTypes();
        boolean boolean31 = periodType18.equals((java.lang.Object) durationFieldTypeArray30);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology34);
        org.joda.time.Period period36 = period35.negated();
        org.joda.time.Period period38 = period35.plusMonths(0);
        org.joda.time.Period period40 = period38.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
        org.joda.time.Period period51 = new org.joda.time.Period((long) ' ');
        int[] intArray53 = gregorianChronology48.get((org.joda.time.ReadablePeriod) period51, (long) 0);
        org.joda.time.Minutes minutes54 = period51.toStandardMinutes();
        boolean boolean55 = fixedDateTimeZone45.equals((java.lang.Object) period51);
        org.joda.time.Period period57 = period51.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType59 = period51.getFieldType(1);
        int int60 = period38.indexOf(durationFieldType59);
        int int61 = periodType18.indexOf(durationFieldType59);
        org.joda.time.Period period63 = period12.withFieldAdded(durationFieldType59, (int) (short) -1);
        org.joda.time.Period period65 = period63.plusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(minutes54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(durationFieldType59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period65);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        long long10 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period7, 9L, (-100));
        org.joda.time.Period period12 = period7.minusWeeks(97);
        org.joda.time.Period period14 = period12.plusMonths(1);
        org.joda.time.Period period16 = period12.plusMonths(8);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3191L) + "'", long10 == (-3191L));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTimeField dateTimeField27 = lenientChronology26.yearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(lenientChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, (int) (byte) 1, (-42));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.weekOfWeekyear();
//        org.joda.time.PeriodType periodType27 = null;
//        try {
//            org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) dateTimeField26, periodType27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28805044L + "'", long24 == 28805044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.secondOfMinute();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 97, locale5);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) chronology6, periodType8);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = period9.normalizedStandard(periodType10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Period period17 = new org.joda.time.Period((long) ' ');
        int[] intArray19 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period17, (long) 0);
        org.joda.time.Period period21 = period17.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.Period period27 = new org.joda.time.Period((long) ' ');
        int[] intArray29 = gregorianChronology24.get((org.joda.time.ReadablePeriod) period27, (long) 0);
        org.joda.time.Period period31 = period27.withYears((int) (short) 1);
        org.joda.time.Weeks weeks32 = period27.toStandardWeeks();
        org.joda.time.Period period33 = period21.plus((org.joda.time.ReadablePeriod) weeks32);
        org.joda.time.Period period34 = period11.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period36 = period11.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology39.getZone();
        org.joda.time.Period period42 = new org.joda.time.Period((long) ' ');
        int[] intArray44 = gregorianChronology39.get((org.joda.time.ReadablePeriod) period42, (long) 0);
        org.joda.time.Period period46 = period42.withYears((int) (short) 1);
        org.joda.time.Weeks weeks47 = period42.toStandardWeeks();
        org.joda.time.PeriodType periodType48 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period49 = period42.withPeriodType(periodType48);
        org.joda.time.Period period50 = period36.minus((org.joda.time.ReadablePeriod) period42);
        int int51 = period42.getYears();
        org.joda.time.Weeks weeks52 = period42.toStandardWeeks();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) weeks52);
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology57);
        org.joda.time.Period period59 = period58.toPeriod();
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology64.getZone();
        org.joda.time.Period period67 = new org.joda.time.Period((long) ' ');
        int[] intArray69 = gregorianChronology64.get((org.joda.time.ReadablePeriod) period67, (long) 0);
        org.joda.time.Period period71 = period67.withYears((int) (short) 1);
        org.joda.time.Weeks weeks72 = period67.toStandardWeeks();
        org.joda.time.PeriodType periodType73 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period74 = period67.withPeriodType(periodType73);
        org.joda.time.Period period75 = new org.joda.time.Period(readableInstant60, readableDuration61, periodType73);
        org.joda.time.PeriodType periodType76 = org.joda.time.DateTimeUtils.getPeriodType(periodType73);
        boolean boolean77 = period59.equals((java.lang.Object) periodType73);
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.Duration duration79 = period59.toDurationTo(readableInstant78);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone80, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone83 = gregorianChronology82.getZone();
        org.joda.time.PeriodType periodType84 = org.joda.time.PeriodType.minutes();
        boolean boolean85 = gregorianChronology82.equals((java.lang.Object) periodType84);
        org.joda.time.Period period86 = new org.joda.time.Period(readableInstant54, (org.joda.time.ReadableDuration) duration79, periodType84);
        org.joda.time.Period period87 = new org.joda.time.Period((java.lang.Object) weeks52, periodType84);
        long long90 = gregorianChronology2.add((org.joda.time.ReadablePeriod) weeks52, (-3191L), 1);
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(weeks32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(weeks47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(weeks52);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(weeks72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(duration79);
        org.junit.Assert.assertNotNull(gregorianChronology82);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(periodType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-3191L) + "'", long90 == (-3191L));
        org.junit.Assert.assertNotNull(dateTimeField91);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        boolean boolean17 = period15.isSupported(durationFieldType16);
//        org.joda.time.Period period19 = period15.withHours(0);
//        org.joda.time.DurationFieldType durationFieldType20 = null;
//        int int21 = period15.get(durationFieldType20);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
//        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
//        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
//        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
//        org.joda.time.Period period38 = period32.withMillis(97);
//        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
//        int int41 = period15.indexOf(durationFieldType40);
//        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
//        long long47 = decoratedDurationField44.getDifferenceAsLong((long) '#', (long) 8);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(minutes35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(durationFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("WeeksNoWeeks");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'WeeksNoWeeks' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        java.lang.Object obj6 = null;
        boolean boolean7 = gregorianChronology2.equals(obj6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.plusMonths(0);
        int int7 = period3.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC(1L, true);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getName(28805044L, locale6);
//        int int9 = dateTimeZone1.getOffsetFromLocal((long) 97);
//        java.lang.String str11 = dateTimeZone1.getShortName(2440587L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Period period1 = org.joda.time.Period.months((-100));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationTo(readableInstant16);
        org.joda.time.Period period19 = period12.plusYears(42);
        org.joda.time.format.PeriodFormatter periodFormatter20 = null;
        java.lang.String str21 = period19.toString(periodFormatter20);
        int int22 = period19.getDays();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "P42Y" + "'", str21.equals("P42Y"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = gregorianChronology7.equals((java.lang.Object) periodType9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone14);
        org.joda.time.Chronology chronology20 = gregorianChronology2.withZone(dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        org.joda.time.Chronology chronology26 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology2.dayOfYear();
        try {
            long long32 = gregorianChronology2.getDateTimeMillis((-1), (int) ' ', 97, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.100" + "'", str16.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Period period1 = org.joda.time.Period.days((-100));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Period period1 = org.joda.time.Period.months(42);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long22 = unsupportedDurationField19.getMillis((-100), (long) 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        try {
            int int23 = unsupportedDurationField19.getValue(28799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField15 = gregorianChronology12.hours();
        org.joda.time.DurationField durationField16 = gregorianChronology12.months();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology12.secondOfDay();
        boolean boolean19 = gregorianChronology12.equals((java.lang.Object) "");
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) boolean19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology6.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dateTimeField21, dateTimeFieldType22, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusSeconds((int) ' ');
        int int12 = period9.getDays();
        org.joda.time.Period period14 = period9.plusDays((int) (short) 0);
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(0L, periodType16, chronology17);
        org.joda.time.Period period19 = period9.plus((org.joda.time.ReadablePeriod) period18);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType8, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-3191L), locale7);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(2440588L);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
        org.joda.time.DateTimeZone dateTimeZone7 = lenientChronology4.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[+00:00:00.100]]" + "'", str5.equals("LenientChronology[ISOChronology[+00:00:00.100]]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Weeks weeks13 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.weeks();
        try {
            org.joda.time.Period period15 = period5.withPeriodType(periodType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period48 = period38.normalizedStandard(periodType47);
        try {
            int int50 = period38.getValue(42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 42");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = iSOChronology0.get(readablePartial6, (-101L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PeriodType[Standard]", (int) '#', (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for PeriodType[Standard] must be in the range [10,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        try {
            long long13 = gregorianChronology2.getDateTimeMillis(110, (int) ' ', (int) 'a', (int) '4', (int) 'a', (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Period period1 = org.joda.time.Period.years(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 10, 97, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology6.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withMonths(42);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        java.lang.String str5 = period3.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        java.lang.String str46 = decoratedDurationField44.toString();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.DurationFieldType durationFieldType54 = null;
        boolean boolean55 = period53.isSupported(durationFieldType54);
        org.joda.time.Period period57 = period53.withHours(0);
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = period53.get(durationFieldType58);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone64 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone65, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
        org.joda.time.Period period70 = new org.joda.time.Period((long) ' ');
        int[] intArray72 = gregorianChronology67.get((org.joda.time.ReadablePeriod) period70, (long) 0);
        org.joda.time.Minutes minutes73 = period70.toStandardMinutes();
        boolean boolean74 = fixedDateTimeZone64.equals((java.lang.Object) period70);
        org.joda.time.Period period76 = period70.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType78 = period70.getFieldType(1);
        int int79 = period53.indexOf(durationFieldType78);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField81 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) decoratedDurationField44, durationFieldType78, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(minutes73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(durationFieldType78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
        long long21 = cachedDateTimeZone18.previousTransition((long) 100);
        long long23 = cachedDateTimeZone18.previousTransition(2440588L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2440588L + "'", long23 == 2440588L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        int[] intArray16 = period15.getValues();
        org.joda.time.Period period18 = period15.minusYears((int) '4');
        org.joda.time.Period period19 = period15.negated();
        org.joda.time.Period period21 = period19.minusWeeks(520);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.dayOfWeek();
        org.joda.time.DurationField durationField27 = iSOChronology6.centuries();
        org.joda.time.DurationField durationField28 = iSOChronology6.millis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Period period14 = period5.withMonths((-100));
        org.joda.time.Period period16 = period14.plusMinutes(520);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfYear();
        try {
            long long13 = gregorianChronology2.getDateTimeMillis(0, 110, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = period5.getPeriodType();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period7.plusMillis(520);
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period9.toString(periodFormatter11);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0.520S" + "'", str12.equals("PT0.520S"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType18, "");
        java.lang.Throwable[] throwableArray22 = illegalFieldValueException21.getSuppressed();
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis(1, 520, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 520 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, dateTimeFieldType27, 0, 33, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone1.isLocalDateTimeGap(localDateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Period period14 = period12.multipliedBy(520);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("ISOChronology[America/Los_Angeles]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "P100WT0.520S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology6.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.dayOfWeek();
        org.joda.time.DurationField durationField27 = iSOChronology6.centuries();
        org.joda.time.ReadablePartial readablePartial28 = null;
        try {
            int[] intArray30 = iSOChronology6.get(readablePartial28, 2440587L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (-1), false);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-101L) + "'", long6 == (-101L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported", "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WeeksNoWeeks" + "'", str3.equals("WeeksNoWeeks"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WeeksNoWeeks" + "'", str5.equals("WeeksNoWeeks"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-3191L), locale7);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(2440588L);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        int int13 = fixedDateTimeZone4.getStandardOffset(2440588L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        int int6 = fixedDateTimeZone4.getStandardOffset(2440588L);
        int int8 = fixedDateTimeZone4.getOffset((long) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-4190400001L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-362261426846400000L) + "'", long1 == (-362261426846400000L));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Period period2 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) chronology5, periodType7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.plusMillis(520);
        org.joda.time.Period period13 = period2.plus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        java.lang.String str15 = periodType14.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DurationField durationField21 = gregorianChronology18.hours();
        org.joda.time.Period period22 = new org.joda.time.Period(4190400101L, periodType14, (org.joda.time.Chronology) gregorianChronology18);
        try {
            long long27 = gregorianChronology18.getDateTimeMillis((-100), (-42), 42, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -42 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Standard" + "'", str15.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        try {
            long long24 = unsupportedDurationField19.getValueAsLong((long) 42, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        try {
            int int22 = unsupportedDurationField19.getValue(4161600002L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType14);
        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType18 = periodType17.withMinutesRemoved();
        java.lang.String str19 = periodType18.toString();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period23 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DurationField durationField25 = iSOChronology22.seconds();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long30 = dateTimeZone27.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        java.lang.String str36 = dateTimeZone34.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        long long41 = dateTimeZone34.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long43 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone44 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
        int int46 = cachedDateTimeZone44.getOffset(28799999L);
        org.joda.time.Chronology chronology47 = iSOChronology22.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone44);
        org.joda.time.Period period48 = new org.joda.time.Period((long) (byte) 1, periodType18, chronology47);
        org.joda.time.PeriodType periodType49 = periodType18.withSecondsRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str19.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.100" + "'", str36.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-101L) + "'", long41 == (-101L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 4944L + "'", long43 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(periodType49);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.weekyear();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField16, (int) ' ', 0, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        long long10 = iSOChronology6.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.monthOfYear();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) iSOChronology5, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        java.lang.String str46 = decoratedDurationField44.toString();
        long long49 = decoratedDurationField44.getMillis(33L, 100L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1425600000L + "'", long49 == 1425600000L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology6.millisOfDay();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology6.year();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-101L) + "'", long22 == (-101L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4944L + "'", long24 == 4944L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "P100WT0.520S", "DurationField[months]");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.yearOfEra();
        long long15 = iSOChronology6.getDateTimeMillis((long) (short) 10, (int) (short) 10, (int) ' ', 0, 520);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 37920420L + "'", long15 == 37920420L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType17 = periodType16.withMinutesRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period7.plusMillis(520);
        org.joda.time.Period period11 = period9.withWeeks((int) (byte) 100);
        java.lang.String str12 = period11.toString();
        org.joda.time.Minutes minutes13 = period11.toStandardMinutes();
        org.joda.time.Period period15 = period11.withSeconds((int) (short) 10);
        int int16 = period15.size();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "P100WT0.520S" + "'", str12.equals("P100WT0.520S"));
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) '4');
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        java.lang.String str6 = dateTimeZone4.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Chronology chronology12 = iSOChronology7.withZone(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        java.lang.String str19 = dateTimeZone17.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DurationFieldType durationFieldType30 = null;
        boolean boolean31 = period29.isSupported(durationFieldType30);
        org.joda.time.Period period33 = period29.withHours(0);
        org.joda.time.DurationFieldType durationFieldType34 = null;
        int int35 = period29.get(durationFieldType34);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
        org.joda.time.Period period46 = new org.joda.time.Period((long) ' ');
        int[] intArray48 = gregorianChronology43.get((org.joda.time.ReadablePeriod) period46, (long) 0);
        org.joda.time.Minutes minutes49 = period46.toStandardMinutes();
        boolean boolean50 = fixedDateTimeZone40.equals((java.lang.Object) period46);
        org.joda.time.Period period52 = period46.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType54 = period46.getFieldType(1);
        int int55 = period29.indexOf(durationFieldType54);
        org.joda.time.field.PreciseDurationField preciseDurationField57 = new org.joda.time.field.PreciseDurationField(durationFieldType54, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField22, durationFieldType54);
        long long61 = decoratedDurationField58.add(5044L, (long) 8);
        org.joda.time.DurationFieldType durationFieldType62 = decoratedDurationField58.getType();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField63 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField13, (org.joda.time.DurationField) decoratedDurationField58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.100" + "'", str19.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(minutes49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 345605044L + "'", long61 == 345605044L);
        org.junit.Assert.assertNotNull(durationFieldType62);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(8, (int) (short) 100, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        try {
            int int50 = preciseDurationField34.getValue(345605044L, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        try {
            long long23 = unsupportedDurationField19.getMillis(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        int int15 = fixedDateTimeZone13.getOffset((long) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.Chronology chronology19 = zonedChronology16.withZone(dateTimeZone18);
        java.lang.String str20 = zonedChronology16.toString();
        try {
            long long26 = zonedChronology16.getDateTimeMillis(0L, (-100), (int) (short) 0, (int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 42 + "'", int15 == 42);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[ISOChronology[UTC], PST]" + "'", str20.equals("ZonedChronology[ISOChronology[UTC], PST]"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField9 = gregorianChronology2.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        java.lang.String str7 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[+00:00:00.100,mdfw=1]" + "'", str7.equals("GregorianChronology[+00:00:00.100,mdfw=1]"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        int int33 = period7.getYears();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) durationFieldType2);
        int int5 = period4.getWeeks();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.Period period4 = new org.joda.time.Period((-1), 97, (int) (short) -1, (int) 'a');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Minutes minutes18 = period15.toStandardMinutes();
        boolean boolean19 = fixedDateTimeZone9.equals((java.lang.Object) period15);
        org.joda.time.Period period21 = period15.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType23 = period15.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType23);
        long long25 = unsupportedDurationField24.getUnitMillis();
        java.lang.String str26 = unsupportedDurationField24.getName();
        org.joda.time.DurationFieldType durationFieldType27 = unsupportedDurationField24.getType();
        int int28 = period4.get(durationFieldType27);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(minutes18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "months" + "'", str26.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        illegalFieldValueException2.prependMessage("hi!");
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType31, "PeriodType[YearWeekDayTimeNoMinutes]");
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType14);
        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType18 = periodType17.withMinutesRemoved();
        java.lang.String str19 = periodType18.toString();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period23 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DurationField durationField25 = iSOChronology22.seconds();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long30 = dateTimeZone27.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        java.lang.String str36 = dateTimeZone34.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        long long41 = dateTimeZone34.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long43 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone44 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
        int int46 = cachedDateTimeZone44.getOffset(28799999L);
        org.joda.time.Chronology chronology47 = iSOChronology22.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone44);
        org.joda.time.Period period48 = new org.joda.time.Period((long) (byte) 1, periodType18, chronology47);
        org.joda.time.Period period50 = period48.minusWeeks(110);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str19.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.100" + "'", str36.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-101L) + "'", long41 == (-101L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 4944L + "'", long43 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(period50);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = lenientChronology4.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getShortName((-3191L), locale13);
        org.joda.time.Chronology chronology15 = lenientChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long17 = fixedDateTimeZone10.previousTransition(5044L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) chronology6, periodType8);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = period9.normalizedStandard(periodType10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Period period17 = new org.joda.time.Period((long) ' ');
        int[] intArray19 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period17, (long) 0);
        org.joda.time.Period period21 = period17.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.Period period27 = new org.joda.time.Period((long) ' ');
        int[] intArray29 = gregorianChronology24.get((org.joda.time.ReadablePeriod) period27, (long) 0);
        org.joda.time.Period period31 = period27.withYears((int) (short) 1);
        org.joda.time.Weeks weeks32 = period27.toStandardWeeks();
        org.joda.time.Period period33 = period21.plus((org.joda.time.ReadablePeriod) weeks32);
        org.joda.time.Period period34 = period11.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period36 = period11.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology39.getZone();
        org.joda.time.Period period42 = new org.joda.time.Period((long) ' ');
        int[] intArray44 = gregorianChronology39.get((org.joda.time.ReadablePeriod) period42, (long) 0);
        org.joda.time.Period period46 = period42.withYears((int) (short) 1);
        org.joda.time.Weeks weeks47 = period42.toStandardWeeks();
        org.joda.time.PeriodType periodType48 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period49 = period42.withPeriodType(periodType48);
        org.joda.time.Period period50 = period36.minus((org.joda.time.ReadablePeriod) period42);
        int int51 = period42.getYears();
        org.joda.time.Weeks weeks52 = period42.toStandardWeeks();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) weeks52);
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology57);
        org.joda.time.Period period59 = period58.toPeriod();
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology64.getZone();
        org.joda.time.Period period67 = new org.joda.time.Period((long) ' ');
        int[] intArray69 = gregorianChronology64.get((org.joda.time.ReadablePeriod) period67, (long) 0);
        org.joda.time.Period period71 = period67.withYears((int) (short) 1);
        org.joda.time.Weeks weeks72 = period67.toStandardWeeks();
        org.joda.time.PeriodType periodType73 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period74 = period67.withPeriodType(periodType73);
        org.joda.time.Period period75 = new org.joda.time.Period(readableInstant60, readableDuration61, periodType73);
        org.joda.time.PeriodType periodType76 = org.joda.time.DateTimeUtils.getPeriodType(periodType73);
        boolean boolean77 = period59.equals((java.lang.Object) periodType73);
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.Duration duration79 = period59.toDurationTo(readableInstant78);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone80, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone83 = gregorianChronology82.getZone();
        org.joda.time.PeriodType periodType84 = org.joda.time.PeriodType.minutes();
        boolean boolean85 = gregorianChronology82.equals((java.lang.Object) periodType84);
        org.joda.time.Period period86 = new org.joda.time.Period(readableInstant54, (org.joda.time.ReadableDuration) duration79, periodType84);
        org.joda.time.Period period87 = new org.joda.time.Period((java.lang.Object) weeks52, periodType84);
        long long90 = gregorianChronology2.add((org.joda.time.ReadablePeriod) weeks52, (-3191L), 1);
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField92 = gregorianChronology2.year();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(weeks32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(weeks47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(weeks52);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(weeks72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(duration79);
        org.junit.Assert.assertNotNull(gregorianChronology82);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(periodType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-3191L) + "'", long90 == (-3191L));
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertNotNull(dateTimeField92);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology10);
        long long16 = gregorianChronology10.add((long) (short) -1, (long) '#', 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) chronology19, periodType21);
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Period period24 = period22.normalizedStandard(periodType23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.Period period30 = new org.joda.time.Period((long) ' ');
        int[] intArray32 = gregorianChronology27.get((org.joda.time.ReadablePeriod) period30, (long) 0);
        org.joda.time.Period period34 = period30.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.Period period40 = new org.joda.time.Period((long) ' ');
        int[] intArray42 = gregorianChronology37.get((org.joda.time.ReadablePeriod) period40, (long) 0);
        org.joda.time.Period period44 = period40.withYears((int) (short) 1);
        org.joda.time.Weeks weeks45 = period40.toStandardWeeks();
        org.joda.time.Period period46 = period34.plus((org.joda.time.ReadablePeriod) weeks45);
        org.joda.time.Period period47 = period24.withFields((org.joda.time.ReadablePeriod) period34);
        boolean boolean48 = gregorianChronology10.equals((java.lang.Object) period24);
        org.joda.time.PeriodType periodType49 = period24.getPeriodType();
        org.joda.time.Period period50 = new org.joda.time.Period((-1), 0, (int) (byte) 1, (int) '#', (int) '#', (int) (byte) -1, 8, 97, periodType49);
        org.joda.time.Period period52 = period50.plusMillis(110);
        org.joda.time.Period period54 = period52.multipliedBy(0);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3499L + "'", long16 == 3499L);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(weeks45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
//        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone18.getUncachedZone();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getShortName(0L, locale24);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) '#');
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.Period period21 = period4.withPeriodType(periodType18);
        org.joda.time.PeriodType periodType22 = period4.getPeriodType();
        boolean boolean24 = periodType22.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 'a');
        org.joda.time.Period period3 = period1.withDays((int) (byte) 1);
        org.joda.time.Period period5 = period3.plusMonths((-100));
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period5.toDurationTo(readableInstant8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.Period period16 = new org.joda.time.Period();
        org.joda.time.Period period18 = period16.plusYears(1);
        org.joda.time.Period period20 = period16.minusMonths(42);
        org.joda.time.Period period21 = period15.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period23 = period21.withYears((int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField68 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType62);
        try {
            long long71 = unsupportedDurationField68.add(97L, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(unsupportedDurationField68);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusYears(1);
        org.joda.time.Period period4 = period0.minusMonths(42);
        org.joda.time.Hours hours5 = period0.toStandardHours();
        org.joda.time.Period period7 = period0.withDays((int) '4');
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(hours5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        try {
            long long49 = preciseDurationField34.getValueAsLong((-42L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(110, (-42), 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DurationField durationField13 = iSOChronology6.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology6.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.Chronology chronology19 = iSOChronology6.withZone(dateTimeZone18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTimeZone18.getShortName((long) 1, locale21);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.100" + "'", str22.equals("+00:00:00.100"));
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        boolean boolean20 = cachedDateTimeZone18.isFixed();
//        java.lang.String str22 = cachedDateTimeZone18.getNameKey((long) 110);
//        java.lang.String str24 = cachedDateTimeZone18.getShortName((long) 110);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 10);
        org.joda.time.Period period3 = period1.withWeeks(0);
        org.joda.time.Period period5 = period1.withMillis((int) (short) 1);
        org.joda.time.Period period7 = period1.plusMonths(42);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        long long47 = decoratedDurationField44.subtract(28800032L, 2440587L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-105433329599968L) + "'", long47 == (-105433329599968L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.Hours hours16 = period15.toStandardHours();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(hours16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.Period period19 = period17.minusMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        try {
            long long24 = unsupportedDurationField19.add((long) 42, 28805044L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 33, (-100), (int) (short) 100);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, "P1YT0.032S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        int int8 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.era();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.year();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationField durationField20 = null;
        int int21 = unsupportedDurationField19.compareTo(durationField20);
        try {
            int int24 = unsupportedDurationField19.getValue((-3191L), (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ', periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            long long23 = unsupportedDurationField19.getDifferenceAsLong((long) 0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        int int15 = fixedDateTimeZone13.getOffset((long) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology6.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 42 + "'", int15 == 42);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', periodType1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Period period14 = period10.withYears((int) (short) 1);
        org.joda.time.Weeks weeks15 = period10.toStandardWeeks();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period10.withPeriodType(periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType16);
        java.lang.String str19 = periodType16.toString();
        org.joda.time.PeriodType periodType20 = periodType16.withMillisRemoved();
        try {
            org.joda.time.Period period21 = period2.withPeriodType(periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(weeks15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PeriodType[YearWeekDayTime]" + "'", str19.equals("PeriodType[YearWeekDayTime]"));
        org.junit.Assert.assertNotNull(periodType20);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period(33L, periodType1);
        org.joda.time.PeriodType periodType4 = periodType1.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 1120, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        org.joda.time.PeriodType periodType16 = periodType13.withMinutesRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType18 = periodType13.getFieldType(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        java.lang.String str6 = dateTimeZone4.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField9 = iSOChronology8.halfdays();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        boolean boolean18 = period16.isSupported(durationFieldType17);
        org.joda.time.Period period20 = period16.withHours(0);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period16.get(durationFieldType21);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        org.joda.time.Period period33 = new org.joda.time.Period((long) ' ');
        int[] intArray35 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period33, (long) 0);
        org.joda.time.Minutes minutes36 = period33.toStandardMinutes();
        boolean boolean37 = fixedDateTimeZone27.equals((java.lang.Object) period33);
        org.joda.time.Period period39 = period33.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType41 = period33.getFieldType(1);
        int int42 = period16.indexOf(durationFieldType41);
        org.joda.time.field.PreciseDurationField preciseDurationField44 = new org.joda.time.field.PreciseDurationField(durationFieldType41, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField45 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType41);
        boolean boolean46 = decoratedDurationField45.isPrecise();
        java.lang.String str47 = decoratedDurationField45.toString();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) decoratedDurationField45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(minutes36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DurationField[months]" + "'", str47.equals("DurationField[months]"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationField durationField20 = null;
        int int21 = unsupportedDurationField19.compareTo(durationField20);
        try {
            long long23 = unsupportedDurationField19.getValueAsLong((long) 520);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        jodaTimePermission1.checkGuard((java.lang.Object) period15);
        java.lang.String str17 = jodaTimePermission1.toString();
        java.lang.String str18 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-3191L), locale7);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(2440588L);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        long long13 = fixedDateTimeZone4.previousTransition(28805044L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28805044L + "'", long13 == 28805044L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray14 = new int[] { 8, (short) -1, 0 };
        try {
            gregorianChronology2.validate(readablePartial10, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        long long11 = durationField8.subtract((-1L), (long) 6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200001L) + "'", long11 == (-259200001L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(42, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) ' ');
        int[] intArray8 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period6, (long) 0);
        org.joda.time.Period period10 = period6.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) ' ');
        int[] intArray18 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period16, (long) 0);
        org.joda.time.Period period20 = period16.withYears((int) (short) 1);
        org.joda.time.Weeks weeks21 = period16.toStandardWeeks();
        org.joda.time.Period period22 = period10.plus((org.joda.time.ReadablePeriod) weeks21);
        org.joda.time.Period period24 = period22.minusSeconds((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period22.toDurationTo(readableInstant25);
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration26);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(weeks21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        int int47 = period38.getYears();
        org.joda.time.Weeks weeks48 = period38.toStandardWeeks();
        org.joda.time.Period period49 = new org.joda.time.Period((java.lang.Object) weeks48);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology53);
        org.joda.time.Period period55 = period54.toPeriod();
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone58, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology60.getZone();
        org.joda.time.Period period63 = new org.joda.time.Period((long) ' ');
        int[] intArray65 = gregorianChronology60.get((org.joda.time.ReadablePeriod) period63, (long) 0);
        org.joda.time.Period period67 = period63.withYears((int) (short) 1);
        org.joda.time.Weeks weeks68 = period63.toStandardWeeks();
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period70 = period63.withPeriodType(periodType69);
        org.joda.time.Period period71 = new org.joda.time.Period(readableInstant56, readableDuration57, periodType69);
        org.joda.time.PeriodType periodType72 = org.joda.time.DateTimeUtils.getPeriodType(periodType69);
        boolean boolean73 = period55.equals((java.lang.Object) periodType69);
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.Duration duration75 = period55.toDurationTo(readableInstant74);
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone76, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone79 = gregorianChronology78.getZone();
        org.joda.time.PeriodType periodType80 = org.joda.time.PeriodType.minutes();
        boolean boolean81 = gregorianChronology78.equals((java.lang.Object) periodType80);
        org.joda.time.Period period82 = new org.joda.time.Period(readableInstant50, (org.joda.time.ReadableDuration) duration75, periodType80);
        org.joda.time.Period period83 = new org.joda.time.Period((java.lang.Object) weeks48, periodType80);
        org.joda.time.DurationFieldType durationFieldType85 = periodType80.getFieldType(0);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(weeks48);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(weeks68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(duration75);
        org.junit.Assert.assertNotNull(gregorianChronology78);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(periodType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(durationFieldType85);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long9 = dateTimeZone6.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        long long20 = dateTimeZone13.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long22 = dateTimeZone6.getMillisKeepLocal(dateTimeZone13, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.Chronology chronology24 = iSOChronology0.withZone(dateTimeZone6);
//        java.lang.String str25 = dateTimeZone6.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 5044L + "'", long22 == 5044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        java.lang.Throwable throwable3 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
//        boolean boolean10 = gregorianChronology7.equals((java.lang.Object) periodType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone14);
//        org.joda.time.Chronology chronology20 = gregorianChronology2.withZone(dateTimeZone14);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
//        org.joda.time.Chronology chronology26 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        int int28 = fixedDateTimeZone25.getOffsetFromLocal((long) 520);
//        int int30 = fixedDateTimeZone25.getOffset((long) (byte) 100);
//        org.joda.time.LocalDateTime localDateTime31 = null;
//        boolean boolean32 = fixedDateTimeZone25.isLocalDateTimeGap(localDateTime31);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC(1L, true);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getName(28805044L, locale6);
//        int int9 = dateTimeZone1.getOffsetFromLocal((long) 97);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getName(4190400111L, locale11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusWeeks((int) (short) -1);
        org.joda.time.Period period13 = period9.minusMonths(100);
        org.joda.time.Period period14 = period9.negated();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        int int47 = period46.getYears();
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Duration duration49 = period46.toDurationTo(readableInstant48);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(duration49);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DurationField durationField13 = gregorianChronology10.hours();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.months();
//        boolean boolean15 = gregorianChronology5.equals((java.lang.Object) durationField14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long27 = dateTimeZone24.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        java.lang.String str33 = dateTimeZone31.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        long long38 = dateTimeZone31.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long40 = dateTimeZone24.getMillisKeepLocal(dateTimeZone31, 5044L);
//        org.joda.time.Chronology chronology41 = iSOChronology22.withZone(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology22.dayOfWeek();
//        org.joda.time.DurationField durationField43 = iSOChronology22.centuries();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField14, durationField43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 5044L + "'", long40 == 5044L);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(durationField43);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-3L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3L) + "'", long2 == (-3L));
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        java.lang.String str15 = zonedChronology14.toString();
//        try {
//            long long20 = zonedChronology14.getDateTimeMillis(100, 100, (int) (short) 0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Seconds]" + "'", str15.equals("ZonedChronology[GregorianChronology[UTC], Seconds]"));
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int26 = cachedDateTimeZone24.getOffset(28799999L);
//        org.joda.time.Chronology chronology27 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        long long29 = cachedDateTimeZone24.nextTransition((-259200001L));
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5044L + "'", long23 == 5044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-259200001L) + "'", long29 == (-259200001L));
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int26 = cachedDateTimeZone24.getOffset(28799999L);
//        org.joda.time.Chronology chronology27 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.Chronology chronology29 = iSOChronology2.withZone(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5044L + "'", long23 == 5044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(chronology29);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
//        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
//        try {
//            long long21 = iSOChronology6.getDateTimeMillis((-259200001L), 0, (int) (short) -1, (int) '4', (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PST", "Seconds");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        java.lang.String str7 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period5.plusWeeks((int) (short) 0);
        org.joda.time.Period period13 = period5.minusSeconds(110);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.format.PeriodFormatter periodFormatter17 = null;
        java.lang.String str18 = period10.toString(periodFormatter17);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.032S" + "'", str18.equals("PT0.032S"));
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
//        long long21 = cachedDateTimeZone18.previousTransition((-3191L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone18, (int) (byte) 1);
//        long long25 = cachedDateTimeZone18.nextTransition(2458650L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3191L) + "'", long21 == (-3191L));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2458650L + "'", long25 == 2458650L);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2440588L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282475464d + "'", double1 == 2440587.5282475464d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(345605044L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440592L + "'", long1 == 2440592L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        java.lang.String str5 = lenientChronology4.toString();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        java.lang.String str7 = lenientChronology4.toString();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[Seconds]]" + "'", str5.equals("LenientChronology[ISOChronology[Seconds]]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[Seconds]]" + "'", str7.equals("LenientChronology[ISOChronology[Seconds]]"));
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        boolean boolean17 = period15.isSupported(durationFieldType16);
//        org.joda.time.Period period19 = period15.withHours(0);
//        org.joda.time.DurationFieldType durationFieldType20 = null;
//        int int21 = period15.get(durationFieldType20);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
//        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
//        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
//        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
//        org.joda.time.Period period38 = period32.withMillis(97);
//        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
//        int int41 = period15.indexOf(durationFieldType40);
//        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
//        boolean boolean45 = decoratedDurationField44.isPrecise();
//        java.lang.String str46 = decoratedDurationField44.toString();
//        long long48 = decoratedDurationField44.getMillis((long) 6);
//        int int50 = decoratedDurationField44.getValue(2440587L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(minutes35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(durationFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 259200000L + "'", long48 == 259200000L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PST");
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        java.lang.String str47 = period32.toString();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PT10M" + "'", str47.equals("PT10M"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        try {
            long long24 = unsupportedDurationField19.getMillis((long) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
//        int int6 = fixedDateTimeZone4.getStandardOffset((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        java.lang.String str12 = dateTimeZone10.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.Chronology chronology18 = iSOChronology13.withZone(dateTimeZone17);
//        org.joda.time.DurationField durationField19 = iSOChronology13.weeks();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(100);
//        org.joda.time.Chronology chronology22 = iSOChronology13.withZone(dateTimeZone21);
//        boolean boolean23 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        try {
//            long long9 = iSOChronology6.set(readablePartial7, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.Weeks weeks14 = period9.toStandardWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = period9.withPeriodType(periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.PeriodType periodType19 = periodType18.withMinutesRemoved();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        try {
            long long23 = unsupportedDurationField19.add((-68L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-42));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
//        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        int int18 = gregorianChronology17.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-259200001L), 4161600002L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3902400001L + "'", long2 == 3902400001L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) '#');
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(259200000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology11);
        org.joda.time.Period period13 = period12.toPeriod();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Period period21 = new org.joda.time.Period((long) ' ');
        int[] intArray23 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, (long) 0);
        org.joda.time.Period period25 = period21.withYears((int) (short) 1);
        org.joda.time.Weeks weeks26 = period21.toStandardWeeks();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period28 = period21.withPeriodType(periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType27);
        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
        boolean boolean31 = period13.equals((java.lang.Object) periodType27);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Duration duration33 = period13.toDurationTo(readableInstant32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone37 = gregorianChronology36.getZone();
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.minutes();
        boolean boolean39 = gregorianChronology36.equals((java.lang.Object) periodType38);
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant8, (org.joda.time.ReadableDuration) duration33, periodType38);
        org.joda.time.PeriodType periodType41 = periodType38.withYearsRemoved();
        try {
            org.joda.time.Period period42 = new org.joda.time.Period(0, (int) (short) 100, (-1), 0, (int) (short) 100, 100, (int) '#', (int) (short) 0, periodType41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(weeks26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(periodType41);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gregorianChronology2.minutes();
        org.joda.time.Period period16 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) chronology19, periodType21);
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Period period24 = period22.normalizedStandard(periodType23);
        org.joda.time.Period period26 = period24.plusMillis(520);
        org.joda.time.Period period27 = period16.plus((org.joda.time.ReadablePeriod) period26);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        long long31 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period27, (long) 4, 4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2212L + "'", long31 == 2212L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

