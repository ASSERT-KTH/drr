import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.Weeks weeks18 = period13.toStandardWeeks();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period20 = period13.withPeriodType(periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType19);
        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
        boolean boolean23 = period5.equals((java.lang.Object) periodType19);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period5.toDurationTo(readableInstant24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.minutes();
        boolean boolean31 = gregorianChronology28.equals((java.lang.Object) periodType30);
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration25, periodType30);
        try {
            org.joda.time.Period period34 = period32.plusYears(8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(weeks18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.Period period6 = period3.minusDays((int) ' ');
        org.joda.time.Period period8 = period3.plusMonths(33);
        int int9 = period3.getMillis();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        int int13 = period12.getYears();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
//        long long19 = zonedChronology14.getDateTimeMillis(4, 10, 6, (int) (short) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62016883200000L) + "'", long19 == (-62016883200000L));
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
//        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology6.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology6.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology6.millisOfDay();
//        org.joda.time.DurationField durationField29 = iSOChronology6.months();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5044L + "'", long24 == 5044L);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(durationField29);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.centuryOfEra();
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            long long11 = gregorianChronology2.set(readablePartial9, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        int int14 = period1.getValue((int) (short) 0);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 8, chronology5);
        org.joda.time.Period period8 = period6.minusYears(4);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
        org.joda.time.DurationField durationField6 = iSOChronology2.days();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        try {
            long long24 = unsupportedDurationField19.getValueAsLong((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period7.plusMillis(520);
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period9.toDurationFrom(readableInstant11);
        int int13 = period9.getMinutes();
        try {
            int int15 = period9.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        int int15 = fixedDateTimeZone13.getOffset((long) ' ');
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology6.clockhourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 42 + "'", int15 == 42);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        int int16 = fixedDateTimeZone4.getStandardOffset((long) 1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str19 = fixedDateTimeZone4.getShortName((long) 42);
        boolean boolean20 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationTo(readableInstant16);
        org.joda.time.Period period19 = period12.plusYears(42);
        int[] intArray20 = period19.getValues();
        int int22 = period19.getValue(4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology4, periodType6);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period9.plusMillis(520);
        org.joda.time.Period period12 = period1.plus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period1);
        org.joda.time.Period period15 = period13.minusMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str8 = dateTimeZone3.getID();
        java.lang.String str9 = dateTimeZone3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Seconds" + "'", str8.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Seconds" + "'", str9.equals("Seconds"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        boolean boolean23 = cachedDateTimeZone18.equals((java.lang.Object) 0.0d);
        boolean boolean25 = cachedDateTimeZone18.equals((java.lang.Object) 1560628447856L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) ' ');
        int[] intArray8 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period6, (long) 0);
        org.joda.time.Period period10 = period6.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period10.getFieldTypes();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.forFields(durationFieldTypeArray11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.forFields(durationFieldTypeArray11);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology16);
        org.joda.time.Period period18 = period17.negated();
        org.joda.time.Period period20 = period17.plusMonths(0);
        org.joda.time.Period period22 = period20.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        org.joda.time.Period period33 = new org.joda.time.Period((long) ' ');
        int[] intArray35 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period33, (long) 0);
        org.joda.time.Minutes minutes36 = period33.toStandardMinutes();
        boolean boolean37 = fixedDateTimeZone27.equals((java.lang.Object) period33);
        org.joda.time.Period period39 = period33.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType41 = period33.getFieldType(1);
        int int42 = period20.indexOf(durationFieldType41);
        int int43 = periodType13.indexOf(durationFieldType41);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period47 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.chrono.LenientChronology lenientChronology48 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology46);
        java.lang.Object obj49 = null;
        boolean boolean50 = lenientChronology48.equals(obj49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) lenientChronology48);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(minutes36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(lenientChronology48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            long long11 = iSOChronology6.set(readablePartial9, (-68L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        boolean boolean23 = unsupportedDurationField19.isPrecise();
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology2.era();
        org.joda.time.DurationField durationField15 = gregorianChronology2.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology2.millis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period48 = period38.normalizedStandard(periodType47);
        org.joda.time.Period period50 = period48.minusWeeks(0);
        int int51 = period50.getSeconds();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        jodaTimePermission1.checkGuard((java.lang.Object) period15);
        java.lang.String str17 = jodaTimePermission1.toString();
        java.lang.String str18 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        long long10 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period7, 9L, (-100));
        org.joda.time.Period period12 = period7.minusWeeks(97);
        org.joda.time.Duration duration13 = period12.toStandardDuration();
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration13);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3191L) + "'", long10 == (-3191L));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58665599968L) + "'", long14 == (-58665599968L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.Period period3 = period1.plusMinutes((-100));
        org.joda.time.Period period5 = period3.minusMillis(6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Minutes minutes10 = period7.toStandardMinutes();
        int int11 = period7.getWeeks();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableInstant13);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.Period period17 = period7.minus((org.joda.time.ReadablePeriod) period14);
        org.joda.time.Period period19 = period7.minusWeeks(1);
        boolean boolean20 = period1.equals((java.lang.Object) period7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(minutes10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT0S" + "'", str16.equals("PT0S"));
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.Period period2 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) chronology5, periodType7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.plusMillis(520);
        org.joda.time.Period period13 = period2.plus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        java.lang.String str15 = periodType14.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DurationField durationField21 = gregorianChronology18.hours();
        org.joda.time.Period period22 = new org.joda.time.Period(4190400101L, periodType14, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Duration duration23 = period22.toStandardDuration();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.Period period25 = period22.plus(readablePeriod24);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Standard" + "'", str15.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 'a');
        org.joda.time.Period period3 = period1.plusSeconds((int) '#');
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField26 = iSOChronology6.months();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType28, 33, (-42), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5044L + "'", long24 == 5044L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period16 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DurationField durationField18 = iSOChronology15.seconds();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period5, (org.joda.time.Chronology) iSOChronology15);
        java.lang.Class<?> wildcardClass20 = period19.getClass();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Duration duration22 = period19.toDurationFrom(readableInstant21);
        int[] intArray23 = period19.getValues();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(duration22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology3.add(readablePeriod5, (long) (-1), 0);
        org.joda.time.DurationField durationField9 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology3.withZone(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology3.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-42L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        try {
            int int24 = unsupportedDurationField19.getValue(43200000L, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period25 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
        boolean boolean28 = unsupportedDurationField19.equals((java.lang.Object) durationField27);
        try {
            long long31 = unsupportedDurationField19.subtract((long) 100, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.dayOfWeek();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            long long10 = gregorianChronology2.set(readablePartial8, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long8 = dateTimeZone5.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        java.lang.String str14 = dateTimeZone12.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long19 = dateTimeZone12.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long21 = dateTimeZone5.getMillisKeepLocal(dateTimeZone12, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone23 = cachedDateTimeZone22.getUncachedZone();
        long long25 = cachedDateTimeZone22.nextTransition(28800032L);
        boolean boolean27 = cachedDateTimeZone22.equals((java.lang.Object) 0.0d);
        java.lang.String str29 = cachedDateTimeZone22.getNameKey((-3191L));
        org.joda.time.Chronology chronology30 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        boolean boolean31 = cachedDateTimeZone22.isFixed();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5044L + "'", long21 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800032L + "'", long25 == 28800032L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = gregorianChronology6.equals((java.lang.Object) periodType8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period(2440587L, 100L, periodType3, (org.joda.time.Chronology) zonedChronology18);
        java.lang.String str21 = zonedChronology18.toString();
        try {
            long long29 = zonedChronology18.getDateTimeMillis(33, 42, 520, 97, 0, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Seconds]" + "'", str21.equals("ZonedChronology[GregorianChronology[UTC], Seconds]"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1814400000L, (java.lang.Number) 10.0d, (java.lang.Number) 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
        boolean boolean20 = cachedDateTimeZone18.isFixed();
        boolean boolean21 = cachedDateTimeZone18.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType46 = decoratedDurationField44.getType();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.DurationFieldType durationFieldType54 = null;
        boolean boolean55 = period53.isSupported(durationFieldType54);
        org.joda.time.Period period57 = period53.withHours(0);
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = period53.get(durationFieldType58);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone64 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone65, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
        org.joda.time.Period period70 = new org.joda.time.Period((long) ' ');
        int[] intArray72 = gregorianChronology67.get((org.joda.time.ReadablePeriod) period70, (long) 0);
        org.joda.time.Minutes minutes73 = period70.toStandardMinutes();
        boolean boolean74 = fixedDateTimeZone64.equals((java.lang.Object) period70);
        org.joda.time.Period period76 = period70.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType78 = period70.getFieldType(1);
        int int79 = period53.indexOf(durationFieldType78);
        org.joda.time.field.PreciseDurationField preciseDurationField81 = new org.joda.time.field.PreciseDurationField(durationFieldType78, (long) (short) 0);
        int int82 = decoratedDurationField44.compareTo((org.joda.time.DurationField) preciseDurationField81);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(minutes73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(durationFieldType78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.minutes();
        try {
            long long21 = zonedChronology14.getDateTimeMillis((long) (-1), 0, 8, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        int int8 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology2.era();
        org.joda.time.DurationField durationField15 = gregorianChronology2.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology2.clockhourOfDay();
        org.joda.time.Chronology chronology18 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType46 = decoratedDurationField44.getType();
        long long49 = decoratedDurationField44.getMillis(42, 0L);
        long long51 = decoratedDurationField44.getValueAsLong(4190400111L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1814400000L + "'", long49 == 1814400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 97L + "'", long51 == 97L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology49);
        org.joda.time.Period period51 = period50.negated();
        org.joda.time.Period period53 = period50.plusMonths(0);
        org.joda.time.Period period55 = period53.plusYears(1);
        org.joda.time.Period period56 = period32.withFields((org.joda.time.ReadablePeriod) period55);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Duration duration58 = period56.toDurationFrom(readableInstant57);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(duration58);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.Period period2 = period1.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField18 = gregorianChronology17.eras();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) chronology11, periodType13);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.Period period22 = new org.joda.time.Period((long) ' ');
        int[] intArray24 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period22, (long) 0);
        org.joda.time.Period period26 = period22.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Period period36 = period32.withYears((int) (short) 1);
        org.joda.time.Weeks weeks37 = period32.toStandardWeeks();
        org.joda.time.Period period38 = period26.plus((org.joda.time.ReadablePeriod) weeks37);
        org.joda.time.Period period39 = period16.withFields((org.joda.time.ReadablePeriod) period26);
        boolean boolean40 = gregorianChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, dateTimeFieldType42, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(weeks37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1425600000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 122960973240000000L + "'", long1 == 122960973240000000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.Period period11 = new org.joda.time.Period((long) ' ');
        int[] intArray13 = gregorianChronology8.get((org.joda.time.ReadablePeriod) period11, (long) 0);
        org.joda.time.Period period15 = period11.withYears((int) (short) 1);
        org.joda.time.Weeks weeks16 = period11.toStandardWeeks();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period18 = period11.withPeriodType(periodType17);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period22 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DurationField durationField24 = iSOChronology21.seconds();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period11, (org.joda.time.Chronology) iSOChronology21);
        java.lang.Class<?> wildcardClass26 = period25.getClass();
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period25.toDurationFrom(readableInstant27);
        boolean boolean29 = lenientChronology4.equals((java.lang.Object) readableInstant27);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(weeks16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        boolean boolean22 = unsupportedDurationField19.isSupported();
        try {
            int int25 = unsupportedDurationField19.getValue(2458650L, (-105433329599968L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gregorianChronology4.add(readablePeriod6, (long) (-1), 0);
        org.joda.time.DurationField durationField10 = gregorianChronology4.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Chronology chronology15 = gregorianChronology4.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology4.era();
        org.joda.time.Period period17 = new org.joda.time.Period(1425600000L, (long) 6, (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = gregorianChronology6.equals((java.lang.Object) periodType8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period(2440587L, 100L, periodType3, (org.joda.time.Chronology) zonedChronology18);
        java.lang.String str21 = zonedChronology18.toString();
        try {
            long long26 = zonedChronology18.getDateTimeMillis((int) (short) 100, (-1), (int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Seconds]" + "'", str21.equals("ZonedChronology[GregorianChronology[UTC], Seconds]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        long long22 = dateTimeZone15.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long24 = dateTimeZone8.getMillisKeepLocal(dateTimeZone15, 5044L);
        org.joda.time.Chronology chronology25 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField27 = lenientChronology26.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5044L + "'", long24 == 5044L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-259200001L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-259199901L) + "'", long2 == (-259199901L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 8, chronology5);
        int int7 = period6.getSeconds();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("WeeksNoWeeks");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, 1120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        long long8 = fixedDateTimeZone4.convertLocalToUTC(0L, true, 28800009L);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-42L) + "'", long8 == (-42L));
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        long long50 = preciseDurationField34.add((-3L), (long) 110);
        long long53 = preciseDurationField34.getMillis((int) (short) 0, (-1L));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-3L) + "'", long50 == (-3L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str16 = fixedDateTimeZone4.getShortName(8L);
        long long18 = fixedDateTimeZone4.previousTransition((long) (byte) -1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology4);
        long long10 = gregorianChronology4.add((long) (short) -1, (long) '#', 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        boolean boolean13 = gregorianChronology4.equals((java.lang.Object) periodType11);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType11);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3499L + "'", long10 == 3499L);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DurationField durationField12 = gregorianChronology9.hours();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        boolean boolean14 = gregorianChronology4.equals((java.lang.Object) durationField13);
        boolean boolean16 = gregorianChronology4.equals((java.lang.Object) 2458650L);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        int int16 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(iSOChronology17);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusSeconds((int) ' ');
        org.joda.time.Period period13 = period9.plusMonths((int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekOfWeekyear();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.plusSeconds((int) ' ');
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.indexOf(durationFieldType12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationFrom(readableInstant14);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str16 = fixedDateTimeZone4.getShortName(8L);
        boolean boolean17 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        boolean boolean23 = cachedDateTimeZone18.equals((java.lang.Object) 0.0d);
        java.lang.String str25 = cachedDateTimeZone18.getNameKey((-3191L));
        boolean boolean26 = cachedDateTimeZone18.isFixed();
        int int28 = cachedDateTimeZone18.getOffset(2440587L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        try {
            long long13 = gregorianChronology2.getDateTimeMillis(10, (int) (short) 0, (int) 'a', (-42), (int) '4', (int) (short) 10, 1120);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -42 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        int int47 = period38.getYears();
        org.joda.time.Weeks weeks48 = period38.toStandardWeeks();
        org.joda.time.Period period50 = period38.plusWeeks(6);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(weeks48);
        org.junit.Assert.assertNotNull(period50);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            long long10 = iSOChronology6.set(readablePartial8, 1560628423938L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        java.lang.Object obj20 = null;
        boolean boolean21 = unsupportedDurationField19.equals(obj20);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField68 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType62);
        java.lang.String str69 = unsupportedDurationField68.getName();
        boolean boolean70 = unsupportedDurationField68.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(unsupportedDurationField68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "months" + "'", str69.equals("months"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str20 = cachedDateTimeZone18.getNameKey((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Period period2 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) chronology5, periodType7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.plusMillis(520);
        org.joda.time.Period period13 = period2.plus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        java.lang.String str15 = periodType14.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DurationField durationField21 = gregorianChronology18.hours();
        org.joda.time.Period period22 = new org.joda.time.Period(4190400101L, periodType14, (org.joda.time.Chronology) gregorianChronology18);
        try {
            long long30 = gregorianChronology18.getDateTimeMillis((int) '#', 0, 97, (int) ' ', 0, (int) ' ', (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Standard" + "'", str15.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 0, (int) 'a', 0, (int) ' ', (int) (byte) 1, 110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, (java.lang.Number) (byte) -1, (java.lang.Number) (-259200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Seconds", "PeriodType[YearWeekDayTimeNoMinutes]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number6 = illegalFieldValueException5.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException5.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str9 = illegalFieldValueException2.getFieldName();
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Seconds" + "'", str9.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        long long23 = cachedDateTimeZone18.previousTransition(1560628423938L);
        int int25 = cachedDateTimeZone18.getOffset((long) 42);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560628423938L + "'", long23 == 1560628423938L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        try {
            org.joda.time.DurationFieldType durationFieldType14 = period6.getFieldType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        org.joda.time.Period period17 = period15.minusWeeks(1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) weeks20);
        org.joda.time.Period period23 = period21.plusWeeks(0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.Period period1 = org.joda.time.Period.years(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int26 = cachedDateTimeZone24.getOffset(28799999L);
        org.joda.time.Chronology chronology27 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5044L + "'", long23 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        boolean boolean26 = dateTimeZone24.isStandardOffset(28800032L);
        long long28 = cachedDateTimeZone18.getMillisKeepLocal(dateTimeZone24, 4190400101L);
        long long30 = cachedDateTimeZone18.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone31 = cachedDateTimeZone18.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5044L + "'", long17 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4190400001L + "'", long28 == 4190400001L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Standard");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.Period period18 = period16.withWeeks((int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName(0L, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withDaysRemoved();
        org.joda.time.PeriodType periodType12 = periodType10.withHoursRemoved();
        org.joda.time.PeriodType periodType13 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((int) (short) 10, (int) 'a', (int) '#', 0, 0, 0, (int) '#', 33, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        long long13 = dateTimeZone10.convertUTCToLocal(1000L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1000L + "'", long13 == 1000L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        boolean boolean51 = preciseDurationField34.equals((java.lang.Object) dateTimeField50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, dateTimeFieldType52, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.Period period1 = org.joda.time.Period.days(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(2440587L, "P42Y");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.Period period2 = new org.joda.time.Period((-3191L), (-105433329599968L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology6.clockhourOfHalfday();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period16 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DurationField durationField18 = iSOChronology15.seconds();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period5, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DurationField durationField20 = iSOChronology15.eras();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 10, chronology3);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.Weeks weeks14 = period9.toStandardWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = period9.withPeriodType(periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.PeriodType periodType19 = periodType18.withMinutesRemoved();
        java.lang.String str20 = periodType19.toString();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period24 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DurationField durationField26 = iSOChronology23.seconds();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long31 = dateTimeZone28.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology34.getZone();
        java.lang.String str37 = dateTimeZone35.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long42 = dateTimeZone35.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long44 = dateTimeZone28.getMillisKeepLocal(dateTimeZone35, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
        int int47 = cachedDateTimeZone45.getOffset(28799999L);
        org.joda.time.Chronology chronology48 = iSOChronology23.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 1, periodType19, chronology48);
        org.joda.time.Period period50 = new org.joda.time.Period(0L, periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str20.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 5044L + "'", long44 == 5044L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(chronology48);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = lenientChronology4.hours();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) lenientChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = gregorianChronology9.add(readablePeriod11, (long) (-1), 0);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology9.centuryOfEra();
        org.joda.time.DurationField durationField16 = gregorianChronology9.months();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology9.halfdayOfDay();
        boolean boolean18 = lenientChronology4.equals((java.lang.Object) dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DurationField durationField15 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField16 = gregorianChronology2.years();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(37920420L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 379204200L + "'", long2 == 379204200L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology5.add(readablePeriod7, (long) (-1), 0);
        org.joda.time.DurationField durationField11 = gregorianChronology5.halfdays();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Chronology chronology16 = gregorianChronology5.withZone(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType2, chronology16);
        org.joda.time.Period period18 = new org.joda.time.Period((-42L), periodType2);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology21);
        org.joda.time.Period period23 = period22.negated();
        org.joda.time.Period period25 = period22.plusMonths(0);
        org.joda.time.Period period27 = period25.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Minutes minutes41 = period38.toStandardMinutes();
        boolean boolean42 = fixedDateTimeZone32.equals((java.lang.Object) period38);
        org.joda.time.Period period44 = period38.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType46 = period38.getFieldType(1);
        int int47 = period25.indexOf(durationFieldType46);
        boolean boolean48 = periodType2.isSupported(durationFieldType46);
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(durationFieldType46, (java.lang.Number) 0L, (java.lang.Number) 43200000L, (java.lang.Number) 42);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(minutes41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
        long long14 = lenientChronology4.getDateTimeMillis(1, 0, 10, (int) (short) 0, 100, (int) '#', 0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[Seconds]]" + "'", str5.equals("LenientChronology[ISOChronology[Seconds]]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62137491565000L) + "'", long14 == (-62137491565000L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (-31507200000L));
        org.joda.time.DurationFieldType durationFieldType35 = preciseDurationField34.getType();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(durationFieldType35);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField15 = gregorianChronology12.hours();
        org.joda.time.DurationField durationField16 = gregorianChronology12.months();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology12.secondOfDay();
        boolean boolean19 = gregorianChronology12.equals((java.lang.Object) "");
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) boolean19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.Period period1 = org.joda.time.Period.years((-1));
        org.joda.time.Period period3 = period1.withWeeks((int) (byte) 1);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        java.lang.String str15 = zonedChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        org.joda.time.Chronology chronology19 = zonedChronology14.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Seconds]" + "'", str15.equals("ZonedChronology[GregorianChronology[UTC], Seconds]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period3 = period1.multipliedBy((-100));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.minutes();
        try {
            long long23 = zonedChronology14.getDateTimeMillis((int) 'a', (int) (short) 1, 100, (int) (short) 0, (int) (byte) 0, 0, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.minutes();
        boolean boolean27 = gregorianChronology24.equals((java.lang.Object) periodType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        java.lang.String str33 = dateTimeZone31.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, dateTimeZone31);
        org.joda.time.Chronology chronology37 = gregorianChronology19.withZone(dateTimeZone31);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        org.joda.time.Chronology chronology43 = gregorianChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology19.getZone();
        org.joda.time.Chronology chronology45 = zonedChronology14.withZone(dateTimeZone44);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.100" + "'", str33.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        long long15 = fixedDateTimeZone4.previousTransition((long) 8);
        boolean boolean16 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8L + "'", long15 == 8L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        long long12 = dateTimeZone9.convertLocalToUTC((long) (-1), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-101L) + "'", long12 == (-101L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-3191L), locale7);
        long long11 = fixedDateTimeZone4.adjustOffset(33L, false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 33L + "'", long11 == 33L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        long long47 = decoratedDurationField44.add(5044L, (long) 8);
        int int50 = decoratedDurationField44.getDifference(33L, (long) (byte) -1);
        long long52 = decoratedDurationField44.getValueAsLong((-101L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 345605044L + "'", long47 == 345605044L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period48 = period38.normalizedStandard(periodType47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology53.getZone();
        org.joda.time.Period period56 = new org.joda.time.Period((long) ' ');
        int[] intArray58 = gregorianChronology53.get((org.joda.time.ReadablePeriod) period56, (long) 0);
        org.joda.time.Period period60 = period56.withYears((int) (short) 1);
        org.joda.time.Weeks weeks61 = period56.toStandardWeeks();
        org.joda.time.PeriodType periodType62 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period63 = period56.withPeriodType(periodType62);
        org.joda.time.Period period64 = new org.joda.time.Period(readableInstant49, readableDuration50, periodType62);
        int[] intArray65 = period64.getValues();
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology68);
        org.joda.time.Period period70 = period69.negated();
        org.joda.time.Period period72 = period69.plusMonths(0);
        org.joda.time.Period period73 = period64.minus((org.joda.time.ReadablePeriod) period72);
        org.joda.time.Period period74 = period38.withFields((org.joda.time.ReadablePeriod) period72);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone75, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone78 = gregorianChronology77.getZone();
        org.joda.time.Period period80 = new org.joda.time.Period((long) ' ');
        int[] intArray82 = gregorianChronology77.get((org.joda.time.ReadablePeriod) period80, (long) 0);
        org.joda.time.Period period84 = period80.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray85 = period84.getFieldTypes();
        org.joda.time.Period period87 = period84.withDays(33);
        org.joda.time.Period period88 = period38.plus((org.joda.time.ReadablePeriod) period87);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(weeks61);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(gregorianChronology77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(period84);
        org.junit.Assert.assertNotNull(durationFieldTypeArray85);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertNotNull(period88);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone3.getOffset(readableInstant6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[YearDay]" + "'", str1.equals("PeriodType[YearDay]"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField68 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType62);
        try {
            long long71 = unsupportedDurationField68.getMillis(0L, 1814400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(unsupportedDurationField68);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.Period period3 = period1.plusMinutes((-100));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = period10.isSupported(durationFieldType11);
        org.joda.time.Period period14 = period10.withHours(0);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period10.get(durationFieldType15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.Period period27 = new org.joda.time.Period((long) ' ');
        int[] intArray29 = gregorianChronology24.get((org.joda.time.ReadablePeriod) period27, (long) 0);
        org.joda.time.Minutes minutes30 = period27.toStandardMinutes();
        boolean boolean31 = fixedDateTimeZone21.equals((java.lang.Object) period27);
        org.joda.time.Period period33 = period27.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType35 = period27.getFieldType(1);
        int int36 = period10.indexOf(durationFieldType35);
        org.joda.time.field.PreciseDurationField preciseDurationField38 = new org.joda.time.field.PreciseDurationField(durationFieldType35, (long) (short) 0);
        int int39 = period3.indexOf(durationFieldType35);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(minutes30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(durationFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        try {
            long long24 = unsupportedDurationField19.getDifferenceAsLong(1425600000L, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period(33L, periodType1);
        int int4 = periodType1.size();
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType1.getFieldType(42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period13.getFieldTypes();
        boolean boolean15 = periodType2.equals((java.lang.Object) durationFieldTypeArray14);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology18);
        org.joda.time.Period period20 = period19.negated();
        org.joda.time.Period period22 = period19.plusMonths(0);
        org.joda.time.Period period24 = period22.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology32.getZone();
        org.joda.time.Period period35 = new org.joda.time.Period((long) ' ');
        int[] intArray37 = gregorianChronology32.get((org.joda.time.ReadablePeriod) period35, (long) 0);
        org.joda.time.Minutes minutes38 = period35.toStandardMinutes();
        boolean boolean39 = fixedDateTimeZone29.equals((java.lang.Object) period35);
        org.joda.time.Period period41 = period35.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType43 = period35.getFieldType(1);
        int int44 = period22.indexOf(durationFieldType43);
        int int45 = periodType2.indexOf(durationFieldType43);
        boolean boolean46 = period1.isSupported(durationFieldType43);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(minutes38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType46 = decoratedDurationField44.getType();
        long long49 = decoratedDurationField44.getMillis(42, 0L);
        long long51 = decoratedDurationField44.getValueAsLong((long) 1120);
        boolean boolean52 = decoratedDurationField44.isPrecise();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology57.getZone();
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology57);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        boolean boolean61 = period59.isSupported(durationFieldType60);
        org.joda.time.Period period63 = period59.withHours(0);
        org.joda.time.DurationFieldType durationFieldType64 = null;
        int int65 = period59.get(durationFieldType64);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone71, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone74 = gregorianChronology73.getZone();
        org.joda.time.Period period76 = new org.joda.time.Period((long) ' ');
        int[] intArray78 = gregorianChronology73.get((org.joda.time.ReadablePeriod) period76, (long) 0);
        org.joda.time.Minutes minutes79 = period76.toStandardMinutes();
        boolean boolean80 = fixedDateTimeZone70.equals((java.lang.Object) period76);
        org.joda.time.Period period82 = period76.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType84 = period76.getFieldType(1);
        int int85 = period59.indexOf(durationFieldType84);
        org.joda.time.field.PreciseDurationField preciseDurationField87 = new org.joda.time.field.PreciseDurationField(durationFieldType84, (long) (short) 0);
        long long90 = preciseDurationField87.add((-3L), (int) (short) 100);
        int int91 = decoratedDurationField44.compareTo((org.joda.time.DurationField) preciseDurationField87);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1814400000L + "'", long49 == 1814400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(minutes79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(durationFieldType84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-3L) + "'", long90 == (-3L));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        long long6 = fixedDateTimeZone4.previousTransition((-259200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-259200001L) + "'", long6 == (-259200001L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.Period period19 = period5.plusWeeks(110);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period12.withMonths((int) (byte) 100);
        org.joda.time.Period period19 = period17.plusHours((int) (byte) 10);
        org.joda.time.Period period21 = period17.minusMinutes((int) 'a');
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.months();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DurationFieldType durationFieldType30 = null;
        boolean boolean31 = period29.isSupported(durationFieldType30);
        org.joda.time.Period period33 = period29.withHours(0);
        org.joda.time.DurationFieldType durationFieldType34 = null;
        int int35 = period29.get(durationFieldType34);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
        org.joda.time.Period period46 = new org.joda.time.Period((long) ' ');
        int[] intArray48 = gregorianChronology43.get((org.joda.time.ReadablePeriod) period46, (long) 0);
        org.joda.time.Minutes minutes49 = period46.toStandardMinutes();
        boolean boolean50 = fixedDateTimeZone40.equals((java.lang.Object) period46);
        org.joda.time.Period period52 = period46.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType54 = period46.getFieldType(1);
        int int55 = period29.indexOf(durationFieldType54);
        boolean boolean56 = periodType22.isSupported(durationFieldType54);
        int int57 = period17.indexOf(durationFieldType54);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(minutes49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) chronology11, periodType13);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.Period period22 = new org.joda.time.Period((long) ' ');
        int[] intArray24 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period22, (long) 0);
        org.joda.time.Period period26 = period22.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Period period36 = period32.withYears((int) (short) 1);
        org.joda.time.Weeks weeks37 = period32.toStandardWeeks();
        org.joda.time.Period period38 = period26.plus((org.joda.time.ReadablePeriod) weeks37);
        org.joda.time.Period period39 = period16.withFields((org.joda.time.ReadablePeriod) period26);
        boolean boolean40 = gregorianChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(weeks37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.Period period2 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) chronology5, periodType7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.plusMillis(520);
        org.joda.time.Period period13 = period2.plus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        java.lang.String str15 = periodType14.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DurationField durationField21 = gregorianChronology18.hours();
        org.joda.time.Period period22 = new org.joda.time.Period(4190400101L, periodType14, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Duration duration23 = period22.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration23, readableInstant24);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Standard" + "'", str15.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(duration23);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT0.520S");
        org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) "PT0.520S");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        try {
            int int37 = preciseDurationField34.getValue((-362261426846400000L), 28800032L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
//        boolean boolean23 = cachedDateTimeZone18.equals((java.lang.Object) 0.0d);
//        java.lang.String str25 = cachedDateTimeZone18.getNameKey((-3191L));
//        boolean boolean26 = cachedDateTimeZone18.isFixed();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = cachedDateTimeZone18.getName((-4190400001L), locale28);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Coordinated Universal Time" + "'", str29.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, (int) ' ', 4, (int) '#');
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField6 = gregorianChronology3.hours();
        org.joda.time.DurationField durationField7 = gregorianChronology3.months();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.secondOfDay();
        int int9 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.era();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-100), (org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        org.joda.time.Period period3 = new org.joda.time.Period(28800009L, 33L, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.DurationFieldType durationFieldType32 = null;
        boolean boolean33 = period30.isSupported(durationFieldType32);
        try {
            org.joda.time.Seconds seconds34 = period30.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Period period11 = period9.withYears((int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        long long50 = preciseDurationField34.add((-3L), (long) 110);
        long long53 = preciseDurationField34.getMillis((int) (short) 10, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-3L) + "'", long50 == (-3L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField7 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-62016883200000L), (java.lang.Number) 28800097L, (java.lang.Number) 4944L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        try {
            int int23 = unsupportedDurationField19.getValue(349900L, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType8, (-100), (-1), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = lenientChronology4.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getShortName((-3191L), locale13);
        org.joda.time.Chronology chronology15 = lenientChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DurationField durationField16 = lenientChronology4.minutes();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone18.getUncachedZone();
        long long25 = cachedDateTimeZone18.adjustOffset(1814400000L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1814400000L + "'", long25 == 1814400000L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        jodaTimePermission1.checkGuard((java.lang.Object) period15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone18.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        java.lang.String str27 = dateTimeZone25.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        long long32 = dateTimeZone25.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long34 = dateTimeZone18.getMillisKeepLocal(dateTimeZone25, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        java.util.TimeZone timeZone36 = cachedDateTimeZone35.toTimeZone();
        long long38 = cachedDateTimeZone35.previousTransition((-3191L));
        jodaTimePermission1.checkGuard((java.lang.Object) cachedDateTimeZone35);
        java.security.PermissionCollection permissionCollection40 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.100" + "'", str27.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-101L) + "'", long32 == (-101L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4944L + "'", long34 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-3191L) + "'", long38 == (-3191L));
        org.junit.Assert.assertNotNull(permissionCollection40);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        try {
            long long25 = unsupportedDurationField19.getDifferenceAsLong((-259200001L), (-62137491565000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.Period period34 = period32.plusWeeks((int) (short) 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-259199901L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440584.500001146d + "'", double1 == 2440584.500001146d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.Period period2 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) chronology5, periodType7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.plusMillis(520);
        org.joda.time.Period period13 = period2.plus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        java.lang.String str15 = periodType14.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DurationField durationField21 = gregorianChronology18.hours();
        org.joda.time.Period period22 = new org.joda.time.Period(4190400101L, periodType14, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Chronology chronology23 = gregorianChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology18.millisOfSecond();
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Standard" + "'", str15.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.Period period30 = new org.joda.time.Period((long) ' ');
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) chronology33, periodType35);
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Period period38 = period36.normalizedStandard(periodType37);
        org.joda.time.Period period40 = period38.plusMillis(520);
        org.joda.time.Period period41 = period30.plus((org.joda.time.ReadablePeriod) period40);
        org.joda.time.PeriodType periodType42 = period41.getPeriodType();
        java.lang.String str43 = periodType42.getName();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology46.getZone();
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.DurationField durationField49 = gregorianChronology46.hours();
        org.joda.time.Period period50 = new org.joda.time.Period(4190400101L, periodType42, (org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.Period period51 = new org.joda.time.Period(10, (int) (byte) 1, 97, 100, 110, (int) (short) 1, 8, 0, periodType42);
        boolean boolean52 = unsupportedDurationField19.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Standard" + "'", str43.equals("Standard"));
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "UnsupportedDurationField[months]", "LenientChronology[ISOChronology[Seconds]]");
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
//        int int6 = fixedDateTimeZone4.getStandardOffset(2440588L);
//        java.lang.String str7 = fixedDateTimeZone4.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Period period11 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DurationField durationField13 = iSOChronology10.seconds();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long18 = dateTimeZone15.convertLocalToUTC((long) (short) 10, false);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        java.lang.String str24 = dateTimeZone22.getShortName((long) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        long long29 = dateTimeZone22.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
//        long long31 = dateTimeZone15.getMillisKeepLocal(dateTimeZone22, 5044L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        int int34 = cachedDateTimeZone32.getOffset(28799999L);
//        org.joda.time.Chronology chronology35 = iSOChronology10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone32);
//        long long38 = cachedDateTimeZone32.convertLocalToUTC(100L, false);
//        java.lang.String str40 = cachedDateTimeZone32.getShortName(8L);
//        boolean boolean41 = fixedDateTimeZone4.equals((java.lang.Object) str40);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(lenientChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.100" + "'", str24.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-101L) + "'", long29 == (-101L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4944L + "'", long31 == 4944L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) weeks20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType23 = periodType22.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        long long31 = gregorianChronology26.add(readablePeriod28, (long) (-1), 0);
        org.joda.time.DurationField durationField32 = gregorianChronology26.halfdays();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Chronology chronology37 = gregorianChronology26.withZone(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology26.era();
        org.joda.time.DurationField durationField39 = gregorianChronology26.years();
        org.joda.time.Period period40 = new org.joda.time.Period((java.lang.Object) period9, periodType22, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.PeriodType periodType41 = periodType22.withMonthsRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(periodType41);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
        long long21 = cachedDateTimeZone18.previousTransition((-3191L));
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone18, (int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableInstant25);
        org.joda.time.Seconds seconds27 = period26.toStandardSeconds();
        boolean boolean28 = cachedDateTimeZone18.equals((java.lang.Object) period26);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3191L) + "'", long21 == (-3191L));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(seconds27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int26 = cachedDateTimeZone24.getOffset(28799999L);
        org.joda.time.Chronology chronology27 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        java.lang.Object obj28 = null;
        boolean boolean29 = cachedDateTimeZone24.equals(obj28);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.100" + "'", str16.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-101L) + "'", long21 == (-101L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 4944L + "'", long23 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long21 = dateTimeZone14.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long23 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int26 = cachedDateTimeZone24.getOffset(28799999L);
        org.joda.time.Chronology chronology27 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.joda.time.LocalDateTime localDateTime28 = null;
        boolean boolean29 = cachedDateTimeZone24.isLocalDateTimeGap(localDateTime28);
        long long31 = cachedDateTimeZone24.nextTransition(0L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.100" + "'", str16.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-101L) + "'", long21 == (-101L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 4944L + "'", long23 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType62, (long) (short) 1);
        long long72 = preciseDurationField69.getMillis((int) (byte) 10, 1560628423938L);
        boolean boolean73 = preciseDurationField69.isPrecise();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DurationField durationField15 = gregorianChronology2.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("");
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.Period period12 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology15);
        org.joda.time.Period period17 = period16.negated();
        org.joda.time.Period period19 = period16.plusMonths(0);
        org.joda.time.Period period21 = period19.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period19.indexOf(durationFieldType40);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType40, "LenientChronology[ISOChronology[America/Los_Angeles]]");
        boolean boolean44 = periodType4.isSupported(durationFieldType40);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        long long47 = decoratedDurationField44.add(5044L, (long) 8);
        boolean boolean48 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType49 = decoratedDurationField44.getType();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 345605044L + "'", long47 == 345605044L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(durationFieldType49);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.Period period6 = period4.withSeconds(10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "Pacific Standard Time", "Coordinated Universal Time");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean20 = unsupportedDurationField19.isPrecise();
        boolean boolean21 = unsupportedDurationField19.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period48 = period38.normalizedStandard(periodType47);
        int int49 = period48.getMonths();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        int[] intArray16 = period15.getValues();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology19);
        org.joda.time.Period period21 = period20.negated();
        org.joda.time.Period period23 = period20.plusMonths(0);
        org.joda.time.Period period24 = period15.minus((org.joda.time.ReadablePeriod) period23);
        int int25 = period24.getMillis();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType46 = decoratedDurationField44.getType();
        org.joda.time.DurationField durationField47 = decoratedDurationField44.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertNotNull(durationField47);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Period period14 = period10.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray15 = period14.getFieldTypes();
        boolean boolean16 = periodType3.equals((java.lang.Object) durationFieldTypeArray15);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology19);
        org.joda.time.Period period21 = period20.negated();
        org.joda.time.Period period23 = period20.plusMonths(0);
        org.joda.time.Period period25 = period23.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.Period period36 = new org.joda.time.Period((long) ' ');
        int[] intArray38 = gregorianChronology33.get((org.joda.time.ReadablePeriod) period36, (long) 0);
        org.joda.time.Minutes minutes39 = period36.toStandardMinutes();
        boolean boolean40 = fixedDateTimeZone30.equals((java.lang.Object) period36);
        org.joda.time.Period period42 = period36.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType44 = period36.getFieldType(1);
        int int45 = period23.indexOf(durationFieldType44);
        int int46 = periodType3.indexOf(durationFieldType44);
        int int47 = periodType0.indexOf(durationFieldType44);
        org.joda.time.field.PreciseDurationField preciseDurationField49 = new org.joda.time.field.PreciseDurationField(durationFieldType44, (long) 100);
        long long52 = preciseDurationField49.add(4190400101L, 0L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(minutes39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4190400101L + "'", long52 == 4190400101L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        java.lang.String str17 = lenientChronology16.toString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "LenientChronology[ZonedChronology[GregorianChronology[UTC], +00:00:00.100]]" + "'", str17.equals("LenientChronology[ZonedChronology[GregorianChronology[UTC], +00:00:00.100]]"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-4190400001L), "LenientChronology[ZonedChronology[GregorianChronology[UTC], +00:00:00.100]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        boolean boolean13 = dateTimeZone10.isStandardOffset(0L);
        java.lang.String str14 = dateTimeZone10.getID();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.100" + "'", str14.equals("+00:00:00.100"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.Period period8 = new org.joda.time.Period(42, (int) (byte) 0, (int) (byte) -1, 1, (int) (byte) 1, (int) (byte) 100, (int) '4', (int) (byte) 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Period period13 = period9.withYears((int) (short) 1);
        org.joda.time.Weeks weeks14 = period9.toStandardWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = period9.withPeriodType(periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType15);
        java.lang.String str18 = periodType15.toString();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 100, (long) ' ', periodType15);
        org.joda.time.PeriodType periodType20 = periodType15.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = periodType20.withYearsRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PeriodType[YearWeekDayTime]" + "'", str18.equals("PeriodType[YearWeekDayTime]"));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("P1YT0.032S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'P1YT0.032S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField68 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType62);
        boolean boolean69 = unsupportedDurationField68.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(unsupportedDurationField68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(4190400001L, "LenientChronology[ZonedChronology[GregorianChronology[UTC], +00:00:00.100]]");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField68 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType62);
        try {
            long long71 = unsupportedDurationField68.add(1425600000L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(unsupportedDurationField68);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period3 = period1.minusHours(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        int int16 = fixedDateTimeZone4.getStandardOffset((long) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int19 = fixedDateTimeZone4.getOffsetFromLocal(2440587L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        int int16 = fixedDateTimeZone4.getStandardOffset(0L);
        java.lang.Object obj17 = null;
        boolean boolean18 = fixedDateTimeZone4.equals(obj17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone4.getShortName((-42L), locale20);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.042" + "'", str21.equals("+00:00:00.042"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.Weeks weeks10 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period5.withPeriodType(periodType11);
        org.joda.time.Weeks weeks13 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType16 = periodType15.withWeeksRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withDaysRemoved();
        org.joda.time.PeriodType periodType18 = periodType16.withMinutesRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = iSOChronology19.weeks();
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, periodType18, (org.joda.time.Chronology) iSOChronology19);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period5, periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(2440592L, 3902400001L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3899959409L) + "'", long2 == (-3899959409L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        long long37 = preciseDurationField34.add((-3L), (int) (short) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.Period period48 = new org.joda.time.Period((long) ' ');
        int[] intArray50 = gregorianChronology45.get((org.joda.time.ReadablePeriod) period48, (long) 0);
        org.joda.time.Minutes minutes51 = period48.toStandardMinutes();
        boolean boolean52 = fixedDateTimeZone42.equals((java.lang.Object) period48);
        org.joda.time.Period period54 = period48.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType56 = period48.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField57 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType56);
        long long58 = unsupportedDurationField57.getUnitMillis();
        int int59 = preciseDurationField34.compareTo((org.joda.time.DurationField) unsupportedDurationField57);
        java.lang.String str60 = unsupportedDurationField57.toString();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3L) + "'", long37 == (-3L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(minutes51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertNotNull(unsupportedDurationField57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "UnsupportedDurationField[months]" + "'", str60.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        long long8 = gregorianChronology2.add((long) (short) -1, (long) '#', 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) chronology11, periodType13);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.Period period22 = new org.joda.time.Period((long) ' ');
        int[] intArray24 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period22, (long) 0);
        org.joda.time.Period period26 = period22.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Period period36 = period32.withYears((int) (short) 1);
        org.joda.time.Weeks weeks37 = period32.toStandardWeeks();
        org.joda.time.Period period38 = period26.plus((org.joda.time.ReadablePeriod) weeks37);
        org.joda.time.Period period39 = period16.withFields((org.joda.time.ReadablePeriod) period26);
        boolean boolean40 = gregorianChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
        java.lang.String str47 = dateTimeZone45.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Chronology chronology53 = iSOChronology48.withZone(dateTimeZone52);
        org.joda.time.DurationField durationField54 = iSOChronology48.weeks();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.Chronology chronology57 = iSOChronology48.withZone(dateTimeZone56);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone58 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone56);
        org.joda.time.Chronology chronology59 = gregorianChronology2.withZone(dateTimeZone56);
        org.joda.time.DurationField durationField60 = gregorianChronology2.eras();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3499L + "'", long8 == 3499L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(weeks37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.100" + "'", str47.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(cachedDateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(durationField60);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.Weeks weeks18 = period13.toStandardWeeks();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period20 = period13.withPeriodType(periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType19);
        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
        boolean boolean23 = period5.equals((java.lang.Object) periodType19);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period5.toDurationTo(readableInstant24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.minutes();
        boolean boolean31 = gregorianChronology28.equals((java.lang.Object) periodType30);
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration25, periodType30);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology36);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period39 = new org.joda.time.Period((java.lang.Object) chronology36, periodType38);
        org.joda.time.Period period40 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant33, periodType38);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Period period42 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant41);
        long long43 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration25);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(weeks18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        boolean boolean22 = period4.equals((java.lang.Object) periodType18);
        org.joda.time.Period period24 = period4.withYears(97);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.Period period8 = new org.joda.time.Period(100, (int) 'a', (int) '4', (int) '#', (-1), 0, (int) (byte) 100, (int) 'a');
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("+00:00");
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[GregorianChronology[UTC], +00:00:00.100]", 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("Pacific Standard Time", (-1), (int) (short) 100, (int) (short) 100, '#', 97, (-42), (-42), false, 520);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) chronology3, periodType5);
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = period6.normalizedStandard(periodType7);
        org.joda.time.Period period10 = period8.plusMillis(520);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period10.toDurationFrom(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology17);
        org.joda.time.Period period19 = period18.toPeriod();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.Period period27 = new org.joda.time.Period((long) ' ');
        int[] intArray29 = gregorianChronology24.get((org.joda.time.ReadablePeriod) period27, (long) 0);
        org.joda.time.Period period31 = period27.withYears((int) (short) 1);
        org.joda.time.Weeks weeks32 = period27.toStandardWeeks();
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period34 = period27.withPeriodType(periodType33);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant20, readableDuration21, periodType33);
        org.joda.time.PeriodType periodType36 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
        boolean boolean37 = period19.equals((java.lang.Object) periodType33);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Duration duration39 = period19.toDurationTo(readableInstant38);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone43 = gregorianChronology42.getZone();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.minutes();
        boolean boolean45 = gregorianChronology42.equals((java.lang.Object) periodType44);
        org.joda.time.Period period46 = new org.joda.time.Period(readableInstant14, (org.joda.time.ReadableDuration) duration39, periodType44);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) chronology50, periodType52);
        org.joda.time.Period period54 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration39, readableInstant47, periodType52);
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType52);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(weeks32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(duration39);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(periodType52);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long9 = dateTimeZone3.convertLocalToUTC((long) ' ', false);
        long long13 = dateTimeZone3.convertLocalToUTC(9L, false, (long) 100);
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = dateTimeZone3.isLocalDateTimeGap(localDateTime14);
        int int17 = dateTimeZone3.getOffsetFromLocal(43200000L);
        java.lang.String str19 = dateTimeZone3.getName((-210430958400000L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-68L) + "'", long9 == (-68L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-91L) + "'", long13 == (-91L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.100" + "'", str19.equals("+00:00:00.100"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        org.joda.time.Period period10 = period5.minusSeconds(0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) ' ');
        int[] intArray18 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period16, (long) 0);
        org.joda.time.Minutes minutes19 = period16.toStandardMinutes();
        int int20 = period16.getWeeks();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant21, readableInstant22);
        org.joda.time.format.PeriodFormatter periodFormatter24 = null;
        java.lang.String str25 = period23.toString(periodFormatter24);
        org.joda.time.Period period26 = period16.minus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period23.toDurationTo(readableInstant27);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.Period period36 = new org.joda.time.Period((long) ' ');
        int[] intArray38 = gregorianChronology33.get((org.joda.time.ReadablePeriod) period36, (long) 0);
        org.joda.time.Period period40 = period36.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray41 = period40.getFieldTypes();
        boolean boolean42 = periodType29.equals((java.lang.Object) durationFieldTypeArray41);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology45);
        org.joda.time.Period period47 = period46.negated();
        org.joda.time.Period period49 = period46.plusMonths(0);
        org.joda.time.Period period51 = period49.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone56 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology59.getZone();
        org.joda.time.Period period62 = new org.joda.time.Period((long) ' ');
        int[] intArray64 = gregorianChronology59.get((org.joda.time.ReadablePeriod) period62, (long) 0);
        org.joda.time.Minutes minutes65 = period62.toStandardMinutes();
        boolean boolean66 = fixedDateTimeZone56.equals((java.lang.Object) period62);
        org.joda.time.Period period68 = period62.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType70 = period62.getFieldType(1);
        int int71 = period49.indexOf(durationFieldType70);
        int int72 = periodType29.indexOf(durationFieldType70);
        org.joda.time.Period period74 = period23.withFieldAdded(durationFieldType70, (int) (short) -1);
        int int75 = period5.get(durationFieldType70);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField76 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType70);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(minutes19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PT0S" + "'", str25.equals("PT0S"));
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(durationFieldTypeArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(minutes65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(durationFieldType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField76);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.year();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) ' ');
        int[] intArray8 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period6, (long) 0);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = gregorianChronology6.equals((java.lang.Object) periodType8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period(2440587L, 100L, periodType3, (org.joda.time.Chronology) zonedChronology18);
        java.lang.String str21 = zonedChronology18.toString();
        try {
            long long27 = zonedChronology18.getDateTimeMillis((-2L), 0, 100, (int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +00:00:00.100]" + "'", str21.equals("ZonedChronology[GregorianChronology[UTC], +00:00:00.100]"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("Seconds", "PeriodType[YearWeekDayTimeNoMinutes]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.Number number12 = illegalFieldValueException10.getLowerBound();
        illegalFieldValueException7.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str14 = illegalFieldValueException7.getIllegalStringValue();
        java.lang.String str15 = illegalFieldValueException7.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str14.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str15.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        org.joda.time.DateTimeField dateTimeField17 = lenientChronology16.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology16.monthOfYear();
        org.joda.time.Chronology chronology19 = lenientChronology16.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 10, (int) (byte) 0, 100, (int) (byte) 100, (int) (byte) 100, (int) ' ', (int) (byte) 100, (int) (short) 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        try {
            int int25 = unsupportedDurationField19.getValue((long) 520, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "Pacific Standard Time", "months");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        int[] intArray9 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period7, (long) 0);
        org.joda.time.Period period11 = period7.withYears((int) (short) 1);
        org.joda.time.Weeks weeks12 = period7.toStandardWeeks();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period7.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType13);
        java.lang.String str16 = periodType13.toString();
        org.joda.time.PeriodType periodType17 = periodType13.withMillisRemoved();
        int int18 = periodType17.size();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PeriodType[YearWeekDayTime]" + "'", str16.equals("PeriodType[YearWeekDayTime]"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        java.lang.String str9 = dateTimeZone7.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology10.withZone(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology10.weeks();
        org.joda.time.DurationField durationField17 = iSOChronology10.weekyears();
        org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) period3, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType62, (long) (short) 1);
        java.lang.String str70 = preciseDurationField69.toString();
        long long73 = preciseDurationField69.add((-3L), (int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "DurationField[months]" + "'", str70.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 97L + "'", long73 == 97L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology10);
        org.joda.time.Period period12 = period11.toPeriod();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period((long) ' ');
        int[] intArray22 = gregorianChronology17.get((org.joda.time.ReadablePeriod) period20, (long) 0);
        org.joda.time.Period period24 = period20.withYears((int) (short) 1);
        org.joda.time.Weeks weeks25 = period20.toStandardWeeks();
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period27 = period20.withPeriodType(periodType26);
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType26);
        org.joda.time.PeriodType periodType29 = org.joda.time.DateTimeUtils.getPeriodType(periodType26);
        boolean boolean30 = period12.equals((java.lang.Object) periodType26);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period12.toDurationTo(readableInstant31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.minutes();
        boolean boolean38 = gregorianChronology35.equals((java.lang.Object) periodType37);
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration32, periodType37);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) chronology43, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration32, readableInstant40, periodType45);
        boolean boolean48 = fixedDateTimeZone4.equals((java.lang.Object) period47);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(weeks25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int20 = cachedDateTimeZone18.getOffset(28799999L);
        org.joda.time.ReadableInstant readableInstant21 = null;
        int int22 = cachedDateTimeZone18.getOffset(readableInstant21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Minutes minutes16 = period13.toStandardMinutes();
        org.joda.time.Period period18 = period13.minusSeconds(0);
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) period18, (long) 'a');
        org.joda.time.Period period21 = period18.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period18.toDurationTo(readableInstant22);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(minutes16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-3191L), locale7);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(2440588L);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(105433401600000L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone4.getName(0L, locale14);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = gregorianChronology8.equals((java.lang.Object) periodType10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        java.lang.String str17 = dateTimeZone15.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, dateTimeZone15);
        java.util.TimeZone timeZone21 = dateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology22 = lenientChronology4.withZone(dateTimeZone15);
        org.joda.time.JodaTimePermission jodaTimePermission24 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str25 = jodaTimePermission24.toString();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
        org.joda.time.Period period31 = new org.joda.time.Period((long) ' ');
        int[] intArray33 = gregorianChronology28.get((org.joda.time.ReadablePeriod) period31, (long) 0);
        org.joda.time.Period period35 = period31.withYears((int) (short) 1);
        org.joda.time.Weeks weeks36 = period31.toStandardWeeks();
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period38 = period31.withPeriodType(periodType37);
        jodaTimePermission24.checkGuard((java.lang.Object) period38);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long44 = dateTimeZone41.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology47.getZone();
        java.lang.String str50 = dateTimeZone48.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        long long55 = dateTimeZone48.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long57 = dateTimeZone41.getMillisKeepLocal(dateTimeZone48, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone58 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone41);
        java.util.TimeZone timeZone59 = cachedDateTimeZone58.toTimeZone();
        long long61 = cachedDateTimeZone58.previousTransition((-3191L));
        jodaTimePermission24.checkGuard((java.lang.Object) cachedDateTimeZone58);
        long long64 = dateTimeZone15.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone58, 0L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str25.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(weeks36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "+00:00:00.100" + "'", str50.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-101L) + "'", long55 == (-101L));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 4944L + "'", long57 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-3191L) + "'", long61 == (-3191L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[GregorianChronology[UTC], +00:00:00.100]", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Standard", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        org.joda.time.Period period15 = period10.minusSeconds(0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Period period21 = new org.joda.time.Period((long) ' ');
        int[] intArray23 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, (long) 0);
        org.joda.time.Minutes minutes24 = period21.toStandardMinutes();
        int int25 = period21.getWeeks();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.format.PeriodFormatter periodFormatter29 = null;
        java.lang.String str30 = period28.toString(periodFormatter29);
        org.joda.time.Period period31 = period21.minus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Duration duration33 = period28.toDurationTo(readableInstant32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType35 = periodType34.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology38.getZone();
        org.joda.time.Period period41 = new org.joda.time.Period((long) ' ');
        int[] intArray43 = gregorianChronology38.get((org.joda.time.ReadablePeriod) period41, (long) 0);
        org.joda.time.Period period45 = period41.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray46 = period45.getFieldTypes();
        boolean boolean47 = periodType34.equals((java.lang.Object) durationFieldTypeArray46);
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology50);
        org.joda.time.Period period52 = period51.negated();
        org.joda.time.Period period54 = period51.plusMonths(0);
        org.joda.time.Period period56 = period54.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology64.getZone();
        org.joda.time.Period period67 = new org.joda.time.Period((long) ' ');
        int[] intArray69 = gregorianChronology64.get((org.joda.time.ReadablePeriod) period67, (long) 0);
        org.joda.time.Minutes minutes70 = period67.toStandardMinutes();
        boolean boolean71 = fixedDateTimeZone61.equals((java.lang.Object) period67);
        org.joda.time.Period period73 = period67.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType75 = period67.getFieldType(1);
        int int76 = period54.indexOf(durationFieldType75);
        int int77 = periodType34.indexOf(durationFieldType75);
        org.joda.time.Period period79 = period28.withFieldAdded(durationFieldType75, (int) (short) -1);
        int int80 = period10.get(durationFieldType75);
        boolean boolean81 = periodType4.isSupported(durationFieldType75);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType75, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(minutes24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PT0S" + "'", str30.equals("PT0S"));
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(durationFieldTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(minutes70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(durationFieldType75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[GregorianChronology[UTC], +00:00:00.100]", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT0.032S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0.032S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        boolean boolean22 = unsupportedDurationField19.isSupported();
        try {
            int int25 = unsupportedDurationField19.getDifference(4161600002L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.Weeks weeks18 = period13.toStandardWeeks();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period20 = period13.withPeriodType(periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType19);
        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
        boolean boolean23 = period5.equals((java.lang.Object) periodType19);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period5.toDurationTo(readableInstant24);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
        org.joda.time.Period period34 = new org.joda.time.Period((long) ' ');
        int[] intArray36 = gregorianChronology31.get((org.joda.time.ReadablePeriod) period34, (long) 0);
        org.joda.time.Period period38 = period34.withYears((int) (short) 1);
        org.joda.time.Weeks weeks39 = period34.toStandardWeeks();
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period41 = period34.withPeriodType(periodType40);
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant27, readableDuration28, periodType40);
        org.joda.time.PeriodType periodType43 = org.joda.time.DateTimeUtils.getPeriodType(periodType40);
        org.joda.time.PeriodType periodType44 = periodType43.withMinutesRemoved();
        java.lang.String str45 = periodType44.toString();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period49 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.chrono.LenientChronology lenientChronology50 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DurationField durationField51 = iSOChronology48.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long56 = dateTimeZone53.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology59.getZone();
        java.lang.String str62 = dateTimeZone60.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        long long67 = dateTimeZone60.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long69 = dateTimeZone53.getMillisKeepLocal(dateTimeZone60, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone70 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone53);
        int int72 = cachedDateTimeZone70.getOffset(28799999L);
        org.joda.time.Chronology chronology73 = iSOChronology48.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone70);
        org.joda.time.Period period74 = new org.joda.time.Period((long) (byte) 1, periodType44, chronology73);
        org.joda.time.Period period75 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration25, periodType44);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(weeks18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(weeks39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PeriodType[YearWeekDayTimeNoMinutes]" + "'", str45.equals("PeriodType[YearWeekDayTimeNoMinutes]"));
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(lenientChronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+00:00:00.100" + "'", str62.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-101L) + "'", long67 == (-101L));
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 4944L + "'", long69 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(chronology73);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        jodaTimePermission1.checkGuard((java.lang.Object) period15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone18.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        java.lang.String str27 = dateTimeZone25.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        long long32 = dateTimeZone25.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long34 = dateTimeZone18.getMillisKeepLocal(dateTimeZone25, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        java.util.TimeZone timeZone36 = cachedDateTimeZone35.toTimeZone();
        long long38 = cachedDateTimeZone35.previousTransition((-3191L));
        jodaTimePermission1.checkGuard((java.lang.Object) cachedDateTimeZone35);
        org.joda.time.JodaTimePermission jodaTimePermission41 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str42 = jodaTimePermission41.toString();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.Period period48 = new org.joda.time.Period((long) ' ');
        int[] intArray50 = gregorianChronology45.get((org.joda.time.ReadablePeriod) period48, (long) 0);
        org.joda.time.Period period52 = period48.withYears((int) (short) 1);
        org.joda.time.Weeks weeks53 = period48.toStandardWeeks();
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period55 = period48.withPeriodType(periodType54);
        jodaTimePermission41.checkGuard((java.lang.Object) period55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology59.getZone();
        org.joda.time.Chronology chronology61 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology59);
        org.joda.time.DurationField durationField62 = gregorianChronology59.hours();
        org.joda.time.DurationField durationField63 = gregorianChronology59.months();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology59.secondOfDay();
        int int65 = gregorianChronology59.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology59);
        boolean boolean67 = jodaTimePermission41.equals((java.lang.Object) gregorianChronology59);
        boolean boolean68 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.100" + "'", str27.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-101L) + "'", long32 == (-101L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4944L + "'", long34 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-3191L) + "'", long38 == (-3191L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str42.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(weeks53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period7.withHours(0);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period7.get(durationFieldType12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.Period period24 = new org.joda.time.Period((long) ' ');
        int[] intArray26 = gregorianChronology21.get((org.joda.time.ReadablePeriod) period24, (long) 0);
        org.joda.time.Minutes minutes27 = period24.toStandardMinutes();
        boolean boolean28 = fixedDateTimeZone18.equals((java.lang.Object) period24);
        org.joda.time.Period period30 = period24.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType32 = period24.getFieldType(1);
        int int33 = period7.indexOf(durationFieldType32);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType32, (long) (short) 0);
        long long38 = preciseDurationField35.add((-3L), (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology41.getZone();
        org.joda.time.Period period44 = new org.joda.time.Period((long) ' ');
        int[] intArray46 = gregorianChronology41.get((org.joda.time.ReadablePeriod) period44, (long) 0);
        org.joda.time.Period period48 = period44.withYears((int) (short) 1);
        org.joda.time.Period period50 = period48.plusSeconds((int) ' ');
        int int51 = period48.getDays();
        org.joda.time.Period period53 = period48.plusDays((int) (short) 0);
        org.joda.time.Period period55 = period53.plusYears((int) (short) 10);
        boolean boolean56 = preciseDurationField35.equals((java.lang.Object) period55);
        boolean boolean57 = periodType0.equals((java.lang.Object) boolean56);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(minutes27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-3L) + "'", long38 == (-3L));
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long12 = fixedDateTimeZone4.nextTransition(4944L);
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4944L + "'", long12 == 4944L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = gregorianChronology7.equals((java.lang.Object) periodType9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        java.lang.String str16 = dateTimeZone14.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone14);
        org.joda.time.Chronology chronology20 = gregorianChronology2.withZone(dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        org.joda.time.Chronology chronology26 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.100" + "'", str16.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: Value \"WeeksNoWeeks\" for  is not supported' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        boolean boolean51 = preciseDurationField34.equals((java.lang.Object) dateTimeField50);
        java.lang.String str52 = preciseDurationField34.getName();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "months" + "'", str52.equals("months"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone19 = cachedDateTimeZone18.toTimeZone();
        long long21 = cachedDateTimeZone18.previousTransition((long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.Period period1 = org.joda.time.Period.hours(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        long long37 = preciseDurationField34.add((-3L), (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
        org.joda.time.Period period43 = new org.joda.time.Period((long) ' ');
        int[] intArray45 = gregorianChronology40.get((org.joda.time.ReadablePeriod) period43, (long) 0);
        org.joda.time.Period period47 = period43.withYears((int) (short) 1);
        org.joda.time.Period period49 = period47.plusSeconds((int) ' ');
        int int50 = period47.getDays();
        org.joda.time.Period period52 = period47.plusDays((int) (short) 0);
        org.joda.time.Period period54 = period52.plusYears((int) (short) 10);
        boolean boolean55 = preciseDurationField34.equals((java.lang.Object) period54);
        try {
            int int58 = preciseDurationField34.getValue((-31507200000L), 4161600002L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3L) + "'", long37 == (-3L));
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("months");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"months/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        boolean boolean20 = cachedDateTimeZone18.isFixed();
        java.lang.String str22 = cachedDateTimeZone18.getNameKey((long) 110);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) weeks20);
        org.joda.time.Period period23 = period21.minusSeconds((int) (short) 0);
        int int24 = period21.size();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) chronology6, periodType8);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = period9.normalizedStandard(periodType10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.Period period17 = new org.joda.time.Period((long) ' ');
        int[] intArray19 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period17, (long) 0);
        org.joda.time.Period period21 = period17.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        org.joda.time.Period period27 = new org.joda.time.Period((long) ' ');
        int[] intArray29 = gregorianChronology24.get((org.joda.time.ReadablePeriod) period27, (long) 0);
        org.joda.time.Period period31 = period27.withYears((int) (short) 1);
        org.joda.time.Weeks weeks32 = period27.toStandardWeeks();
        org.joda.time.Period period33 = period21.plus((org.joda.time.ReadablePeriod) weeks32);
        org.joda.time.Period period34 = period11.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period36 = period11.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology39.getZone();
        org.joda.time.Period period42 = new org.joda.time.Period((long) ' ');
        int[] intArray44 = gregorianChronology39.get((org.joda.time.ReadablePeriod) period42, (long) 0);
        org.joda.time.Period period46 = period42.withYears((int) (short) 1);
        org.joda.time.Weeks weeks47 = period42.toStandardWeeks();
        org.joda.time.PeriodType periodType48 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period49 = period42.withPeriodType(periodType48);
        org.joda.time.Period period50 = period36.minus((org.joda.time.ReadablePeriod) period42);
        int int51 = period42.getYears();
        org.joda.time.Weeks weeks52 = period42.toStandardWeeks();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) weeks52);
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology57);
        org.joda.time.Period period59 = period58.toPeriod();
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology64.getZone();
        org.joda.time.Period period67 = new org.joda.time.Period((long) ' ');
        int[] intArray69 = gregorianChronology64.get((org.joda.time.ReadablePeriod) period67, (long) 0);
        org.joda.time.Period period71 = period67.withYears((int) (short) 1);
        org.joda.time.Weeks weeks72 = period67.toStandardWeeks();
        org.joda.time.PeriodType periodType73 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period74 = period67.withPeriodType(periodType73);
        org.joda.time.Period period75 = new org.joda.time.Period(readableInstant60, readableDuration61, periodType73);
        org.joda.time.PeriodType periodType76 = org.joda.time.DateTimeUtils.getPeriodType(periodType73);
        boolean boolean77 = period59.equals((java.lang.Object) periodType73);
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.Duration duration79 = period59.toDurationTo(readableInstant78);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone80, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone83 = gregorianChronology82.getZone();
        org.joda.time.PeriodType periodType84 = org.joda.time.PeriodType.minutes();
        boolean boolean85 = gregorianChronology82.equals((java.lang.Object) periodType84);
        org.joda.time.Period period86 = new org.joda.time.Period(readableInstant54, (org.joda.time.ReadableDuration) duration79, periodType84);
        org.joda.time.Period period87 = new org.joda.time.Period((java.lang.Object) weeks52, periodType84);
        long long90 = gregorianChronology2.add((org.joda.time.ReadablePeriod) weeks52, (-3191L), 1);
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField96 = new org.joda.time.field.OffsetDateTimeField(dateTimeField91, dateTimeFieldType92, (int) '4', 1120, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(weeks32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(weeks47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(weeks52);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(weeks72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(duration79);
        org.junit.Assert.assertNotNull(gregorianChronology82);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(periodType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-3191L) + "'", long90 == (-3191L));
        org.junit.Assert.assertNotNull(dateTimeField91);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2440588L, true);
        long long10 = fixedDateTimeZone4.previousTransition((-4190400001L));
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        int int16 = fixedDateTimeZone4.getStandardOffset((long) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Class<?> wildcardClass18 = dateTimeZone17.getClass();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2440588L + "'", long8 == 2440588L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4190400001L) + "'", long10 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long4 = gregorianChronology0.add(100L, (-4190400001L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        java.lang.String str6 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4190400101L + "'", long4 == 4190400101L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gregorianChronology2.minutes();
        long long17 = durationField14.subtract(43200000L, (-62016883200000L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3721012992043200000L + "'", long17 == 3721012992043200000L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        java.lang.String str46 = decoratedDurationField44.toString();
        long long48 = decoratedDurationField44.getMillis(1);
        long long51 = decoratedDurationField44.getDifferenceAsLong((-68L), (-3191L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43200000L + "'", long48 == 43200000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone6.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        java.lang.String str15 = dateTimeZone13.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        long long20 = dateTimeZone13.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long22 = dateTimeZone6.getMillisKeepLocal(dateTimeZone13, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology24 = iSOChronology0.withZone(dateTimeZone6);
        long long26 = dateTimeZone6.convertUTCToLocal(349900L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-101L) + "'", long20 == (-101L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 4944L + "'", long22 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 349900L + "'", long26 == 349900L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-3191L), "Standard");
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DurationField durationField13 = iSOChronology6.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology6.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.Chronology chronology19 = iSOChronology6.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology6.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        long long48 = decoratedDurationField44.getDifferenceAsLong(28799999L, (long) 1120);
        long long51 = decoratedDurationField44.getMillis(10, (-42L));
        int int53 = decoratedDurationField44.getValue((-42L));
        long long56 = decoratedDurationField44.getDifferenceAsLong((-31507200000L), (-42L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 432000000L + "'", long51 == 432000000L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-729L) + "'", long56 == (-729L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.Period period13 = new org.joda.time.Period((long) ' ');
        int[] intArray15 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period13, (long) 0);
        org.joda.time.Period period17 = period13.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Weeks weeks28 = period23.toStandardWeeks();
        org.joda.time.Period period29 = period17.plus((org.joda.time.ReadablePeriod) weeks28);
        org.joda.time.Period period30 = period7.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period32 = period7.plusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((long) ' ');
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period38, (long) 0);
        org.joda.time.Period period42 = period38.withYears((int) (short) 1);
        org.joda.time.Weeks weeks43 = period38.toStandardWeeks();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period45 = period38.withPeriodType(periodType44);
        org.joda.time.Period period46 = period32.minus((org.joda.time.ReadablePeriod) period38);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology49);
        org.joda.time.Period period51 = period50.negated();
        org.joda.time.Period period53 = period50.plusMonths(0);
        org.joda.time.Period period55 = period53.plusYears(1);
        org.joda.time.Period period56 = period32.withFields((org.joda.time.ReadablePeriod) period55);
        org.joda.time.PeriodType periodType57 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone58, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology60.getZone();
        java.lang.String str63 = dateTimeZone61.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone65, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
        org.joda.time.Chronology chronology69 = iSOChronology64.withZone(dateTimeZone68);
        org.joda.time.DurationField durationField70 = iSOChronology64.weeks();
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.Chronology chronology73 = iSOChronology64.withZone(dateTimeZone72);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone74 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone72);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone72);
        org.joda.time.Chronology chronology76 = gregorianChronology75.withUTC();
        org.joda.time.Period period77 = new org.joda.time.Period((java.lang.Object) period55, periodType57, chronology76);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(weeks28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(weeks43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "+00:00:00.100" + "'", str63.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(cachedDateTimeZone74);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertNotNull(chronology76);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) ' ');
        int[] intArray8 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period6, (long) 0);
        org.joda.time.Period period10 = period6.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period10.getFieldTypes();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.forFields(durationFieldTypeArray11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.forFields(durationFieldTypeArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DurationField durationField19 = gregorianChronology16.hours();
        org.joda.time.DurationField durationField20 = gregorianChronology16.months();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology16.secondOfDay();
        int int22 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.Period period24 = new org.joda.time.Period((-105433329599968L), periodType13, chronology23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.months();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DurationFieldType durationFieldType33 = null;
        boolean boolean34 = period32.isSupported(durationFieldType33);
        org.joda.time.Period period36 = period32.withHours(0);
        org.joda.time.DurationFieldType durationFieldType37 = null;
        int int38 = period32.get(durationFieldType37);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology46.getZone();
        org.joda.time.Period period49 = new org.joda.time.Period((long) ' ');
        int[] intArray51 = gregorianChronology46.get((org.joda.time.ReadablePeriod) period49, (long) 0);
        org.joda.time.Minutes minutes52 = period49.toStandardMinutes();
        boolean boolean53 = fixedDateTimeZone43.equals((java.lang.Object) period49);
        org.joda.time.Period period55 = period49.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType57 = period49.getFieldType(1);
        int int58 = period32.indexOf(durationFieldType57);
        boolean boolean59 = periodType25.isSupported(durationFieldType57);
        boolean boolean60 = period24.isSupported(durationFieldType57);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(minutes52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.Period period4 = new org.joda.time.Period(0, 1120, (int) (byte) 10, 0);
        int int5 = period4.getHours();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.joda.time.Period period3 = period1.minusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Period period27 = period23.withYears((int) (short) 1);
        org.joda.time.Period period29 = period27.plusSeconds((int) ' ');
        int int30 = period27.getDays();
        long long33 = gregorianChronology17.add((org.joda.time.ReadablePeriod) period27, 28800032L, (int) (short) -1);
        int int34 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31507200000L) + "'", long33 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Seconds", "PeriodType[YearWeekDayTimeNoMinutes]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number6 = illegalFieldValueException5.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException5.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number9 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType62, (long) (short) 1);
        long long72 = preciseDurationField69.getMillis(10, (long) 42);
        long long75 = preciseDurationField69.getMillis((-4190400001L), 1560628447856L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-4190400001L) + "'", long75 == (-4190400001L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Period period9 = period5.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "WeeksNoWeeks", 0, 97);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        long long15 = fixedDateTimeZone11.convertLocalToUTC(2440588L, true);
        long long17 = fixedDateTimeZone11.previousTransition((-4190400001L));
        long long20 = fixedDateTimeZone11.convertLocalToUTC(0L, false);
        int int22 = fixedDateTimeZone11.getOffset(0L);
        java.lang.String str24 = fixedDateTimeZone11.getNameKey(1425600000L);
        org.joda.time.Chronology chronology25 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.Chronology chronology26 = lenientChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[+00:00:00.100]]" + "'", str5.equals("LenientChronology[ISOChronology[+00:00:00.100]]"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2440588L + "'", long15 == 2440588L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4190400001L) + "'", long17 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "WeeksNoWeeks" + "'", str24.equals("WeeksNoWeeks"));
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str5 = jodaTimePermission4.getName();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) chronology8, periodType10);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = period11.normalizedStandard(periodType12);
        org.joda.time.Period period15 = period13.plusMillis(520);
        org.joda.time.Period period17 = period15.withWeeks((int) (byte) 100);
        java.lang.String str18 = period17.toString();
        org.joda.time.Minutes minutes19 = period17.toStandardMinutes();
        org.joda.time.Period period21 = period17.withSeconds((int) (short) 10);
        jodaTimePermission4.checkGuard((java.lang.Object) period21);
        boolean boolean23 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P100WT0.520S" + "'", str18.equals("P100WT0.520S"));
        org.junit.Assert.assertNotNull(minutes19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        long long48 = decoratedDurationField44.add(28800097L, (long) 1120);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 48412800097L + "'", long48 == 48412800097L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PST", "Seconds");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "LenientChronology[ZonedChronology[GregorianChronology[UTC], +00:00:00.100]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.plusYears((int) '#');
        org.joda.time.Period period4 = period2.plusWeeks((int) (byte) 100);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period9 = new org.joda.time.Period(2440588L, 105433401600000L, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        boolean boolean11 = jodaTimePermission4.equals((java.lang.Object) period10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str2.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        org.joda.time.DurationFieldType durationFieldType46 = decoratedDurationField44.getType();
        long long49 = decoratedDurationField44.getMillis(42, 0L);
        long long51 = decoratedDurationField44.getValueAsLong((long) 1120);
        boolean boolean52 = decoratedDurationField44.isPrecise();
        boolean boolean53 = decoratedDurationField44.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(durationFieldType46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1814400000L + "'", long49 == 1814400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P1YT0.032S", "");
        illegalFieldValueException2.prependMessage("PT0.032S");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period5, (long) 0);
        org.joda.time.Minutes minutes8 = period5.toStandardMinutes();
        int int9 = period5.getWeeks();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableInstant11);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period15 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period5.minusWeeks(1);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.Period period28 = new org.joda.time.Period((long) ' ');
        int[] intArray30 = gregorianChronology25.get((org.joda.time.ReadablePeriod) period28, (long) 0);
        org.joda.time.Period period32 = period28.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray33 = period32.getFieldTypes();
        boolean boolean34 = periodType21.equals((java.lang.Object) durationFieldTypeArray33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology37);
        org.joda.time.Period period39 = period38.negated();
        org.joda.time.Period period41 = period38.plusMonths(0);
        org.joda.time.Period period43 = period41.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.Period period54 = new org.joda.time.Period((long) ' ');
        int[] intArray56 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period54, (long) 0);
        org.joda.time.Minutes minutes57 = period54.toStandardMinutes();
        boolean boolean58 = fixedDateTimeZone48.equals((java.lang.Object) period54);
        org.joda.time.Period period60 = period54.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType62 = period54.getFieldType(1);
        int int63 = period41.indexOf(durationFieldType62);
        int int64 = periodType21.indexOf(durationFieldType62);
        int int65 = periodType18.indexOf(durationFieldType62);
        org.joda.time.Period period67 = period5.withField(durationFieldType62, (-1));
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType62, (long) (short) 1);
        java.lang.String str70 = preciseDurationField69.toString();
        long long73 = preciseDurationField69.add(0L, 97);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(minutes57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(durationFieldType62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "DurationField[months]" + "'", str70.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 97L + "'", long73 == 97L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        java.lang.String str7 = dateTimeZone5.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology8.weeks();
        org.joda.time.Period period15 = new org.joda.time.Period(28805044L, (long) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.Duration duration16 = period15.toStandardDuration();
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28805034L) + "'", long17 == (-28805034L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.plusMonths(0);
        org.joda.time.Period period8 = period6.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.Period period19 = new org.joda.time.Period((long) ' ');
        int[] intArray21 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period19, (long) 0);
        org.joda.time.Minutes minutes22 = period19.toStandardMinutes();
        boolean boolean23 = fixedDateTimeZone13.equals((java.lang.Object) period19);
        org.joda.time.Period period25 = period19.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType27 = period19.getFieldType(1);
        int int28 = period6.indexOf(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "LenientChronology[ISOChronology[America/Los_Angeles]]");
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = illegalFieldValueException30.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(minutes22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(dateTimeFieldType31);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.hours();
        org.joda.time.DurationField durationField7 = gregorianChronology2.years();
        org.joda.time.DurationField durationField8 = gregorianChronology2.millis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 10);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) (-100));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        org.joda.time.DateTimeField dateTimeField17 = lenientChronology16.dayOfYear();
        org.joda.time.DurationField durationField18 = lenientChronology16.weeks();
        org.joda.time.Period period20 = org.joda.time.Period.days(0);
        boolean boolean21 = lenientChronology16.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        try {
            long long20 = zonedChronology14.getDateTimeMillis(37920420L, (int) (byte) 0, (int) (short) 0, (-42), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -42 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ');
        int[] intArray10 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period8, (long) 0);
        org.joda.time.Period period12 = period8.withYears((int) (short) 1);
        org.joda.time.Weeks weeks13 = period8.toStandardWeeks();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = period8.withPeriodType(periodType14);
        jodaTimePermission1.checkGuard((java.lang.Object) period15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone18.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
        java.lang.String str27 = dateTimeZone25.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        long long32 = dateTimeZone25.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long34 = dateTimeZone18.getMillisKeepLocal(dateTimeZone25, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        java.util.TimeZone timeZone36 = cachedDateTimeZone35.toTimeZone();
        long long38 = cachedDateTimeZone35.previousTransition((-3191L));
        jodaTimePermission1.checkGuard((java.lang.Object) cachedDateTimeZone35);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology42);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period45 = new org.joda.time.Period((java.lang.Object) chronology42, periodType44);
        org.joda.time.PeriodType periodType46 = null;
        org.joda.time.Period period47 = period45.normalizedStandard(periodType46);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
        org.joda.time.Period period53 = new org.joda.time.Period((long) ' ');
        int[] intArray55 = gregorianChronology50.get((org.joda.time.ReadablePeriod) period53, (long) 0);
        org.joda.time.Period period57 = period53.withYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone58, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology60.getZone();
        org.joda.time.Period period63 = new org.joda.time.Period((long) ' ');
        int[] intArray65 = gregorianChronology60.get((org.joda.time.ReadablePeriod) period63, (long) 0);
        org.joda.time.Period period67 = period63.withYears((int) (short) 1);
        org.joda.time.Weeks weeks68 = period63.toStandardWeeks();
        org.joda.time.Period period69 = period57.plus((org.joda.time.ReadablePeriod) weeks68);
        org.joda.time.Period period70 = period47.withFields((org.joda.time.ReadablePeriod) period57);
        org.joda.time.Period period71 = period70.toPeriod();
        boolean boolean72 = jodaTimePermission1.equals((java.lang.Object) period70);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\")"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.100" + "'", str27.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-101L) + "'", long32 == (-101L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4944L + "'", long34 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-3191L) + "'", long38 == (-3191L));
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(weeks68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Object obj0 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        illegalFieldValueException3.prependMessage("hi!");
        java.lang.String str6 = illegalFieldValueException3.getFieldName();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) str6);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Period period9 = new org.joda.time.Period((long) ' ');
        int[] intArray11 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period9, (long) 0);
        org.joda.time.Minutes minutes12 = period9.toStandardMinutes();
        org.joda.time.Period period14 = period9.minusSeconds(0);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period((long) ' ');
        int[] intArray22 = gregorianChronology17.get((org.joda.time.ReadablePeriod) period20, (long) 0);
        org.joda.time.Minutes minutes23 = period20.toStandardMinutes();
        int int24 = period20.getWeeks();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableInstant26);
        org.joda.time.format.PeriodFormatter periodFormatter28 = null;
        java.lang.String str29 = period27.toString(periodFormatter28);
        org.joda.time.Period period30 = period20.minus((org.joda.time.ReadablePeriod) period27);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period27.toDurationTo(readableInstant31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = periodType33.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.Period period40 = new org.joda.time.Period((long) ' ');
        int[] intArray42 = gregorianChronology37.get((org.joda.time.ReadablePeriod) period40, (long) 0);
        org.joda.time.Period period44 = period40.withYears((int) (short) 1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray45 = period44.getFieldTypes();
        boolean boolean46 = periodType33.equals((java.lang.Object) durationFieldTypeArray45);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology49);
        org.joda.time.Period period51 = period50.negated();
        org.joda.time.Period period53 = period50.plusMonths(0);
        org.joda.time.Period period55 = period53.plusYears(1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone60 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone64 = gregorianChronology63.getZone();
        org.joda.time.Period period66 = new org.joda.time.Period((long) ' ');
        int[] intArray68 = gregorianChronology63.get((org.joda.time.ReadablePeriod) period66, (long) 0);
        org.joda.time.Minutes minutes69 = period66.toStandardMinutes();
        boolean boolean70 = fixedDateTimeZone60.equals((java.lang.Object) period66);
        org.joda.time.Period period72 = period66.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType74 = period66.getFieldType(1);
        int int75 = period53.indexOf(durationFieldType74);
        int int76 = periodType33.indexOf(durationFieldType74);
        org.joda.time.Period period78 = period27.withFieldAdded(durationFieldType74, (int) (short) -1);
        int int79 = period9.get(durationFieldType74);
        boolean boolean80 = periodType3.isSupported(durationFieldType74);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField81 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType74);
        java.lang.String str82 = unsupportedDurationField81.getName();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(minutes12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(minutes23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PT0S" + "'", str29.equals("PT0S"));
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(durationFieldTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(minutes69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(durationFieldType74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(period78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "months" + "'", str82.equals("months"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PeriodType[Standard]", (-1), (int) (byte) 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[GregorianChronology[UTC], +00:00:00.100]", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 0);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("UnsupportedDurationField[months]", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(1120);
        org.joda.time.Period period2 = period1.toPeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.Period period2 = new org.joda.time.Period((-62137491565000L), 105433401600000L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology2.era();
        org.joda.time.DurationField durationField15 = gregorianChronology2.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology2.hourOfDay();
        try {
            long long21 = gregorianChronology2.getDateTimeMillis((int) (byte) -1, (-100), (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        org.joda.time.DateTimeField dateTimeField17 = lenientChronology16.dayOfYear();
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = lenientChronology16.millis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long20 = unsupportedDurationField19.getUnitMillis();
        java.lang.String str21 = unsupportedDurationField19.getName();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField19.getType();
        long long23 = unsupportedDurationField19.getUnitMillis();
        try {
            int int26 = unsupportedDurationField19.getDifference((long) 0, 1000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "months" + "'", str21.equals("months"));
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        long long8 = fixedDateTimeZone4.convertLocalToUTC(0L, true, 28800009L);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-42L) + "'", long8 == (-42L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Seconds" + "'", str10.equals("Seconds"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        boolean boolean26 = dateTimeZone24.isStandardOffset(28800032L);
        long long28 = cachedDateTimeZone18.getMillisKeepLocal(dateTimeZone24, 4190400101L);
        long long30 = cachedDateTimeZone18.previousTransition(43200000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4190400001L + "'", long28 == 4190400001L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43200000L + "'", long30 == 43200000L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), 0);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        boolean boolean3 = dateTimeZone1.isStandardOffset(28800032L);
        java.lang.String str4 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.100" + "'", str4.equals("+00:00:00.100"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (long) 6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(520);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Period period19 = period15.withYears((int) (short) 1);
        org.joda.time.Weeks weeks20 = period15.toStandardWeeks();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period22 = period15.withPeriodType(periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType21);
        org.joda.time.PeriodType periodType24 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period(0, (int) (byte) 0, (int) '4', (int) '#', 42, 97, (int) (short) 10, 0, periodType21);
        org.joda.time.Period period27 = org.joda.time.Period.weeks((int) ' ');
        org.joda.time.Period period28 = period25.withFields((org.joda.time.ReadablePeriod) period27);
        java.lang.Class<?> wildcardClass29 = period27.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period7.withHours(0);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period7.get(durationFieldType12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.Period period24 = new org.joda.time.Period((long) ' ');
        int[] intArray26 = gregorianChronology21.get((org.joda.time.ReadablePeriod) period24, (long) 0);
        org.joda.time.Minutes minutes27 = period24.toStandardMinutes();
        boolean boolean28 = fixedDateTimeZone18.equals((java.lang.Object) period24);
        org.joda.time.Period period30 = period24.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType32 = period24.getFieldType(1);
        int int33 = period7.indexOf(durationFieldType32);
        boolean boolean34 = periodType0.isSupported(durationFieldType32);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField35 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType32);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(minutes27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField35);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        long long47 = decoratedDurationField44.add(5044L, (long) 8);
        org.joda.time.DurationFieldType durationFieldType48 = decoratedDurationField44.getType();
        long long51 = decoratedDurationField44.add((-1L), (int) (short) 0);
        long long54 = decoratedDurationField44.getMillis(48412800097L, 37920420L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 345605044L + "'", long47 == 345605044L);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2091432964190400000L + "'", long54 == 2091432964190400000L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        java.lang.String str21 = unsupportedDurationField19.toString();
        try {
            int int24 = unsupportedDurationField19.getValue(43200000L, (-259200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDurationField[months]" + "'", str21.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.plusYears((int) '#');
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType1);
        org.joda.time.Period period5 = period3.minusMinutes(0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Time" + "'", str1.equals("Time"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.months();
        org.joda.time.DurationField durationField7 = gregorianChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str3 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "WeeksNoWeeks");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getIllegalNumberValue();
        java.lang.String str8 = illegalFieldValueException6.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException6.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WeeksNoWeeks" + "'", str3.equals("WeeksNoWeeks"));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        long long37 = preciseDurationField34.add((-3L), (int) (short) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.Period period48 = new org.joda.time.Period((long) ' ');
        int[] intArray50 = gregorianChronology45.get((org.joda.time.ReadablePeriod) period48, (long) 0);
        org.joda.time.Minutes minutes51 = period48.toStandardMinutes();
        boolean boolean52 = fixedDateTimeZone42.equals((java.lang.Object) period48);
        org.joda.time.Period period54 = period48.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType56 = period48.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField57 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType56);
        long long58 = unsupportedDurationField57.getUnitMillis();
        int int59 = preciseDurationField34.compareTo((org.joda.time.DurationField) unsupportedDurationField57);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone60, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology62.getZone();
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        long long67 = gregorianChronology62.add(readablePeriod64, (long) (-1), 0);
        org.joda.time.DurationField durationField68 = gregorianChronology62.halfdays();
        int int69 = unsupportedDurationField57.compareTo(durationField68);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3L) + "'", long37 == (-3L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(minutes51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertNotNull(unsupportedDurationField57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-1L) + "'", long67 == (-1L));
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, false);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        java.lang.String str10 = dateTimeZone8.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long15 = dateTimeZone8.convertLocalToUTC((long) (short) -1, true, (long) (short) -1);
        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 5044L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        long long21 = cachedDateTimeZone18.nextTransition(28800032L);
        boolean boolean23 = cachedDateTimeZone18.equals((java.lang.Object) 0.0d);
        int int25 = cachedDateTimeZone18.getOffset((-3899959409L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.100" + "'", str10.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-101L) + "'", long15 == (-101L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4944L + "'", long17 == 4944L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800032L + "'", long21 == 28800032L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) (-1), 0);
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        long long5 = iSOChronology1.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField8 = iSOChronology1.centuries();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (org.joda.time.Chronology) iSOChronology1);
        try {
            long long17 = iSOChronology1.getDateTimeMillis((int) ' ', (int) (byte) 10, 100, 8, (int) (byte) 1, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        long long37 = preciseDurationField34.add((-3L), (int) (short) 100);
        long long40 = preciseDurationField34.getMillis((long) 0, 97L);
        try {
            long long43 = preciseDurationField34.getDifferenceAsLong(37920420L, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3L) + "'", long37 == (-3L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        java.lang.String str11 = dateTimeZone9.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = zonedChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology14.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology2, periodType4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        try {
            org.joda.time.Period period9 = period5.withYears((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        illegalFieldValueException2.prependMessage("LenientChronology[ISOChronology[+00:00:00.100]]");
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(43200000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440588.0d + "'", double1 == 2440588.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, (long) (byte) 0, chronology3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) chronology3, periodType5);
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = period6.normalizedStandard(periodType7);
        org.joda.time.Period period10 = period8.plusMillis(520);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period10.toDurationFrom(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.Period period21 = new org.joda.time.Period((long) ' ');
        int[] intArray23 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, (long) 0);
        org.joda.time.Period period25 = period21.withYears((int) (short) 1);
        org.joda.time.Weeks weeks26 = period21.toStandardWeeks();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period28 = period21.withPeriodType(periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType27);
        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
        org.joda.time.PeriodType periodType31 = periodType30.withMinutesRemoved();
        org.joda.time.PeriodType periodType32 = periodType31.withMonthsRemoved();
        org.joda.time.Period period33 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType32);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(weeks26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str9 = illegalFieldValueException8.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ');
        int[] intArray12 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period10, (long) 0);
        org.joda.time.Minutes minutes13 = period10.toStandardMinutes();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period10);
        org.joda.time.Period period16 = period10.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType(1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = unsupportedDurationField19.getType();
        try {
            long long23 = unsupportedDurationField19.getMillis((-1), (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        boolean boolean51 = preciseDurationField34.equals((java.lang.Object) dateTimeField50);
        long long54 = preciseDurationField34.getMillis(0, 1L);
        boolean boolean55 = preciseDurationField34.isSupported();
        long long57 = preciseDurationField34.getMillis((int) (short) 100);
        long long60 = preciseDurationField34.getMillis((long) (short) -1, (-62137491565000L));
        long long63 = preciseDurationField34.add(4944L, (long) (byte) 0);
        try {
            long long65 = preciseDurationField34.getValueAsLong((-4190400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 4944L + "'", long63 == 4944L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period(2440587L, 0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.Object obj5 = null;
        boolean boolean6 = lenientChronology4.equals(obj5);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1120);
        java.lang.String str11 = offsetDateTimeField9.getAsText((-729L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3090" + "'", str11.equals("3090"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        java.util.TimeZone timeZone17 = dateTimeZone14.toTimeZone();
        java.lang.String str19 = dateTimeZone14.getShortName((long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.100" + "'", str19.equals("+00:00:00.100"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) -1, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.withSeconds(8);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        java.lang.String str46 = decoratedDurationField44.toString();
        long long48 = decoratedDurationField44.getMillis(1);
        org.joda.time.DurationField durationField49 = decoratedDurationField44.getWrappedField();
        long long52 = decoratedDurationField44.getMillis(0L, (long) 33);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43200000L + "'", long48 == 43200000L);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfHalfday();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 33, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        boolean boolean51 = preciseDurationField34.equals((java.lang.Object) dateTimeField50);
        long long54 = preciseDurationField34.getMillis(0, 1L);
        boolean boolean55 = preciseDurationField34.isSupported();
        long long57 = preciseDurationField34.getMillis((int) (short) 100);
        long long60 = preciseDurationField34.getMillis((long) (short) -1, (-62137491565000L));
        long long63 = preciseDurationField34.add(4944L, (long) (byte) 0);
        long long64 = preciseDurationField34.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 4944L + "'", long63 == 4944L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (-31507200000L));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology39.getZone();
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        boolean boolean43 = period41.isSupported(durationFieldType42);
        org.joda.time.Period period45 = period41.withHours(0);
        org.joda.time.DurationFieldType durationFieldType46 = null;
        int int47 = period41.get(durationFieldType46);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone52 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone56 = gregorianChronology55.getZone();
        org.joda.time.Period period58 = new org.joda.time.Period((long) ' ');
        int[] intArray60 = gregorianChronology55.get((org.joda.time.ReadablePeriod) period58, (long) 0);
        org.joda.time.Minutes minutes61 = period58.toStandardMinutes();
        boolean boolean62 = fixedDateTimeZone52.equals((java.lang.Object) period58);
        org.joda.time.Period period64 = period58.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType66 = period58.getFieldType(1);
        int int67 = period41.indexOf(durationFieldType66);
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType66, (-31507200000L));
        int int70 = preciseDurationField34.compareTo((org.joda.time.DurationField) preciseDurationField69);
        boolean boolean71 = preciseDurationField34.isPrecise();
        try {
            long long73 = preciseDurationField34.getMillis(1814400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1814400000 * -31507200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(minutes61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(durationFieldType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) periodType4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DurationField durationField12 = gregorianChronology9.hours();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        boolean boolean14 = gregorianChronology4.equals((java.lang.Object) durationField13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology4.dayOfWeek();
        java.lang.String str16 = gregorianChronology4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[+00:00:00.100,mdfw=1]" + "'", str16.equals("GregorianChronology[+00:00:00.100,mdfw=1]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.Period period1 = org.joda.time.Period.years((-42));
        int int2 = period1.size();
        org.joda.time.Period period4 = period1.plusHours((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.joda.time.Period period10 = period6.withHours(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period6.get(durationFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((long) ' ');
        int[] intArray25 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period23, (long) 0);
        org.joda.time.Minutes minutes26 = period23.toStandardMinutes();
        boolean boolean27 = fixedDateTimeZone17.equals((java.lang.Object) period23);
        org.joda.time.Period period29 = period23.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType31 = period23.getFieldType(1);
        int int32 = period6.indexOf(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = gregorianChronology37.add(readablePeriod39, (long) (-1), 0);
        org.joda.time.DurationField durationField43 = gregorianChronology37.halfdays();
        long long46 = durationField43.subtract((-1L), 97);
        int int47 = preciseDurationField34.compareTo(durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        boolean boolean51 = preciseDurationField34.equals((java.lang.Object) dateTimeField50);
        long long54 = preciseDurationField34.getMillis(0, 1L);
        boolean boolean55 = preciseDurationField34.isSupported();
        long long57 = preciseDurationField34.getMillis((int) (short) 100);
        long long60 = preciseDurationField34.getMillis((long) (short) -1, (-62137491565000L));
        long long61 = preciseDurationField34.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(minutes26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4190400001L) + "'", long46 == (-4190400001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) '#');
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ');
        int[] intArray14 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (long) 0);
        org.joda.time.Period period16 = period12.withYears((int) (short) 1);
        org.joda.time.Weeks weeks17 = period12.toStandardWeeks();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period19 = period12.withPeriodType(periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType18);
        org.joda.time.Period period21 = period4.withPeriodType(periodType18);
        org.joda.time.PeriodType periodType22 = period4.getPeriodType();
        org.joda.time.PeriodType periodType23 = org.joda.time.DateTimeUtils.getPeriodType(periodType22);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        boolean boolean8 = gregorianChronology2.equals((java.lang.Object) periodType6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Period period6 = new org.joda.time.Period((long) ' ');
        int[] intArray8 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period6, (long) 0);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) ' ');
        int[] intArray17 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (long) 0);
        org.joda.time.Minutes minutes18 = period15.toStandardMinutes();
        int int19 = period15.getWeeks();
        org.joda.time.Period period20 = period9.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period22 = period20.plusYears((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(minutes18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        java.lang.String str5 = dateTimeZone3.getShortName((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, 0L, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period15.isSupported(durationFieldType16);
        org.joda.time.Period period19 = period15.withHours(0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("PST", "Seconds", 42, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) ' ');
        int[] intArray34 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period32, (long) 0);
        org.joda.time.Minutes minutes35 = period32.toStandardMinutes();
        boolean boolean36 = fixedDateTimeZone26.equals((java.lang.Object) period32);
        org.joda.time.Period period38 = period32.withMillis(97);
        org.joda.time.DurationFieldType durationFieldType40 = period32.getFieldType(1);
        int int41 = period15.indexOf(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
        boolean boolean45 = decoratedDurationField44.isPrecise();
        java.lang.String str46 = decoratedDurationField44.toString();
        long long48 = decoratedDurationField44.getMillis(1);
        long long51 = decoratedDurationField44.getDifferenceAsLong((-3L), 100L);
        long long54 = decoratedDurationField44.add((long) '#', 6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DurationField[months]" + "'", str46.equals("DurationField[months]"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43200000L + "'", long48 == 43200000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 259200035L + "'", long54 == 259200035L);
    }
}

