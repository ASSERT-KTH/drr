import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 100, (int) 'a', (int) (short) 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 100, (int) (short) -1, 100);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long7 = iSOChronology1.getDateTimeMillis((long) (byte) 0, (int) (short) -1, 100, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = iSOChronology1.get(readablePeriod3, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 0, (int) '#', (int) (byte) 100, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 1, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(10L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.years();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology13.years();
        long long17 = durationField14.subtract(1L, (int) (short) 1);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField11, durationField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31535999999L) + "'", long17 == (-31535999999L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 959);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 4L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = offsetDateTimeField4.getAsShortText(readablePartial9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        java.io.Writer writer4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        try {
            dateTimeFormatter0.printTo(writer4, readableInstant5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray10 = new int[] { 100, 6, (byte) -1, 10, (short) 0 };
        try {
            iSOChronology1.validate(readablePartial4, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(2, (int) (byte) 10, (int) ' ', 100, 4, (int) (short) 100, 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gregorianChronology1.getDateTimeMillis((int) (byte) 100, 0, (-25200000), (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) 10);
        int int7 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.minuteOfDay();
        org.joda.time.DateTime dateTime14 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) yearMonthDay15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 100, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        int int8 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(0L);
//        int int11 = dateTime7.getSecondOfMinute();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-25200000) + "'", int8 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (byte) 0, 39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39 + "'", int3 == 39);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.minuteOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DurationField durationField8 = iSOChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        long long9 = offsetDateTimeField4.roundHalfCeiling((long) 2);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) (short) 10);
//        int int14 = dateTime11.getMonthOfYear();
//        org.joda.time.DateTime.Property property15 = dateTime11.millisOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime11.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime17.withChronology((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        int[] intArray26 = new int[] { '#', 'a' };
//        try {
//            int[] intArray28 = offsetDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay22, 0, intArray26, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) 10);
        int int15 = dateTime12.getMonthOfYear();
        org.joda.time.DateTime.Property property16 = dateTime12.millisOfDay();
        org.joda.time.DateTime dateTime18 = dateTime12.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfDay();
        org.joda.time.DateTime dateTime22 = dateTime18.withChronology((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        int[] intArray31 = new int[] { (byte) 1, 'a', (byte) 0, 2, 959, 2 };
        try {
            int[] intArray33 = offsetDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay23, 1, intArray31, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        int int6 = dateTime3.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '4', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560634745675L + "'", long0 == 1560634745675L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePeriod3, 0L, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', 1, (int) (byte) 1, (int) '#', (int) ' ', 2, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Pacific Standard Time");
        java.lang.String str11 = illegalFieldValueException10.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', 10, (int) (short) 100, 1, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        long long5 = durationField2.subtract(1L, (int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31535999999L) + "'", long5 == (-31535999999L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        int int10 = offsetDateTimeField4.getLeapAmount((long) 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType11, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis(100, (int) (byte) 100, (int) ' ', (int) (short) 1, 959, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
//        long long12 = offsetDateTimeField4.roundFloor(4L);
//        java.util.Locale locale15 = null;
//        try {
//            long long16 = offsetDateTimeField4.set((long) 0, "ISOChronology[America/Los_Angeles]", locale15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(5, (-25200000), (int) (short) 0, (int) (short) 1, (int) (short) 100, 4, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime8.withDate((int) 'a', (int) '4', (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-25200000) + "'", int6 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 10, (long) 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20190 + "'", int2 == 20190);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = iSOChronology1.add(readablePeriod4, (long) 2, (-1));
        org.joda.time.DurationField durationField8 = iSOChronology1.hours();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = iSOChronology1.get(readablePeriod9, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(39, (int) (byte) 0, 2, 5, (int) 'a', dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withTime(100, 0, 20190, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withHourOfDay(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(0);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-25200000) + "'", int6 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withZone(dateTimeZone6);
//        try {
//            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (byte) -1, 0, 879, (int) '4', 2019, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("879", (int) (byte) 100, 5, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for 879 must be in the range [5,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        int int6 = property5.get();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) (short) 10);
//        int int11 = dateTime8.getMonthOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime8.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime14.withChronology((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        try {
//            int int20 = property5.compareTo((org.joda.time.ReadablePartial) yearMonthDay19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52750580 + "'", int6 == 52750580);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField12 = iSOChronology9.centuries();
        java.lang.Class<?> wildcardClass13 = durationField12.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
//        boolean boolean11 = property9.isLeap();
//        org.joda.time.DurationField durationField12 = property9.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMonthOfYear(6);
//        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfMonth((int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) (short) 100, locale21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        int int25 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.minus(readableDuration26);
//        org.joda.time.DateTime.Property property28 = dateTime27.year();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.minus(readablePeriod29);
//        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
//        org.joda.time.DateTime dateTime32 = dateTime18.withFields((org.joda.time.ReadablePartial) localTime31);
//        try {
//            int int33 = property9.compareTo((org.joda.time.ReadablePartial) localTime31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-25200000) + "'", int6 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-25200000) + "'", int25 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("1969-12-31T15:59:59", 1, (int) 'a', 52750, ' ', 2019, (int) (byte) 1, 0, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1969-12-31T15:59:59", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-12-31T15:59:59/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(0);
        java.lang.StringBuffer stringBuffer5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfDay();
        org.joda.time.DateTime dateTime17 = dateTime13.withChronology((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer5, (org.joda.time.ReadablePartial) yearMonthDay18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 2019);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withDayOfYear(970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 970 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 2, (-1));
        org.joda.time.DurationField durationField9 = iSOChronology2.hours();
        org.joda.time.DurationField durationField10 = iSOChronology2.halfdays();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 2019, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2023L + "'", long2 == 2023L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.addWrapField((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (-25200000));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, (int) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2100004L + "'", long10 == 2100004L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gregorianChronology1.get(readablePeriod4, (long) 'a', 60960L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = iSOChronology9.get(readablePeriod12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
//        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
//        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfDay();
//        org.joda.time.DurationField durationField21 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTime dateTime24 = dateTime17.withChronology((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (short) 100, locale27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(0L);
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime17, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-25200000) + "'", int31 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (short) 10);
//        int int8 = dateTime5.getMonthOfYear();
//        org.joda.time.DateTime.Property property9 = dateTime5.millisOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime5.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        java.lang.String str13 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDateTime12);
//        java.io.Writer writer14 = null;
//        try {
//            dateTimeFormatter2.printTo(writer14, (long) 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5219-W24-6" + "'", str13.equals("5219-W24-6"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            java.lang.String str5 = dateTime3.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField4.getWrappedField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, 0, 2019, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [2019,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
//        long long9 = offsetDateTimeField4.roundHalfEven((long) (byte) 0);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        java.util.Locale locale11 = null;
//        try {
//            java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial10, locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        long long4 = dateTimeZone0.convertUTCToLocal((long) ' ');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-28799968L) + "'", long4 == (-28799968L));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        long long7 = iSOChronology1.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = iSOChronology1.millis();
        org.joda.time.DurationField durationField9 = iSOChronology1.millis();
        org.joda.time.DurationField durationField10 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60960L + "'", long7 == 60960L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 39);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
//        int int12 = offsetDateTimeField4.get(660001L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType13, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 970 + "'", int12 == 970);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(52, 0, 52743869, 4, (int) (byte) 1, (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 2023L, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
//        java.lang.String str5 = dateTimeFormatter0.print((long) (short) -1);
//        try {
//            org.joda.time.LocalTime localTime7 = dateTimeFormatter0.parseLocalTime("57600039");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57600039\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T15:59:59" + "'", str5.equals("1969-12-31T15:59:59"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        int int9 = dateTime5.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
//        boolean boolean11 = property9.isLeap();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) 10);
//        int int16 = dateTime13.getMonthOfYear();
//        int int17 = property9.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime19 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 39, 20190);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        long long10 = offsetDateTimeField4.addWrapField((long) 4, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (-25200000));
//        long long14 = offsetDateTimeField12.roundHalfEven(2100004L);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 100, locale17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.minus(readableDuration22);
//        org.joda.time.DateTime.Property property24 = dateTime23.year();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.minus(readablePeriod25);
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks((int) (short) 10);
//        int int33 = dateTime30.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
//        long long41 = offsetDateTimeField38.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "Pacific Standard Time");
//        org.joda.time.DateTime dateTime46 = dateTime30.withField(dateTimeFieldType42, 0);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.minuteOfDay();
//        org.joda.time.DurationField durationField50 = iSOChronology48.halfdays();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology48.secondOfMinute();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.DateTime dateTime53 = dateTime46.withChronology((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter54.withZone(dateTimeZone55);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter56.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime61 = dateTime59.plusWeeks((int) (short) 10);
//        int int62 = dateTime59.getMonthOfYear();
//        org.joda.time.DateTime.Property property63 = dateTime59.millisOfDay();
//        org.joda.time.DateTime dateTime65 = dateTime59.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
//        java.lang.String str67 = dateTimeFormatter56.print((org.joda.time.ReadablePartial) localDateTime66);
//        int[] intArray69 = iSOChronology48.get((org.joda.time.ReadablePartial) localDateTime66, (long) (-28800000));
//        java.util.Locale locale71 = null;
//        try {
//            int[] intArray72 = offsetDateTimeField12.set((org.joda.time.ReadablePartial) localTime27, (int) (short) 0, intArray69, "����-W��-�", locale71);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-W��-�\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2100004L + "'", long10 == 2100004L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2100000L + "'", long14 == 2100000L);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 600001L + "'", long41 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localDateTime66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "5270-W01-2" + "'", str67.equals("5270-W01-2"));
//        org.junit.Assert.assertNotNull(intArray69);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        java.lang.String str8 = offsetDateTimeField4.getName();
        java.util.Locale locale11 = null;
        try {
            long long12 = offsetDateTimeField4.set(0L, "", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "minuteOfDay" + "'", str8.equals("minuteOfDay"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DurationField durationField12 = iSOChronology9.centuries();
//        org.joda.time.DurationField durationField13 = iSOChronology9.days();
//        org.joda.time.DurationField durationField14 = iSOChronology9.millis();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("1969-12-31T15:59:59", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property7 = dateTime1.era();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis((int) (short) 100);
//        int int11 = dateTime8.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime1.withTime(6, (-25200000), (int) (byte) -1, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DurationField durationField5 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.minuteOfHour();
        org.joda.time.DurationField durationField7 = iSOChronology1.seconds();
        try {
            long long13 = iSOChronology1.getDateTimeMillis((long) (short) 0, (-28800000), (-25200000), 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "879");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology2.halfdays();
        org.joda.time.DurationField durationField5 = iSOChronology2.seconds();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) gregorianChronology0, chronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("398");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2, 1438, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) 10);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone0, (java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 100, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        int int8 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.minus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime10.year();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
//        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localTime14);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
//        int int10 = dateTime7.getMonthOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
//        int int12 = property11.getMinimumValue();
//        int int13 = property11.getMaximumValue();
//        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
//        java.lang.String str15 = dateTime14.toString();
//        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = property5.withMinimumValue();
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withHourOfDay((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-15T14:39:17.136-07:00" + "'", str15.equals("2019-06-15T14:39:17.136-07:00"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField4.set((-30263155621999L), "14:39:13.631", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"14:39:13.631\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withYear(959);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-31535999999L));
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField4.getWrappedField();
//        boolean boolean9 = offsetDateTimeField4.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(6);
//        org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth((int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) 10);
//        int int20 = dateTime17.getMonthOfYear();
//        org.joda.time.DateTime.Property property21 = dateTime17.millisOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime17.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
//        org.joda.time.DateTime dateTime25 = dateTime15.withFields((org.joda.time.ReadablePartial) localDateTime24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDateTime24, 4, locale27);
//        long long31 = offsetDateTimeField4.add(60000L, 682);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "4" + "'", str28.equals("4"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 40980000L + "'", long31 == 40980000L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 39, dateTimeZone3);
        int int5 = dateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        long long9 = offsetDateTimeField4.roundHalfCeiling((long) 2);
//        long long11 = offsetDateTimeField4.roundHalfEven((long) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("����-W��-�");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-W��-�\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(52750);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52750) + "'", int1 == (-52750));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.DurationField durationField4 = iSOChronology1.weekyears();
        org.joda.time.DurationField durationField5 = iSOChronology1.days();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.addWrapField((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (-25200000));
        int int14 = offsetDateTimeField4.getLeapAmount((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2100004L + "'", long10 == 2100004L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) -1);
//        int int7 = offsetDateTimeField5.get((long) 0);
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        long long11 = offsetDateTimeField5.add(600001L, 1L);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (short) 100, locale14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        int int18 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.minus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.year();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.minus(readablePeriod22);
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        int[] intArray28 = new int[] { 4, 52 };
//        int[] intArray30 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) localTime24, 2019, intArray28, (int) (byte) 0);
//        java.lang.String str31 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime24);
//        java.lang.String str33 = dateTimeFormatter0.print((long) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 959 + "'", int7 == 959);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 660001L + "'", long11 == 660001L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����-W��-�" + "'", str31.equals("����-W��-�"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970-W01-3" + "'", str33.equals("1970-W01-3"));
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        int int6 = property5.getMinimumValue();
//        int int7 = property5.getMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime9 = property5.setCopy("Pacific Standard Time");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField6 = iSOChronology1.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = dateTime5.toString("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 86399999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("", 0, 10, (-28800000), 'a', 52743869, 970, 5, true, (int) 'a');
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder3.writeTo("AD", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
//        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((int) '4');
//        org.joda.time.DateTime dateTime18 = dateTime14.plusMillis(0);
//        int int19 = dateTime14.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 59 + "'", int19 == 59);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 960 + "'", int2 == 960);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "52743686");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField4.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withZone(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) 10);
//        int int18 = dateTime15.getMonthOfYear();
//        org.joda.time.DateTime.Property property19 = dateTime15.millisOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime15.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
//        java.lang.String str23 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) localDateTime22);
//        boolean boolean24 = dateTimeZone9.isLocalDateTimeGap(localDateTime22);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) (short) 10);
//        int int30 = dateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (byte) -1);
//        long long38 = offsetDateTimeField35.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField35.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, "Pacific Standard Time");
//        org.joda.time.DateTime dateTime43 = dateTime27.withField(dateTimeFieldType39, 0);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.minuteOfDay();
//        org.joda.time.DurationField durationField47 = iSOChronology45.halfdays();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.secondOfMinute();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTime dateTime50 = dateTime43.withChronology((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter51.withZone(dateTimeZone52);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter53.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now(dateTimeZone55);
//        org.joda.time.DateTime dateTime58 = dateTime56.plusWeeks((int) (short) 10);
//        int int59 = dateTime56.getMonthOfYear();
//        org.joda.time.DateTime.Property property60 = dateTime56.millisOfDay();
//        org.joda.time.DateTime dateTime62 = dateTime56.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime63 = dateTime62.toLocalDateTime();
//        java.lang.String str64 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) localDateTime63);
//        int[] intArray66 = iSOChronology45.get((org.joda.time.ReadablePartial) localDateTime63, (long) (-28800000));
//        try {
//            int[] intArray68 = offsetDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDateTime22, 1970, intArray66, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1970");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "5269-W01-1" + "'", str23.equals("5269-W01-1"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 600001L + "'", long38 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(localDateTime63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "5269-W01-1" + "'", str64.equals("5269-W01-1"));
//        org.junit.Assert.assertNotNull(intArray66);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        long long9 = dateTimeZone0.convertLocalToUTC(60000L, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28860000L + "'", long9 == 28860000L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1969);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DurationField durationField12 = iSOChronology9.centuries();
//        org.joda.time.DurationField durationField13 = iSOChronology9.days();
//        org.joda.time.DurationFieldType durationFieldType14 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField15 = new org.joda.time.field.DecoratedDurationField(durationField13, durationFieldType14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("", 0, 10, (-28800000), 'a', 52743869, 970, 5, true, (int) 'a');
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("5219-W24-6", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 1);
        boolean boolean8 = dateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        long long5 = durationField2.subtract(1L, (int) (short) 1);
//        long long8 = durationField2.subtract((long) (short) 1, (long) 959);
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType9, (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31535999999L) + "'", long5 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30263155621999L) + "'", long8 == (-30263155621999L));
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) -1);
//        int int7 = offsetDateTimeField5.get((long) 0);
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        long long11 = offsetDateTimeField5.add(600001L, 1L);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (short) 100, locale14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        int int18 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.minus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.year();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.minus(readablePeriod22);
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        int[] intArray28 = new int[] { 4, 52 };
//        int[] intArray30 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) localTime24, 2019, intArray28, (int) (byte) 0);
//        java.lang.String str31 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-28800000));
//        boolean boolean34 = dateTimeFormatter0.isOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 959 + "'", int7 == 959);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 660001L + "'", long11 == 660001L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����-W��-�" + "'", str31.equals("����-W��-�"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        boolean boolean10 = property9.isLeap();
//        int int11 = property9.getLeapAmount();
//        org.joda.time.DateTime dateTime13 = property9.setCopy((int) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
//        org.joda.time.DateTime.Property property12 = dateTime11.era();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 100, (java.lang.Number) 960, (java.lang.Number) 60960L);
        org.joda.time.DurationFieldType durationFieldType13 = illegalFieldValueException12.getDurationFieldType();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType13);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(86399999, (int) (byte) -1, (-98), 86399999, 0, 6, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) 107);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("52753417", true);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder3.writeTo("ISOChronology[America/Los_Angeles]", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        int int10 = offsetDateTimeField4.getLeapAmount((-28799999L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "5269-W01-1", 970);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-971) + "'", int10 == (-971));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "14:39:13.631");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
//        int int10 = dateTime7.getMonthOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
//        int int12 = property11.getMinimumValue();
//        int int13 = property11.getMaximumValue();
//        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
//        java.lang.String str15 = dateTime14.toString();
//        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = property5.roundCeilingCopy();
//        java.util.Locale locale19 = null;
//        try {
//            org.joda.time.DateTime dateTime20 = property5.setCopy("ISOChronology[America/Los_Angeles]", locale19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str15.equals("1969-12-31T16:00:01.969-08:00"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        int int9 = dateTime7.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        long long7 = iSOChronology1.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = iSOChronology1.millis();
        try {
            long long16 = iSOChronology1.getDateTimeMillis(10, (-52750), (int) (byte) 10, (int) '#', 52753462, 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60960L + "'", long7 == 60960L);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DurationField durationField12 = iSOChronology9.centuries();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime1.withHourOfDay((int) (short) 10);
        int int6 = dateTime1.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        boolean boolean4 = dateTime1.isAfterNow();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        int int7 = dateTime6.getCenturyOfEra();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withDate(57601969, 970, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property7 = dateTime1.era();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        org.joda.time.DateTime dateTime9 = property7.roundCeilingCopy();
//        int int10 = property7.getMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime12 = property7.setCopy("1969-12-31T16:00:00.039-08:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.039-08:00\" for era is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(52743869);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52743869 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long6 = offsetDateTimeField4.roundHalfFloor(60000L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withZone(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) 10);
//        int int15 = dateTime12.getMonthOfYear();
//        org.joda.time.DateTime.Property property16 = dateTime12.millisOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime12.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfDay();
//        org.joda.time.DurationField durationField25 = iSOChronology23.halfdays();
//        org.joda.time.DurationField durationField26 = iSOChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) (short) 10);
//        int int31 = dateTime28.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) (byte) -1);
//        long long39 = offsetDateTimeField36.add((long) (short) 1, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField36.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "Pacific Standard Time");
//        org.joda.time.DateTime dateTime44 = dateTime28.withField(dateTimeFieldType40, 0);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.minuteOfDay();
//        org.joda.time.DurationField durationField48 = iSOChronology46.halfdays();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.secondOfMinute();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology46);
//        org.joda.time.DateTime dateTime51 = dateTime44.withChronology((org.joda.time.Chronology) iSOChronology46);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter52.withZone(dateTimeZone53);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter54.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
//        org.joda.time.DateTime dateTime59 = dateTime57.plusWeeks((int) (short) 10);
//        int int60 = dateTime57.getMonthOfYear();
//        org.joda.time.DateTime.Property property61 = dateTime57.millisOfDay();
//        org.joda.time.DateTime dateTime63 = dateTime57.withCenturyOfEra((int) '4');
//        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
//        java.lang.String str65 = dateTimeFormatter54.print((org.joda.time.ReadablePartial) localDateTime64);
//        int[] intArray67 = iSOChronology46.get((org.joda.time.ReadablePartial) localDateTime64, (long) (-28800000));
//        int[] intArray69 = iSOChronology23.get((org.joda.time.ReadablePartial) localDateTime64, 40980000L);
//        try {
//            int[] intArray71 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDateTime19, 1438, intArray69, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1438");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 60000L + "'", long6 == 60000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "5270-W01-2" + "'", str20.equals("5270-W01-2"));
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 600001L + "'", long39 == 600001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(localDateTime64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "5270-W01-2" + "'", str65.equals("5270-W01-2"));
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(intArray69);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
//        int int8 = dateTime7.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", "");
        boolean boolean9 = property4.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) (short) 100, locale9);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(20190, (int) (short) 1, (int) (short) -1, 969, 8, 52753462, 1969, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 969 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
//        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 1);
//        int int8 = dateTime5.getMinuteOfDay();
//        int int9 = dateTime5.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMonths(19);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 22 + "'", int9 == 22);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1438, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1438 + "'", int2 == 1438);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
//        int int4 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfMinute();
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime1.toMutableDateTime(chronology10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1969L + "'", long9 == 1969L);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 60960L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property7.getAsText(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) 10);
        int int15 = property7.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int16 = dateTime14.getMillisOfSecond();
        int int17 = dateTime14.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AD" + "'", str10.equals("AD"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 973 + "'", int16 == 973);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 973 + "'", int17 == 973);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DurationField durationField11 = property9.getDurationField();
        int int12 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        try {
            long long28 = zonedChronology21.getDateTimeMillis(0L, 2, (int) (short) 10, 52743869, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52743869 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 10, 52, (int) (byte) 0, 0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        java.lang.String str6 = property5.getAsShortText();
        java.lang.String str7 = property5.getName();
        java.util.Locale locale8 = null;
        int int9 = property5.getMaximumTextLength(locale8);
        try {
            org.joda.time.DateTime dateTime11 = property5.setCopy("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1973" + "'", str6.equals("1973"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "millisOfDay" + "'", str7.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime dateTime15 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime14);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.DateTime dateTime19 = dateTime15.withFieldAdded(durationFieldType17, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        int int15 = dateTime11.getMillisOfDay();
        org.joda.time.DateTime.Property property16 = dateTime11.monthOfYear();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1973 + "'", int15 == 1973);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long12 = gregorianChronology7.getDateTimeMillis(959, 10, (-98), (-52750));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52750 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillis((long) 52750);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        try {
            long long27 = zonedChronology21.getDateTimeMillis(8, 52750, 0, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52750 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withMinuteOfHour(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField4.getWrappedField();
        java.lang.String str9 = offsetDateTimeField4.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str9.equals("DateTimeField[minuteOfDay]"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        long long14 = offsetDateTimeField11.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType15, 1, (int) (byte) 10, 20190);
        org.joda.time.DurationField durationField20 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 600001L + "'", long14 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("879", number1, number2, (java.lang.Number) (-28799999L));
        illegalFieldValueException4.prependMessage("minuteOfDay");
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        boolean boolean4 = dateTime1.isAfterNow();
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField4.getWrappedField();
        boolean boolean9 = offsetDateTimeField4.isSupported();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(6);
        org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) 10);
        int int20 = dateTime17.getMonthOfYear();
        org.joda.time.DateTime.Property property21 = dateTime17.millisOfDay();
        org.joda.time.DateTime dateTime23 = dateTime17.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.DateTime dateTime25 = dateTime15.withFields((org.joda.time.ReadablePartial) localDateTime24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDateTime24, 4, locale27);
        int int30 = offsetDateTimeField4.getLeapAmount((long) ' ');
        java.util.Locale locale31 = null;
        int int32 = offsetDateTimeField4.getMaximumTextLength(locale31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "4" + "'", str28.equals("4"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 1);
        int int8 = dateTime5.getMinuteOfDay();
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 13046401969L + "'", long9 == 13046401969L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.Instant instant8 = dateTime1.toInstant();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DurationField durationField12 = iSOChronology10.halfdays();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime1.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        try {
            org.joda.time.DateTime dateTime16 = dateTime1.withEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("57600039", (java.lang.Number) (-52750), (java.lang.Number) 600001L, (java.lang.Number) 10L);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -52750 for 57600039 must be in the range [600001,10]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value -52750 for 57600039 must be in the range [600001,10]"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.roundCeilingCopy();
        org.joda.time.DateTime dateTime18 = property5.roundHalfCeilingCopy();
        java.lang.String str19 = property5.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1973" + "'", str19.equals("1973"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology10);
        java.lang.StringBuffer stringBuffer14 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer14, (long) 960);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        boolean boolean10 = dateTime8.isAfter((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.DurationField durationField11 = iSOChronology8.seconds();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime5.toMutableDateTime((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology1.get(readablePeriod5, 660001L, (long) 39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1973);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        int int6 = property5.getMinimumValue();
        int int7 = property5.getMaximumValue();
        java.lang.String str8 = property5.getAsText();
        int int9 = property5.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1973" + "'", str8.equals("1973"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.DateTime dateTime9 = property7.roundCeilingCopy();
        org.joda.time.ReadableInstant readableInstant10 = null;
        try {
            int int11 = property7.compareTo(readableInstant10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12-31T15:59:59");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T15:59:59\" is malformed at \"-12-31T15:59:59\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        boolean boolean11 = property9.isLeap();
        org.joda.time.DurationField durationField12 = property9.getRangeDurationField();
        org.joda.time.DurationField durationField13 = property9.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 39, dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime11.withZoneRetainFields(dateTimeZone16);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1969L + "'", long19 == 1969L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(60960L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(52753462, 973, (-1), 959);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 973 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 100, (java.lang.Number) 960, (java.lang.Number) 60960L);
        java.lang.Number number13 = illegalFieldValueException12.getLowerBound();
        java.lang.String str14 = illegalFieldValueException12.getIllegalStringValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 960 + "'", number13.equals(960));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DurationField durationField14 = iSOChronology10.centuries();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "millisOfDay", "14:39:13.631");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "0", "");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "5270-W01-2", "1968-12-31T16:00:00.001-08:00");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getShortName(locale13, "100", "5219-W24-6");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DurationField durationField3 = iSOChronology1.days();
        try {
            long long9 = iSOChronology1.getDateTimeMillis((long) 52753462, 39, 0, 2019, 22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 2100004L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        int int9 = dateTimeZone6.getOffsetFromLocal(48L);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(6);
        org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) 10);
        int int20 = dateTime17.getMonthOfYear();
        org.joda.time.DateTime.Property property21 = dateTime17.millisOfDay();
        org.joda.time.DateTime dateTime23 = dateTime17.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.DateTime dateTime25 = dateTime15.withFields((org.joda.time.ReadablePartial) localDateTime24);
        boolean boolean26 = dateTimeZone6.isLocalDateTimeGap(localDateTime24);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(1438, 2019, 12, 879, 20190, (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 879 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName((long) (short) 100, locale4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.004" + "'", str5.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("1968-12-31T16:00:00.001-08:00", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long6 = offsetDateTimeField4.roundHalfFloor(60000L);
        long long8 = offsetDateTimeField4.roundCeiling(60960L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsText((int) (short) 100, locale10);
        boolean boolean12 = offsetDateTimeField4.isSupported();
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsShortText(0L, locale14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsText((-52750), locale17);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 59996L + "'", long6 == 59996L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 119996L + "'", long8 == 119996L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-52750" + "'", str18.equals("-52750"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: Value -52750 for 57600039 must be in the range [600001,10]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 70, 86399999, 292278993, 6, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfEra(100);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime18);
        org.joda.time.DateTime dateTime21 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime dateTime23 = dateTime5.plusMonths(39);
        int int24 = dateTime5.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        long long7 = dateTimeZone4.adjustOffset(600001L, false);
        java.lang.String str8 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str8.equals("1969-12-31T16:00:01.969-08:00"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', (int) (short) 1, 8, 2019, 1438, (int) ' ', 57600039);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology7.halfdays();
        org.joda.time.DurationField durationField10 = iSOChronology7.seconds();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology7);
        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "10", (int) 'a');
        java.lang.String str16 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-98) + "'", int14 == (-98));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "000000.004+0000" + "'", str16.equals("000000.004+0000"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        try {
            long long11 = iSOChronology1.getDateTimeMillis((long) 973, 52750, 1969, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52750 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.get((long) 0);
        int int7 = offsetDateTimeField4.getMinimumValue();
        long long10 = offsetDateTimeField4.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getName((long) (short) 100, locale13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.minus(readableDuration18);
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.minus(readablePeriod21);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int[] intArray27 = new int[] { 4, 52 };
        int[] intArray29 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) localTime23, 2019, intArray27, (int) (byte) 0);
        org.joda.time.DurationField durationField30 = offsetDateTimeField4.getDurationField();
        int int31 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 660001L + "'", long10 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.004" + "'", str14.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        long long4 = durationField1.subtract(2100000L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2100000L + "'", long4 == 2100000L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfMinute();
        boolean boolean10 = property8.equals((java.lang.Object) 1L);
        int int11 = property8.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName((long) (short) 100, locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime12);
        long long15 = dateTimeZone7.convertUTCToLocal((long) (byte) 1);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (byte) 1, 8, 2019, 0, 100, 10, (-98), dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.004" + "'", str10.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.secondOfMinute();
        org.joda.time.DurationField durationField10 = iSOChronology6.centuries();
        org.joda.time.Chronology chronology11 = iSOChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) 'a', (int) (short) 100, (-52750), 1969, (int) (byte) 10, chronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), 660001L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-660001) + "'", int2 == (-660001));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) (short) 100, 4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            java.lang.String str13 = dateTime8.toString(dateTimeFormatter12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 39, dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime11.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks(960);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) -1);
        long long13 = offsetDateTimeField10.add((long) (byte) 1, (int) (short) 1);
        long long15 = offsetDateTimeField10.roundHalfEven((long) (byte) 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField10.getLeapDurationField();
        int int17 = dateTime3.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6048001969L + "'", long5 == 6048001969L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 60001L + "'", long13 == 60001L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4L) + "'", long15 == (-4L));
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1969L + "'", long1 == 1969L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        int int6 = property5.get();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) (short) 10);
        int int11 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) 10);
        int int17 = dateTime14.getMonthOfYear();
        org.joda.time.DateTime.Property property18 = dateTime14.millisOfDay();
        int int19 = property18.getMinimumValue();
        int int20 = property18.getMaximumValue();
        org.joda.time.DateTime dateTime21 = property18.roundHalfFloorCopy();
        java.lang.String str22 = dateTime21.toString();
        int int23 = property12.getDifference((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = property12.withMinimumValue();
        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfDay(86399999);
        org.joda.time.DateTime dateTime28 = dateTime26.plusMinutes(2);
        long long29 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime26);
        java.lang.String str30 = property5.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1973 + "'", int6 == 1973);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86399999 + "'", int20 == 86399999);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str22.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-86398026L) + "'", long29 == (-86398026L));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1973" + "'", str30.equals("1973"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        int int12 = offsetDateTimeField4.get(660001L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsText(959, locale14);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "959" + "'", str15.equals("959"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.minuteOfDay();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.secondOfMinute();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime5.toMutableDateTime(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.withMinimumValue();
        org.joda.time.DateTime.Property property18 = dateTime17.era();
        int int19 = dateTime17.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-98), (-28798030L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2822206940");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
        boolean boolean8 = dateTime7.isAfterNow();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime16.toMutableDateTime();
        java.lang.Class<?> wildcardClass19 = dateTime16.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DurationField durationField11 = property9.getDurationField();
        boolean boolean12 = property9.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1438);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.minusMinutes(5);
        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readableDuration17);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
        org.joda.time.DateTime dateTime19 = dateTime1.minusSeconds(1);
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime dateTime21 = property20.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.plus(0L);
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 1);
        int int8 = dateTime5.getMinuteOfDay();
        int int9 = dateTime5.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime22 = dateTime17.withTime((-25200000), 4, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("", 0, 10, (-28800000), 'a', 52743869, 970, 5, true, (int) 'a');
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder3.writeTo("-1", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withTime(39, 0, 52743869, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("minuteOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'minuteOfDay' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        java.lang.String str15 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDateTime14);
        boolean boolean16 = dateTimeZone1.isLocalDateTimeGap(localDateTime14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5270-W01-3" + "'", str15.equals("5270-W01-3"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        long long12 = offsetDateTimeField4.roundFloor(4L);
        long long14 = offsetDateTimeField4.roundCeiling(1560634750095L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField4.getAsText(6, locale16);
        boolean boolean18 = offsetDateTimeField4.isSupported();
        java.lang.String str20 = offsetDateTimeField4.getAsShortText((long) (-98));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4L) + "'", long12 == (-4L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560634799996L + "'", long14 == 1560634799996L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6" + "'", str17.equals("6"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1438" + "'", str20.equals("1438"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.DurationField durationField11 = iSOChronology8.seconds();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime5.toMutableDateTime((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) 10);
        int int17 = dateTime14.getMonthOfYear();
        org.joda.time.DateTime.Property property18 = dateTime14.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime14.plus(readablePeriod19);
        org.joda.time.DateTime.Property property21 = dateTime14.secondOfMinute();
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime14.getZone();
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(100L, locale25);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) iSOChronology8, dateTimeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1969L + "'", long22 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.004" + "'", str26.equals("+00:00:00.004"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime5.minusHours(959);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.Chronology chronology18 = gregorianChronology16.withUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology16.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter0.withZone(dateTimeZone19);
        java.io.Writer writer21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) -1);
        long long29 = offsetDateTimeField26.add((long) (byte) 1, (int) (short) 1);
        long long31 = offsetDateTimeField26.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) 10);
        int int36 = dateTime33.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) -1);
        long long44 = offsetDateTimeField41.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField41.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "Pacific Standard Time");
        org.joda.time.DateTime dateTime49 = dateTime33.withField(dateTimeFieldType45, 0);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.minuteOfDay();
        org.joda.time.DurationField durationField53 = iSOChronology51.halfdays();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.DateTime dateTime56 = dateTime49.withChronology((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter57.withZone(dateTimeZone58);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter59.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now(dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime62.plusWeeks((int) (short) 10);
        int int65 = dateTime62.getMonthOfYear();
        org.joda.time.DateTime.Property property66 = dateTime62.millisOfDay();
        org.joda.time.DateTime dateTime68 = dateTime62.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
        java.lang.String str70 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) localDateTime69);
        int[] intArray72 = iSOChronology51.get((org.joda.time.ReadablePartial) localDateTime69, (long) (-28800000));
        int int73 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDateTime69);
        try {
            dateTimeFormatter0.printTo(writer21, (org.joda.time.ReadablePartial) localDateTime69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60001L + "'", long29 == 60001L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-4L) + "'", long31 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 600001L + "'", long44 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "5270-W01-3" + "'", str70.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 292278993);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1968-12-31T16:00:00.001-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1968-12-31T16:00:00.001-08:00\" is malformed at \"-12-31T16:00:00.001-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.Chronology chronology5 = dateTimeFormatter4.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(chronology5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfMinute();
        boolean boolean10 = property8.equals((java.lang.Object) 1L);
        int int11 = property8.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property4.setCopy("1", locale6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("878");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDateTime2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gregorianChronology1.get(readablePeriod5, (long) 52750);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField4.set((-28798030L), "5269-W01-1", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"5269-W01-1\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology21.clockhourOfDay();
        try {
            long long29 = zonedChronology21.getDateTimeMillis(0L, 960, 2, 57601969, 86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(107, 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2126 + "'", int2 == 2126);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(70);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.era();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int3 = dateTimeZone0.getOffsetFromLocal(48L);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.months();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(970, 86399999, (-25200000), 52750, 0, 1438, 19, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52750 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.get((long) 0);
        int int7 = offsetDateTimeField4.getMinimumValue();
        long long10 = offsetDateTimeField4.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getName((long) (short) 100, locale13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.minus(readableDuration18);
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.minus(readablePeriod21);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int[] intArray27 = new int[] { 4, 52 };
        int[] intArray29 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) localTime23, 2019, intArray27, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
        long long37 = offsetDateTimeField34.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField34.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, "Pacific Standard Time");
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 660001L + "'", long10 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.004" + "'", str14.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 600001L + "'", long37 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-1", 1438, 960, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1438 for -1 must be in the range [960,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone5.getName((long) (short) 100, locale7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        org.joda.time.DurationField durationField16 = iSOChronology13.seconds();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime10.toMutableDateTime((org.joda.time.Chronology) iSOChronology13);
        int int20 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime17, "-52750", 22);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName((long) (short) 100, locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.minus(readableDuration32);
        org.joda.time.DateTime.Property property34 = dateTime33.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.minus(readablePeriod35);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale39 = null;
        java.lang.String str40 = dateTimeZone37.getName((long) (short) 100, locale39);
        org.joda.time.DateTime dateTime41 = dateTime36.toDateTime(dateTimeZone37);
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology23, dateTimeZone37);
        try {
            org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter4, (org.joda.time.Chronology) gregorianChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.004" + "'", str8.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-23) + "'", int20 == (-23));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.004" + "'", str28.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+00:00:00.004" + "'", str40.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(zonedChronology42);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName((long) (short) 100, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        int int8 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime7);
        java.lang.String str9 = dateTimeZone2.toString();
        long long12 = dateTimeZone2.adjustOffset((-28799968L), false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', dateTimeZone2);
        org.joda.time.Chronology chronology14 = gregorianChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.004" + "'", str5.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str9.equals("1969-12-31T16:00:01.969-08:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28799968L) + "'", long12 == (-28799968L));
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int7 = cachedDateTimeZone5.getStandardOffset((long) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.years();
        long long13 = durationField10.subtract(1L, (int) (short) 1);
        long long16 = durationField10.subtract((long) (short) 1, (long) 959);
        long long19 = durationField10.subtract((long) 879, (long) (byte) -1);
        boolean boolean20 = cachedDateTimeZone5.equals((java.lang.Object) 879);
        int int22 = cachedDateTimeZone5.getOffset((long) 10);
        long long24 = cachedDateTimeZone5.convertUTCToLocal((long) (byte) 100);
        long long26 = cachedDateTimeZone5.nextTransition(660001L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-30263155199999L) + "'", long16 == (-30263155199999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000879L + "'", long19 == 31536000879L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 104L + "'", long24 == 104L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 660001L + "'", long26 == 660001L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        try {
            java.lang.String str24 = unsupportedDateTimeField22.getAsText((long) (-98));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        int int4 = dateTimeFormatter3.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "millisOfDay", "14:39:13.631");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "1968-12-31T16:00:00.001-08:00", "1969-12-31T16:00:00.039-08:00");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission5.newPermissionCollection();
        java.lang.String str7 = jodaTimePermission5.toString();
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")"));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-31535999999L), (java.lang.Number) 60960L, (java.lang.Number) 1560634800000L);
        org.joda.time.DateTime dateTime23 = dateTime6.withField(dateTimeFieldType17, (int) ' ');
        try {
            org.joda.time.DateTime dateTime25 = dateTime6.withEra((-23));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -23 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 600001L + "'", long16 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName((long) (short) 100, locale3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        int int7 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
        long long21 = offsetDateTimeField18.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 20190, "millisOfDay");
        boolean boolean26 = dateTime12.isSupported(dateTimeFieldType22);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.004" + "'", str4.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 600001L + "'", long21 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        long long14 = offsetDateTimeField11.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType15, 1, (int) (byte) 10, 20190);
        int int21 = offsetDateTimeField19.get((long) 52753462);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfDay();
        org.joda.time.DurationField durationField25 = iSOChronology23.halfdays();
        org.joda.time.DurationField durationField26 = iSOChronology23.seconds();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) (short) 10);
        int int31 = dateTime28.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) (byte) -1);
        long long39 = offsetDateTimeField36.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField36.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "Pacific Standard Time");
        org.joda.time.DateTime dateTime44 = dateTime28.withField(dateTimeFieldType40, 0);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.minuteOfDay();
        org.joda.time.DurationField durationField48 = iSOChronology46.halfdays();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.secondOfMinute();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTime dateTime51 = dateTime44.withChronology((org.joda.time.Chronology) iSOChronology46);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter52.withZone(dateTimeZone53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter54.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.plusWeeks((int) (short) 10);
        int int60 = dateTime57.getMonthOfYear();
        org.joda.time.DateTime.Property property61 = dateTime57.millisOfDay();
        org.joda.time.DateTime dateTime63 = dateTime57.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
        java.lang.String str65 = dateTimeFormatter54.print((org.joda.time.ReadablePartial) localDateTime64);
        int[] intArray67 = iSOChronology46.get((org.joda.time.ReadablePartial) localDateTime64, (long) (-28800000));
        int[] intArray69 = iSOChronology23.get((org.joda.time.ReadablePartial) localDateTime64, 40980000L);
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDateTime64, locale70);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 600001L + "'", long14 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 879 + "'", int21 == 879);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 600001L + "'", long39 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDateTime64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "5270-W01-3" + "'", str65.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(0);
        int int5 = dateTimeFormatter4.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter4.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter4.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 60960L, "Pacific Standard Time");
        java.lang.Number number21 = illegalFieldValueException20.getIllegalNumberValue();
        java.lang.Number number22 = illegalFieldValueException20.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 60960L + "'", number21.equals(60960L));
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        java.lang.String str3 = dateTimeZone0.getShortName((long) '#');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        long long9 = offsetDateTimeField4.roundHalfEven((long) (byte) 0);
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = iSOChronology9.get(readablePeriod12, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        long long14 = offsetDateTimeField11.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType15, 1, (int) (byte) 10, 20190);
        int int21 = offsetDateTimeField19.get((long) 52753462);
        int int23 = offsetDateTimeField19.getLeapAmount((long) 970);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField19.getAsText((int) (short) 1, locale25);
        int int28 = offsetDateTimeField19.getMaximumValue((long) 4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 600001L + "'", long14 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 879 + "'", int21 == 879);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1439 + "'", int28 == 1439);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime14.weekOfWeekyear();
        int int18 = dateTime14.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 959 + "'", int18 == 959);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 1438, 970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("959");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '959' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfCentury();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "70" + "'", str14.equals("70"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        java.util.Locale locale23 = null;
        try {
            int int24 = unsupportedDateTimeField22.getMaximumShortTextLength(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.secondOfMinute();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-23), 973, 52, 52743869, (int) (short) 10, chronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52743869 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType13, (int) (short) 1, 0, (int) (byte) 100);
        long long19 = offsetDateTimeField17.roundHalfFloor((long) 100);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName((long) (short) 100, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        int int26 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.minus(readableDuration27);
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
        long long37 = offsetDateTimeField34.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime40.plusWeeks((int) (short) 10);
        int int43 = dateTime40.getMonthOfYear();
        org.joda.time.DateTime.Property property44 = dateTime40.millisOfDay();
        org.joda.time.DateTime dateTime46 = dateTime40.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime47 = dateTime46.toLocalDateTime();
        java.util.Locale locale49 = null;
        java.lang.String str50 = offsetDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDateTime47, (int) (short) 10, locale49);
        int int51 = property29.compareTo((org.joda.time.ReadablePartial) localDateTime47);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks((int) (short) 10);
        int int57 = dateTime54.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) (byte) -1);
        long long65 = offsetDateTimeField62.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField62.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, "Pacific Standard Time");
        org.joda.time.DateTime dateTime70 = dateTime54.withField(dateTimeFieldType66, 0);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = iSOChronology72.minuteOfDay();
        org.joda.time.DurationField durationField74 = iSOChronology72.halfdays();
        org.joda.time.DateTimeField dateTimeField75 = iSOChronology72.secondOfMinute();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology72);
        org.joda.time.DateTime dateTime77 = dateTime70.withChronology((org.joda.time.Chronology) iSOChronology72);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone79 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter80 = dateTimeFormatter78.withZone(dateTimeZone79);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = dateTimeFormatter80.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime83 = org.joda.time.DateTime.now(dateTimeZone82);
        org.joda.time.DateTime dateTime85 = dateTime83.plusWeeks((int) (short) 10);
        int int86 = dateTime83.getMonthOfYear();
        org.joda.time.DateTime.Property property87 = dateTime83.millisOfDay();
        org.joda.time.DateTime dateTime89 = dateTime83.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime90 = dateTime89.toLocalDateTime();
        java.lang.String str91 = dateTimeFormatter80.print((org.joda.time.ReadablePartial) localDateTime90);
        int[] intArray93 = iSOChronology72.get((org.joda.time.ReadablePartial) localDateTime90, (long) (-28800000));
        try {
            int[] intArray95 = offsetDateTimeField17.addWrapField((org.joda.time.ReadablePartial) localDateTime47, (int) (byte) 100, intArray93, 52753462);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[1969-12-31T16:00:01.969-08:00]" + "'", str3.equals("ISOChronology[1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-4L) + "'", long19 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.004" + "'", str23.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 600001L + "'", long37 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10" + "'", str50.equals("10"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 600001L + "'", long65 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeFormatter78);
        org.junit.Assert.assertNotNull(dateTimeFormatter80);
        org.junit.Assert.assertNotNull(dateTimeFormatter81);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(property87);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(localDateTime90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "5270-W01-3" + "'", str91.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray93);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology1.equals(obj5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 2, (java.lang.Number) (byte) 1, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        java.lang.String str3 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[1969-12-31T16:00:01.969-08:00]" + "'", str3.equals("GregorianChronology[1969-12-31T16:00:01.969-08:00]"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        try {
            java.lang.String str24 = unsupportedDateTimeField22.getAsText(1560634800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            long long2 = dateTimeFormatter0.parseMillis("879");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"879\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.DateTime dateTime9 = property7.roundCeilingCopy();
        int int10 = property7.getMaximumValue();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property7.getAsText(locale11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AD" + "'", str12.equals("AD"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withZone(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter17.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) (short) 10);
        int int23 = dateTime20.getMonthOfYear();
        org.joda.time.DateTime.Property property24 = dateTime20.millisOfDay();
        org.joda.time.DateTime dateTime26 = dateTime20.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        java.lang.String str28 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) localDateTime27);
        boolean boolean29 = dateTimeZone14.isLocalDateTimeGap(localDateTime27);
        long long31 = dateTimeZone11.getMillisKeepLocal(dateTimeZone14, (long) (-971));
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime10.toMutableDateTime(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "5270-W01-3" + "'", str28.equals("5270-W01-3"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-967L) + "'", long31 == (-967L));
        org.junit.Assert.assertNotNull(mutableDateTime32);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        long long9 = offsetDateTimeField4.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) -1);
        long long17 = offsetDateTimeField14.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField14.getType();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        int int22 = dateTimeZone19.getOffsetFromLocal(48L);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMonthOfYear(6);
        org.joda.time.DateTime dateTime28 = dateTime26.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks((int) (short) 10);
        int int33 = dateTime30.getMonthOfYear();
        org.joda.time.DateTime.Property property34 = dateTime30.millisOfDay();
        org.joda.time.DateTime dateTime36 = dateTime30.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime37 = dateTime36.toLocalDateTime();
        org.joda.time.DateTime dateTime38 = dateTime28.withFields((org.joda.time.ReadablePartial) localDateTime37);
        boolean boolean39 = dateTimeZone19.isLocalDateTimeGap(localDateTime37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDateTime37, locale40);
        int[] intArray46 = new int[] { (short) 10, 4, 2 };
        try {
            int[] intArray48 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDateTime37, 52750, intArray46, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52750");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 600001L + "'", long17 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField22.getAsText((long) (-971), locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 973);
        int int8 = fixedDateTimeZone4.getStandardOffset((-28798030L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 973L + "'", long6 == 973L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        boolean boolean8 = dateTime1.isAfterNow();
        int int9 = dateTime1.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfDay();
        org.joda.time.DurationField durationField13 = iSOChronology11.halfdays();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.secondOfMinute();
        java.lang.Object obj15 = null;
        boolean boolean16 = iSOChronology11.equals(obj15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTime.Property property19 = dateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int7 = cachedDateTimeZone5.getStandardOffset((long) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.years();
        long long13 = durationField10.subtract(1L, (int) (short) 1);
        long long16 = durationField10.subtract((long) (short) 1, (long) 959);
        long long19 = durationField10.subtract((long) 879, (long) (byte) -1);
        boolean boolean20 = cachedDateTimeZone5.equals((java.lang.Object) 879);
        int int22 = cachedDateTimeZone5.getOffset((long) 10);
        long long24 = cachedDateTimeZone5.nextTransition((-31535999999L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-30263155199999L) + "'", long16 == (-30263155199999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000879L + "'", long19 == 31536000879L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("10", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int12 = cachedDateTimeZone10.getStandardOffset((long) (byte) -1);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(6, 292278993, 2126, 879, 20190, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 879 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property7.getAsText(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) 10);
        int int15 = property7.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.plus((long) 1438);
        int int18 = dateTime14.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AD" + "'", str10.equals("AD"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfDay();
        org.joda.time.DurationField durationField21 = iSOChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTime dateTime24 = dateTime17.withChronology((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName((long) (short) 100, locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.plus(0L);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime17, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime36 = dateTime17.withYearOfEra((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.004" + "'", str28.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int7 = cachedDateTimeZone5.getStandardOffset((long) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.years();
        long long13 = durationField10.subtract(1L, (int) (short) 1);
        long long16 = durationField10.subtract((long) (short) 1, (long) 959);
        long long19 = durationField10.subtract((long) 879, (long) (byte) -1);
        boolean boolean20 = cachedDateTimeZone5.equals((java.lang.Object) 879);
        int int22 = cachedDateTimeZone5.getOffset((long) 10);
        long long24 = cachedDateTimeZone5.convertUTCToLocal((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName((long) (short) 100, locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.minus(readableDuration32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, 4);
        org.joda.time.DateTime dateTime38 = dateTime33.withYear((int) (byte) 100);
        boolean boolean39 = cachedDateTimeZone5.equals((java.lang.Object) (byte) 100);
        long long41 = cachedDateTimeZone5.previousTransition((-28798030L));
        java.lang.String str43 = cachedDateTimeZone5.getNameKey(120000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-30263155199999L) + "'", long16 == (-30263155199999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000879L + "'", long19 == 31536000879L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 104L + "'", long24 == 104L);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.004" + "'", str28.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-28798030L) + "'", long41 == (-28798030L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.minusMinutes(5);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) (byte) -1, 100);
        try {
            org.joda.time.DateTime dateTime19 = dateTime14.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime dateTime15 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime14);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        long long12 = offsetDateTimeField4.roundFloor(4L);
        long long15 = offsetDateTimeField4.add(0L, 48L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4L) + "'", long12 == (-4L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2880000L + "'", long15 == 2880000L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.minusMinutes(5);
        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) (short) -1);
        org.joda.time.DateTime dateTime17 = dateTime16.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime dateTime15 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime14);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) 19);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '#');
        int int21 = property16.compareTo((org.joda.time.ReadableInstant) dateTime20);
        int int22 = property16.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 23 + "'", int22 == 23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime18);
        boolean boolean21 = dateTime19.isEqual((long) 70);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        org.joda.time.Instant instant4 = dateTime1.toInstant();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear(10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        try {
            long long28 = unsupportedDateTimeField22.roundFloor((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 1);
        int int8 = dateTime5.getMinuteOfDay();
        boolean boolean10 = dateTime5.isAfter(13046459996L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("000000.004+0000", (-52750), 52753462, 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52750 for 000000.004+0000 must be in the range [52753462,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((-52750));
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusWeeks((int) (short) 10);
        int int26 = dateTime23.getMonthOfYear();
        org.joda.time.DateTime.Property property27 = dateTime23.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime23.plus(readablePeriod28);
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTimeISO();
        boolean boolean31 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale34 = null;
        java.lang.String str35 = dateTimeZone32.getName((long) (short) 100, locale34);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
        int int38 = dateTimeZone32.getOffset((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime40 = dateTime37.minus(readableDuration39);
        org.joda.time.DateTime.Property property41 = dateTime40.year();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime40.minus(readablePeriod42);
        org.joda.time.DateTime.Property property44 = dateTime40.yearOfCentury();
        boolean boolean45 = dateTime19.isAfter((org.joda.time.ReadableInstant) dateTime40);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.004" + "'", str35.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long9 = offsetDateTimeField4.roundHalfCeiling((long) 2);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) (short) 10);
        int int14 = dateTime11.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        long long22 = offsetDateTimeField19.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "Pacific Standard Time");
        org.joda.time.DateTime dateTime27 = dateTime11.withField(dateTimeFieldType23, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType23, 6, (int) (byte) 100, 20190);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType23, (int) (byte) -1, 20190, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfDay must be in the range [20190,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600001L + "'", long22 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("52748811");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '52748811' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(0);
        java.lang.String str5 = dateTime1.toString(dateTimeFormatter4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plus(0L);
        int int15 = dateTime14.getMinuteOfHour();
        org.joda.time.DateTime.Property property16 = dateTime14.secondOfMinute();
        java.lang.String str17 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "000001+0000" + "'", str5.equals("000001+0000"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "000001+0000" + "'", str17.equals("000001+0000"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        try {
            long long25 = unsupportedDateTimeField22.roundFloor((long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        long long6 = dateTime1.getMillis();
        org.joda.time.DateTime.Property property7 = dateTime1.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 2, (-1));
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(48L, (org.joda.time.Chronology) iSOChronology2);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withDate((-28800000), (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 48L + "'", long10 == 48L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(57601969, 86399999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 144001968 + "'", int2 == 144001968);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(23, 1, 52750, 879, 22, 970, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 879 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.joda.time.DurationField durationField5 = iSOChronology1.days();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        java.util.Locale locale27 = null;
        try {
            int int28 = unsupportedDateTimeField22.getMaximumShortTextLength(locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DurationField durationField5 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.minuteOfHour();
        org.joda.time.DurationField durationField7 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.year();
        java.lang.Object obj9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        int int17 = cachedDateTimeZone15.getStandardOffset((long) (byte) -1);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj9, (org.joda.time.DateTimeZone) cachedDateTimeZone15);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((long) (byte) 10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone11.getName((long) 4, locale15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(22, (int) (short) 1, (int) (short) 1, (int) (byte) 10, 19, 12, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        boolean boolean21 = fixedDateTimeZone11.equals((java.lang.Object) dateTimeZone20);
        int int23 = dateTimeZone20.getOffsetFromLocal(100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.004" + "'", str16.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) -1);
        long long8 = offsetDateTimeField5.add((long) (short) 1, (int) (byte) 10);
        long long11 = offsetDateTimeField5.getDifferenceAsLong((long) 100, (long) 10);
        long long13 = offsetDateTimeField5.roundFloor(4L);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField5.getWrappedField();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 600001L + "'", long8 == 600001L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-4L) + "'", long13 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours(4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) -1);
        long long17 = offsetDateTimeField14.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField14.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) (short) 10);
        int int23 = dateTime20.getMonthOfYear();
        org.joda.time.DateTime.Property property24 = dateTime20.millisOfDay();
        org.joda.time.DateTime dateTime26 = dateTime20.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDateTime27, (int) (short) 10, locale29);
        int int31 = property9.compareTo((org.joda.time.ReadablePartial) localDateTime27);
        org.joda.time.DateTime dateTime32 = property9.withMinimumValue();
        org.joda.time.DateTime dateTime34 = property9.setCopy("6");
        org.joda.time.DateMidnight dateMidnight35 = dateTime34.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 600001L + "'", long17 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateMidnight35);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        try {
            long long24 = unsupportedDateTimeField22.roundCeiling(2023L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 60960L, "Pacific Standard Time");
        java.lang.Number number21 = illegalFieldValueException20.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = iSOChronology1.add(readablePeriod4, (long) 2, (-1));
        org.joda.time.DurationField durationField8 = iSOChronology1.hours();
        org.joda.time.DurationField durationField9 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        int int14 = dateTimeZone11.getOffsetFromLocal(48L);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMonthOfYear(6);
        org.joda.time.DateTime dateTime20 = dateTime18.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks((int) (short) 10);
        int int25 = dateTime22.getMonthOfYear();
        org.joda.time.DateTime.Property property26 = dateTime22.millisOfDay();
        org.joda.time.DateTime dateTime28 = dateTime22.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        org.joda.time.DateTime dateTime30 = dateTime20.withFields((org.joda.time.ReadablePartial) localDateTime29);
        boolean boolean31 = dateTimeZone11.isLocalDateTimeGap(localDateTime29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) 10);
        int int36 = dateTime33.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) -1);
        long long44 = offsetDateTimeField41.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField41.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "Pacific Standard Time");
        org.joda.time.DateTime dateTime49 = dateTime33.withField(dateTimeFieldType45, 0);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.minuteOfDay();
        org.joda.time.DurationField durationField53 = iSOChronology51.halfdays();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.DateTime dateTime56 = dateTime49.withChronology((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter57.withZone(dateTimeZone58);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter59.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now(dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime62.plusWeeks((int) (short) 10);
        int int65 = dateTime62.getMonthOfYear();
        org.joda.time.DateTime.Property property66 = dateTime62.millisOfDay();
        org.joda.time.DateTime dateTime68 = dateTime62.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
        java.lang.String str70 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) localDateTime69);
        int[] intArray72 = iSOChronology51.get((org.joda.time.ReadablePartial) localDateTime69, (long) (-28800000));
        iSOChronology1.validate((org.joda.time.ReadablePartial) localDateTime29, intArray72);
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 600001L + "'", long44 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "5270-W01-3" + "'", str70.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((long) 4, locale8);
        long long11 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        boolean boolean12 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology15.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = iSOChronology15.add(readablePeriod18, (long) 2, (-1));
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(48L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTime dateTime24 = dateTime22.plusSeconds(2);
        int int25 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) (short) 10);
        int int30 = dateTime27.getMonthOfYear();
        org.joda.time.DateTime.Property property31 = dateTime27.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) 10);
        int int36 = dateTime33.getMonthOfYear();
        org.joda.time.DateTime.Property property37 = dateTime33.millisOfDay();
        int int38 = property37.getMinimumValue();
        int int39 = property37.getMaximumValue();
        org.joda.time.DateTime dateTime40 = property37.roundHalfFloorCopy();
        java.lang.String str41 = dateTime40.toString();
        int int42 = property31.getDifference((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime43 = property31.withMinimumValue();
        org.joda.time.DateTime dateTime45 = dateTime43.withMillisOfDay(86399999);
        boolean boolean46 = dateTime22.isBefore((org.joda.time.ReadableInstant) dateTime45);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2L + "'", long21 == 2L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 86399999 + "'", int39 == 86399999);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str41.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        long long9 = offsetDateTimeField4.roundHalfEven((long) (byte) 0);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField4.getType();
        long long13 = offsetDateTimeField4.roundCeiling((long) 57600039);
        int int15 = offsetDateTimeField4.get((long) 52);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 57659996L + "'", long13 == 57659996L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1969-12-31T16:00:01.969-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:01.969-08:00\" is malformed at \"-12-31T16:00:01.969-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.minusMinutes(5);
        org.joda.time.DateTime.Property property15 = dateTime11.era();
        java.util.Locale locale17 = null;
        try {
            org.joda.time.DateTime dateTime18 = property15.setCopy("398", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"398\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) 10);
        int int7 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.minuteOfDay();
        org.joda.time.DateTime dateTime14 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear(959);
        java.lang.String str18 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "00:00:01.973" + "'", str18.equals("00:00:01.973"));
        org.junit.Assert.assertNotNull(dateTimeParser19);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        int int12 = offsetDateTimeField4.get(660001L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.years();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        long long20 = iSOChronology14.add(readablePeriod17, (long) 2, (-1));
        org.joda.time.DurationField durationField21 = iSOChronology14.hours();
        org.joda.time.DurationField durationField22 = iSOChronology14.halfdays();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology14.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        int int27 = dateTimeZone24.getOffsetFromLocal(48L);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime29.withMonthOfYear(6);
        org.joda.time.DateTime dateTime33 = dateTime31.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) (short) 10);
        int int38 = dateTime35.getMonthOfYear();
        org.joda.time.DateTime.Property property39 = dateTime35.millisOfDay();
        org.joda.time.DateTime dateTime41 = dateTime35.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
        org.joda.time.DateTime dateTime43 = dateTime33.withFields((org.joda.time.ReadablePartial) localDateTime42);
        boolean boolean44 = dateTimeZone24.isLocalDateTimeGap(localDateTime42);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.plusWeeks((int) (short) 10);
        int int49 = dateTime46.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) (byte) -1);
        long long57 = offsetDateTimeField54.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField54.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, "Pacific Standard Time");
        org.joda.time.DateTime dateTime62 = dateTime46.withField(dateTimeFieldType58, 0);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone63);
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.minuteOfDay();
        org.joda.time.DurationField durationField66 = iSOChronology64.halfdays();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology64.secondOfMinute();
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology64);
        org.joda.time.DateTime dateTime69 = dateTime62.withChronology((org.joda.time.Chronology) iSOChronology64);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter70.withZone(dateTimeZone71);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = dateTimeFormatter72.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.now(dateTimeZone74);
        org.joda.time.DateTime dateTime77 = dateTime75.plusWeeks((int) (short) 10);
        int int78 = dateTime75.getMonthOfYear();
        org.joda.time.DateTime.Property property79 = dateTime75.millisOfDay();
        org.joda.time.DateTime dateTime81 = dateTime75.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime82 = dateTime81.toLocalDateTime();
        java.lang.String str83 = dateTimeFormatter72.print((org.joda.time.ReadablePartial) localDateTime82);
        int[] intArray85 = iSOChronology64.get((org.joda.time.ReadablePartial) localDateTime82, (long) (-28800000));
        iSOChronology14.validate((org.joda.time.ReadablePartial) localDateTime42, intArray85);
        java.util.Locale locale87 = null;
        java.lang.String str88 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDateTime42, locale87);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2L + "'", long20 == 2L);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 600001L + "'", long57 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(localDateTime82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "5270-W01-3" + "'", str83.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "0" + "'", str88.equals("0"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        int int12 = offsetDateTimeField4.get(660001L);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField4.getMaximumTextLength(locale13);
        int int15 = offsetDateTimeField4.getMaximumValue();
        long long17 = offsetDateTimeField4.roundHalfEven((long) 2019);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1438 + "'", int15 == 1438);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.Chronology chronology18 = gregorianChronology16.withUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology16.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter0.withZone(dateTimeZone19);
        int int22 = dateTimeZone19.getOffsetFromLocal((long) 22);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        try {
            long long25 = unsupportedDateTimeField22.roundHalfFloor(40920000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime18 = property5.roundHalfCeilingCopy();
        int int19 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86399999 + "'", int19 == 86399999);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsText((long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        java.lang.String str6 = offsetDateTimeField4.getAsText((long) 52743869);
        boolean boolean8 = offsetDateTimeField4.isLeap((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 100, (java.lang.Number) 960, (java.lang.Number) 60960L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType17, 10);
        long long25 = offsetDateTimeField23.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "878" + "'", str6.equals("878"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 600001L + "'", long16 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-4L) + "'", long25 == (-4L));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("52743686");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"52743686\" is malformed at \"743686\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 39, (java.lang.Number) (-52750), (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 52743869, 600001L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31646374143869L + "'", long2 == 31646374143869L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.plus(0L);
        int int9 = dateTime5.getSecondOfMinute();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.withDurationAdded(readableDuration10, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (short) 10);
        int int9 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime6.millisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
        java.lang.String str14 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDateTime13);
        boolean boolean15 = dateTimeZone0.isLocalDateTimeGap(localDateTime13);
        long long17 = dateTimeZone0.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5270-W01-3" + "'", str14.equals("5270-W01-3"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((long) 4, locale8);
        long long11 = fixedDateTimeZone4.nextTransition(292259996L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 292259996L + "'", long11 == 292259996L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 152L + "'", long2 == 152L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology21.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone12.getName((long) (short) 100, locale14);
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime18 = dateTime11.plusMonths(960);
        org.joda.time.DateTime dateTime20 = dateTime11.minusMillis((-25200000));
        try {
            org.joda.time.DateTime dateTime22 = dateTime11.withSecondOfMinute((-98));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.004" + "'", str15.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime1.toString("10", locale6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        boolean boolean4 = dateTime1.isAfterNow();
        org.joda.time.DateTime dateTime6 = dateTime1.withMonthOfYear((int) (byte) 1);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) 10);
        int int6 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime.Property property7 = dateTime3.millisOfDay();
        int int8 = property7.getMinimumValue();
        int int9 = property7.getMaximumValue();
        java.lang.String str10 = property7.getAsText();
        org.joda.time.DateTime dateTime11 = property7.getDateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes(2019);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399999 + "'", int9 == 86399999);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1973" + "'", str10.equals("1973"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("000000.004+0000", (java.lang.Number) (-1.0f), number2, (java.lang.Number) 2L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-971));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("-52750", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 20190);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        long long9 = offsetDateTimeField4.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) (short) 10);
        int int14 = dateTime11.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        long long22 = offsetDateTimeField19.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "Pacific Standard Time");
        org.joda.time.DateTime dateTime27 = dateTime11.withField(dateTimeFieldType23, 0);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.minuteOfDay();
        org.joda.time.DurationField durationField31 = iSOChronology29.halfdays();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.secondOfMinute();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime dateTime34 = dateTime27.withChronology((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter35.withZone(dateTimeZone36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter37.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime40.plusWeeks((int) (short) 10);
        int int43 = dateTime40.getMonthOfYear();
        org.joda.time.DateTime.Property property44 = dateTime40.millisOfDay();
        org.joda.time.DateTime dateTime46 = dateTime40.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime47 = dateTime46.toLocalDateTime();
        java.lang.String str48 = dateTimeFormatter37.print((org.joda.time.ReadablePartial) localDateTime47);
        int[] intArray50 = iSOChronology29.get((org.joda.time.ReadablePartial) localDateTime47, (long) (-28800000));
        int int51 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDateTime47);
        java.lang.String str53 = offsetDateTimeField4.getAsShortText((long) (byte) 100);
        long long55 = offsetDateTimeField4.roundCeiling(4L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600001L + "'", long22 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "5270-W01-3" + "'", str48.equals("5270-W01-3"));
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "-1" + "'", str53.equals("-1"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 59996L + "'", long55 == 59996L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-31535999999L), (java.lang.Number) 60960L, (java.lang.Number) 1560634800000L);
        java.lang.Number number13 = illegalFieldValueException12.getLowerBound();
        java.lang.Number number14 = illegalFieldValueException12.getUpperBound();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 60960L + "'", number13.equals(60960L));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1560634800000L + "'", number14.equals(1560634800000L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("57601969", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"57601969/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        long long12 = offsetDateTimeField9.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Pacific Standard Time");
        org.joda.time.DateTime dateTime17 = dateTime1.withField(dateTimeFieldType13, 0);
        org.joda.time.DateTime dateTime19 = dateTime1.withCenturyOfEra((int) ' ');
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 600001L + "'", long12 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long6 = offsetDateTimeField4.roundHalfFloor(60000L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText(973, locale8);
        try {
            long long12 = offsetDateTimeField4.set((long) 52, "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 59996L + "'", long6 == 59996L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "973" + "'", str9.equals("973"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getName((long) (short) 100, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) -1);
        long long17 = offsetDateTimeField14.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField14.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) (short) 10);
        int int23 = dateTime20.getMonthOfYear();
        org.joda.time.DateTime.Property property24 = dateTime20.millisOfDay();
        org.joda.time.DateTime dateTime26 = dateTime20.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDateTime27, (int) (short) 10, locale29);
        int int31 = property9.compareTo((org.joda.time.ReadablePartial) localDateTime27);
        org.joda.time.DateTime dateTime32 = property9.withMinimumValue();
        org.joda.time.DateTime dateTime34 = property9.setCopy("6");
        long long35 = property9.remainder();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.004" + "'", str3.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 600001L + "'", long17 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1973L + "'", long35 == 1973L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.String str18 = property17.getAsShortText();
        int int19 = property17.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "958" + "'", str18.equals("958"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292278993 + "'", int19 == 292278993);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder3.setStandardOffset(2);
        java.io.OutputStream outputStream9 = null;
        try {
            dateTimeZoneBuilder7.writeTo("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]", outputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField22.getAsShortText((int) (short) 1, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "millisOfDay", "14:39:13.631");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "0", "");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "", "1969-W01-2");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DurationField durationField3 = iSOChronology1.eras();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = iSOChronology1.get(readablePeriod4, (long) (short) -1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        java.lang.String str6 = offsetDateTimeField4.getAsText((long) 52743869);
        boolean boolean8 = offsetDateTimeField4.isLeap((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 100, (java.lang.Number) 960, (java.lang.Number) 60960L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType17, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "57600039");
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "878" + "'", str6.equals("878"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 600001L + "'", long16 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology21.getZone();
        try {
            long long31 = zonedChronology21.getDateTimeMillis(0, 973, 1969, (int) (short) 0, 0, 1973, 107);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1973 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[1969-12-31T16:00:01.969-08:00]" + "'", str3.equals("ISOChronology[1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
        int int11 = offsetDateTimeField9.get((long) 0);
        int int14 = offsetDateTimeField9.getDifference(0L, 10L);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        int int21 = offsetDateTimeField19.get((long) 0);
        int int22 = offsetDateTimeField19.getMinimumValue();
        long long25 = offsetDateTimeField19.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale28 = null;
        java.lang.String str29 = dateTimeZone26.getName((long) (short) 100, locale28);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        int int32 = dateTimeZone26.getOffset((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.minus(readableDuration33);
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.minus(readablePeriod36);
        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
        int[] intArray42 = new int[] { 4, 52 };
        int[] intArray44 = offsetDateTimeField19.add((org.joda.time.ReadablePartial) localTime38, 2019, intArray42, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) (byte) -1);
        int int51 = offsetDateTimeField49.get((long) 0);
        int int52 = offsetDateTimeField49.getMinimumValue();
        long long55 = offsetDateTimeField49.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale58 = null;
        java.lang.String str59 = dateTimeZone56.getName((long) (short) 100, locale58);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone60);
        int int62 = dateTimeZone56.getOffset((org.joda.time.ReadableInstant) dateTime61);
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.DateTime dateTime64 = dateTime61.minus(readableDuration63);
        org.joda.time.DateTime.Property property65 = dateTime64.year();
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.DateTime dateTime67 = dateTime64.minus(readablePeriod66);
        org.joda.time.LocalTime localTime68 = dateTime67.toLocalTime();
        int[] intArray72 = new int[] { 4, 52 };
        int[] intArray74 = offsetDateTimeField49.add((org.joda.time.ReadablePartial) localTime68, 2019, intArray72, (int) (byte) 0);
        int int75 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localTime38, intArray72);
        long long77 = iSOChronology1.set((org.joda.time.ReadablePartial) localTime38, (long) 59);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 660001L + "'", long25 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.004" + "'", str29.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localTime38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 660001L + "'", long55 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "+00:00:00.004" + "'", str59.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localTime68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1969L + "'", long77 == 1969L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear(959);
        int int15 = dateTime11.getMillisOfDay();
        org.joda.time.DateTime.Property property16 = dateTime11.monthOfYear();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        int int25 = dateTimeZone22.getOffsetFromLocal(48L);
        java.lang.String str26 = dateTimeZone22.toString();
        org.joda.time.DateTime dateTime27 = dateTime21.withZoneRetainFields(dateTimeZone22);
        org.joda.time.DateTime.Property property28 = dateTime21.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks((int) (short) 10);
        int int33 = dateTime30.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        long long41 = offsetDateTimeField38.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "Pacific Standard Time");
        org.joda.time.DateTime dateTime46 = dateTime30.withField(dateTimeFieldType42, 0);
        org.joda.time.DateTime dateTime48 = dateTime30.minusSeconds(1);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone52);
        org.joda.time.DateTime dateTime55 = dateTime48.withZone(dateTimeZone52);
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime55);
        long long57 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1973 + "'", int15 == 1973);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str26.equals("1969-12-31T16:00:01.969-08:00"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 600001L + "'", long41 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 39600L + "'", long57 == 39600L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) 10);
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.withCenturyOfEra((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology15 = gregorianChronology14.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withChronology(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter3.parseMutableDateTime("878");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"878\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        boolean boolean9 = offsetDateTimeField4.isSupported();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) -1);
        long long16 = offsetDateTimeField14.roundHalfFloor(60000L);
        long long18 = offsetDateTimeField14.roundHalfFloor((long) 960);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMonthOfYear(6);
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName((long) (short) 100, locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.minus(readableDuration32);
        org.joda.time.DateTime.Property property34 = dateTime33.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.minus(readablePeriod35);
        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
        org.joda.time.DateTime dateTime38 = dateTime24.withFields((org.joda.time.ReadablePartial) localTime37);
        int int39 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localTime37);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
        int int47 = offsetDateTimeField45.get((long) 0);
        int int48 = offsetDateTimeField45.getMinimumValue();
        long long51 = offsetDateTimeField45.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale54 = null;
        java.lang.String str55 = dateTimeZone52.getName((long) (short) 100, locale54);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
        int int58 = dateTimeZone52.getOffset((org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.DateTime dateTime60 = dateTime57.minus(readableDuration59);
        org.joda.time.DateTime.Property property61 = dateTime60.year();
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime63 = dateTime60.minus(readablePeriod62);
        org.joda.time.LocalTime localTime64 = dateTime63.toLocalTime();
        int[] intArray68 = new int[] { 4, 52 };
        int[] intArray70 = offsetDateTimeField45.add((org.joda.time.ReadablePartial) localTime64, 2019, intArray68, (int) (byte) 0);
        int[] intArray72 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) localTime37, 86399999, intArray68, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 59996L + "'", long16 == 59996L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-4L) + "'", long18 == (-4L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.004" + "'", str28.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1438 + "'", int39 == 1438);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 660001L + "'", long51 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "+00:00:00.004" + "'", str55.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localTime64);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        long long7 = durationField4.subtract((-967L), 1970);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1970967L) + "'", long7 == (-1970967L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsText((-31535999999L), locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsShortText(6, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        long long10 = offsetDateTimeField4.remainder((long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 36L + "'", long10 == 36L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("5219-W24-6", 20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(20190);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder3.setStandardOffset(2);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder3.addRecurringSavings("", 682, 52, 52750, '#', 86399999, 0, 144001968, false, 2126);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField22.getAsText(0L, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) 10);
        int int7 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.plus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime4.secondOfMinute();
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime4.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology1.withZone(dateTimeZone13);
        try {
            long long19 = gregorianChronology1.getDateTimeMillis(20190, 0, 4, 57601969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekyear(12);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560634750095L, 52743869);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 1560634750095 * 52743869");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((int) (short) 10);
        int int4 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        int int12 = property11.getMinimumValue();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
        java.lang.String str15 = dateTime14.toString();
        int int16 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = property5.roundCeilingCopy();
        org.joda.time.LocalDate localDate18 = dateTime17.toLocalDate();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01T00:00:01.973+00:00:00.004" + "'", str15.equals("1970-01-01T00:00:01.973+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone16.getShortName((long) 1969, locale23);
        java.lang.String str26 = dateTimeZone16.getShortName((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.004" + "'", str24.equals("+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.004" + "'", str26.equals("+00:00:00.004"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        long long25 = durationField21.subtract((long) (byte) 1, 57600039);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-57600038L) + "'", long25 == (-57600038L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 973, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 973L + "'", long2 == 973L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1973);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long6 = offsetDateTimeField4.roundHalfFloor(60000L);
        int int8 = offsetDateTimeField4.getMaximumValue((long) (-25200000));
        long long10 = offsetDateTimeField4.roundCeiling((long) 86399999);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 59996L + "'", long6 == 59996L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86459996L + "'", long10 == 86459996L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsShortText((-25200000), locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName((long) (short) 100, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((-52750));
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(6);
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone28.getName((long) (short) 100, locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
        int int34 = dateTimeZone28.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.minus(readableDuration35);
        org.joda.time.DateTime.Property property37 = dateTime36.year();
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime36.minus(readablePeriod38);
        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
        org.joda.time.DateTime dateTime41 = dateTime27.withFields((org.joda.time.ReadablePartial) localTime40);
        org.joda.time.DateTime dateTime43 = dateTime27.plusWeeks(0);
        org.joda.time.DateTime dateTime45 = dateTime27.plusMonths(39);
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.MutableDateTime mutableDateTime47 = dateTime21.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.004" + "'", str9.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.004" + "'", str31.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        long long26 = unsupportedDateTimeField22.add(6048001969L, 4L);
        try {
            long long29 = unsupportedDateTimeField22.addWrapField(40920000L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6048001973L + "'", long26 == 6048001973L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear(6);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName((long) (short) 100, locale12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.minus(readableDuration17);
        org.joda.time.DateTime.Property property19 = dateTime18.year();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.minus(readablePeriod20);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime9.withFields((org.joda.time.ReadablePartial) localTime22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((-52750));
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime23);
        java.lang.String str27 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Pacific Standard Time\")"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.004" + "'", str13.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 10);
        int int10 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime12 = dateTime7.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property13 = dateTime7.era();
        org.joda.time.DateTime dateTime14 = property13.getDateTime();
        boolean boolean15 = zonedChronology5.equals((java.lang.Object) property13);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 1, 20190);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 39, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.969-08:00", "", 4, 0);
        java.lang.String str11 = fixedDateTimeZone9.getNameKey((long) (byte) 10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone9.getName((long) 4, locale13);
        long long16 = fixedDateTimeZone9.nextTransition((long) (byte) 1);
        boolean boolean17 = fixedDateTimeZone9.isFixed();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = iSOChronology20.years();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = iSOChronology20.add(readablePeriod23, (long) 2, (-1));
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(48L, (org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime dateTime29 = dateTime27.plusSeconds(2);
        int int30 = fixedDateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime31 = dateTime4.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.004" + "'", str14.equals("+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.Object obj22 = null;
        boolean boolean23 = zonedChronology21.equals(obj22);
        try {
            long long31 = zonedChronology21.getDateTimeMillis(107, 959, 2019, 969, 1970, 10, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 100, (long) 10);
        int int12 = offsetDateTimeField4.get(660001L);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField4.getMaximumTextLength(locale13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology16.halfdays();
        long long22 = iSOChronology16.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField23 = iSOChronology16.millis();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMonthOfYear(6);
        org.joda.time.DateTime dateTime29 = dateTime27.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.plusWeeks((int) (short) 10);
        int int34 = dateTime31.getMonthOfYear();
        org.joda.time.DateTime.Property property35 = dateTime31.millisOfDay();
        org.joda.time.DateTime dateTime37 = dateTime31.withCenturyOfEra((int) '4');
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        org.joda.time.DateTime dateTime39 = dateTime29.withFields((org.joda.time.ReadablePartial) localDateTime38);
        boolean boolean40 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime38);
        long long42 = iSOChronology16.set((org.joda.time.ReadablePartial) localDateTime38, (long) 682);
        int int43 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDateTime38);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60960L + "'", long22 == 60960L);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 104138006401969L + "'", long42 == 104138006401969L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 879);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        long long10 = offsetDateTimeField4.add(0L, (-28800971L));
        long long13 = offsetDateTimeField4.add((long) 39, (int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1728058260000L) + "'", long10 == (-1728058260000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5820039L + "'", long13 == 5820039L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (byte) 1, (int) (short) 1);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long11 = offsetDateTimeField4.addWrapField(1969L, 0);
        long long14 = offsetDateTimeField4.set((-1970967L), 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60001L + "'", long7 == 60001L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "minuteOfDay" + "'", str8.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-86330967L) + "'", long14 == (-86330967L));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) (short) 1, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 20190, "millisOfDay");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology13.halfdays();
        long long19 = iSOChronology13.add((long) 959, 60001L, (int) (byte) 1);
        org.joda.time.DurationField durationField20 = iSOChronology13.millis();
        org.joda.time.DurationField durationField21 = iSOChronology13.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
        long long31 = offsetDateTimeField28.add((long) (byte) 1, (int) (short) 1);
        long long33 = offsetDateTimeField28.roundHalfEven((long) (byte) 0);
        org.joda.time.DurationField durationField34 = offsetDateTimeField28.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) -1);
        int int41 = offsetDateTimeField39.get((long) 0);
        int int42 = offsetDateTimeField39.getMinimumValue();
        long long45 = offsetDateTimeField39.add(600001L, 1L);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale48 = null;
        java.lang.String str49 = dateTimeZone46.getName((long) (short) 100, locale48);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now(dateTimeZone50);
        int int52 = dateTimeZone46.getOffset((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.ReadableDuration readableDuration53 = null;
        org.joda.time.DateTime dateTime54 = dateTime51.minus(readableDuration53);
        org.joda.time.DateTime.Property property55 = dateTime54.year();
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime57 = dateTime54.minus(readablePeriod56);
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        int[] intArray62 = new int[] { 4, 52 };
        int[] intArray64 = offsetDateTimeField39.add((org.joda.time.ReadablePartial) localTime58, 2019, intArray62, (int) (byte) 0);
        int int65 = offsetDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localTime58);
        try {
            int int66 = unsupportedDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localTime58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 600001L + "'", long7 == 600001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 60960L + "'", long19 == 60960L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 60001L + "'", long31 == 60001L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-4L) + "'", long33 == (-4L));
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 660001L + "'", long45 == 660001L);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00:00.004" + "'", str49.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) 100, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName((long) (short) 100, locale18);
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone16);
        java.lang.String str22 = zonedChronology21.toString();
        java.lang.String str23 = zonedChronology21.toString();
        java.lang.Object obj24 = null;
        boolean boolean25 = zonedChronology21.equals(obj24);
        try {
            long long30 = zonedChronology21.getDateTimeMillis(100, 12, 0, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.004" + "'", str19.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str22.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]" + "'", str23.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-31T16:00:01.969-08:00]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-52750));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName((long) (short) 100, locale3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        int int7 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime6);
        java.lang.String str8 = dateTimeZone1.toString();
        long long11 = dateTimeZone1.adjustOffset((-28799968L), false);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', dateTimeZone1);
        java.lang.String str13 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.004" + "'", str4.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str8.equals("1969-12-31T16:00:01.969-08:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28799968L) + "'", long11 == (-28799968L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31T16:00:01.969-08:00" + "'", str13.equals("1969-12-31T16:00:01.969-08:00"));
    }
}

