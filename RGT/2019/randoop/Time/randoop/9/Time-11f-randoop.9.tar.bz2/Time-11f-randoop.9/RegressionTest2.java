import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.Period period8 = new org.joda.time.Period(10000, (int) (short) 10, (-1), 2922799, 29, 288000, 101, 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-287999));
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.year();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (long) 100, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period12 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Seconds seconds13 = period12.toStandardSeconds();
        org.joda.time.Period period14 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period16 = period12.withWeeks(29);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = dateTimeZone5.getMillisKeepLocal(dateTimeZone11, (long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.PeriodType periodType7 = periodType3.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("DateTimeField[clockhourOfDay]", 124, 8, 7, '4', 287999, 8, 0, false, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder13.setStandardOffset(4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.era();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.millisOfSecond();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, 287999, (-287999), (int) (short) 0, 287999, (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 287999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(60483000931200000L, periodType1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusSeconds((int) 'a');
        org.joda.time.Period period11 = period7.minusDays(2);
        org.joda.time.Period period12 = period7.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withYearsRemoved();
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone8.isLocalDateTimeGap(localDateTime9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField12 = iSOChronology11.weeks();
        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.yearOfEra();
        org.joda.time.DurationField durationField17 = iSOChronology11.minutes();
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((-257171673599920L), periodType7, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -4286194559");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "PT-0.009S");
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.ReadableInstant readableInstant9 = null;
        int int10 = fixedDateTimeZone4.getOffset(readableInstant9);
        int int12 = fixedDateTimeZone4.getStandardOffset((-3600000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        try {
            long long10 = unsupportedDurationField5.getValueAsLong(314496000000005200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("YearMonthDay", 0, 97, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for YearMonthDay must be in the range [97,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.Period period1 = org.joda.time.Period.hours(101);
        int int2 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.Object obj0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, chronology1);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime3 = null;
//        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
//        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime10 = null;
//        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone14.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        long long19 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime21 = null;
//        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        long long25 = dateTimeZone14.getMillisKeepLocal(dateTimeZone20, (long) ' ');
//        org.joda.time.Chronology chronology26 = iSOChronology5.withZone(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology5.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology5.getZone();
//        java.lang.String str30 = dateTimeZone28.getShortName(60482054246400000L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField12.getMaximumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "9");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "DateTimeField[clockhourOfDay]");
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2922799 + "'", int23 == 2922799);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.clockhourOfDay();
        org.joda.time.Period period11 = org.joda.time.Period.millis(1);
        int[] intArray13 = iSOChronology5.get((org.joda.time.ReadablePeriod) period11, 0L);
        org.joda.time.Period period15 = period11.plusYears(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray16 = period11.getFieldTypes();
        org.joda.time.format.PeriodFormatter periodFormatter17 = null;
        java.lang.String str18 = period11.toString(periodFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldTypeArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.001S" + "'", str18.equals("PT0.001S"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField14 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.yearOfCentury();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone17.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = dateTimeZone22.isLocalDateTimeGap(localDateTime23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        long long27 = dateTimeZone17.getMillisKeepLocal(dateTimeZone22, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime29 = null;
        boolean boolean30 = dateTimeZone28.isLocalDateTimeGap(localDateTime29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        long long33 = dateTimeZone22.getMillisKeepLocal(dateTimeZone28, (long) ' ');
        org.joda.time.Chronology chronology34 = iSOChronology13.withZone(dateTimeZone28);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period36 = new org.joda.time.Period(0L, (long) '4', periodType7, chronology35);
        int int37 = period36.getDays();
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Duration duration39 = period36.toDurationFrom(readableInstant38);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 32L + "'", long33 == 32L);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(duration39);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        long long43 = offsetDateTimeField12.roundHalfFloor((long) (short) 100);
        boolean boolean44 = offsetDateTimeField12.isLenient();
        boolean boolean46 = offsetDateTimeField12.isLeap(92036995200000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 946684800000L + "'", long43 == 946684800000L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getStandardOffset((-287999L));
        long long11 = cachedDateTimeZone7.previousTransition((-6048000000000L));
        long long13 = cachedDateTimeZone7.previousTransition((long) (byte) 0);
        long long15 = cachedDateTimeZone7.nextTransition(32L);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period18 = org.joda.time.Period.months(52);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period18.toDurationTo(readableInstant19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration20);
        boolean boolean22 = cachedDateTimeZone7.equals((java.lang.Object) readableInstant16);
        java.lang.String str24 = cachedDateTimeZone7.getNameKey(221937235200000L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = cachedDateTimeZone7.getShortName(800L, locale26);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-6048000000000L) + "'", long11 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.052" + "'", str27.equals("+00:00:00.052"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1100);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMonthsRemoved();
        org.joda.time.PeriodType periodType9 = periodType6.withSecondsRemoved();
        int int10 = periodType9.size();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        long long22 = offsetDateTimeField12.add((long) 'a', 0L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField12.getAsText(readablePartial23, (int) (byte) 100, locale25);
        long long28 = offsetDateTimeField12.roundCeiling((-604800000000000L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-598635360000000L) + "'", long28 == (-598635360000000L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        long long12 = fixedDateTimeZone9.nextTransition(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long21 = fixedDateTimeZone18.nextTransition(3200L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3200L + "'", long21 == 3200L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long12 = preciseDurationField6.getValueAsLong(0L);
        long long15 = preciseDurationField6.getValueAsLong(0L, (-1L));
        long long18 = preciseDurationField6.getMillis(0L, 0L);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField25 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) (short) 100);
        int int27 = preciseDurationField25.getValue((long) '4');
        int int28 = preciseDurationField6.compareTo((org.joda.time.DurationField) preciseDurationField25);
        long long31 = preciseDurationField25.getMillis(110, (long) 29);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 11000L + "'", long31 == 11000L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekOfWeekyear();
        java.lang.String str5 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        int int65 = offsetDateTimeField12.getLeapAmount(165042835200000L);
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField12.getMaximumShortTextLength(locale66);
        long long69 = offsetDateTimeField12.roundHalfFloor((long) 2879);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 7 + "'", int67 == 7);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 946684800000L + "'", long69 == 946684800000L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(60480000000000L, chronology1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        long long65 = offsetDateTimeField12.roundHalfCeiling((-100L));
        long long67 = offsetDateTimeField12.roundHalfFloor(946684800132L);
        int int70 = offsetDateTimeField12.getDifference(0L, 604800000010000L);
        org.joda.time.ReadablePartial readablePartial71 = null;
        java.util.Locale locale72 = null;
        try {
            java.lang.String str73 = offsetDateTimeField12.getAsText(readablePartial71, locale72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 946684800000L + "'", long65 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684800000L + "'", long67 == 946684800000L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-191) + "'", int70 == (-191));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P-1D");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("P-1D");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (short) 100);
        java.lang.String str14 = preciseDurationField13.getName();
        int int17 = preciseDurationField13.getDifference((long) 100, (long) (byte) 10);
        long long19 = preciseDurationField13.getValueAsLong(0L);
        long long22 = preciseDurationField13.getValueAsLong(0L, (-1L));
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        long long35 = iSOChronology28.add((long) (short) 0, (long) '4', (int) '4');
        org.joda.time.DurationField durationField36 = iSOChronology28.halfdays();
        boolean boolean37 = preciseDurationField13.equals((java.lang.Object) iSOChronology28);
        org.joda.time.Period period39 = org.joda.time.Period.millis(1);
        org.joda.time.Period period41 = period39.plusDays((int) (byte) -1);
        int int42 = period39.getMinutes();
        org.joda.time.Period period44 = period39.withWeeks((int) '#');
        int int45 = period39.getMinutes();
        int[] intArray48 = iSOChronology28.get((org.joda.time.ReadablePeriod) period39, 3140588L, 287999L);
        jodaTimePermission1.checkGuard((java.lang.Object) iSOChronology28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P-1D\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"P-1D\")"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P-1D\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"P-1D\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "minutes" + "'", str14.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2704L + "'", long35 == 2704L);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.yearOfCentury();
        org.joda.time.Chronology chronology8 = iSOChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long12 = preciseDurationField6.getValueAsLong(0L);
        long long15 = preciseDurationField6.getValueAsLong(0L, (-1L));
        long long18 = preciseDurationField6.getMillis(0L, 0L);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField25 = iSOChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.yearOfCentury();
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Chronology chronology28 = iSOChronology24.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology24.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray35 = new int[] { ' ', 97 };
        int int36 = offsetDateTimeField31.getMinimumValue(readablePartial32, intArray35);
        long long39 = offsetDateTimeField31.add(10L, (long) '4');
        java.util.Locale locale40 = null;
        int int41 = offsetDateTimeField31.getMaximumTextLength(locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime46 = null;
        boolean boolean47 = dateTimeZone45.isLocalDateTimeGap(localDateTime46);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DurationField durationField49 = iSOChronology48.weeks();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.yearOfCentury();
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.Period period53 = org.joda.time.Period.hours(10);
        int[] intArray55 = iSOChronology48.get((org.joda.time.ReadablePeriod) period53, 60480000000000L);
        int int56 = offsetDateTimeField31.getMinimumValue(readablePartial42, intArray55);
        boolean boolean57 = preciseDurationField6.equals((java.lang.Object) intArray55);
        try {
            int int60 = preciseDurationField6.getDifference((-908836115155200000L), (long) 124);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -9088361151552001");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 164096150400010L + "'", long39 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 7 + "'", int41 == 7);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) 97);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10.0", "PT0.001S");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Minutes");
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.yearOfCentury();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean14 = fixedDateTimeZone13.isFixed();
        java.lang.String str15 = fixedDateTimeZone13.toString();
        java.util.TimeZone timeZone16 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.Chronology chronology17 = iSOChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Period period18 = new org.joda.time.Period(287999L, chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        java.lang.Number number21 = illegalFieldValueException20.getIllegalNumberValue();
        java.lang.String str22 = illegalFieldValueException20.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType23 = illegalFieldValueException20.getDurationFieldType();
        java.lang.Number number24 = illegalFieldValueException20.getUpperBound();
        java.lang.Number number25 = illegalFieldValueException20.getLowerBound();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0" + "'", str22.equals("10.0"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10L + "'", number24.equals(10L));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (byte) 100 + "'", number25.equals((byte) 100));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        boolean boolean11 = fixedDateTimeZone9.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int14 = cachedDateTimeZone12.getStandardOffset((-287999L));
        long long16 = cachedDateTimeZone12.previousTransition((-6048000000000L));
        long long18 = cachedDateTimeZone12.previousTransition((long) (byte) 0);
        long long20 = cachedDateTimeZone12.nextTransition(32L);
        org.joda.time.Chronology chronology21 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        int int22 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6048000000000L) + "'", long16 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period9.plusMinutes((int) (short) 1);
        org.joda.time.Period period12 = period9.normalizedStandard();
        org.joda.time.Period period14 = period9.withMillis(97);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone19.isLocalDateTimeGap(localDateTime20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField23 = iSOChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.yearOfCentury();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.Chronology chronology26 = iSOChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology22.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology22.centuryOfEra();
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean30 = iSOChronology22.equals((java.lang.Object) periodType29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType29);
        org.joda.time.Period period32 = period14.minus((org.joda.time.ReadablePeriod) period31);
        org.joda.time.Period period34 = period31.minusMonths(9);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.Period period1 = org.joda.time.Period.millis(1);
        org.joda.time.Period period3 = period1.plusDays((int) (byte) -1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds9 = period6.toStandardSeconds();
        org.joda.time.Period period11 = period6.plusDays((-1));
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 0);
        java.lang.String str14 = period11.toString();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        boolean boolean17 = periodType15.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType19 = periodType15.getFieldType(0);
        int int20 = period11.get(durationFieldType19);
        org.joda.time.Period period22 = period3.withField(durationFieldType19, (int) 'a');
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', periodType26);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) 0, chronology29);
        org.joda.time.Period period32 = period30.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
        org.joda.time.Period period35 = period30.plusDays((-1));
        org.joda.time.Period period37 = period35.plusSeconds((int) (short) 0);
        java.lang.String str38 = period35.toString();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.minutes();
        boolean boolean41 = periodType39.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = period35.get(durationFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(durationFieldType43, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean49 = period27.isSupported(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField50 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean51 = unsupportedDurationField50.isPrecise();
        int int52 = unsupportedDurationField24.compareTo((org.joda.time.DurationField) unsupportedDurationField50);
        boolean boolean53 = unsupportedDurationField24.isPrecise();
        boolean boolean54 = unsupportedDurationField24.isPrecise();
        java.lang.String str55 = unsupportedDurationField24.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1D" + "'", str14.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(seconds33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "P-1D" + "'", str38.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "UnsupportedDurationField[minutes]" + "'", str55.equals("UnsupportedDurationField[minutes]"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusYears((int) '#');
        org.joda.time.Period period11 = period7.minusYears(4);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = dateTimeZone5.getMillisKeepLocal(dateTimeZone11, (long) ' ');
        long long18 = dateTimeZone11.convertUTCToLocal(60480000000052L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone19, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 14");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 60480000000052L + "'", long18 == 60480000000052L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long12 = preciseDurationField6.getValueAsLong(0L);
        long long15 = preciseDurationField6.getValueAsLong(0L, (-1L));
        long long18 = preciseDurationField6.getMillis(0L, 0L);
        long long19 = preciseDurationField6.getUnitMillis();
        long long22 = preciseDurationField6.add(306102499200097L, 94670938321032L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9773196331303297L + "'", long22 == 9773196331303297L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField14 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.yearOfCentury();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone17.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = dateTimeZone22.isLocalDateTimeGap(localDateTime23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        long long27 = dateTimeZone17.getMillisKeepLocal(dateTimeZone22, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime29 = null;
        boolean boolean30 = dateTimeZone28.isLocalDateTimeGap(localDateTime29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        long long33 = dateTimeZone22.getMillisKeepLocal(dateTimeZone28, (long) ' ');
        org.joda.time.Chronology chronology34 = iSOChronology13.withZone(dateTimeZone28);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period36 = new org.joda.time.Period(0L, (long) '4', periodType7, chronology35);
        int int37 = period36.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 32L + "'", long33 == 32L);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField9 = iSOChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.monthOfYear();
        boolean boolean14 = gregorianChronology1.equals((java.lang.Object) iSOChronology8);
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        boolean boolean42 = offsetDateTimeField12.isSupported();
        long long45 = offsetDateTimeField12.add(52L, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField12.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-3155673599948L) + "'", long45 == (-3155673599948L));
        org.junit.Assert.assertNotNull(dateTimeField46);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.monthOfYear();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, periodType6);
        org.joda.time.Period period9 = period7.withSeconds((int) '#');
        long long12 = iSOChronology2.add((org.joda.time.ReadablePeriod) period9, 1056586204800000L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1056586205150010L + "'", long12 == 1056586205150010L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.add(52L, (long) 10);
        boolean boolean39 = scaledDurationField31.isPrecise();
        long long41 = scaledDurationField31.getMillis((long) 1);
        long long44 = scaledDurationField31.getDifferenceAsLong((long) 101, (long) '#');
        long long47 = scaledDurationField31.getMillis((-287999), (long) 122757558);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 60480000000052L + "'", long38 == 60480000000052L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 6048000000000L + "'", long41 == 6048000000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1741817952000000000L) + "'", long47 == (-1741817952000000000L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        int int38 = scaledDurationField31.getValue(1L, 0L);
        long long41 = scaledDurationField31.getValueAsLong(200L, 29L);
        long long43 = scaledDurationField31.getValueAsLong(60479845257600000L);
        java.lang.Object obj44 = null;
        boolean boolean45 = scaledDurationField31.equals(obj44);
        java.lang.Class<?> wildcardClass46 = scaledDurationField31.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9999L + "'", long43 == 9999L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.year();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (long) 100, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period12 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Seconds seconds13 = period12.toStandardSeconds();
        org.joda.time.Period period14 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.minutes();
        boolean boolean19 = periodType17.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType20 = periodType17.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
        org.joda.time.PeriodType periodType22 = periodType20.withYearsRemoved();
        org.joda.time.PeriodType periodType23 = periodType20.withMillisRemoved();
        try {
            org.joda.time.Period period24 = period14.withPeriodType(periodType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT0.038S" + "'", str16.equals("PT0.038S"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(readablePartial18, 1, locale20);
        long long23 = offsetDateTimeField12.roundCeiling((long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, 30);
        int int26 = offsetDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2922799 + "'", int26 == 2922799);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add((long) 1, (long) (short) 10);
        long long37 = scaledDurationField31.add((long) (byte) 100, (long) 100);
        long long40 = scaledDurationField31.add((-287999L), 0);
        boolean boolean41 = scaledDurationField31.isPrecise();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60480000000001L + "'", long34 == 60480000000001L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604800000000100L + "'", long37 == 604800000000100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-287999L) + "'", long40 == (-287999L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        boolean boolean11 = fixedDateTimeZone9.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int14 = cachedDateTimeZone12.getStandardOffset((-287999L));
        long long16 = cachedDateTimeZone12.previousTransition((-6048000000000L));
        long long18 = cachedDateTimeZone12.previousTransition((long) (byte) 0);
        long long20 = cachedDateTimeZone12.nextTransition(32L);
        org.joda.time.Chronology chronology21 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = dateTimeZone24.isLocalDateTimeGap(localDateTime25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField28 = iSOChronology27.weeks();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.yearOfCentury();
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology27.clockhourOfDay();
        org.joda.time.Period period33 = org.joda.time.Period.millis(1);
        int[] intArray35 = iSOChronology27.get((org.joda.time.ReadablePeriod) period33, 0L);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.Period period37 = period33.plus(readablePeriod36);
        int int38 = period37.getYears();
        boolean boolean39 = cachedDateTimeZone12.equals((java.lang.Object) period37);
        long long42 = cachedDateTimeZone12.adjustOffset(665280000000000L, false);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6048000000000L) + "'", long16 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 665280000000000L + "'", long42 == 665280000000000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long41 = offsetDateTimeField12.roundCeiling((long) 1);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsText((int) 'a', locale43);
        long long46 = offsetDateTimeField12.remainder(6048000000005235L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 946684800000L + "'", long41 == 946684800000L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "97" + "'", str44.equals("97"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1467763194765L) + "'", long46 == (-1467763194765L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.DurationFieldType durationFieldType9 = unsupportedDurationField5.getType();
        java.lang.String str10 = unsupportedDurationField5.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minutes" + "'", str10.equals("minutes"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.DurationFieldType durationFieldType9 = unsupportedDurationField5.getType();
        try {
            long long11 = unsupportedDurationField5.getValueAsLong((-287999990300L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationFieldType9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = fixedDateTimeZone4.getOffset(readableInstant13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField12.getMaximumTextLength(locale18);
        int int20 = offsetDateTimeField12.getOffset();
        boolean boolean21 = offsetDateTimeField12.isSupported();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField12.getAsShortText((long) 8, locale23);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "29" + "'", str24.equals("29"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getValueAsLong((long) '4', (long) 52);
        long long37 = scaledDurationField31.add(0L, (-1));
        long long40 = scaledDurationField31.getMillis((long) (short) 0, (long) 1);
        int int42 = scaledDurationField31.getValue(254016000000001L);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime44 = null;
        boolean boolean45 = dateTimeZone43.isLocalDateTimeGap(localDateTime44);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.DurationField durationField47 = iSOChronology46.weeks();
        org.joda.time.PeriodType periodType49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) 'a', periodType49);
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (short) 0, chronology52);
        org.joda.time.Period period55 = period53.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds56 = period53.toStandardSeconds();
        org.joda.time.Period period58 = period53.plusDays((-1));
        org.joda.time.Period period60 = period58.plusSeconds((int) (short) 0);
        java.lang.String str61 = period58.toString();
        org.joda.time.PeriodType periodType62 = org.joda.time.PeriodType.minutes();
        boolean boolean64 = periodType62.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType66 = periodType62.getFieldType(0);
        int int67 = period58.get(durationFieldType66);
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(durationFieldType66, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean72 = period50.isSupported(durationFieldType66);
        org.joda.time.field.ScaledDurationField scaledDurationField74 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType66, 10000);
        long long77 = scaledDurationField74.add((long) 1, (long) (short) 10);
        long long80 = scaledDurationField74.add((long) (byte) 100, (long) 100);
        boolean boolean81 = scaledDurationField31.equals((java.lang.Object) (byte) 100);
        long long83 = scaledDurationField31.getMillis(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-6048000000000L) + "'", long37 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 42 + "'", int42 == 42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(seconds56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "P-1D" + "'", str61.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(durationFieldType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 60480000000001L + "'", long77 == 60480000000001L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 604800000000100L + "'", long80 == 604800000000100L);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long42 = offsetDateTimeField12.getDifferenceAsLong(42336000010000L, 41024102400000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsShortText(220L, locale43);
        boolean boolean46 = offsetDateTimeField12.isLeap(99L);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField12.getAsText(100L, locale48);
        try {
            long long52 = offsetDateTimeField12.set((-210590280000000L), 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for centuryOfEra must be in the range [10,2922799]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "29" + "'", str44.equals("29"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "29" + "'", str49.equals("29"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P-1D");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField9 = iSOChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.yearOfCentury();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.Chronology chronology12 = iSOChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 10);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray19 = new int[] { ' ', 97 };
        int int20 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray19);
        long long23 = offsetDateTimeField15.add(10L, (long) '4');
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField15.getMaximumTextLength(locale24);
        jodaTimePermission1.checkGuard((java.lang.Object) locale24);
        org.joda.time.Period period28 = org.joda.time.Period.hours(29);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) 97, chronology30);
        org.joda.time.Period period33 = period31.withYears((-1));
        org.joda.time.Period period35 = period31.multipliedBy((int) (short) 100);
        org.joda.time.Period period37 = period31.withMonths((int) '#');
        org.joda.time.Period period39 = period31.plusHours(10);
        int int40 = period39.size();
        org.joda.time.Minutes minutes41 = period39.toStandardMinutes();
        org.joda.time.Period period42 = period28.plus((org.joda.time.ReadablePeriod) minutes41);
        org.joda.time.Period period44 = period28.minusHours((int) '#');
        jodaTimePermission1.checkGuard((java.lang.Object) period28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P-1D\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"P-1D\")"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 164096150400010L + "'", long23 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 8 + "'", int40 == 8);
        org.junit.Assert.assertNotNull(minutes41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period44);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(readablePartial18, 1, locale20);
        long long23 = offsetDateTimeField12.roundCeiling((long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, 30);
        long long28 = offsetDateTimeField12.add((long) 5, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 306102499200005L + "'", long28 == 306102499200005L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        org.joda.time.Period period13 = period9.plusYears((int) (byte) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField12.getAsText((int) (byte) -1, locale41);
        boolean boolean44 = offsetDateTimeField12.isLeap((-18478968L));
        boolean boolean46 = offsetDateTimeField12.isLeap(1L);
        long long48 = offsetDateTimeField12.roundHalfEven(53L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-1" + "'", str42.equals("-1"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 946684800000L + "'", long48 == 946684800000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        long long9 = preciseDurationField6.getMillis(0);
        long long12 = preciseDurationField6.add(604800000000000L, 100);
        boolean boolean13 = preciseDurationField6.isPrecise();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 604800000010000L + "'", long12 == 604800000010000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) (short) 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, chronology11);
        org.joda.time.Period period14 = period12.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.joda.time.Period period17 = period12.plusDays((-1));
        org.joda.time.Period period19 = period17.plusSeconds((int) (short) 0);
        boolean boolean20 = fixedDateTimeZone4.equals((java.lang.Object) period17);
        java.util.TimeZone timeZone21 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str23 = fixedDateTimeZone4.getNameKey((long) (byte) -1);
        int int25 = fixedDateTimeZone4.getOffsetFromLocal(171734428800100L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(seconds15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withDaysRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType8 = periodType7.withDaysRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType7);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.Period period1 = org.joda.time.Period.millis(1);
        org.joda.time.Period period3 = period1.plusDays((int) (byte) -1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds9 = period6.toStandardSeconds();
        org.joda.time.Period period11 = period6.plusDays((-1));
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 0);
        java.lang.String str14 = period11.toString();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        boolean boolean17 = periodType15.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType19 = periodType15.getFieldType(0);
        int int20 = period11.get(durationFieldType19);
        org.joda.time.Period period22 = period3.withField(durationFieldType19, (int) 'a');
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 0, chronology24);
        org.joda.time.Period period27 = period25.minusMonths((int) (byte) 10);
        org.joda.time.Period period29 = period25.plusMonths((int) '#');
        org.joda.time.Period period31 = org.joda.time.Period.hours(29);
        org.joda.time.Period period33 = period31.plusWeeks(52);
        org.joda.time.Period period35 = period33.withWeeks(0);
        org.joda.time.Period period37 = org.joda.time.Period.seconds((int) (byte) -1);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 0, chronology39);
        org.joda.time.Period period42 = period40.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds43 = period40.toStandardSeconds();
        org.joda.time.Period period45 = period40.plusDays((-1));
        org.joda.time.Period period47 = period45.plusSeconds((int) (short) 0);
        java.lang.String str48 = period45.toString();
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.minutes();
        boolean boolean51 = periodType49.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType53 = periodType49.getFieldType(0);
        int int54 = period45.get(durationFieldType53);
        int int55 = period37.get(durationFieldType53);
        org.joda.time.PeriodType periodType57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) 'a', periodType57);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period((long) (short) 0, chronology60);
        org.joda.time.Period period63 = period61.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds64 = period61.toStandardSeconds();
        org.joda.time.Period period66 = period61.plusDays((-1));
        org.joda.time.Period period68 = period66.plusSeconds((int) (short) 0);
        java.lang.String str69 = period66.toString();
        org.joda.time.PeriodType periodType70 = org.joda.time.PeriodType.minutes();
        boolean boolean72 = periodType70.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType74 = periodType70.getFieldType(0);
        int int75 = period66.get(durationFieldType74);
        org.joda.time.IllegalFieldValueException illegalFieldValueException79 = new org.joda.time.IllegalFieldValueException(durationFieldType74, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean80 = period58.isSupported(durationFieldType74);
        org.joda.time.field.PreciseDurationField preciseDurationField82 = new org.joda.time.field.PreciseDurationField(durationFieldType74, 254015999999949L);
        boolean boolean83 = period37.isSupported(durationFieldType74);
        int int84 = period33.indexOf(durationFieldType74);
        org.joda.time.Period period86 = period29.withField(durationFieldType74, 0);
        org.joda.time.Period period88 = period3.withField(durationFieldType74, 0);
        int int89 = period88.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1D" + "'", str14.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(seconds43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "P-1D" + "'", str48.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(seconds64);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "P-1D" + "'", str69.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(durationFieldType74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 5 + "'", int84 == 5);
        org.junit.Assert.assertNotNull(period86);
        org.junit.Assert.assertNotNull(period88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 8 + "'", int89 == 8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds6 = period3.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = periodType9.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType13 = periodType9.getFieldType(0);
        org.joda.time.PeriodType periodType14 = periodType9.withMonthsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        boolean boolean18 = periodType16.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType(0);
        org.joda.time.PeriodType periodType21 = periodType16.withSecondsRemoved();
        int int22 = periodType16.size();
        org.joda.time.Period period23 = period15.withPeriodType(periodType16);
        org.joda.time.Period period25 = period15.plusWeeks(0);
        try {
            org.joda.time.Period period27 = period15.minusMillis(29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
//        java.lang.String str2 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Coordinated Universal Time", 0, (int) ' ');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period9.plusMinutes((int) (short) 1);
        org.joda.time.Period period12 = period9.normalizedStandard();
        org.joda.time.Period period14 = period9.withMillis(97);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone19.isLocalDateTimeGap(localDateTime20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField23 = iSOChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.yearOfCentury();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.Chronology chronology26 = iSOChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology22.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology22.centuryOfEra();
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean30 = iSOChronology22.equals((java.lang.Object) periodType29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType29);
        org.joda.time.Period period32 = period14.minus((org.joda.time.ReadablePeriod) period31);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) (short) 0, chronology34);
        org.joda.time.Period period37 = period35.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds38 = period35.toStandardSeconds();
        org.joda.time.Period period40 = period35.plusDays((-1));
        org.joda.time.Period period42 = period40.plusSeconds((int) (short) 0);
        java.lang.String str43 = period40.toString();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.minutes();
        boolean boolean46 = periodType44.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType48 = periodType44.getFieldType(0);
        int int49 = period40.get(durationFieldType48);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(durationFieldType48, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean54 = period31.isSupported(durationFieldType48);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(seconds38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "P-1D" + "'", str43.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.withMonths(124);
        org.joda.time.Period period10 = period8.withMinutes(287999);
        org.joda.time.Period period11 = period8.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        java.lang.String str5 = fixedDateTimeZone4.getID();
        long long7 = fixedDateTimeZone4.nextTransition(28800000L);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset(0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("DateTimeField[clockhourOfDay]", 124, 8, 7, '4', 287999, 8, 0, false, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder13.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Period period9 = period7.plusMonths(1);
        org.joda.time.Period period10 = period4.minus((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period12 = period9.minusYears(30);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        org.joda.time.ReadablePartial readablePartial64 = null;
        int int65 = offsetDateTimeField12.getMaximumValue(readablePartial64);
        long long68 = offsetDateTimeField12.add(0L, 288000);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2922799 + "'", int65 == 2922799);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 908840217600000000L + "'", long68 == 908840217600000000L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.Period period8 = period4.negated();
        int int9 = period4.getWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.DurationFieldType durationFieldType21 = illegalFieldValueException20.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType22 = illegalFieldValueException20.getDurationFieldType();
        java.lang.Throwable[] throwableArray23 = illegalFieldValueException20.getSuppressed();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        int int8 = period2.getMillis();
        org.joda.time.Period period10 = period2.minusHours(1);
        org.joda.time.Period period12 = period10.multipliedBy(0);
        org.joda.time.Period period14 = period10.minusDays(110);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        long long12 = fixedDateTimeZone9.nextTransition(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.Period period16 = org.joda.time.Period.days(14);
        long long19 = gregorianChronology1.add((org.joda.time.ReadablePeriod) period16, (long) 2879, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2879L + "'", long19 == 2879L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period9.plusMinutes((int) (short) 1);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds17 = period14.toStandardSeconds();
        org.joda.time.Period period19 = period14.plusDays((-1));
        org.joda.time.Period period21 = period19.plusSeconds((int) (short) 0);
        java.lang.String str22 = period19.toString();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        boolean boolean25 = periodType23.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        int int28 = period19.get(durationFieldType27);
        org.joda.time.Period period30 = period11.withField(durationFieldType27, 0);
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.minutes();
        boolean boolean33 = periodType31.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType35 = periodType31.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType35);
        org.joda.time.DurationFieldType durationFieldType37 = unsupportedDurationField36.getType();
        int int38 = period30.get(durationFieldType37);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(seconds17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "P-1D" + "'", str22.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(durationFieldType35);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 30);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = dateTimeZone13.isLocalDateTimeGap(localDateTime14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField17 = iSOChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.yearOfCentury();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology20 = iSOChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology16.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray27 = new int[] { ' ', 97 };
        int int28 = offsetDateTimeField23.getMinimumValue(readablePartial24, intArray27);
        java.lang.String str30 = offsetDateTimeField23.getAsText((long) (byte) 1);
        int int32 = offsetDateTimeField23.get((-287999L));
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = offsetDateTimeField23.getMaximumValue(readablePartial33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField23.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType35, 1100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "29" + "'", str30.equals("29"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 29 + "'", int32 == 29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2922799 + "'", int34 == 2922799);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.Period period7 = period2.multipliedBy(97);
        org.joda.time.Weeks weeks8 = period2.toStandardWeeks();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period2.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period10.withSeconds(288000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(weeks8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusSeconds((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.minusMinutes(110);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField7 = iSOChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        org.joda.time.DurationField durationField9 = iSOChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.dayOfMonth();
        boolean boolean12 = gregorianChronology0.equals((java.lang.Object) iSOChronology6);
        org.joda.time.Chronology chronology13 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField14 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.yearOfCentury();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone17.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = dateTimeZone22.isLocalDateTimeGap(localDateTime23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        long long27 = dateTimeZone17.getMillisKeepLocal(dateTimeZone22, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime29 = null;
        boolean boolean30 = dateTimeZone28.isLocalDateTimeGap(localDateTime29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        long long33 = dateTimeZone22.getMillisKeepLocal(dateTimeZone28, (long) ' ');
        org.joda.time.Chronology chronology34 = iSOChronology13.withZone(dateTimeZone28);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period36 = new org.joda.time.Period(0L, (long) '4', periodType7, chronology35);
        org.joda.time.PeriodType periodType37 = periodType7.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 32L + "'", long33 == 32L);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(periodType37);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean21 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException20);
        java.lang.Number number22 = illegalFieldValueException20.getUpperBound();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10L + "'", number22.equals(10L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.Period period7 = period2.plusMillis(2);
        org.joda.time.PeriodType periodType8 = period2.getPeriodType();
        java.lang.String str9 = periodType8.getName();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Standard" + "'", str9.equals("Standard"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds7 = period4.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationTo(readableInstant8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.minutes();
        boolean boolean12 = periodType10.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType14 = periodType10.getFieldType(0);
        org.joda.time.PeriodType periodType15 = periodType10.withMonthsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(seconds7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean21 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException20);
        java.lang.Number number22 = illegalFieldValueException20.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone4.isLocalDateTimeGap(localDateTime5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField8 = iSOChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.yearOfCentury();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Chronology chronology11 = iSOChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.centuryOfEra();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean15 = iSOChronology7.equals((java.lang.Object) periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean22 = fixedDateTimeZone21.isFixed();
        int int24 = fixedDateTimeZone21.getOffsetFromLocal((long) 'a');
        java.lang.String str26 = fixedDateTimeZone21.getNameKey((long) (short) 100);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 0, chronology28);
        org.joda.time.Period period31 = period29.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds32 = period29.toStandardSeconds();
        org.joda.time.Period period34 = period29.plusDays((-1));
        org.joda.time.Period period36 = period34.plusSeconds((int) (short) 0);
        boolean boolean37 = fixedDateTimeZone21.equals((java.lang.Object) period34);
        org.joda.time.Period period39 = period34.minusMinutes(287999);
        int int40 = period34.getMonths();
        org.joda.time.Period period41 = period16.plus((org.joda.time.ReadablePeriod) period34);
        int int42 = period41.getYears();
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(seconds32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 97, chronology1);
        org.joda.time.Period period4 = period2.withYears((-1));
        org.joda.time.Period period6 = period2.multipliedBy((int) (short) 100);
        org.joda.time.Period period8 = period2.withMonths((int) '#');
        org.joda.time.Period period10 = period2.plusHours(10);
        int int11 = period10.size();
        org.joda.time.Minutes minutes12 = period10.toStandardMinutes();
        org.joda.time.Period period14 = org.joda.time.Period.days((int) 'a');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.Period period17 = period10.withFields((org.joda.time.ReadablePeriod) period14);
        int[] intArray18 = period10.getValues();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(minutes12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        java.lang.Number number21 = illegalFieldValueException20.getLowerBound();
        illegalFieldValueException20.prependMessage("");
        java.lang.String str24 = illegalFieldValueException20.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 100 + "'", number21.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value 10.0 for minutes must be in the range [100,10]" + "'", str24.equals("org.joda.time.IllegalFieldValueException: : Value 10.0 for minutes must be in the range [100,10]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.year();
        try {
            long long10 = iSOChronology3.getDateTimeMillis((long) (short) 1, 2879, 42, 101, 124);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2879 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology8.centuries();
        org.joda.time.DurationField durationField13 = iSOChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.secondOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        long long6 = unsupportedDurationField5.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType7 = unsupportedDurationField5.getType();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone8.isLocalDateTimeGap(localDateTime9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField12 = iSOChronology11.weeks();
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', periodType14);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, chronology17);
        org.joda.time.Period period20 = period18.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds21 = period18.toStandardSeconds();
        org.joda.time.Period period23 = period18.plusDays((-1));
        org.joda.time.Period period25 = period23.plusSeconds((int) (short) 0);
        java.lang.String str26 = period23.toString();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.minutes();
        boolean boolean29 = periodType27.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType31 = periodType27.getFieldType(0);
        int int32 = period23.get(durationFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType31, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean37 = period15.isSupported(durationFieldType31);
        org.joda.time.field.ScaledDurationField scaledDurationField39 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType31, 10000);
        long long42 = scaledDurationField39.add((long) 1, (long) (short) 10);
        boolean boolean43 = scaledDurationField39.isPrecise();
        int int44 = unsupportedDurationField5.compareTo((org.joda.time.DurationField) scaledDurationField39);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(seconds21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "P-1D" + "'", str26.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 60480000000001L + "'", long42 == 60480000000001L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.clockhourOfDay();
        org.joda.time.Period period11 = org.joda.time.Period.millis(1);
        int[] intArray13 = iSOChronology5.get((org.joda.time.ReadablePeriod) period11, 0L);
        org.joda.time.Duration duration14 = period11.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        boolean boolean18 = periodType16.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType(0);
        org.joda.time.PeriodType periodType21 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15, periodType22);
        try {
            org.joda.time.Period period25 = period23.plusSeconds((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P-1D");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.Object obj3 = null;
        boolean boolean4 = jodaTimePermission1.equals(obj3);
        java.lang.Class<?> wildcardClass5 = jodaTimePermission1.getClass();
        java.lang.String str6 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "P-1D" + "'", str2.equals("P-1D"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "P-1D" + "'", str6.equals("P-1D"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Period period6 = period2.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.plusSeconds(10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, chronology11);
        org.joda.time.Period period14 = period12.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationTo(readableInstant16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.minutes();
        boolean boolean20 = periodType18.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType22 = periodType18.getFieldType(0);
        org.joda.time.PeriodType periodType23 = periodType18.withMonthsRemoved();
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration17, periodType23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.minutes();
        boolean boolean27 = periodType25.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType29 = periodType25.getFieldType(0);
        org.joda.time.PeriodType periodType30 = periodType25.withSecondsRemoved();
        int int31 = periodType25.size();
        org.joda.time.Period period32 = period24.withPeriodType(periodType25);
        org.joda.time.PeriodType periodType33 = periodType25.withMinutesRemoved();
        org.joda.time.PeriodType periodType34 = periodType33.withMonthsRemoved();
        try {
            org.joda.time.Period period35 = period8.withPeriodType(periodType33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(seconds15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.Period period5 = period1.normalizedStandard(periodType4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT1M" + "'", str3.equals("PT1M"));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '#');
        java.lang.String str3 = dateTimeZone1.getShortName((-254015999999920L));
        long long6 = dateTimeZone1.adjustOffset(946684800132L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.035" + "'", str3.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 946684800132L + "'", long6 == 946684800132L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        long long65 = offsetDateTimeField12.roundHalfCeiling((-100L));
        long long67 = offsetDateTimeField12.roundHalfFloor(946684800132L);
        java.lang.String str69 = offsetDateTimeField12.getAsText(0L);
        org.joda.time.ReadablePartial readablePartial70 = null;
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime74 = null;
        boolean boolean75 = dateTimeZone73.isLocalDateTimeGap(localDateTime74);
        org.joda.time.chrono.ISOChronology iSOChronology76 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone73);
        org.joda.time.DurationField durationField77 = iSOChronology76.weeks();
        org.joda.time.DateTimeField dateTimeField78 = iSOChronology76.yearOfCentury();
        org.joda.time.Period period79 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology76);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology76.clockhourOfDay();
        org.joda.time.Period period82 = org.joda.time.Period.millis(1);
        int[] intArray84 = iSOChronology76.get((org.joda.time.ReadablePeriod) period82, 0L);
        int int85 = offsetDateTimeField12.getMaximumValue(readablePartial70, intArray84);
        int int88 = offsetDateTimeField12.getDifference((-1640961504000L), (long) (byte) 10);
        java.lang.String str89 = offsetDateTimeField12.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 946684800000L + "'", long65 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684800000L + "'", long67 == 946684800000L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "29" + "'", str69.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(iSOChronology76);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 2922799 + "'", int85 == 2922799);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str89.equals("DateTimeField[centuryOfEra]"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        int int8 = period2.getMillis();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone12.isLocalDateTimeGap(localDateTime13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone17.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        long long22 = dateTimeZone12.getMillisKeepLocal(dateTimeZone17, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        long long28 = dateTimeZone17.getMillisKeepLocal(dateTimeZone23, (long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) 1, periodType31);
        org.joda.time.Period period34 = period32.withSeconds((int) '#');
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period36 = period32.normalizedStandard(periodType35);
        int int37 = period36.getMinutes();
        long long40 = iSOChronology29.add((org.joda.time.ReadablePeriod) period36, (long) 29, 9);
        org.joda.time.Period period42 = period36.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.Period period45 = new org.joda.time.Period((long) (short) 0, chronology44);
        org.joda.time.Period period47 = period45.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds48 = period45.toStandardSeconds();
        org.joda.time.Period period50 = period45.plusDays((-1));
        org.joda.time.Period period52 = period50.plusSeconds((int) (short) 0);
        java.lang.String str53 = period50.toString();
        int int54 = period50.getDays();
        org.joda.time.Period period56 = period50.plusMillis((-28800000));
        org.joda.time.DurationFieldType durationFieldType58 = period50.getFieldType(0);
        int int59 = period36.indexOf(durationFieldType58);
        int int60 = period11.indexOf(durationFieldType58);
        org.joda.time.Period period61 = period2.plus((org.joda.time.ReadablePeriod) period11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 29L + "'", long40 == 29L);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(seconds48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "P-1D" + "'", str53.equals("P-1D"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(durationFieldType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(period61);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "PT-0.009S");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds9 = period6.toStandardSeconds();
        org.joda.time.Period period11 = period6.plusDays((-1));
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 0);
        java.lang.String str14 = period11.toString();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        boolean boolean17 = periodType15.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType19 = periodType15.getFieldType(0);
        int int20 = period11.get(durationFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType19, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean25 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException24);
        java.lang.String str26 = illegalFieldValueException24.getFieldName();
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalFieldValueException24);
        org.joda.time.IllegalInstantException illegalInstantException30 = new org.joda.time.IllegalInstantException(169L, "Minutes");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1D" + "'", str14.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "minutes" + "'", str26.equals("minutes"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        int int66 = offsetDateTimeField12.getLeapAmount(10L);
        boolean boolean68 = offsetDateTimeField12.isLeap((long) (-287999));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.joda.time.Period period3 = period1.minusDays((int) (short) -1);
        try {
            org.joda.time.DurationFieldType durationFieldType5 = period1.getFieldType(2922799);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        long long65 = offsetDateTimeField12.roundHalfCeiling((-100L));
        long long67 = offsetDateTimeField12.roundHalfFloor(946684800132L);
        int int69 = offsetDateTimeField12.getLeapAmount(60480000000001L);
        long long71 = offsetDateTimeField12.roundHalfEven((long) 10000);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 946684800000L + "'", long65 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684800000L + "'", long67 == 946684800000L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 946684800000L + "'", long71 == 946684800000L);
    }
}

