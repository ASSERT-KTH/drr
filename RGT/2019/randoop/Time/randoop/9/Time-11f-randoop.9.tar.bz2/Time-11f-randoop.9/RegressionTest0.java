import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test001");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560627445200L + "'", long1 == 1560627445200L);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) -1, (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 1, periodType2);
        org.joda.time.Period period5 = period3.withSeconds((int) '#');
        boolean boolean6 = periodType0.equals((java.lang.Object) period5);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) dateTimeZone0, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 10000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (short) 0, 0, 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        try {
            long long10 = iSOChronology3.getDateTimeMillis((long) (short) 0, (int) (byte) 100, (int) (short) 10, 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 0, 10000, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long8 = dateTimeZone0.convertLocalToUTC(100L, false, 100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 0, 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.years();
        try {
            long long10 = iSOChronology3.getDateTimeMillis((long) (short) 1, (int) '#', (int) (short) 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology4.centuries();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField11 = iSOChronology10.weeks();
        org.joda.time.DurationField durationField12 = iSOChronology10.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField13 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField6, durationField12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean6 = periodType4.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType8 = periodType4.getFieldType(0);
        org.joda.time.PeriodType periodType9 = periodType4.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', 1L, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray5 = new int[] {};
        try {
            iSOChronology3.validate(readablePartial4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) 'a', 97, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology3.centuries();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = new int[] {};
        try {
            iSOChronology3.validate(readablePartial6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(52L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        try {
            long long14 = iSOChronology5.getDateTimeMillis(1, 97, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 1);
        try {
            org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "P-1D");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        int int10 = period9.getDays();
        try {
            org.joda.time.Period period12 = period9.plusWeeks((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        long long4 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
//        long long7 = dateTimeZone1.convertLocalToUTC(0L, true);
//        boolean boolean9 = dateTimeZone1.isStandardOffset((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType11, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(60480000000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3140588L + "'", long1 == 3140588L);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        long long4 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
//        long long7 = dateTimeZone1.convertLocalToUTC(0L, true);
//        int int9 = dateTimeZone1.getOffsetFromLocal((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PT0.097S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.toString();
        java.lang.Class<?> wildcardClass8 = preciseDurationField6.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DurationField[minutes]" + "'", str7.equals("DurationField[minutes]"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        long long9 = preciseDurationField6.add(100L, (int) (short) 1);
        long long12 = preciseDurationField6.getDifferenceAsLong(0L, 3140588L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 200L + "'", long9 == 200L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31405L) + "'", long12 == (-31405L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology8.add(readablePeriod10, (-18478968L), 10);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-18478968L) + "'", long13 == (-18478968L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 97, chronology1);
        org.joda.time.Period period4 = period2.withYears((-1));
        org.joda.time.Minutes minutes5 = period2.toStandardMinutes();
        org.joda.time.Period period7 = period2.plusDays((int) (short) -1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(minutes5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType10 = periodType7.withWeeksRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withDaysRemoved();
        org.joda.time.PeriodType periodType12 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 100, periodType12);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology16);
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) iSOChronology3, periodType12, (org.joda.time.Chronology) iSOChronology16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        try {
            org.joda.time.Period period18 = period7.withPeriodType(periodType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'days'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(periodType17);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str6 = dateTimeZone0.getName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray20 = new int[] {};
        try {
            int[] intArray22 = offsetDateTimeField12.addWrapField(readablePartial18, (int) (short) 1, intArray20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = offsetDateTimeField12.getAsText(readablePartial14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str13.equals("DateTimeField[centuryOfEra]"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfHalfday();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) "+00:00:00.052", (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.052\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 97);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PT0.097S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-210858120000000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        long long8 = gregorianChronology1.getDateTimeMillis(0L, (int) (byte) 10, 52, 1, (int) ' ');
//        org.joda.time.Chronology chronology9 = gregorianChronology1.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-18478968L) + "'", long8 == (-18478968L));
//        org.junit.Assert.assertNotNull(chronology9);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        long long8 = gregorianChronology1.getDateTimeMillis(0L, (int) (byte) 10, 52, 1, (int) ' ');
//        try {
//            long long16 = gregorianChronology1.getDateTimeMillis((int) (byte) 100, 0, 0, 0, (int) (short) -1, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-18478968L) + "'", long8 == (-18478968L));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.field.FieldUtils.verifyValueBounds("minutes", 8, (-1), (int) (short) 100);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long27 = unsupportedDurationField25.getValueAsLong(946684800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(100, (-1), 10000, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = iSOChronology3.set(readablePartial7, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        java.lang.String str3 = dateTimeZone0.toString();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        java.lang.String str13 = offsetDateTimeField12.toString();
        long long16 = offsetDateTimeField12.addWrapField(0L, (int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField25 = iSOChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.yearOfCentury();
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Chronology chronology28 = iSOChronology24.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology24.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray35 = new int[] { ' ', 97 };
        int int36 = offsetDateTimeField31.getMinimumValue(readablePartial32, intArray35);
        java.lang.String str38 = offsetDateTimeField31.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime43 = null;
        boolean boolean44 = dateTimeZone42.isLocalDateTimeGap(localDateTime43);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.DurationField durationField46 = iSOChronology45.weeks();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.yearOfCentury();
        org.joda.time.Period period48 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.Chronology chronology49 = iSOChronology45.withUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology45.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 10);
        org.joda.time.ReadablePartial readablePartial53 = null;
        int[] intArray56 = new int[] { ' ', 97 };
        int int57 = offsetDateTimeField52.getMinimumValue(readablePartial53, intArray56);
        int int58 = offsetDateTimeField31.getMinimumValue(readablePartial39, intArray56);
        try {
            int[] intArray60 = offsetDateTimeField12.addWrapPartial(readablePartial17, (int) (byte) 1, intArray56, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str13.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200000L + "'", long16 == 31556995200000L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "29" + "'", str38.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        try {
            int int28 = unsupportedDurationField25.getValue(60480000000052L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        try {
            long long29 = unsupportedDurationField25.add((long) (short) 100, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.secondOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 1, "DateTimeField[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long27 = unsupportedDurationField25.getMillis((-31405L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(29, (int) (byte) 1, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, 2704L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        try {
            long long34 = scaledDurationField31.getMillis(193536000000000L, 28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1935360000000000000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.DurationFieldType durationFieldType21 = illegalFieldValueException20.getDurationFieldType();
        java.lang.Throwable[] throwableArray22 = illegalFieldValueException20.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType23 = illegalFieldValueException20.getDurationFieldType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(durationFieldType23);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, (long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        boolean boolean2 = periodType0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long41 = offsetDateTimeField12.roundCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime46 = null;
        boolean boolean47 = dateTimeZone45.isLocalDateTimeGap(localDateTime46);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DurationField durationField49 = iSOChronology48.weeks();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.yearOfCentury();
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.Chronology chronology52 = iSOChronology48.withUTC();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology48.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 10);
        org.joda.time.ReadablePartial readablePartial56 = null;
        int[] intArray59 = new int[] { ' ', 97 };
        int int60 = offsetDateTimeField55.getMinimumValue(readablePartial56, intArray59);
        java.lang.String str62 = offsetDateTimeField55.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial63 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime67 = null;
        boolean boolean68 = dateTimeZone66.isLocalDateTimeGap(localDateTime67);
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DurationField durationField70 = iSOChronology69.weeks();
        org.joda.time.DateTimeField dateTimeField71 = iSOChronology69.yearOfCentury();
        org.joda.time.Period period72 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology69);
        org.joda.time.Chronology chronology73 = iSOChronology69.withUTC();
        org.joda.time.DateTimeField dateTimeField74 = iSOChronology69.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, 10);
        org.joda.time.ReadablePartial readablePartial77 = null;
        int[] intArray80 = new int[] { ' ', 97 };
        int int81 = offsetDateTimeField76.getMinimumValue(readablePartial77, intArray80);
        int int82 = offsetDateTimeField55.getMinimumValue(readablePartial63, intArray80);
        int int83 = offsetDateTimeField12.getMinimumValue(readablePartial42, intArray80);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 946684800000L + "'", long41 == 946684800000L);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "29" + "'", str62.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 10 + "'", int82 == 10);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.add(52L, (long) 10);
        try {
            long long41 = scaledDurationField31.add((-100L), 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 24405880000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 60480000000052L + "'", long38 == 60480000000052L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField7 = new org.joda.time.field.PreciseDurationField(durationFieldType5, (long) (short) 100);
        java.lang.String str8 = preciseDurationField7.getName();
        int int11 = preciseDurationField7.getDifference((long) 100, (long) (byte) 10);
        long long13 = preciseDurationField7.getValueAsLong(0L);
        long long16 = preciseDurationField7.getValueAsLong(0L, (-1L));
        long long19 = preciseDurationField7.getMillis(0L, 0L);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
        boolean boolean22 = periodType20.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType24 = periodType20.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) (short) 100);
        int int28 = preciseDurationField26.getValue((long) '4');
        int int29 = preciseDurationField7.compareTo((org.joda.time.DurationField) preciseDurationField26);
        java.lang.Class<?> wildcardClass30 = preciseDurationField26.getClass();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "minutes" + "'", str8.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getValueAsLong((long) '4', (long) 52);
        long long37 = scaledDurationField31.add(0L, (-1));
        try {
            long long39 = scaledDurationField31.getMillis(28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 288000000000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-6048000000000L) + "'", long37 == (-6048000000000L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.Seconds seconds11 = period7.toStandardSeconds();
        org.joda.time.Period period13 = period7.multipliedBy(29);
        org.joda.time.Period period15 = period13.withWeeks((-287999));
        org.joda.time.PeriodType periodType16 = period13.getPeriodType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(seconds11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-100L), 946684800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-946684800100L) + "'", long2 == (-946684800100L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        int int6 = periodType0.size();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period7 = period4.normalizedStandard();
        try {
            int int9 = period4.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone8.isLocalDateTimeGap(localDateTime9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField12 = iSOChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.yearOfCentury();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime16 = null;
        boolean boolean17 = dateTimeZone15.isLocalDateTimeGap(localDateTime16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        long long25 = dateTimeZone15.getMillisKeepLocal(dateTimeZone20, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = dateTimeZone26.isLocalDateTimeGap(localDateTime27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        long long31 = dateTimeZone20.getMillisKeepLocal(dateTimeZone26, (long) ' ');
        org.joda.time.Chronology chronology32 = iSOChronology11.withZone(dateTimeZone26);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DurationField durationField34 = iSOChronology11.millis();
        try {
            org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) (short) 10, periodType5, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', (-946684800100L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 946684800132L + "'", long2 == 946684800132L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField6 = iSOChronology3.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period3.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(946684800132L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone0.getName((long) (short) 100, locale12);
//        java.util.TimeZone timeZone14 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("+00:00:00.052", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.Period period8 = new org.joda.time.Period(97, (int) '#', 0, (int) '4', (int) (short) 0, (int) (short) 10, 10000, 29);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(8, 29);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 29, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        long long27 = unsupportedDurationField25.getUnitMillis();
        try {
            int int30 = unsupportedDurationField25.getDifference(164096150400010L, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) (-1), chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        long long20 = offsetDateTimeField12.add(10L, (long) '4');
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField12.getMaximumTextLength(locale21);
        org.joda.time.DurationField durationField23 = offsetDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 164096150400010L + "'", long20 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, periodType6);
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "29");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekyearOfCentury();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, chronology11);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.get(durationFieldType13);
        org.joda.time.DurationFieldType[] durationFieldTypeArray15 = period12.getFieldTypes();
        org.joda.time.Period period17 = period12.multipliedBy(97);
        org.joda.time.Period period19 = period12.withMillis((int) (byte) 1);
        long long22 = iSOChronology8.add((org.joda.time.ReadablePeriod) period19, (long) 110, 110);
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) iSOChronology3, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 220L + "'", long22 == 220L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long42 = offsetDateTimeField12.set(97L, 52);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray45 = new int[] { (byte) 10 };
        int int46 = offsetDateTimeField12.getMaximumValue(readablePartial43, intArray45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField48 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 72581011200097L + "'", long42 == 72581011200097L);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922799 + "'", int46 == 2922799);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        try {
            org.joda.time.Period period5 = period1.multipliedBy((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 97 * -28800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Minutes");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException23);
        java.lang.Number number25 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 29, 254015999999949L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-254015999999920L) + "'", long2 == (-254015999999920L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime12 = null;
//        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = dateTimeZone5.getMillisKeepLocal(dateTimeZone11, (long) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.lang.String str19 = dateTimeZone5.getShortName(97L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        long long6 = unsupportedDurationField5.getUnitMillis();
        try {
            long long8 = unsupportedDurationField5.getValueAsLong((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField7 = new org.joda.time.field.PreciseDurationField(durationFieldType5, (long) (short) 100);
        java.lang.String str8 = preciseDurationField7.getName();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "minutes" + "'", str8.equals("minutes"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        java.lang.String str13 = offsetDateTimeField12.toString();
        long long16 = offsetDateTimeField12.addWrapField(0L, (int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField12.getAsText(readablePartial17, (int) (byte) -1, locale19);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField12.getMaximumTextLength(locale21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray29 = new int[] { '4', (-287999), 110, 29 };
        try {
            int[] intArray31 = offsetDateTimeField12.addWrapField(readablePartial23, (int) (short) 100, intArray29, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str13.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200000L + "'", long16 == 31556995200000L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(0L, periodType6);
        java.lang.String str8 = periodType6.getName();
        try {
            org.joda.time.DurationFieldType durationFieldType10 = periodType6.getFieldType(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Minutes" + "'", str8.equals("Minutes"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        long long27 = unsupportedDurationField25.getUnitMillis();
        try {
            int int30 = unsupportedDurationField25.getValue(6048000000000L, 6048000000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 97, chronology1);
        org.joda.time.Period period4 = period2.withYears((-1));
        org.joda.time.Period period6 = period2.multipliedBy((int) (short) 100);
        org.joda.time.Period period8 = period2.withMonths((int) '#');
        org.joda.time.Period period10 = period2.withMinutes(110);
        org.joda.time.Days days11 = period2.toStandardDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(days11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Period period1 = org.joda.time.Period.millis(29);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds17 = period14.toStandardSeconds();
        org.joda.time.Period period19 = period14.plusDays((-1));
        org.joda.time.Period period21 = period19.plusSeconds((int) (short) 0);
        java.lang.String str22 = period19.toString();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        boolean boolean25 = periodType23.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        int int28 = period19.get(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean33 = period11.isSupported(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        int int35 = unsupportedDurationField5.compareTo((org.joda.time.DurationField) unsupportedDurationField34);
        try {
            long long38 = unsupportedDurationField5.add(604800000000000L, (long) 110);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(seconds17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "P-1D" + "'", str22.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-287999));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 287999 + "'", int1 == 287999);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds17 = period14.toStandardSeconds();
        org.joda.time.Period period19 = period14.plusDays((-1));
        org.joda.time.Period period21 = period19.plusSeconds((int) (short) 0);
        java.lang.String str22 = period19.toString();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        boolean boolean25 = periodType23.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        int int28 = period19.get(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean33 = period11.isSupported(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        int int35 = unsupportedDurationField5.compareTo((org.joda.time.DurationField) unsupportedDurationField34);
        try {
            long long37 = unsupportedDurationField5.getValueAsLong(254016000000001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(seconds17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "P-1D" + "'", str22.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        int int8 = period2.getMillis();
        int int9 = period2.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.Period period1 = org.joda.time.Period.days((-28800000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getOffset(28800000L);
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.052" + "'", str10.equals("+00:00:00.052"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 1, 220L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 221L + "'", long2 == 221L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(60480000000001L, 5200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 314496000000005200L + "'", long2 == 314496000000005200L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("Minutes", 110);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder2.writeTo("97", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        try {
            long long8 = unsupportedDurationField5.getDifferenceAsLong((long) 9, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial4 = null;
        int int5 = offsetDateTimeField3.getMaximumValue(readablePartial4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 124 + "'", int5 == 124);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.Period period18 = period7.minusMonths(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("DateTimeField[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[centuryOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.MutablePeriod mutablePeriod7 = period4.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(mutablePeriod7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 100, (long) (short) 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long33 = scaledDurationField31.getMillis((int) (byte) 10);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.minutes();
        boolean boolean35 = scaledDurationField31.equals((java.lang.Object) periodType34);
        long long38 = scaledDurationField31.getMillis(0, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 60480000000000L + "'", long33 == 60480000000000L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("Minutes", 110);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("-1", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        long long6 = unsupportedDurationField5.getUnitMillis();
        try {
            long long9 = unsupportedDurationField5.getDifferenceAsLong((long) 287999, 29L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long42 = offsetDateTimeField12.set(97L, 52);
        org.joda.time.DurationField durationField43 = offsetDateTimeField12.getDurationField();
        long long45 = offsetDateTimeField12.roundCeiling(60480000000000000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 72581011200097L + "'", long42 == 72581011200097L);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 60483000931200000L + "'", long45 == 60483000931200000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray23 = null;
        int int24 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray23);
        long long27 = offsetDateTimeField12.add((-1L), 0L);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int[] intArray30 = new int[] {};
        try {
            int[] intArray32 = offsetDateTimeField12.addWrapPartial(readablePartial28, 8, intArray30, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        long long9 = preciseDurationField6.add(100L, (int) (short) 1);
        long long11 = preciseDurationField6.getValueAsLong(221L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 200L + "'", long9 == 200L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long28 = unsupportedDurationField25.getMillis((int) '#', (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long33 = scaledDurationField31.getMillis((int) (byte) 10);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.minutes();
        boolean boolean35 = scaledDurationField31.equals((java.lang.Object) periodType34);
        try {
            long long38 = scaledDurationField31.add((long) 52, 254016000000001L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 2540160000000010000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 60480000000000L + "'", long33 == 60480000000000L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period4.getFieldTypes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField7 = iSOChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Minutes");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Minutes" + "'", str3.equals("Minutes"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(6048000000000L, 193536000000000L, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3124800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField12.getAsShortText(124, locale66);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "124" + "'", str67.equals("124"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) '#', periodType1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 1, periodType3);
        org.joda.time.Period period6 = period4.withSeconds((int) '#');
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = period4.normalizedStandard(periodType7);
        org.joda.time.Period period9 = new org.joda.time.Period(1935360000000L, 221L, periodType7);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        java.lang.String str4 = dateTimeZone0.getShortName((long) (byte) 0);
//        long long7 = dateTimeZone0.adjustOffset((long) '4', true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Period period1 = new org.joda.time.Period(5200L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(6048000000000L, 604800000000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 6048000000000 * 604800000000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        long long6 = unsupportedDurationField5.getUnitMillis();
        try {
            int int9 = unsupportedDurationField5.getDifference((-1L), (long) 124);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.052\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.add(52L, (long) 10);
        java.lang.String str39 = scaledDurationField31.toString();
        long long42 = scaledDurationField31.getMillis((int) (short) -1, (long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 60480000000052L + "'", long38 == 60480000000052L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[minutes]" + "'", str39.equals("DurationField[minutes]"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-6048000000000L) + "'", long42 == (-6048000000000L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.era();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationTo(readableInstant9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        org.joda.time.PeriodType periodType16 = periodType11.withMonthsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration10, periodType16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.minutes();
        boolean boolean20 = periodType18.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType22 = periodType18.getFieldType(0);
        org.joda.time.PeriodType periodType23 = periodType18.withSecondsRemoved();
        int int24 = periodType18.size();
        org.joda.time.Period period25 = period17.withPeriodType(periodType18);
        try {
            org.joda.time.Period period26 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 164096150400010L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone14.isLocalDateTimeGap(localDateTime15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long19 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        long long25 = dateTimeZone14.getMillisKeepLocal(dateTimeZone20, (long) ' ');
        org.joda.time.Chronology chronology26 = iSOChronology5.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("UTC", (int) '#', 101, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for UTC must be in the range [101,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getOffset(28800000L);
        long long10 = fixedDateTimeZone4.previousTransition(2440588L);
        long long13 = fixedDateTimeZone4.convertLocalToUTC(221L, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2440588L + "'", long10 == 2440588L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 169L + "'", long13 == 169L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsShortText(220L, locale43);
        long long47 = offsetDateTimeField12.addWrapField(60480000000000L, 10000);
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime53 = null;
        boolean boolean54 = dateTimeZone52.isLocalDateTimeGap(localDateTime53);
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        org.joda.time.DurationField durationField56 = iSOChronology55.weeks();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.yearOfCentury();
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology55);
        org.joda.time.Chronology chronology59 = iSOChronology55.withUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology55.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray66 = new int[] { ' ', 97 };
        int int67 = offsetDateTimeField62.getMinimumValue(readablePartial63, intArray66);
        try {
            int[] intArray69 = offsetDateTimeField12.add(readablePartial48, (-287999), intArray66, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -287999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "29" + "'", str44.equals("29"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 31617432000000000L + "'", long47 == 31617432000000000L);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis(0, (int) '#', 10, 110, (-287999), (int) (short) 100, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        try {
            int int11 = period9.getValue(110);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        int int38 = scaledDurationField31.getValue(1L, 0L);
        int int40 = scaledDurationField31.getValue((long) (short) 10);
        long long41 = scaledDurationField31.getUnitMillis();
        long long44 = scaledDurationField31.add(92036995200000L, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 6048000000000L + "'", long41 == 6048000000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 85988995200000L + "'", long44 == 85988995200000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DurationField durationField10 = iSOChronology8.minutes();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        long long11 = fixedDateTimeZone4.adjustOffset(0L, true);
        long long14 = fixedDateTimeZone4.convertLocalToUTC(254016000000001L, true);
        java.util.TimeZone timeZone15 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 254015999999949L + "'", long14 == 254015999999949L);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(2450588L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusSeconds((int) 'a');
        int int10 = period7.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "minutes");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime3 = null;
//        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        long long12 = dateTimeZone2.getMillisKeepLocal(dateTimeZone7, (long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime14 = null;
//        boolean boolean15 = dateTimeZone13.isLocalDateTimeGap(localDateTime14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        long long18 = dateTimeZone7.getMillisKeepLocal(dateTimeZone13, (long) ' ');
//        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone(dateTimeZone7);
//        java.lang.String str21 = dateTimeZone7.getName(193536000000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        java.lang.String str5 = fixedDateTimeZone4.getID();
        long long7 = fixedDateTimeZone4.nextTransition(28800000L);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        try {
            long long11 = unsupportedDurationField5.getDifferenceAsLong((-2208988800000L), (-254015999999920L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Minutes", "UTC");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "97", "DurationField[minutes]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.Seconds seconds11 = period7.toStandardSeconds();
        org.joda.time.Period period13 = period7.multipliedBy(29);
        org.joda.time.Period period15 = period13.minusDays(1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(seconds11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = null;
        try {
            gregorianChronology1.validate(readablePartial6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period(0L, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.millisOfSecond();
        org.joda.time.DurationField durationField8 = iSOChronology4.months();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.add(52L, (long) 10);
        boolean boolean39 = scaledDurationField31.isPrecise();
        long long41 = scaledDurationField31.getMillis((long) 1);
        try {
            long long44 = scaledDurationField31.getMillis(2922799, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 29227990000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 60480000000052L + "'", long38 == 60480000000052L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 6048000000000L + "'", long41 == 6048000000000L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusSeconds((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.year();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.minuteOfHour();
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period10, (org.joda.time.Chronology) iSOChronology14);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int27 = unsupportedDurationField25.getValue((-18478968L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField7 = new org.joda.time.field.PreciseDurationField(durationFieldType5, (long) (short) 100);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField8 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationFieldType5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        int int66 = offsetDateTimeField12.getLeapAmount(10L);
        long long69 = offsetDateTimeField12.add(60480000000000L, (long) 10);
        try {
            long long72 = offsetDateTimeField12.set((long) 10, "UTC");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 92036995200000L + "'", long69 == 92036995200000L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0.097S");
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePartial3, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-1), 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period9.minus(readablePeriod12);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period9.plusMinutes((int) (short) 1);
        org.joda.time.PeriodType periodType12 = period9.getPeriodType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-1", 124, (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 124 for -1 must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        long long22 = offsetDateTimeField12.add((long) 'a', 0L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period28 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 0, chronology30);
        org.joda.time.Period period33 = period31.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds34 = period31.toStandardSeconds();
        org.joda.time.Period period36 = period31.withYears(97);
        org.joda.time.Period period38 = period36.plusSeconds((int) 'a');
        org.joda.time.Period period39 = period36.negated();
        int[] intArray42 = iSOChronology27.get((org.joda.time.ReadablePeriod) period39, (long) '#', (long) 52);
        try {
            int[] intArray44 = offsetDateTimeField12.addWrapPartial(readablePartial23, (int) (byte) 10, intArray42, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(seconds34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Period period8 = new org.joda.time.Period(29, (int) '4', 10000, 2922799, 0, (int) (byte) -1, 1, 101);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) -1, 110, 287999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Period period8 = new org.joda.time.Period(1, (int) (byte) 100, (int) ' ', (int) (short) -1, 287999, (int) (byte) -1, 100, 97);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = periodType9.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType12 = periodType9.withWeeksRemoved();
        try {
            org.joda.time.Period period13 = period8.withPeriodType(periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add((long) 1, (long) (short) 10);
        long long37 = scaledDurationField31.add((long) (byte) 100, (long) 100);
        long long38 = scaledDurationField31.getUnitMillis();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60480000000001L + "'", long34 == 60480000000001L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604800000000100L + "'", long37 == 604800000000100L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 6048000000000L + "'", long38 == 6048000000000L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, chronology10);
        org.joda.time.Period period13 = period11.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds14 = period11.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period11.toDurationTo(readableInstant15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.minutes();
        boolean boolean19 = periodType17.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType21 = periodType17.getFieldType(0);
        org.joda.time.PeriodType periodType22 = periodType17.withMonthsRemoved();
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant8, (org.joda.time.ReadableDuration) duration16, periodType22);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.minutes();
        boolean boolean26 = periodType24.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType28 = periodType24.getFieldType(0);
        org.joda.time.PeriodType periodType29 = periodType24.withSecondsRemoved();
        int int30 = periodType24.size();
        org.joda.time.Period period31 = period23.withPeriodType(periodType24);
        int int32 = periodType24.size();
        org.joda.time.PeriodType periodType33 = periodType24.withMinutesRemoved();
        try {
            org.joda.time.Period period34 = new org.joda.time.Period((int) (short) 100, 101, (int) (byte) -1, 110, 10, 0, 0, 7, periodType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(periodType33);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 60480000000001L, (java.lang.Number) 5200L, (java.lang.Number) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(2440587.5d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.get(durationFieldType6);
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period5.getFieldTypes();
        org.joda.time.Period period10 = period5.multipliedBy(97);
        org.joda.time.Period period12 = period5.withMillis((int) (byte) 1);
        long long15 = iSOChronology1.add((org.joda.time.ReadablePeriod) period12, (long) 110, 110);
        try {
            long long20 = iSOChronology1.getDateTimeMillis(0, 8, (-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220L + "'", long15 == 220L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-287999));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        long long9 = unsupportedDurationField5.getUnitMillis();
        try {
            long long12 = unsupportedDurationField5.add((long) (-287999), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (short) 100);
        java.lang.String str14 = preciseDurationField13.getName();
        java.lang.String str15 = preciseDurationField13.toString();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType5, (java.lang.Object) str15);
        org.joda.time.PeriodType periodType17 = periodType5.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "minutes" + "'", str14.equals("minutes"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DurationField[minutes]" + "'", str15.equals("DurationField[minutes]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(287999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText(60480000000052L);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime16 = null;
        boolean boolean17 = dateTimeZone15.isLocalDateTimeGap(localDateTime16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField19 = iSOChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.yearOfCentury();
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Chronology chronology22 = iSOChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 10);
        org.joda.time.ReadablePartial readablePartial26 = null;
        int[] intArray29 = new int[] { ' ', 97 };
        int int30 = offsetDateTimeField25.getMinimumValue(readablePartial26, intArray29);
        long long33 = offsetDateTimeField25.add(10L, (long) '4');
        java.util.Locale locale34 = null;
        int int35 = offsetDateTimeField25.getMaximumTextLength(locale34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = dateTimeZone39.isLocalDateTimeGap(localDateTime40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField43 = iSOChronology42.weeks();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.yearOfCentury();
        org.joda.time.Period period45 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Period period47 = org.joda.time.Period.hours(10);
        int[] intArray49 = iSOChronology42.get((org.joda.time.ReadablePeriod) period47, 60480000000000L);
        int int50 = offsetDateTimeField25.getMinimumValue(readablePartial36, intArray49);
        int int51 = offsetDateTimeField9.getMinimumValue(readablePartial12, intArray49);
        try {
            iSOChronology2.validate(readablePartial5, intArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "124" + "'", str11.equals("124"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 164096150400010L + "'", long33 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.DurationField durationField8 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 100, 604800000000100L, (org.joda.time.Chronology) iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DurationField durationField11 = iSOChronology9.centuries();
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) 'a', periodType13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
        org.joda.time.Period period19 = period17.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds20 = period17.toStandardSeconds();
        org.joda.time.Period period22 = period17.plusDays((-1));
        org.joda.time.Period period24 = period22.plusSeconds((int) (short) 0);
        java.lang.String str25 = period22.toString();
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.minutes();
        boolean boolean28 = periodType26.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType30 = periodType26.getFieldType(0);
        int int31 = period22.get(durationFieldType30);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(durationFieldType30, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean36 = period14.isSupported(durationFieldType30);
        org.joda.time.field.ScaledDurationField scaledDurationField38 = new org.joda.time.field.ScaledDurationField(durationField11, durationFieldType30, 97);
        boolean boolean39 = period2.isSupported(durationFieldType30);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(seconds20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "P-1D" + "'", str25.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Period period1 = org.joda.time.Period.days(110);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("DurationField[minutes]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DurationField[minutes]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period3.minusWeeks(124);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(readablePartial18, 1, locale20);
        long long23 = offsetDateTimeField12.roundCeiling((long) '4');
        long long26 = offsetDateTimeField12.add(97L, (int) 'a');
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = dateTimeZone31.isLocalDateTimeGap(localDateTime32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField35 = iSOChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.yearOfCentury();
        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology34);
        org.joda.time.Chronology chronology38 = iSOChronology34.withUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology34.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray45 = new int[] { ' ', 97 };
        int int46 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray45);
        java.lang.String str48 = offsetDateTimeField41.getAsText((long) (byte) 1);
        int int50 = offsetDateTimeField41.get((-287999L));
        org.joda.time.ReadablePartial readablePartial51 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime55 = null;
        boolean boolean56 = dateTimeZone54.isLocalDateTimeGap(localDateTime55);
        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
        org.joda.time.DurationField durationField58 = iSOChronology57.weeks();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology57.yearOfCentury();
        org.joda.time.Period period60 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology57);
        org.joda.time.Chronology chronology61 = iSOChronology57.withUTC();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology57.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, 10);
        org.joda.time.ReadablePartial readablePartial65 = null;
        int[] intArray68 = new int[] { ' ', 97 };
        int int69 = offsetDateTimeField64.getMinimumValue(readablePartial65, intArray68);
        java.lang.String str71 = offsetDateTimeField64.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial72 = null;
        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime76 = null;
        boolean boolean77 = dateTimeZone75.isLocalDateTimeGap(localDateTime76);
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone75);
        org.joda.time.DurationField durationField79 = iSOChronology78.weeks();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology78.yearOfCentury();
        org.joda.time.Period period81 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology78);
        org.joda.time.Chronology chronology82 = iSOChronology78.withUTC();
        org.joda.time.DateTimeField dateTimeField83 = iSOChronology78.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField(dateTimeField83, 10);
        org.joda.time.ReadablePartial readablePartial86 = null;
        int[] intArray89 = new int[] { ' ', 97 };
        int int90 = offsetDateTimeField85.getMinimumValue(readablePartial86, intArray89);
        int int91 = offsetDateTimeField64.getMinimumValue(readablePartial72, intArray89);
        int int92 = offsetDateTimeField41.getMinimumValue(readablePartial51, intArray89);
        int[] intArray94 = offsetDateTimeField12.add(readablePartial27, 0, intArray89, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 306102499200097L + "'", long26 == 306102499200097L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "29" + "'", str48.equals("29"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 29 + "'", int50 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(iSOChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "29" + "'", str71.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(chronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 10 + "'", int90 == 10);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 10 + "'", int91 == 10);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 10 + "'", int92 == 10);
        org.junit.Assert.assertNotNull(intArray94);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (short) 100);
        int int14 = periodType6.indexOf(durationFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType11, "P-1D");
        java.lang.Number number17 = illegalFieldValueException16.getUpperBound();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, 124);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gregorianChronology1.getDateTimeMillis(0, 110, (int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType22, (int) 'a', (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(readablePartial18, 1, locale20);
        long long23 = offsetDateTimeField12.roundCeiling((long) '4');
        long long26 = offsetDateTimeField12.add(97L, (int) 'a');
        long long28 = offsetDateTimeField12.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 306102499200097L + "'", long26 == 306102499200097L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 946684800000L + "'", long28 == 946684800000L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean6 = periodType4.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType8 = periodType4.getFieldType(0);
        org.joda.time.PeriodType periodType9 = periodType4.withSecondsRemoved();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone12.isLocalDateTimeGap(localDateTime13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField16 = iSOChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.yearOfCentury();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone19.isLocalDateTimeGap(localDateTime20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = dateTimeZone24.isLocalDateTimeGap(localDateTime25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        long long29 = dateTimeZone19.getMillisKeepLocal(dateTimeZone24, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone30.isLocalDateTimeGap(localDateTime31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        long long35 = dateTimeZone24.getMillisKeepLocal(dateTimeZone30, (long) ' ');
        org.joda.time.Chronology chronology36 = iSOChronology15.withZone(dateTimeZone30);
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Period period38 = new org.joda.time.Period(0L, (long) '4', periodType9, chronology37);
        try {
            org.joda.time.Period period39 = new org.joda.time.Period(60480000000000000L, 5200L, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1007999999999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("Minutes", 110);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("ISOChronology[UTC]", 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(110, '#', (int) (short) 100, 124, (int) (byte) 0, false, 2922799);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', periodType7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, chronology10);
        org.joda.time.Period period13 = period11.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds14 = period11.toStandardSeconds();
        org.joda.time.Period period16 = period11.plusDays((-1));
        org.joda.time.Period period18 = period16.plusSeconds((int) (short) 0);
        java.lang.String str19 = period16.toString();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
        boolean boolean22 = periodType20.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType24 = periodType20.getFieldType(0);
        int int25 = period16.get(durationFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType24, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean30 = period8.isSupported(durationFieldType24);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType24, 10000);
        long long35 = scaledDurationField32.getValueAsLong((long) '4', (long) 52);
        long long38 = scaledDurationField32.add(0L, (-1));
        long long41 = scaledDurationField32.getMillis((long) (short) 0, (long) 1);
        org.joda.time.PeriodType periodType43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period((long) 'a', periodType43);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period((long) (short) 0, chronology46);
        org.joda.time.Period period49 = period47.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds50 = period47.toStandardSeconds();
        org.joda.time.Period period52 = period47.plusDays((-1));
        org.joda.time.Period period54 = period52.plusSeconds((int) (short) 0);
        java.lang.String str55 = period52.toString();
        org.joda.time.PeriodType periodType56 = org.joda.time.PeriodType.minutes();
        boolean boolean58 = periodType56.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType60 = periodType56.getFieldType(0);
        int int61 = period52.get(durationFieldType60);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(durationFieldType60, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean66 = period44.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField68 = new org.joda.time.field.PreciseDurationField(durationFieldType60, 254015999999949L);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField69 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) scaledDurationField32, (org.joda.time.DurationField) preciseDurationField68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "P-1D" + "'", str19.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-6048000000000L) + "'", long38 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(seconds50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "P-1D" + "'", str55.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long11 = preciseDurationField6.getUnitMillis();
        int int13 = preciseDurationField6.getValue(28800000L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 288000 + "'", int13 == 288000);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Minutes");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        illegalFieldValueException2.prependMessage("DurationField[minutes]");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Minutes" + "'", str3.equals("Minutes"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.add(52L, (long) 10);
        boolean boolean39 = scaledDurationField31.isPrecise();
        int int40 = scaledDurationField31.getScalar();
        long long42 = scaledDurationField31.getMillis(52);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 60480000000052L + "'", long38 == 60480000000052L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10000 + "'", int40 == 10000);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 314496000000000L + "'", long42 == 314496000000000L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        long long67 = offsetDateTimeField12.add(2440588L, 100);
        org.joda.time.ReadablePartial readablePartial68 = null;
        int[] intArray70 = null;
        try {
            int[] intArray72 = offsetDateTimeField12.addWrapPartial(readablePartial68, 10, intArray70, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 315569522440588L + "'", long67 == 315569522440588L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.clockhourOfDay();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        long long5 = dateTimeZone0.adjustOffset(9700L, true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9700L + "'", long5 == 9700L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        int int36 = scaledDurationField31.getValue(60480000000000000L);
        boolean boolean37 = scaledDurationField31.isPrecise();
        java.lang.String str38 = scaledDurationField31.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10000 + "'", int36 == 10000);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DurationField[minutes]" + "'", str38.equals("DurationField[minutes]"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Period period4 = period2.plusMonths(1);
        org.joda.time.Period period6 = period4.withYears(1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("29", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.days((int) 'a');
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.Duration duration5 = period2.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType9);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Minutes");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Minutes/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        int int36 = scaledDurationField31.getValue(60480000000000000L);
        int int39 = scaledDurationField31.getValue(60480000000000L, 1935360000000L);
        try {
            long long42 = scaledDurationField31.add((long) '4', (-2879999903L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -28799999030000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10000 + "'", int36 == 10000);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long28 = unsupportedDurationField26.getValueAsLong(60480000000000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 165042835200000L, (java.lang.Number) 164096150405200L, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getValueAsLong((long) '4', (long) 52);
        long long37 = scaledDurationField31.add(0L, (-1));
        int int40 = scaledDurationField31.getValue((long) (byte) 1, 315569522440588L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-6048000000000L) + "'", long37 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds17 = period14.toStandardSeconds();
        org.joda.time.Period period19 = period14.plusDays((-1));
        org.joda.time.Period period21 = period19.plusSeconds((int) (short) 0);
        java.lang.String str22 = period19.toString();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        boolean boolean25 = periodType23.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        int int28 = period19.get(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean33 = period11.isSupported(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        int int35 = unsupportedDurationField5.compareTo((org.joda.time.DurationField) unsupportedDurationField34);
        org.joda.time.DurationFieldType durationFieldType36 = unsupportedDurationField34.getType();
        boolean boolean37 = unsupportedDurationField34.isPrecise();
        try {
            long long39 = unsupportedDurationField34.getMillis((-314L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(seconds17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "P-1D" + "'", str22.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusWeeks((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long42 = offsetDateTimeField12.set(97L, 52);
        boolean boolean44 = offsetDateTimeField12.isLeap((long) (byte) 100);
        long long47 = offsetDateTimeField12.getDifferenceAsLong(60480000000052L, 60480000000000L);
        int int50 = offsetDateTimeField12.getDifference((long) 2922799, 97L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 72581011200097L + "'", long42 == 72581011200097L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        java.util.Locale locale40 = null;
        int int41 = offsetDateTimeField12.getMaximumShortTextLength(locale40);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 7 + "'", int41 == 7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray18 = new int[] { (short) 10, (byte) 100, 100 };
        try {
            iSOChronology8.validate(readablePartial14, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.withMonths(124);
        org.joda.time.MutablePeriod mutablePeriod9 = period8.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        boolean boolean35 = scaledDurationField31.isPrecise();
        long long38 = scaledDurationField31.subtract((long) (byte) 100, 29L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-175391999999900L) + "'", long38 == (-175391999999900L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        long long20 = offsetDateTimeField12.add(10L, (long) '4');
        int int21 = offsetDateTimeField12.getMinimumValue();
        long long23 = offsetDateTimeField12.roundHalfFloor((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 164096150400010L + "'", long20 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', periodType3);
        org.joda.time.Period period6 = period4.plusMonths(1);
        org.joda.time.Period period8 = period6.withMonths((int) (short) 0);
        org.joda.time.Period period9 = period1.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period10 = period6.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.era();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        java.lang.String str2 = periodType1.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "YearMonthDay" + "'", str2.equals("YearMonthDay"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 287999);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-185983646400000L) + "'", long1 == (-185983646400000L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-185983646400000L), number2, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period(0L, (org.joda.time.Chronology) iSOChronology4);
        try {
            long long14 = iSOChronology4.getDateTimeMillis((int) '4', 100, (int) '4', 10000, 10, 0, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        long long67 = offsetDateTimeField12.add(2440588L, 100);
        org.joda.time.ReadablePartial readablePartial68 = null;
        java.util.Locale locale69 = null;
        try {
            java.lang.String str70 = offsetDateTimeField12.getAsText(readablePartial68, locale69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 315569522440588L + "'", long67 == 315569522440588L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.Period period8 = new org.joda.time.Period(52L, (org.joda.time.Chronology) iSOChronology4);
        try {
            int int10 = period8.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.withYears(97);
        org.joda.time.Period period9 = period7.plusSeconds((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        int int11 = period7.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        long long27 = unsupportedDurationField25.getUnitMillis();
        try {
            long long30 = unsupportedDurationField25.getDifferenceAsLong(164096150405200L, 5200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period7.withSeconds((int) (short) 0);
        int int12 = period11.getMillis();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        int int8 = fixedDateTimeZone4.getStandardOffset((long) (byte) -1);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getShortName(2704L, locale10);
        long long13 = fixedDateTimeZone4.previousTransition(254015999999949L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.052" + "'", str11.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 254015999999949L + "'", long13 == 254015999999949L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long41 = offsetDateTimeField12.roundCeiling((long) 1);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsText((int) 'a', locale43);
        long long46 = offsetDateTimeField12.remainder((long) 287999);
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime51 = null;
        boolean boolean52 = dateTimeZone50.isLocalDateTimeGap(localDateTime51);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DurationField durationField54 = iSOChronology53.weeks();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology53.yearOfCentury();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology53);
        org.joda.time.Chronology chronology57 = iSOChronology53.withUTC();
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology53.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 10);
        org.joda.time.ReadablePartial readablePartial61 = null;
        int[] intArray64 = new int[] { ' ', 97 };
        int int65 = offsetDateTimeField60.getMinimumValue(readablePartial61, intArray64);
        java.lang.String str67 = offsetDateTimeField60.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial68 = null;
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime72 = null;
        boolean boolean73 = dateTimeZone71.isLocalDateTimeGap(localDateTime72);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.DurationField durationField75 = iSOChronology74.weeks();
        org.joda.time.DateTimeField dateTimeField76 = iSOChronology74.yearOfCentury();
        org.joda.time.Period period77 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology74);
        org.joda.time.Chronology chronology78 = iSOChronology74.withUTC();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology74.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 10);
        org.joda.time.ReadablePartial readablePartial82 = null;
        int[] intArray85 = new int[] { ' ', 97 };
        int int86 = offsetDateTimeField81.getMinimumValue(readablePartial82, intArray85);
        int int87 = offsetDateTimeField60.getMinimumValue(readablePartial68, intArray85);
        int int88 = offsetDateTimeField12.getMaximumValue(readablePartial47, intArray85);
        long long90 = offsetDateTimeField12.roundHalfFloor(60480000000000000L);
        long long92 = offsetDateTimeField12.remainder(28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 946684800000L + "'", long41 == 946684800000L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "97" + "'", str44.equals("97"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 287999L + "'", long46 == 287999L);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "29" + "'", str67.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 10 + "'", int86 == 10);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2922799 + "'", int88 == 2922799);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 60479845257600000L + "'", long90 == 60479845257600000L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 28800000L + "'", long92 == 28800000L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        try {
            long long8 = unsupportedDurationField5.getMillis((int) '#', (-604800000000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        long long43 = offsetDateTimeField12.roundHalfFloor((long) (short) 100);
        int int44 = offsetDateTimeField12.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime50 = null;
        boolean boolean51 = dateTimeZone49.isLocalDateTimeGap(localDateTime50);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DurationField durationField53 = iSOChronology52.weeks();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.yearOfCentury();
        org.joda.time.Period period55 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology52);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology52.clockhourOfDay();
        org.joda.time.Period period58 = org.joda.time.Period.millis(1);
        int[] intArray60 = iSOChronology52.get((org.joda.time.ReadablePeriod) period58, 0L);
        try {
            int[] intArray62 = offsetDateTimeField12.add(readablePartial45, (int) '#', intArray60, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 946684800000L + "'", long43 == 946684800000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2922799 + "'", int44 == 2922799);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        int int36 = scaledDurationField31.getValue(60480000000000000L);
        long long39 = scaledDurationField31.add(287999L, 8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10000 + "'", int36 == 10000);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 48384000287999L + "'", long39 == 48384000287999L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.years();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) 0, 287999, 2922799, (int) (byte) 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.yearOfCentury();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology13 = iSOChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray20 = new int[] { ' ', 97 };
        int int21 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray20);
        java.lang.String str23 = offsetDateTimeField16.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime28 = null;
        boolean boolean29 = dateTimeZone27.isLocalDateTimeGap(localDateTime28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField31 = iSOChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.yearOfCentury();
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology34 = iSOChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology30.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
        org.joda.time.ReadablePartial readablePartial38 = null;
        int[] intArray41 = new int[] { ' ', 97 };
        int int42 = offsetDateTimeField37.getMinimumValue(readablePartial38, intArray41);
        int int43 = offsetDateTimeField16.getMinimumValue(readablePartial24, intArray41);
        try {
            iSOChronology1.validate(readablePartial3, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "29" + "'", str23.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("Minutes", 110);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder2.setFixedSavings("UTC", 100);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder2.writeTo("P-1D", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) -1, (int) (short) -1, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText(60480000000052L);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType6, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "124" + "'", str5.equals("124"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (-287999), (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) '#');
        long long11 = cachedDateTimeZone7.previousTransition(52L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.withMonths(124);
        int int9 = period4.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        long long9 = gregorianChronology1.add((long) '4', 2450588L, 110);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 269564732L + "'", long9 == 269564732L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        long long65 = offsetDateTimeField12.roundHalfCeiling((-100L));
        long long67 = offsetDateTimeField12.roundHalfFloor(946684800132L);
        int int69 = offsetDateTimeField12.getLeapAmount(60480000000001L);
        boolean boolean71 = offsetDateTimeField12.isLeap(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 946684800000L + "'", long65 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684800000L + "'", long67 == 946684800000L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        int int11 = period7.getDays();
        org.joda.time.Period period13 = period7.plusMillis((-28800000));
        org.joda.time.DurationFieldType durationFieldType15 = period7.getFieldType(0);
        try {
            org.joda.time.DurationFieldType durationFieldType17 = period7.getFieldType(287999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldType15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.minutes();
        boolean boolean29 = periodType27.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType31 = periodType27.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField33 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (short) 100);
        long long36 = preciseDurationField33.add(52L, 0);
        long long38 = preciseDurationField33.getMillis((int) (short) -1);
        int int39 = unsupportedDurationField25.compareTo((org.joda.time.DurationField) preciseDurationField33);
        try {
            long long42 = unsupportedDurationField25.getMillis(164096150400010L, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-100L) + "'", long38 == (-100L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = illegalFieldValueException20.getDateTimeFieldType();
        java.lang.Number number22 = illegalFieldValueException20.getLowerBound();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) 100 + "'", number22.equals((byte) 100));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean12 = preciseDurationField6.equals((java.lang.Object) fixedDateTimeZone11);
        java.lang.String str14 = fixedDateTimeZone11.getShortName((long) 288000);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.052" + "'", str14.equals("+00:00:00.052"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        java.lang.String str64 = offsetDateTimeField12.toString();
        long long66 = offsetDateTimeField12.roundCeiling((-1L));
        long long69 = offsetDateTimeField12.add((-175391999999900L), 110);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str64.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 946684800000L + "'", long66 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 171734428800100L + "'", long69 == 171734428800100L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 1, periodType1);
        org.joda.time.Period period4 = period2.withMonths((int) (short) 10);
        org.joda.time.Period period6 = period4.minusYears(52);
        try {
            org.joda.time.Seconds seconds7 = period4.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        long long22 = offsetDateTimeField12.add((long) 'a', 0L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField12.getAsText(readablePartial23, (int) (byte) 100, locale25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType27, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("Minutes", 110);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder2.setFixedSavings("UTC", 100);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("PT0.097S", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getValueAsLong((long) '4', (long) 52);
        int int35 = scaledDurationField31.getScalar();
        long long37 = scaledDurationField31.getMillis((long) 10000);
        int int40 = scaledDurationField31.getDifference((-31405L), (-6048000000000L));
        long long43 = scaledDurationField31.getValueAsLong(0L, 314496000000000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10000 + "'", int35 == 10000);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 60480000000000000L + "'", long37 == 60480000000000000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray23 = null;
        int int24 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray23);
        long long27 = offsetDateTimeField12.add((-1L), 0L);
        java.util.Locale locale28 = null;
        int int29 = offsetDateTimeField12.getMaximumShortTextLength(locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType30, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getStandardOffset((-287999L));
        long long11 = cachedDateTimeZone7.previousTransition((-6048000000000L));
        long long13 = cachedDateTimeZone7.previousTransition((long) (byte) 0);
        int int15 = cachedDateTimeZone7.getStandardOffset(60483000931200000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-6048000000000L) + "'", long11 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Period period4 = period2.plusMonths(1);
        int int5 = period2.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long12 = preciseDurationField6.getValueAsLong(0L);
        long long15 = preciseDurationField6.getValueAsLong(0L, (-1L));
        long long18 = preciseDurationField6.getMillis(0L, 0L);
        long long21 = preciseDurationField6.getMillis((int) 'a', 604800000000000L);
        boolean boolean22 = preciseDurationField6.isSupported();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9700L + "'", long21 == 9700L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        long long41 = offsetDateTimeField12.roundCeiling((long) 1);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsText((int) 'a', locale43);
        long long46 = offsetDateTimeField12.remainder((long) 287999);
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime51 = null;
        boolean boolean52 = dateTimeZone50.isLocalDateTimeGap(localDateTime51);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DurationField durationField54 = iSOChronology53.weeks();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology53.yearOfCentury();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology53);
        org.joda.time.Chronology chronology57 = iSOChronology53.withUTC();
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology53.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 10);
        org.joda.time.ReadablePartial readablePartial61 = null;
        int[] intArray64 = new int[] { ' ', 97 };
        int int65 = offsetDateTimeField60.getMinimumValue(readablePartial61, intArray64);
        java.lang.String str67 = offsetDateTimeField60.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial68 = null;
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime72 = null;
        boolean boolean73 = dateTimeZone71.isLocalDateTimeGap(localDateTime72);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.DurationField durationField75 = iSOChronology74.weeks();
        org.joda.time.DateTimeField dateTimeField76 = iSOChronology74.yearOfCentury();
        org.joda.time.Period period77 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology74);
        org.joda.time.Chronology chronology78 = iSOChronology74.withUTC();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology74.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 10);
        org.joda.time.ReadablePartial readablePartial82 = null;
        int[] intArray85 = new int[] { ' ', 97 };
        int int86 = offsetDateTimeField81.getMinimumValue(readablePartial82, intArray85);
        int int87 = offsetDateTimeField60.getMinimumValue(readablePartial68, intArray85);
        int int88 = offsetDateTimeField12.getMaximumValue(readablePartial47, intArray85);
        int int89 = offsetDateTimeField12.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 946684800000L + "'", long41 == 946684800000L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "97" + "'", str44.equals("97"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 287999L + "'", long46 == 287999L);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "29" + "'", str67.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 10 + "'", int86 == 10);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2922799 + "'", int88 == 2922799);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 10 + "'", int89 == 10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.Period period2 = new org.joda.time.Period((-6048000000000L), 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.yearOfCentury();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology13 = iSOChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray20 = new int[] { ' ', 97 };
        int int21 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray20);
        java.lang.String str23 = offsetDateTimeField16.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime28 = null;
        boolean boolean29 = dateTimeZone27.isLocalDateTimeGap(localDateTime28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField31 = iSOChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.yearOfCentury();
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology34 = iSOChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology30.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
        org.joda.time.ReadablePartial readablePartial38 = null;
        int[] intArray41 = new int[] { ' ', 97 };
        int int42 = offsetDateTimeField37.getMinimumValue(readablePartial38, intArray41);
        int int43 = offsetDateTimeField16.getMinimumValue(readablePartial24, intArray41);
        try {
            gregorianChronology1.validate(readablePartial3, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "29" + "'", str23.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.clockhourOfDay();
        java.lang.String str10 = iSOChronology5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        long long12 = iSOChronology5.add((long) (short) 0, (long) '4', (int) '4');
        org.joda.time.DurationField durationField13 = iSOChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology5.monthOfYear();
        try {
            long long19 = iSOChronology5.getDateTimeMillis(97, (-287999), 100, 110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -287999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2704L + "'", long12 == 2704L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("-1", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology3.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 'a', periodType2);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds9 = period6.toStandardSeconds();
        org.joda.time.Period period11 = period6.plusDays((-1));
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 0);
        java.lang.String str14 = period11.toString();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        boolean boolean17 = periodType15.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType19 = periodType15.getFieldType(0);
        int int20 = period11.get(durationFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType19, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean25 = period3.isSupported(durationFieldType19);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) unsupportedDurationField26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1D" + "'", str14.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DurationField durationField11 = iSOChronology8.minutes();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds6 = period3.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = periodType9.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType13 = periodType9.getFieldType(0);
        org.joda.time.PeriodType periodType14 = periodType9.withMonthsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        boolean boolean18 = periodType16.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType(0);
        org.joda.time.PeriodType periodType21 = periodType16.withSecondsRemoved();
        int int22 = periodType16.size();
        org.joda.time.Period period23 = period15.withPeriodType(periodType16);
        org.joda.time.Period period25 = period15.plusWeeks(0);
        int[] intArray26 = period15.getValues();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText(60480000000052L);
        java.lang.String str6 = offsetDateTimeField3.toString();
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField14 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.yearOfCentury();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Chronology chronology17 = iSOChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology13.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 10);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray24 = new int[] { ' ', 97 };
        int int25 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray24);
        java.lang.String str27 = offsetDateTimeField20.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = dateTimeZone31.isLocalDateTimeGap(localDateTime32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField35 = iSOChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.yearOfCentury();
        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology34);
        org.joda.time.Chronology chronology38 = iSOChronology34.withUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology34.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray45 = new int[] { ' ', 97 };
        int int46 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray45);
        int int47 = offsetDateTimeField20.getMinimumValue(readablePartial28, intArray45);
        long long50 = offsetDateTimeField20.set(97L, 52);
        boolean boolean52 = offsetDateTimeField20.isLeap((long) (byte) 100);
        long long54 = offsetDateTimeField20.roundFloor(97L);
        org.joda.time.ReadablePartial readablePartial55 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime59 = null;
        boolean boolean60 = dateTimeZone58.isLocalDateTimeGap(localDateTime59);
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DurationField durationField62 = iSOChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology61.yearOfCentury();
        org.joda.time.Period period64 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology61);
        org.joda.time.Chronology chronology65 = iSOChronology61.withUTC();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology61.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, 10);
        org.joda.time.ReadablePartial readablePartial69 = null;
        int[] intArray72 = new int[] { ' ', 97 };
        int int73 = offsetDateTimeField68.getMinimumValue(readablePartial69, intArray72);
        int int74 = offsetDateTimeField20.getMinimumValue(readablePartial55, intArray72);
        int int75 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray72);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "124" + "'", str5.equals("124"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str6.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "29" + "'", str27.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 72581011200097L + "'", long50 == 72581011200097L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2208988800000L) + "'", long54 == (-2208988800000L));
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 124 + "'", int75 == 124);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((-100L));
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.Period period9 = new org.joda.time.Period(52L, (org.joda.time.Chronology) iSOChronology5);
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) 72581011200097L, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DurationField durationField11 = iSOChronology8.months();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType16 = periodType12.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType16, (long) (short) 100);
        java.lang.String str19 = preciseDurationField18.getName();
        int int22 = preciseDurationField18.getDifference((long) 100, (long) (byte) 10);
        long long24 = preciseDurationField18.getValueAsLong(0L);
        long long27 = preciseDurationField18.getValueAsLong(0L, (-1L));
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone30.isLocalDateTimeGap(localDateTime31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField34 = iSOChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.yearOfCentury();
        org.joda.time.Period period36 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology33);
        long long40 = iSOChronology33.add((long) (short) 0, (long) '4', (int) '4');
        org.joda.time.DurationField durationField41 = iSOChronology33.halfdays();
        boolean boolean42 = preciseDurationField18.equals((java.lang.Object) iSOChronology33);
        boolean boolean43 = iSOChronology8.equals((java.lang.Object) boolean42);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "minutes" + "'", str19.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2704L + "'", long40 == 2704L);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.era();
        org.joda.time.DurationField durationField7 = iSOChronology3.halfdays();
        org.joda.time.DurationField durationField8 = iSOChronology3.millis();
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            int[] intArray11 = iSOChronology3.get(readablePartial9, 221L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        org.joda.time.Period period6 = org.joda.time.Period.minutes((int) (byte) -1);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) period6);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(28800000L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.add(60480000000001L, 32L);
        long long37 = scaledDurationField31.getMillis(32L, 32L);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.minutes();
        boolean boolean41 = periodType39.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType42 = periodType39.withWeeksRemoved();
        org.joda.time.PeriodType periodType43 = periodType42.withDaysRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType42);
        org.joda.time.Period period45 = new org.joda.time.Period(0L, periodType44);
        try {
            org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) 32L, periodType44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 254016000000001L + "'", long34 == 254016000000001L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 193536000000000L + "'", long37 == 193536000000000L);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) '#');
        boolean boolean11 = cachedDateTimeZone7.isStandardOffset(169L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = dateTimeZone5.getMillisKeepLocal(dateTimeZone11, (long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(iSOChronology17);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        boolean boolean6 = unsupportedDurationField5.isPrecise();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        long long4 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
        int int6 = dateTimeZone1.getOffsetFromLocal(164096150405200L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology8.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean18 = fixedDateTimeZone17.isFixed();
        int int20 = fixedDateTimeZone17.getOffsetFromLocal((long) 'a');
        java.lang.String str22 = fixedDateTimeZone17.getNameKey((long) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 0, chronology24);
        org.joda.time.Period period27 = period25.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds28 = period25.toStandardSeconds();
        org.joda.time.Period period30 = period25.plusDays((-1));
        org.joda.time.Period period32 = period30.plusSeconds((int) (short) 0);
        boolean boolean33 = fixedDateTimeZone17.equals((java.lang.Object) period30);
        org.joda.time.Period period35 = period30.minusMinutes(287999);
        org.joda.time.Period period37 = period30.withSeconds(287999);
        int[] intArray39 = iSOChronology8.get((org.joda.time.ReadablePeriod) period37, 306102499200097L);
        org.joda.time.Period period41 = period37.minusHours(100);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(seconds28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(period41);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        long long65 = offsetDateTimeField12.roundHalfCeiling((-100L));
        long long67 = offsetDateTimeField12.roundHalfFloor(946684800132L);
        java.lang.String str69 = offsetDateTimeField12.getAsText(0L);
        org.joda.time.ReadablePartial readablePartial70 = null;
        int[] intArray74 = new int[] { 0, '#' };
        java.util.Locale locale76 = null;
        try {
            int[] intArray77 = offsetDateTimeField12.set(readablePartial70, 1, intArray74, "10.0", locale76);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"10.0\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 946684800000L + "'", long65 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684800000L + "'", long67 == 946684800000L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "29" + "'", str69.equals("29"));
        org.junit.Assert.assertNotNull(intArray74);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period2.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period2.negated();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(readablePartial18, 1, locale20);
        long long23 = offsetDateTimeField12.roundCeiling((long) '4');
        long long26 = offsetDateTimeField12.add(97L, (int) 'a');
        org.joda.time.DurationField durationField27 = offsetDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684800000L + "'", long23 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 306102499200097L + "'", long26 == 306102499200097L);
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = dateTimeZone0.getOffset(readableInstant11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        long long4 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, true);
        java.lang.String str8 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.DurationFieldType durationFieldType21 = illegalFieldValueException20.getDurationFieldType();
        java.lang.Throwable[] throwableArray22 = illegalFieldValueException20.getSuppressed();
        java.lang.Throwable[] throwableArray23 = illegalFieldValueException20.getSuppressed();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        java.lang.String str13 = offsetDateTimeField12.toString();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField12, 29, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29 for centuryOfEra must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str13.equals("DateTimeField[centuryOfEra]"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        long long10 = preciseDurationField6.getMillis((-1), 2440588L);
        long long12 = preciseDurationField6.getMillis(100L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10000L + "'", long12 == 10000L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 1);
        try {
            int int9 = preciseDurationField6.getDifference((long) 10, 193536000000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -193535999999990");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(durationFieldType23, "ISOChronology[UTC]");
        java.lang.Number number34 = illegalFieldValueException33.getUpperBound();
        java.lang.Number number35 = illegalFieldValueException33.getIllegalNumberValue();
        java.lang.Throwable[] throwableArray36 = illegalFieldValueException33.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = gregorianChronology1.set(readablePartial6, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField12 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType11);
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField12.getType();
        java.lang.String str14 = unsupportedDurationField12.getName();
        boolean boolean15 = unsupportedDurationField12.isSupported();
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', periodType17);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, chronology20);
        org.joda.time.Period period23 = period21.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds24 = period21.toStandardSeconds();
        org.joda.time.Period period26 = period21.plusDays((-1));
        org.joda.time.Period period28 = period26.plusSeconds((int) (short) 0);
        java.lang.String str29 = period26.toString();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.minutes();
        boolean boolean32 = periodType30.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType34 = periodType30.getFieldType(0);
        int int35 = period26.get(durationFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(durationFieldType34, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean40 = period18.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField41 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        int int42 = unsupportedDurationField12.compareTo((org.joda.time.DurationField) unsupportedDurationField41);
        org.joda.time.DurationFieldType durationFieldType43 = unsupportedDurationField41.getType();
        int int44 = periodType6.indexOf(durationFieldType43);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(unsupportedDurationField12);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "minutes" + "'", str14.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(seconds24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "P-1D" + "'", str29.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.lang.String str7 = offsetDateTimeField5.getAsText(60480000000052L);
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField15 = iSOChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.yearOfCentury();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology18 = iSOChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray25 = new int[] { ' ', 97 };
        int int26 = offsetDateTimeField21.getMinimumValue(readablePartial22, intArray25);
        long long29 = offsetDateTimeField21.add(10L, (long) '4');
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField21.getMaximumTextLength(locale30);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime36 = null;
        boolean boolean37 = dateTimeZone35.isLocalDateTimeGap(localDateTime36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField39 = iSOChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.yearOfCentury();
        org.joda.time.Period period41 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology38);
        org.joda.time.Period period43 = org.joda.time.Period.hours(10);
        int[] intArray45 = iSOChronology38.get((org.joda.time.ReadablePeriod) period43, 60480000000000L);
        int int46 = offsetDateTimeField21.getMinimumValue(readablePartial32, intArray45);
        int int47 = offsetDateTimeField5.getMinimumValue(readablePartial8, intArray45);
        try {
            gregorianChronology0.validate(readablePartial1, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "124" + "'", str7.equals("124"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 164096150400010L + "'", long29 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 101 + "'", int47 == 101);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.year();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.Period period1 = org.joda.time.Period.hours(29);
        org.joda.time.Period period3 = period1.withMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Period period5 = period2.negated();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        java.lang.Number number21 = illegalFieldValueException20.getIllegalNumberValue();
        java.lang.String str22 = illegalFieldValueException20.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType23 = illegalFieldValueException20.getDurationFieldType();
        java.lang.Number number24 = illegalFieldValueException20.getUpperBound();
        java.lang.String str25 = illegalFieldValueException20.getIllegalStringValue();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0" + "'", str22.equals("10.0"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10L + "'", number24.equals(10L));
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period10 = org.joda.time.Period.hours(10);
        int[] intArray12 = iSOChronology5.get((org.joda.time.ReadablePeriod) period10, 60480000000000L);
        org.joda.time.Period period13 = period10.toPeriod();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds17 = period14.toStandardSeconds();
        org.joda.time.Period period19 = period14.plusDays((-1));
        org.joda.time.Period period21 = period19.plusSeconds((int) (short) 0);
        java.lang.String str22 = period19.toString();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        boolean boolean25 = periodType23.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        int int28 = period19.get(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean33 = period11.isSupported(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        int int35 = unsupportedDurationField5.compareTo((org.joda.time.DurationField) unsupportedDurationField34);
        try {
            long long37 = unsupportedDurationField34.getMillis(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(seconds17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "P-1D" + "'", str22.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 0, chronology8);
        org.joda.time.Period period11 = period9.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds12 = period9.toStandardSeconds();
        org.joda.time.Period period14 = period9.plusDays((-1));
        org.joda.time.Period period16 = period14.plusSeconds((int) (short) 0);
        java.lang.String str17 = period14.toString();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.minutes();
        boolean boolean20 = periodType18.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType22 = periodType18.getFieldType(0);
        int int23 = period14.get(durationFieldType22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType22, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.DurationFieldType durationFieldType28 = illegalFieldValueException27.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType28, "29");
        int int31 = periodType5.indexOf(durationFieldType28);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(seconds12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "P-1D" + "'", str17.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.yearOfCentury();
        org.joda.time.DurationField durationField8 = iSOChronology3.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        long long7 = unsupportedDurationField5.getUnitMillis();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        java.lang.Number number21 = illegalFieldValueException20.getIllegalNumberValue();
        java.lang.String str22 = illegalFieldValueException20.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType23 = illegalFieldValueException20.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, (java.lang.Number) 604800000000100L);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0" + "'", str22.equals("10.0"));
        org.junit.Assert.assertNotNull(durationFieldType23);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        long long9 = preciseDurationField6.add(100L, (int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType10 = preciseDurationField6.getType();
        java.lang.String str11 = preciseDurationField6.toString();
        long long14 = preciseDurationField6.add((-604800000000000L), 0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 200L + "'", long9 == 200L);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DurationField[minutes]" + "'", str11.equals("DurationField[minutes]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-604800000000000L) + "'", long14 == (-604800000000000L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        long long9 = unsupportedDurationField5.getUnitMillis();
        try {
            long long11 = unsupportedDurationField5.getMillis(52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 110, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        long long9 = preciseDurationField6.add(100L, (int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType10 = preciseDurationField6.getType();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 0, chronology12);
        org.joda.time.Period period15 = period13.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds16 = period13.toStandardSeconds();
        org.joda.time.Period period18 = period13.plusDays((-1));
        org.joda.time.Period period20 = period18.plusSeconds((int) (short) 0);
        java.lang.String str21 = period18.toString();
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.minutes();
        boolean boolean24 = periodType22.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType26 = periodType22.getFieldType(0);
        int int27 = period18.get(durationFieldType26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType26, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        org.joda.time.field.DecoratedDurationField decoratedDurationField32 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField6, durationFieldType26);
        long long35 = preciseDurationField6.getDifferenceAsLong((-31405L), (long) 7);
        long long38 = preciseDurationField6.getDifferenceAsLong((long) (-1), (long) 8);
        long long41 = preciseDurationField6.getMillis((long) (-287999), 5200L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 200L + "'", long9 == 200L);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(seconds16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "P-1D" + "'", str21.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-314L) + "'", long35 == (-314L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-28799900L) + "'", long41 == (-28799900L));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("+00:00:00.052", (java.lang.Number) 42, (java.lang.Number) 164096150400010L, (java.lang.Number) 221L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 124, (int) (byte) 1, 124);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField12.getAsShortText(220L, locale43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = offsetDateTimeField12.getMaximumValue(readablePartial45);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "29" + "'", str44.equals("29"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922799 + "'", int46 == 2922799);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Seconds seconds9 = period8.toStandardSeconds();
        org.joda.time.Period period11 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period11.toPeriod();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PT-0.009S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "PT-0.009S");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.String str4 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (PT-0.009S)" + "'", str4.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (PT-0.009S)"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.minusWeeks((int) 'a');
        org.joda.time.Period period4 = period0.minusMillis((int) (byte) -1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        boolean boolean7 = periodType5.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType9 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType9, (long) (short) 100);
        int int13 = preciseDurationField11.getValue((long) '4');
        int int16 = preciseDurationField11.getDifference(10L, 28800000L);
        int int18 = preciseDurationField11.getValue(1L);
        boolean boolean19 = period4.equals((java.lang.Object) int18);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-287999) + "'", int16 == (-287999));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.Period period3 = org.joda.time.Period.minutes(52);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = gregorianChronology5.withZone(dateTimeZone7);
        boolean boolean9 = period3.equals((java.lang.Object) chronology8);
        org.joda.time.Period period10 = new org.joda.time.Period(187200000L, (-604800000000000L), chronology8);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period13 = period10.withMinutes(124);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Minutes");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        long long11 = fixedDateTimeZone4.adjustOffset(0L, true);
        long long14 = fixedDateTimeZone4.convertLocalToUTC(254016000000001L, true);
        java.util.TimeZone timeZone15 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone4.getShortName(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 254015999999949L + "'", long14 == 254015999999949L);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.052" + "'", str17.equals("+00:00:00.052"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds6 = period3.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = periodType9.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType13 = periodType9.getFieldType(0);
        org.joda.time.PeriodType periodType14 = periodType9.withMonthsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        boolean boolean18 = periodType16.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType(0);
        org.joda.time.PeriodType periodType21 = periodType16.withSecondsRemoved();
        int int22 = periodType16.size();
        org.joda.time.Period period23 = period15.withPeriodType(periodType16);
        org.joda.time.Period period25 = period15.plusWeeks(0);
        try {
            org.joda.time.Period period27 = period25.minusYears(29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period2 = new org.joda.time.Period(9999L, periodType1);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField6 = new org.joda.time.field.PreciseDurationField(durationFieldType4, (long) (short) 100);
        java.lang.String str7 = preciseDurationField6.getName();
        int int10 = preciseDurationField6.getDifference((long) 100, (long) (byte) 10);
        long long12 = preciseDurationField6.getValueAsLong(0L);
        long long15 = preciseDurationField6.getValueAsLong(0L, (-1L));
        long long18 = preciseDurationField6.getMillis(0L, 0L);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField25 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) (short) 100);
        int int27 = preciseDurationField25.getValue((long) '4');
        int int28 = preciseDurationField6.compareTo((org.joda.time.DurationField) preciseDurationField25);
        java.lang.Class<?> wildcardClass29 = preciseDurationField25.getClass();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType31 = periodType30.withMillisRemoved();
        try {
            org.joda.time.Period period32 = new org.joda.time.Period((java.lang.Object) wildcardClass29, periodType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Class");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField7 = new org.joda.time.field.PreciseDurationField(durationFieldType5, (long) (short) 1);
        boolean boolean8 = periodType0.isSupported(durationFieldType5);
        int int9 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(8, 101, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        int int8 = fixedDateTimeZone4.getStandardOffset((long) (byte) -1);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray23 = null;
        int int24 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray23);
        long long26 = offsetDateTimeField12.roundHalfFloor(164096150400010L);
        long long28 = offsetDateTimeField12.roundHalfEven((long) 101);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 165042835200000L + "'", long26 == 165042835200000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 946684800000L + "'", long28 == 946684800000L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = iSOChronology3.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField6 = gregorianChronology1.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = gregorianChronology3.withZone(dateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        boolean boolean13 = fixedDateTimeZone11.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        int int16 = cachedDateTimeZone14.getStandardOffset((-287999L));
        long long18 = cachedDateTimeZone14.previousTransition((-6048000000000L));
        long long20 = cachedDateTimeZone14.previousTransition((long) (byte) 0);
        long long22 = cachedDateTimeZone14.nextTransition(32L);
        org.joda.time.Chronology chronology23 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Period period24 = new org.joda.time.Period((long) '#', periodType1, chronology23);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-6048000000000L) + "'", long18 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 32L + "'", long22 == 32L);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (PT-0.009S)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (PT-0.009S)' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Object obj0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period(obj0);
        org.joda.time.Period period3 = period1.withMinutes((int) 'a');
        int int4 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis(124);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("100", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"100/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.Seconds seconds11 = period7.toStandardSeconds();
        org.joda.time.Period period13 = period7.minusMinutes(0);
        org.joda.time.Period period15 = period13.withMonths(100);
        int int16 = period13.getWeeks();
        org.joda.time.MutablePeriod mutablePeriod17 = period13.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(seconds11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(mutablePeriod17);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.Period period7 = period2.multipliedBy(97);
        org.joda.time.Weeks weeks8 = period2.toStandardWeeks();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 1, periodType10);
        org.joda.time.Period period13 = period11.withMonths((int) (short) 10);
        org.joda.time.Period period15 = period13.minusMinutes(10);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Period period18 = period13.plusSeconds(10000);
        org.joda.time.Period period19 = period2.minus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.clockhourOfDay();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.era();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period18, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.hourOfDay();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(weeks8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        long long13 = dateTimeZone0.convertLocalToUTC(604800000000000L, true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 604800000000000L + "'", long13 == 604800000000000L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P-1D");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField7 = iSOChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P-1D\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"P-1D\")"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period5.toStandardSeconds();
        org.joda.time.Period period10 = period5.plusDays((-1));
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 0);
        java.lang.String str13 = period10.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        int int19 = period10.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean24 = period2.isSupported(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        boolean boolean27 = unsupportedDurationField25.isPrecise();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P-1D" + "'", str13.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long8 = iSOChronology0.getDateTimeMillis(0, 29, (int) (short) 100, 1, (int) (short) 0, (int) (byte) 1, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getValueAsLong((long) '4', (long) 52);
        int int35 = scaledDurationField31.getScalar();
        long long37 = scaledDurationField31.getMillis((long) 10000);
        int int40 = scaledDurationField31.getDifference((-31405L), (-6048000000000L));
        long long43 = scaledDurationField31.getValueAsLong((long) 287999, 0L);
        long long44 = scaledDurationField31.getUnitMillis();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10000 + "'", int35 == 10000);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 60480000000000000L + "'", long37 == 60480000000000000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 6048000000000L + "'", long44 == 6048000000000L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        long long12 = fixedDateTimeZone9.nextTransition(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int20 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.Period period1 = org.joda.time.Period.years(10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = gregorianChronology3.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.millisOfSecond();
        boolean boolean9 = gregorianChronology3.equals((java.lang.Object) 97);
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period10.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00:00.035");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        java.lang.String str7 = unsupportedDurationField5.getName();
        boolean boolean8 = unsupportedDurationField5.isSupported();
        long long9 = unsupportedDurationField5.getUnitMillis();
        boolean boolean10 = unsupportedDurationField5.isSupported();
        try {
            long long13 = unsupportedDurationField5.add((long) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minutes" + "'", str7.equals("minutes"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = dateTimeZone5.getMillisKeepLocal(dateTimeZone11, (long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) 1, periodType19);
        org.joda.time.Period period22 = period20.withSeconds((int) '#');
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period24 = period20.normalizedStandard(periodType23);
        int int25 = period24.getMinutes();
        long long28 = iSOChronology17.add((org.joda.time.ReadablePeriod) period24, (long) 29, 9);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology17.hourOfDay();
        try {
            long long37 = iSOChronology17.getDateTimeMillis((int) '4', 0, 100, 0, 100, (int) (byte) -1, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 29L + "'", long28 == 29L);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (short) 100);
        int int14 = periodType6.indexOf(durationFieldType11);
        org.joda.time.PeriodType periodType15 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        boolean boolean9 = periodType7.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (short) 100);
        int int14 = periodType6.indexOf(durationFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType11, "P-1D");
        java.lang.Number number17 = illegalFieldValueException16.getLowerBound();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 29");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology5.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        long long6 = unsupportedDurationField5.getUnitMillis();
        try {
            long long8 = unsupportedDurationField5.getMillis(28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        long long6 = durationField3.subtract(164096150405200L, 287999);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-908672965689594800L) + "'", long6 == (-908672965689594800L));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField12.getAsText((int) (byte) -1, locale41);
        boolean boolean44 = offsetDateTimeField12.isLeap((-18478968L));
        int int45 = offsetDateTimeField12.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-1" + "'", str42.equals("-1"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT-0.009S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT-0.009S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.get(durationFieldType6);
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period5.getFieldTypes();
        org.joda.time.Period period10 = period5.multipliedBy(97);
        org.joda.time.Period period12 = period5.withMillis((int) (byte) 1);
        long long15 = iSOChronology1.add((org.joda.time.ReadablePeriod) period12, (long) 110, 110);
        org.joda.time.format.PeriodFormatter periodFormatter16 = null;
        java.lang.String str17 = period12.toString(periodFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220L + "'", long15 == 220L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.001S" + "'", str17.equals("PT0.001S"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "(\"org.joda.time.JodaTimePermission\" \"P-1D\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, (java.lang.Number) 3140588L, (java.lang.Number) 254015999999949L, (java.lang.Number) 60479845257600000L);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        boolean boolean19 = offsetDateTimeField12.isLeap((-18478968L));
        boolean boolean21 = offsetDateTimeField12.isLeap(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone0.getName((long) (short) 100, locale12);
//        java.util.TimeZone timeZone14 = dateTimeZone0.toTimeZone();
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        int int16 = dateTimeZone0.getOffset(readableInstant15);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.lang.String str19 = dateTimeZone0.getShortName(187200000L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getStandardOffset((-287999L));
        long long11 = cachedDateTimeZone7.previousTransition((-6048000000000L));
        long long13 = cachedDateTimeZone7.previousTransition((long) (byte) 0);
        long long16 = cachedDateTimeZone7.adjustOffset((-908672965689594800L), true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-6048000000000L) + "'", long11 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-908672965689594800L) + "'", long16 == (-908672965689594800L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.year();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (long) 100, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period8.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.048S" + "'", str10.equals("PT0.048S"));
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("9");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"9\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        org.joda.time.Period period11 = period9.plusMinutes((int) (short) 1);
        org.joda.time.Period period12 = period9.normalizedStandard();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.minutes();
        boolean boolean15 = periodType13.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType17 = periodType13.getFieldType(0);
        org.joda.time.PeriodType periodType18 = periodType13.withSecondsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period9, periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'days'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        long long22 = offsetDateTimeField12.add((long) 'a', 0L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField12.getAsText(readablePartial23, (int) (byte) 100, locale25);
        long long29 = offsetDateTimeField12.addWrapField((long) 100, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1350321976080000100L + "'", long29 == 1350321976080000100L);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) (short) 100);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone0.getName((long) (short) 100, locale12);
//        java.util.TimeZone timeZone14 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType5 = periodType2.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period10 = new org.joda.time.Period(100L, periodType5, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.year();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.yearOfEra();
        org.joda.time.DurationField durationField13 = iSOChronology9.centuries();
        org.joda.time.DurationField durationField14 = iSOChronology9.seconds();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) iSOChronology9);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        long long20 = offsetDateTimeField12.add(10L, (long) '4');
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField12.getMaximumTextLength(locale21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = dateTimeZone26.isLocalDateTimeGap(localDateTime27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.DurationField durationField30 = iSOChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.yearOfCentury();
        org.joda.time.Period period32 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Period period34 = org.joda.time.Period.hours(10);
        int[] intArray36 = iSOChronology29.get((org.joda.time.ReadablePeriod) period34, 60480000000000L);
        int int37 = offsetDateTimeField12.getMinimumValue(readablePartial23, intArray36);
        try {
            long long40 = offsetDateTimeField12.set((long) 4, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for centuryOfEra must be in the range [10,2922799]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 164096150400010L + "'", long20 == 164096150400010L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Period period3 = org.joda.time.Period.minutes(52);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = gregorianChronology5.withZone(dateTimeZone7);
        boolean boolean9 = period3.equals((java.lang.Object) chronology8);
        org.joda.time.Period period10 = new org.joda.time.Period(187200000L, (-604800000000000L), chronology8);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period13 = period10.withMinutes((int) (short) 100);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 97, chronology1);
        org.joda.time.Period period4 = period2.withYears((-1));
        org.joda.time.Period period6 = period2.multipliedBy((int) (short) 100);
        org.joda.time.Period period8 = period2.withMonths((int) '#');
        org.joda.time.Period period10 = period2.plusHours(10);
        int int11 = period10.size();
        org.joda.time.Minutes minutes12 = period10.toStandardMinutes();
        org.joda.time.Period period14 = period10.minusSeconds((int) (short) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(minutes12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        long long12 = fixedDateTimeZone9.nextTransition(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology14 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', periodType1);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        boolean boolean7 = periodType5.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType9 = periodType5.getFieldType(0);
        org.joda.time.PeriodType periodType10 = periodType5.withMonthsRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withMinutesRemoved();
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', periodType14);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, chronology17);
        org.joda.time.Period period20 = period18.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds21 = period18.toStandardSeconds();
        org.joda.time.Period period23 = period18.plusDays((-1));
        org.joda.time.Period period25 = period23.plusSeconds((int) (short) 0);
        java.lang.String str26 = period23.toString();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.minutes();
        boolean boolean29 = periodType27.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType31 = periodType27.getFieldType(0);
        int int32 = period23.get(durationFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType31, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean37 = period15.isSupported(durationFieldType31);
        org.joda.time.field.PreciseDurationField preciseDurationField39 = new org.joda.time.field.PreciseDurationField(durationFieldType31, 254015999999949L);
        int int40 = periodType12.indexOf(durationFieldType31);
        int int41 = period2.get(durationFieldType31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.097S" + "'", str4.equals("PT0.097S"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(seconds21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "P-1D" + "'", str26.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 97, chronology1);
        org.joda.time.Period period4 = period2.withYears((-1));
        org.joda.time.Period period6 = period2.multipliedBy((int) (short) 100);
        org.joda.time.Period period8 = period2.withMonths((int) '#');
        org.joda.time.Period period10 = period2.plusHours(10);
        int int11 = period10.size();
        org.joda.time.Minutes minutes12 = period10.toStandardMinutes();
        org.joda.time.Period period14 = org.joda.time.Period.days((int) 'a');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.Period period17 = period10.withFields((org.joda.time.ReadablePeriod) period14);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.minutes();
        boolean boolean20 = periodType18.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType22 = periodType18.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField24 = new org.joda.time.field.PreciseDurationField(durationFieldType22, (long) (short) 100);
        long long27 = preciseDurationField24.add(100L, (int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType28 = preciseDurationField24.getType();
        int int29 = period14.get(durationFieldType28);
        org.joda.time.Period period31 = period14.plusMinutes(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(minutes12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 200L + "'", long27 == 200L);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(period31);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Period period1 = org.joda.time.Period.millis(1);
        org.joda.time.Period period3 = period1.plusDays((int) (byte) -1);
        int int4 = period1.getMinutes();
        org.joda.time.Period period6 = period1.withWeeks((int) '#');
        java.lang.String str7 = period6.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "P35WT0.001S" + "'", str7.equals("P35WT0.001S"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', (int) 'a');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        java.lang.String str11 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Minutes");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Minutes" + "'", str3.equals("Minutes"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2922799, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 122757558 + "'", int2 == 122757558);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        boolean boolean65 = offsetDateTimeField12.isLeap(2704L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis((int) 'a', (-1), (int) (byte) -1, 124, 110, (-28800000), 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 124 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.years();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType10 = periodType6.getFieldType(0);
        org.joda.time.PeriodType periodType11 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withSecondsRemoved();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.minutes();
        boolean boolean15 = periodType13.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType17 = periodType13.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType17, (long) (short) 100);
        int int20 = periodType12.indexOf(durationFieldType17);
        org.joda.time.field.ScaledDurationField scaledDurationField22 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType17, (int) (byte) -1);
        boolean boolean23 = periodType0.isSupported(durationFieldType17);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(0);
        org.joda.time.PeriodType periodType7 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10, (-28800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28799990) + "'", int2 == (-28799990));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.year();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (long) 100, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.minusMinutes(29);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.048S" + "'", str10.equals("PT0.048S"));
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        int int41 = offsetDateTimeField12.getLeapAmount(60480000000052L);
        java.lang.String str43 = offsetDateTimeField12.getAsShortText((-3155673600000L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28" + "'", str43.equals("28"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', periodType6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds13 = period10.toStandardSeconds();
        org.joda.time.Period period15 = period10.plusDays((-1));
        org.joda.time.Period period17 = period15.plusSeconds((int) (short) 0);
        java.lang.String str18 = period15.toString();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = period15.get(durationFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean29 = period7.isSupported(durationFieldType23);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType23, 10000);
        long long34 = scaledDurationField31.getMillis((-1), (long) 10000);
        long long37 = scaledDurationField31.getDifferenceAsLong((long) 122757558, (-314L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P-1D" + "'", str18.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-6048000000000L) + "'", long34 == (-6048000000000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.Duration duration4 = period1.toStandardDuration();
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8380800000L + "'", long5 == 8380800000L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone14.isLocalDateTimeGap(localDateTime15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long19 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        long long25 = dateTimeZone14.getMillisKeepLocal(dateTimeZone20, (long) ' ');
        org.joda.time.Chronology chronology26 = iSOChronology5.withZone(dateTimeZone20);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField28 = iSOChronology5.millis();
        org.joda.time.DurationField durationField29 = iSOChronology5.millis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.Period period1 = org.joda.time.Period.millis(1);
        org.joda.time.Period period3 = period1.plusDays((int) (byte) -1);
        org.joda.time.Period period5 = period1.minusMillis((int) (short) 10);
        java.lang.String str6 = period5.toString();
        int int7 = period5.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT-0.009S" + "'", str6.equals("PT-0.009S"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = dateTimeZone23.isLocalDateTimeGap(localDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField27 = iSOChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.yearOfCentury();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Chronology chronology30 = iSOChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray37 = new int[] { ' ', 97 };
        int int38 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray37);
        int int39 = offsetDateTimeField12.getMinimumValue(readablePartial20, intArray37);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField12.getAsText((int) (byte) -1, locale41);
        try {
            long long45 = offsetDateTimeField12.set((-3155673599948L), 122757558);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 122757558 for centuryOfEra must be in the range [10,2922799]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-1" + "'", str42.equals("-1"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-287999));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.Period period8 = new org.joda.time.Period(52L, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray16 = new int[] { ' ', 97 };
        int int17 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray16);
        java.lang.String str19 = offsetDateTimeField12.getAsText((long) (byte) 1);
        int int21 = offsetDateTimeField12.get((-287999L));
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField29 = iSOChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.yearOfCentury();
        org.joda.time.Period period31 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology32 = iSOChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology28.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray39 = new int[] { ' ', 97 };
        int int40 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray39);
        java.lang.String str42 = offsetDateTimeField35.getAsText((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone46.isLocalDateTimeGap(localDateTime47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField50 = iSOChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.yearOfCentury();
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology53 = iSOChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { ' ', 97 };
        int int61 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray60);
        int int62 = offsetDateTimeField35.getMinimumValue(readablePartial43, intArray60);
        int int63 = offsetDateTimeField12.getMinimumValue(readablePartial22, intArray60);
        org.joda.time.ReadablePartial readablePartial64 = null;
        int int65 = offsetDateTimeField12.getMaximumValue(readablePartial64);
        boolean boolean66 = offsetDateTimeField12.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "29" + "'", str19.equals("29"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "29" + "'", str42.equals("29"));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2922799 + "'", int65 == 2922799);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.Period period3 = org.joda.time.Period.minutes(52);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = gregorianChronology5.withZone(dateTimeZone7);
        boolean boolean9 = period3.equals((java.lang.Object) chronology8);
        org.joda.time.Period period10 = new org.joda.time.Period(187200000L, (-604800000000000L), chronology8);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period13 = period10.minusMinutes((-287999));
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone14.isLocalDateTimeGap(localDateTime15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        long long19 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        long long25 = dateTimeZone14.getMillisKeepLocal(dateTimeZone20, (long) ' ');
        org.joda.time.Chronology chronology26 = iSOChronology5.withZone(dateTimeZone20);
        org.joda.time.ReadablePartial readablePartial27 = null;
        try {
            long long29 = iSOChronology5.set(readablePartial27, 610848000288000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds5 = period2.toStandardSeconds();
        org.joda.time.Period period7 = period2.plusDays((-1));
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) 0);
        java.lang.String str10 = period7.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        boolean boolean13 = periodType11.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = period7.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        java.lang.Number number21 = illegalFieldValueException20.getLowerBound();
        java.lang.String str22 = illegalFieldValueException20.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-1D" + "'", str10.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 100 + "'", number21.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for minutes must be in the range [100,10]" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for minutes must be in the range [100,10]"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField5 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = unsupportedDurationField5.getType();
        try {
            long long8 = unsupportedDurationField5.getMillis(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minutes field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(unsupportedDurationField5);
        org.junit.Assert.assertNotNull(durationFieldType6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField6 = iSOChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.yearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.centuryOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        java.lang.String str13 = offsetDateTimeField12.toString();
        long long16 = offsetDateTimeField12.addWrapField(0L, (int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField12.getAsText(readablePartial17, (int) (byte) -1, locale19);
        int int22 = offsetDateTimeField12.getMaximumValue((-185983646400000L));
        long long25 = offsetDateTimeField12.add(665280000000000L, 124);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str13.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200000L + "'", long16 == 31556995200000L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2922799 + "'", int22 == 2922799);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1056586204800000L + "'", long25 == 1056586204800000L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', periodType7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, chronology10);
        org.joda.time.Period period13 = period11.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds14 = period11.toStandardSeconds();
        org.joda.time.Period period16 = period11.plusDays((-1));
        org.joda.time.Period period18 = period16.plusSeconds((int) (short) 0);
        java.lang.String str19 = period16.toString();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
        boolean boolean22 = periodType20.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType24 = periodType20.getFieldType(0);
        int int25 = period16.get(durationFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType24, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 10L);
        boolean boolean30 = period8.isSupported(durationFieldType24);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType24, 10000);
        long long34 = scaledDurationField32.getMillis((int) (byte) 10);
        long long37 = scaledDurationField32.getMillis((long) 100, (long) (short) 100);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.minutes();
        boolean boolean40 = periodType38.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType42 = periodType38.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField43 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) scaledDurationField32, durationFieldType42);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField45 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType42, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "P-1D" + "'", str19.equals("P-1D"));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60480000000000L + "'", long34 == 60480000000000L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604800000000000L + "'", long37 == 604800000000000L);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(durationFieldType42);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.yearOfCentury();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) "");
        org.joda.time.PeriodType periodType4 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period9 = new org.joda.time.Period(100L, periodType4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology8.centuries();
        org.joda.time.DurationField durationField13 = iSOChronology8.seconds();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            long long16 = iSOChronology8.set(readablePartial14, 29L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology1.hours();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) (byte) 10);
        org.joda.time.Seconds seconds11 = period8.toStandardSeconds();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period8.toDurationTo(readableInstant12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        boolean boolean16 = periodType14.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType(0);
        org.joda.time.PeriodType periodType19 = periodType14.withMonthsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant5, (org.joda.time.ReadableDuration) duration13, periodType19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.minutes();
        boolean boolean23 = periodType21.equals((java.lang.Object) "");
        org.joda.time.DurationFieldType durationFieldType25 = periodType21.getFieldType(0);
        org.joda.time.PeriodType periodType26 = periodType21.withSecondsRemoved();
        int int27 = periodType21.size();
        org.joda.time.Period period28 = period20.withPeriodType(periodType21);
        boolean boolean29 = iSOChronology3.equals((java.lang.Object) periodType21);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(seconds11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }
}

