import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test001");
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
//        java.util.Locale locale1 = null;
//        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "-47326-02-26T03:39:06.592-07:52:58");
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField7, (int) 'a');
//        long long12 = skipUndoDateTimeField9.add((long) 0, (long) 7);
//        long long15 = skipUndoDateTimeField9.add(0L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.withZone(dateTimeZone18);
//        int int20 = dateTime17.getMinuteOfDay();
//        org.joda.time.DateTime dateTime22 = dateTime17.plusHours((int) '4');
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(10L, (-1));
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        java.util.Locale locale31 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology30, locale31, (java.lang.Integer) 0, 0);
//        dateTimeParserBucket34.setOffset((java.lang.Integer) 366);
//        long long39 = dateTimeParserBucket34.computeMillis(false, "11:59:08 PM -07:52:58");
//        java.util.Locale locale40 = dateTimeParserBucket34.getLocale();
//        java.lang.String str41 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) timeOfDay26, 1603, locale40);
//        java.lang.String str44 = defaultNameProvider0.getName(locale40, "", "2019-06-15T15:15:02.407Z");
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 220924800000L + "'", long12 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3155760000000L + "'", long15 == 3155760000000L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 753 + "'", int20 == 753);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-357L) + "'", long39 == (-357L));
//        org.junit.Assert.assertNotNull(locale40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1603" + "'", str41.equals("1603"));
//        org.junit.Assert.assertNull(str44);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMillisOfSecond(52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendYear(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.withZone(dateTimeZone5);
//        java.lang.String str7 = dateTime4.toString();
//        org.joda.time.DateTime dateTime9 = dateTime4.withYearOfEra(366);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((-1));
//        org.joda.time.TimeOfDay timeOfDay12 = dateTime11.toTimeOfDay();
//        try {
//            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadablePartial) timeOfDay12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-12T12:33:10.997Z" + "'", str7.equals("2019-06-12T12:33:10.997Z"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(timeOfDay12);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int9 = skipUndoDateTimeField4.get((long) 366);
//        int int10 = skipUndoDateTimeField4.getMinimumValue();
//        java.lang.String str11 = skipUndoDateTimeField4.getName();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        java.lang.String str16 = dateTime13.toString();
//        org.joda.time.DateTime dateTime18 = dateTime13.withYearOfEra(366);
//        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
//        org.joda.time.LocalTime localTime20 = dateTime18.toLocalTime();
//        int int21 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime20);
//        long long24 = skipUndoDateTimeField4.getDifferenceAsLong(18539999L, (long) (byte) 1);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269054) + "'", int10 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-12T12:33:11.014Z" + "'", str16.equals("2019-06-12T12:33:11.014Z"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292269054) + "'", int21 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[minuteOfDay]", number1, (java.lang.Number) 219, (java.lang.Number) (-1595503694458L));
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        illegalFieldValueException4.prependMessage("2019-06-12T05:31:48.059-07:00");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
//        boolean boolean10 = dateTime8.isEqual(1L);
//        int int11 = dateTime8.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T12:33:11.063Z" + "'", str4.equals("2019-06-12T12:33:11.063Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone14);
        int int18 = dateTimeZone14.getOffsetFromLocal((long) 960);
        java.lang.String str20 = dateTimeZone14.getName((long) 101);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) (byte) -1);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.year();
        mutableDateTime9.addYears((int) (short) 10);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfWeek();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.era();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMinutes(271);
        org.joda.time.DateTime dateTime11 = dateTime7.minusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        org.joda.time.Instant instant10 = mutableDateTime9.toInstant();
        mutableDateTime9.setWeekOfWeekyear(9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long19 = fixedDateTimeZone17.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long26 = fixedDateTimeZone24.convertUTCToLocal((long) '#');
        long long29 = fixedDateTimeZone24.adjustOffset(0L, false);
        long long31 = fixedDateTimeZone17.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone24, (long) (short) 100);
        java.util.TimeZone timeZone32 = fixedDateTimeZone24.toTimeZone();
        long long34 = fixedDateTimeZone24.previousTransition(0L);
        java.lang.String str36 = fixedDateTimeZone24.getNameKey((-1595503694458L));
        boolean boolean37 = fixedDateTimeZone24.isFixed();
        int int39 = fixedDateTimeZone24.getStandardOffset(0L);
        org.joda.time.MutableDateTime mutableDateTime40 = mutableDateTime9.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str36.equals("2019-06-12T05:31:42.623-07:00"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(mutableDateTime40);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
        long long15 = offsetDateTimeField11.roundCeiling((-1595503694458L));
        long long17 = offsetDateTimeField11.roundHalfFloor((-33735053220031L));
        try {
            long long20 = offsetDateTimeField11.set(1560634979915L, "Wed");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Wed\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1595503680000L) + "'", long15 == (-1595503680000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-33735053220000L) + "'", long17 == (-33735053220000L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        boolean boolean17 = skipDateTimeField16.isLenient();
        int int19 = skipDateTimeField16.getMinimumValue((long) 2000);
        long long22 = skipDateTimeField16.set((-62042285222000L), 1602);
        int int24 = skipDateTimeField16.getMaximumValue((long) 3042);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-292269054) + "'", int19 == (-292269054));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-11581661222000L) + "'", long22 == (-11581661222000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292272992 + "'", int24 == 292272992);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        long long9 = durationField6.subtract(1560342705542L, (long) (byte) 100);
        long long12 = durationField6.subtract((-33735053221480L), 1969);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1595503694458L) + "'", long9 == (-1595503694458L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-95871600421480L) + "'", long12 == (-95871600421480L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMillis(292272992);
        boolean boolean5 = dateTime3.isAfter((-1555626601676148L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("minuteOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'minuteOfDay' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        dateTimeParserBucket10.setOffset((-292275054));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        dateTimeParserBucket10.saveField(dateTimeFieldType20, 2000);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass24 = gJChronology23.getClass();
        org.joda.time.DurationField durationField25 = gJChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField25);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType27, (-47326));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, 331);
        mutableDateTime6.setDate((long) 1969);
        mutableDateTime6.setSecondOfDay((int) (short) 10);
        mutableDateTime6.setMillisOfDay(100);
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime17 = instant16.toMutableDateTime();
        org.joda.time.Instant instant19 = instant16.plus((long) 366);
        org.joda.time.MutableDateTime mutableDateTime20 = instant16.toMutableDateTime();
        mutableDateTime6.setTime((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Instant instant23 = instant16.minus(18539999L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(instant23);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        long long13 = offsetDateTimeField11.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField11.getAsText((long) 3, locale15);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19, (int) 'a');
//        long long24 = skipUndoDateTimeField21.add((long) 0, (long) 7);
//        java.util.Locale locale25 = null;
//        int int26 = skipUndoDateTimeField21.getMaximumTextLength(locale25);
//        java.lang.String str28 = skipUndoDateTimeField21.getAsShortText((long) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.append(dateTimeFormatter33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder32.appendMillisOfSecond(52);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.withZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = dateTime42.toDateTimeISO();
//        org.joda.time.DateTime.Property property44 = dateTime43.weekOfWeekyear();
//        org.joda.time.DateTime dateTime45 = property44.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder32.appendShortText(dateTimeFieldType46);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, dateTimeFieldType46, (int) (short) -1, (int) (short) 10, 9);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = dateTime53.withZone(dateTimeZone54);
//        java.lang.String str56 = dateTime53.toString();
//        org.joda.time.DateTime dateTime58 = dateTime53.withYearOfEra(366);
//        org.joda.time.DateTime.Property property59 = dateTime58.minuteOfDay();
//        org.joda.time.DateTime dateTime60 = property59.getDateTime();
//        org.joda.time.LocalTime localTime61 = dateTime60.toLocalTime();
//        int int62 = skipUndoDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localTime61);
//        org.joda.time.Chronology chronology64 = null;
//        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField66 = julianChronology65.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField(chronology64, dateTimeField66, (int) 'a');
//        long long71 = skipUndoDateTimeField68.add((long) 0, (long) 7);
//        int int72 = skipUndoDateTimeField68.getMinimumValue();
//        long long75 = skipUndoDateTimeField68.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime(dateTimeZone76);
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.DateTime dateTime79 = dateTime77.withZone(dateTimeZone78);
//        org.joda.time.LocalTime localTime80 = dateTime79.toLocalTime();
//        boolean boolean81 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime80);
//        int[] intArray89 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray91 = skipUndoDateTimeField68.add((org.joda.time.ReadablePartial) localTime80, 4, intArray89, (int) ' ');
//        try {
//            int[] intArray93 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localTime61, 219, intArray89, 8662309);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8662309 for minuteOfDay must be in the range [1603,3042]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60481942500000L) + "'", long13 == (-60481942500000L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1603" + "'", str16.equals("1603"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 220924800000L + "'", long24 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1969" + "'", str28.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019-06-12T12:33:11.770Z" + "'", str56.equals("2019-06-12T12:33:11.770Z"));
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 292272992 + "'", int62 == 292272992);
//        org.junit.Assert.assertNotNull(julianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 220924800000L + "'", long71 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-292269054) + "'", int72 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62042284800000L) + "'", long75 == (-62042284800000L));
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(localTime80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertNotNull(intArray89);
//        org.junit.Assert.assertNotNull(intArray91);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks(1602);
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560342791789L + "'", long4 == 1560342791789L);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField44.getDurationField();
        try {
            long long48 = unsupportedDateTimeField44.set((-210866846447326L), 8662309);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(1969, 2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.addWrapField(18);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundFloor();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
//        boolean boolean10 = dateTime8.isEqual(1L);
//        int int11 = dateTime8.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T12:33:11.880Z" + "'", str4.equals("2019-06-12T12:33:11.880Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(331);
        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra((int) '4');
        java.lang.Object obj10 = null;
        boolean boolean11 = dateTime9.equals(obj10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1000, (java.lang.Number) (-11581661222000L), (java.lang.Number) 2L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        int int8 = cachedDateTimeZone5.getOffset((-60481942504213L));
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone5.getUncachedZone();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39, (int) 'a');
        long long44 = skipUndoDateTimeField41.add((long) 0, (long) 7);
        java.util.Locale locale45 = null;
        int int46 = skipUndoDateTimeField41.getMaximumTextLength(locale45);
        java.lang.String str48 = skipUndoDateTimeField41.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.append(dateTimeFormatter53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.withZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTimeISO();
        org.joda.time.DateTime.Property property64 = dateTime63.weekOfWeekyear();
        org.joda.time.DateTime dateTime65 = property64.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder52.appendShortText(dateTimeFieldType66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType66, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology72.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = julianChronology74.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology72, dateTimeField75);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology72.millisOfDay();
        org.joda.time.DurationField durationField78 = julianChronology72.weekyears();
        org.joda.time.DurationField durationField79 = julianChronology72.days();
        org.joda.time.DurationField durationField80 = julianChronology72.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField81 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType66);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 2563, (int) (short) 0, 3042);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField31, dateTimeFieldType66);
        java.lang.String str88 = remainderDateTimeField31.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 220924800000L + "'", long44 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "weekOfWeekyear" + "'", str88.equals("weekOfWeekyear"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "11:59:07 PM -07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfHour(1439, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        int int8 = mutableDateTime7.getMinuteOfHour();
        try {
            mutableDateTime7.setHourOfDay(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField11.getWrappedField();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField11.getAsText(271, locale16);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.withZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property27 = dateTime24.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = property27.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 1603);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField30.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField30.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField33 = offsetDateTimeField30.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.withZone(dateTimeZone37);
//        java.lang.String str39 = dateTime36.toString();
//        org.joda.time.DateTime dateTime41 = dateTime36.withYearOfEra(366);
//        org.joda.time.DateTime.Property property42 = dateTime41.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField43 = property42.getField();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime45.withZone(dateTimeZone46);
//        org.joda.time.DateTime dateTime49 = dateTime47.plusHours((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime47.toDateTime(dateTimeZone50);
//        org.joda.time.DateTime dateTime53 = dateTime51.plusDays((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology56, locale57, (java.lang.Integer) 0, 0);
//        dateTimeParserBucket60.setOffset((java.lang.Integer) 366);
//        long long65 = dateTimeParserBucket60.computeMillis(false, "11:59:08 PM -07:52:58");
//        java.util.Locale locale66 = dateTimeParserBucket60.getLocale();
//        java.util.Calendar calendar67 = dateTime53.toCalendar(locale66);
//        int int68 = property42.getMaximumShortTextLength(locale66);
//        java.lang.String str69 = offsetDateTimeField30.getAsText((int) ' ', locale66);
//        java.lang.String str70 = offsetDateTimeField11.getAsShortText(0, locale66);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "271" + "'", str17.equals("271"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019-06-12T12:33:12.303Z" + "'", str39.equals("2019-06-12T12:33:12.303Z"));
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-357L) + "'", long65 == (-357L));
//        org.junit.Assert.assertNotNull(locale66);
//        org.junit.Assert.assertNotNull(calendar67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "32" + "'", str69.equals("32"));
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "0" + "'", str70.equals("0"));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = cachedDateTimeZone5.isFixed();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(960);
        org.joda.time.DateTime.Property property11 = dateTime5.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) (byte) -1);
        mutableDateTime9.addDays(100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear(2000, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMonthOfYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendLiteral("year");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTimeZoneShortName(strMap18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder8.appendMillisOfSecond(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(strMap18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass9 = gJChronology8.getClass();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(1969, 0, (-292275054), 8662309, (-292275054), 2000, 3, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8662309 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
//        int int8 = mutableDateTime7.getRoundingMode();
//        java.lang.String str9 = mutableDateTime7.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-05-30T12:33:12.915Z" + "'", str9.equals("2019-05-30T12:33:12.915Z"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getLeapDurationField();
        int int14 = offsetDateTimeField11.get((long) (short) 1);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property24 = dateTime21.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1603);
        long long29 = offsetDateTimeField27.roundHalfCeiling((-60481942504213L));
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField(chronology30, dateTimeField32, (int) 'a');
        long long37 = skipUndoDateTimeField34.add((long) 0, (long) 7);
        int int39 = skipUndoDateTimeField34.get((long) 366);
        int int40 = skipUndoDateTimeField34.getMinimumValue();
        java.lang.String str41 = skipUndoDateTimeField34.getName();
        java.lang.String str42 = skipUndoDateTimeField34.toString();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.withZone(dateTimeZone45);
        org.joda.time.LocalTime localTime47 = dateTime46.toLocalTime();
        boolean boolean48 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime47);
        boolean boolean49 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime47);
        int[] intArray50 = null;
        int int51 = skipUndoDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localTime47, intArray50);
        int[] intArray54 = new int[] { '#' };
        int[] intArray56 = offsetDateTimeField27.addWrapPartial((org.joda.time.ReadablePartial) localTime47, 100, intArray54, 0);
        int int57 = offsetDateTimeField11.getMinimumValue(readablePartial15, intArray54);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1603 + "'", int14 == 1603);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60481942500000L) + "'", long29 == (-60481942500000L));
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 220924800000L + "'", long37 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292269054) + "'", int40 == (-292269054));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "year" + "'", str41.equals("year"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTimeField[year]" + "'", str42.equals("DateTimeField[year]"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292272992 + "'", int51 == 292272992);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1603 + "'", int57 == 1603);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
        try {
            mutableDateTime2.setDateTime((int) (short) -1, 0, 11, (int) (byte) 100, 1000, 1602, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            long long2 = dateTimeFormatter0.parseMillis("2019-06-12T12:33:11.014Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T12:33:11.014Z\" is malformed at \".014Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = cachedDateTimeZone5.getOffset((long) 7);
        long long9 = cachedDateTimeZone5.nextTransition((-1595503680000L));
        long long11 = cachedDateTimeZone5.previousTransition((long) 18);
        long long14 = cachedDateTimeZone5.adjustOffset(3120685421025L, true);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        boolean boolean16 = cachedDateTimeZone5.isFixed();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1595503680000L) + "'", long9 == (-1595503680000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 18L + "'", long11 == 18L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3120685421025L + "'", long14 == 3120685421025L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology10);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology10);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology10, locale17);
        dateTimeParserBucket18.setOffset((-292275054));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        dateTimeParserBucket18.saveField(dateTimeFieldType28, 2000);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType28, 52, 1969, 1023);
        boolean boolean35 = offsetDateTimeField34.isSupported();
        java.lang.String str36 = offsetDateTimeField34.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str36.equals("DateTimeField[weekOfWeekyear]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:42.993-07:00");
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.year();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.set((int) '4');
        boolean boolean11 = mutableDateTime9.isEqual(0L);
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime1.setTime((long) 23);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        long long10 = skipUndoDateTimeField4.getDifferenceAsLong((long) (short) 0, (long) (-292269054));
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology11, dateTimeField14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.withZone(dateTimeZone18);
        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
        boolean boolean21 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime20);
        int[] intArray23 = null;
        int[] intArray25 = skipDateTimeField15.addWrapPartial((org.joda.time.ReadablePartial) localTime20, 1603, intArray23, 0);
        int int26 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime20);
        long long28 = skipUndoDateTimeField4.roundHalfCeiling((long) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292269054) + "'", int26 == (-292269054));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1123200000L + "'", long28 == 1123200000L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        try {
            long long47 = unsupportedDateTimeField44.roundHalfEven(387L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long15 = fixedDateTimeZone13.convertUTCToLocal((long) '#');
//        long long19 = fixedDateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) 1);
//        org.joda.time.DateTime dateTime20 = dateTime3.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusDays((int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.yearOfCentury();
//        java.lang.String str25 = gregorianChronology23.toString();
//        org.joda.time.DateTime dateTime26 = dateTime22.withChronology((org.joda.time.Chronology) gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560342793355L + "'", long4 == 1560342793355L);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[UTC]" + "'", str25.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField4.getAsText(0L, locale8);
        java.lang.String str11 = skipDateTimeField4.getAsText((long) 271);
        java.lang.String str13 = skipDateTimeField4.getAsText(49294L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Thursday" + "'", str9.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Thursday" + "'", str11.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thursday" + "'", str13.equals("Thursday"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        java.lang.String str13 = offsetDateTimeField11.getAsShortText(1560342704861L);
        int int16 = offsetDateTimeField11.getDifference((long) 1969, (-1L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.append(dateTimeFormatter26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder25.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTimeISO();
        org.joda.time.DateTime.Property property37 = dateTime36.weekOfWeekyear();
        org.joda.time.DateTime dateTime38 = property37.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.append(dateTimeFormatter45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder44.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder44.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = dateTime52.withZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = dateTime54.toDateTimeISO();
        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = property56.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property56.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder44.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType58, 219, (int) (short) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField65 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType58, 4);
        try {
            long long68 = dividedDateTimeField65.add(1560342746997L, (-158256403020000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -633025612080000 * 60000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2354" + "'", str13.equals("2354"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addHours((int) (byte) 100);
        mutableDateTime1.setMillis((long) (byte) 0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        java.lang.String str46 = unsupportedDateTimeField44.getName();
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = julianChronology50.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = julianChronology52.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology50, dateTimeField53);
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology50);
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology50);
        java.util.Locale locale57 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology50, locale57);
        java.util.Locale locale59 = dateTimeParserBucket58.getLocale();
        try {
            java.lang.String str60 = unsupportedDateTimeField44.getAsShortText(0L, locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "weekOfWeekyear" + "'", str46.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(locale59);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1123200000L, (long) (-47326));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53156563200000L) + "'", long2 == (-53156563200000L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        int int20 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(9, 366);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology7.millisOfDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16, (int) 'a');
        long long21 = skipUndoDateTimeField18.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField18, 331);
        org.joda.time.DurationField durationField24 = julianChronology7.millis();
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 0, (org.joda.time.Chronology) julianChronology7, locale25);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass29 = gJChronology28.getClass();
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology28.getZone();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone30);
        dateTimeParserBucket26.setZone(dateTimeZone30);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass34 = gJChronology33.getClass();
        org.joda.time.DurationField durationField35 = gJChronology33.hours();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.dayOfWeek();
        dateTimeParserBucket26.saveField(dateTimeField36, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = dateTime42.toDateTimeISO();
        org.joda.time.DateTime.Property property44 = dateTime43.weekOfWeekyear();
        org.joda.time.DateTime dateTime45 = property44.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = dateTime49.withZone(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = dateTime51.toDateTimeISO();
        org.joda.time.DateTime.Property property53 = dateTime52.weekOfWeekyear();
        org.joda.time.DateTime dateTime55 = property53.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = dateTime57.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = dateTime59.toDateTime(dateTimeZone62);
        org.joda.time.DateTime dateTime65 = dateTime63.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone67);
        java.util.Locale locale69 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket72 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology68, locale69, (java.lang.Integer) 0, 0);
        dateTimeParserBucket72.setOffset((java.lang.Integer) 366);
        long long77 = dateTimeParserBucket72.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale78 = dateTimeParserBucket72.getLocale();
        java.util.Calendar calendar79 = dateTime65.toCalendar(locale78);
        int int80 = property53.getMaximumShortTextLength(locale78);
        dateTimeParserBucket26.saveField(dateTimeFieldType46, "DateTimeField[year]", locale78);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType46, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 220924800000L + "'", long21 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(iSOChronology68);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-357L) + "'", long77 == (-357L));
        org.junit.Assert.assertNotNull(locale78);
        org.junit.Assert.assertNotNull(calendar79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2 + "'", int80 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.withZone(dateTimeZone18);
//        java.lang.String str20 = dateTime17.toString();
//        org.joda.time.DateTime dateTime22 = dateTime17.withYearOfEra(366);
//        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.plusHours((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusDays((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        java.util.Locale locale38 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology37, locale38, (java.lang.Integer) 0, 0);
//        dateTimeParserBucket41.setOffset((java.lang.Integer) 366);
//        long long46 = dateTimeParserBucket41.computeMillis(false, "11:59:08 PM -07:52:58");
//        java.util.Locale locale47 = dateTimeParserBucket41.getLocale();
//        java.util.Calendar calendar48 = dateTime34.toCalendar(locale47);
//        int int49 = property23.getMaximumShortTextLength(locale47);
//        java.lang.String str50 = offsetDateTimeField11.getAsText((int) ' ', locale47);
//        long long52 = offsetDateTimeField11.roundHalfEven(1560611702361L);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-06-12T12:33:14.050Z" + "'", str20.equals("2019-06-12T12:33:14.050Z"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-357L) + "'", long46 == (-357L));
//        org.junit.Assert.assertNotNull(locale47);
//        org.junit.Assert.assertNotNull(calendar48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "32" + "'", str50.equals("32"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560611700000L + "'", long52 == 1560611700000L);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        java.lang.String str9 = property8.getAsText();
//        java.lang.String str10 = property8.getAsString();
//        org.joda.time.DateTime dateTime12 = property8.setCopy("271");
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime12.withHourOfDay(914);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 914 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "693" + "'", str9.equals("693"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "693" + "'", str10.equals("693"));
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        java.lang.String str46 = unsupportedDateTimeField44.getName();
        java.lang.String str47 = unsupportedDateTimeField44.toString();
        java.lang.String str48 = unsupportedDateTimeField44.getName();
        try {
            long long51 = unsupportedDateTimeField44.add((-210866846400000L), 1781267517589L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: 1781267517589");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "weekOfWeekyear" + "'", str46.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "weekOfWeekyear" + "'", str48.equals("weekOfWeekyear"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addHours((int) (byte) 100);
        mutableDateTime1.setSecondOfDay(1023);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        mutableDateTime1.setWeekyear((int) (short) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.hourOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.clockhourOfHalfday();
        try {
            long long14 = buddhistChronology5.getDateTimeMillis((int) (short) 100, (int) (byte) 10, (int) '#', (int) '4', 292272992, 2, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone14);
        org.joda.time.DurationField durationField17 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        java.lang.String str13 = offsetDateTimeField11.getAsText(220924800000L);
        java.lang.String str15 = offsetDateTimeField11.getAsShortText((long) 'a');
        int int18 = offsetDateTimeField11.getDifference(0L, (long) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1603" + "'", str13.equals("1603"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1603" + "'", str15.equals("1603"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, 331);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.weekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendTwoDigitYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendFractionOfMinute((int) '4', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.append(dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder24.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.withZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTimeISO();
        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
        org.joda.time.DateTime dateTime37 = property36.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.append(dateTimeFormatter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder43.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder43.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.withZone(dateTimeZone52);
        org.joda.time.DateTime dateTime54 = dateTime53.toDateTimeISO();
        org.joda.time.DateTime.Property property55 = dateTime54.weekOfWeekyear();
        org.joda.time.DateTime dateTime56 = property55.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder43.appendShortText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder20.appendDecimal(dateTimeFieldType57, 0, (int) ' ');
        org.joda.time.MutableDateTime.Property property63 = mutableDateTime6.property(dateTimeFieldType57);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "DateTimeField[dayOfWeek]");
        java.lang.Number number66 = illegalFieldValueException65.getUpperBound();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNull(number66);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
//        java.lang.String str2 = jodaTimePermission1.getName();
//        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
//        java.lang.String str5 = jodaTimePermission4.getName();
//        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
//        java.security.PermissionCollection permissionCollection7 = jodaTimePermission4.newPermissionCollection();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
//        java.lang.String str12 = dateTime9.toString();
//        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        boolean boolean15 = jodaTimePermission4.equals((java.lang.Object) property14);
//        org.joda.time.DurationField durationField16 = property14.getRangeDurationField();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str2.equals("2019-06-12T05:31:45.337-07:00"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str5.equals("2019-06-12T05:31:45.337-07:00"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(permissionCollection7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-12T12:33:14.562Z" + "'", str12.equals("2019-06-12T12:33:14.562Z"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(durationField16);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfWeek();
        org.joda.time.Interval interval12 = property11.toInterval();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(interval12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "1969", (-292275054), (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        org.joda.time.DateTime dateTime24 = property23.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField17, dateTimeFieldType25);
        java.lang.String str28 = zeroIsMaxDateTimeField26.getAsText(1560342760194L);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime37 = dateTime35.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property38 = dateTime35.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1603);
        org.joda.time.DateTimeField dateTimeField42 = offsetDateTimeField41.getWrappedField();
        org.joda.time.DateTimeField dateTimeField43 = offsetDateTimeField41.getWrappedField();
        org.joda.time.DateTimeField dateTimeField44 = offsetDateTimeField41.getWrappedField();
        long long46 = offsetDateTimeField41.roundHalfEven(0L);
        int int48 = offsetDateTimeField41.getLeapAmount((long) 271);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.withZone(dateTimeZone52);
        org.joda.time.DateTime dateTime54 = dateTime53.toDateTimeISO();
        org.joda.time.DateTime.Property property55 = dateTime54.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = property55.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = dateTime59.withZone(dateTimeZone60);
        org.joda.time.DateTime dateTime63 = dateTime61.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = dateTime61.toDateTime(dateTimeZone64);
        org.joda.time.DateTime dateTime67 = dateTime65.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone69);
        java.util.Locale locale71 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology70, locale71, (java.lang.Integer) 0, 0);
        dateTimeParserBucket74.setOffset((java.lang.Integer) 366);
        long long79 = dateTimeParserBucket74.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale80 = dateTimeParserBucket74.getLocale();
        java.util.Calendar calendar81 = dateTime67.toCalendar(locale80);
        int int82 = property55.getMaximumShortTextLength(locale80);
        java.lang.String str83 = offsetDateTimeField41.getAsShortText(8639999999L, locale80);
        java.lang.String str84 = zeroIsMaxDateTimeField26.getAsShortText((-1555626601680000L), locale80);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "140" + "'", str28.equals("140"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-357L) + "'", long79 == (-357L));
        org.junit.Assert.assertNotNull(locale80);
        org.junit.Assert.assertNotNull(calendar81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2 + "'", int82 == 2);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "3042" + "'", str83.equals("3042"));
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "946" + "'", str84.equals("946"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (short) 100, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitYear(9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        boolean boolean5 = dateTime3.isAfter((long) (short) 1);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
//        int int7 = property6.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        java.lang.String str6 = property5.getAsShortText();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        mutableDateTime7.setMillisOfDay((int) 'a');
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) mutableDateTime7);
        boolean boolean12 = gregorianChronology0.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        mutableDateTime21.setMillisOfDay((int) 'a');
        boolean boolean24 = gregorianChronology14.equals((java.lang.Object) mutableDateTime21);
        boolean boolean26 = gregorianChronology14.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology14.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField28, 1439);
        try {
            long long36 = gregorianChronology0.getDateTimeMillis((long) 1000, 51, 219, 1275, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39, (int) 'a');
        long long44 = skipUndoDateTimeField41.add((long) 0, (long) 7);
        java.util.Locale locale45 = null;
        int int46 = skipUndoDateTimeField41.getMaximumTextLength(locale45);
        java.lang.String str48 = skipUndoDateTimeField41.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.append(dateTimeFormatter53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.withZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTimeISO();
        org.joda.time.DateTime.Property property64 = dateTime63.weekOfWeekyear();
        org.joda.time.DateTime dateTime65 = property64.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder52.appendShortText(dateTimeFieldType66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType66, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology72.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = julianChronology74.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology72, dateTimeField75);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology72.millisOfDay();
        org.joda.time.DurationField durationField78 = julianChronology72.weekyears();
        org.joda.time.DurationField durationField79 = julianChronology72.days();
        org.joda.time.DurationField durationField80 = julianChronology72.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField81 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType66);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 2563, (int) (short) 0, 3042);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField31, dateTimeFieldType66);
        long long90 = dividedDateTimeField87.addWrapField(1560367904861L, 219);
        org.joda.time.DurationField durationField91 = dividedDateTimeField87.getDurationField();
        long long94 = dividedDateTimeField87.set((long) (byte) 100, 0);
        int int95 = dividedDateTimeField87.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 220924800000L + "'", long44 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560367724861L + "'", long90 == 1560367724861L);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 100L + "'", long94 == 100L);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        long long33 = remainderDateTimeField31.roundHalfCeiling((long) 960);
        int int34 = remainderDateTimeField31.getMinimumValue();
        long long37 = remainderDateTimeField31.addWrapField((-210866846447326L), 7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-210866846567326L) + "'", long37 == (-210866846567326L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime7.addMillis((-1));
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.hourOfDay();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.year();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime18 = property17.roundHalfEven();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 4);
        int int21 = property17.getDifference((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfDay(1602);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology29, dateTimeField31, (int) 'a');
        long long36 = skipUndoDateTimeField33.add((long) 0, (long) 7);
        java.util.Locale locale37 = null;
        int int38 = skipUndoDateTimeField33.getMaximumTextLength(locale37);
        java.lang.String str40 = skipUndoDateTimeField33.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.append(dateTimeFormatter45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder44.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder44.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = dateTime52.withZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = dateTime54.toDateTimeISO();
        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = property56.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property56.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder44.appendShortText(dateTimeFieldType58);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType58, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology64 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField65 = julianChronology64.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = julianChronology66.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField68 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology64, dateTimeField67);
        org.joda.time.DateTimeField dateTimeField69 = julianChronology64.millisOfDay();
        org.joda.time.DurationField durationField70 = julianChronology64.weekyears();
        org.joda.time.DurationField durationField71 = julianChronology64.days();
        org.joda.time.DurationField durationField72 = julianChronology64.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType58, durationField72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder27.appendText(dateTimeFieldType58);
        org.joda.time.DateTime.Property property75 = dateTime20.property(dateTimeFieldType58);
        int int76 = mutableDateTime7.get(dateTimeFieldType58);
        boolean boolean77 = gJChronology0.equals((java.lang.Object) mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 220924800000L + "'", long36 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1969" + "'", str40.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(julianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 51 + "'", int76 == 51);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("692");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"692\" is malformed at \"2\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.millisOfDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, (int) 'a');
        long long15 = skipUndoDateTimeField12.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField12, 331);
        org.joda.time.DurationField durationField18 = julianChronology1.millis();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 0, (org.joda.time.Chronology) julianChronology1, locale19);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass23 = gJChronology22.getClass();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology22.getZone();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone24);
        dateTimeParserBucket20.setZone(dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass28 = gJChronology27.getClass();
        org.joda.time.DurationField durationField29 = gJChronology27.hours();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology27.dayOfWeek();
        dateTimeParserBucket20.saveField(dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.withZone(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime.Property property38 = dateTime37.weekOfWeekyear();
        org.joda.time.DateTime dateTime39 = property38.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = dateTime43.withZone(dateTimeZone44);
        org.joda.time.DateTime dateTime46 = dateTime45.toDateTimeISO();
        org.joda.time.DateTime.Property property47 = dateTime46.weekOfWeekyear();
        org.joda.time.DateTime dateTime49 = property47.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.withZone(dateTimeZone52);
        org.joda.time.DateTime dateTime55 = dateTime53.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = dateTime53.toDateTime(dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
        java.util.Locale locale63 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket66 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology62, locale63, (java.lang.Integer) 0, 0);
        dateTimeParserBucket66.setOffset((java.lang.Integer) 366);
        long long71 = dateTimeParserBucket66.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale72 = dateTimeParserBucket66.getLocale();
        java.util.Calendar calendar73 = dateTime59.toCalendar(locale72);
        int int74 = property47.getMaximumShortTextLength(locale72);
        dateTimeParserBucket20.saveField(dateTimeFieldType40, "DateTimeField[year]", locale72);
        org.joda.time.chrono.JulianChronology julianChronology76 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField77 = julianChronology76.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology78 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField79 = julianChronology78.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology76, dateTimeField79);
        org.joda.time.DateTimeField dateTimeField81 = julianChronology76.millisOfDay();
        org.joda.time.DurationField durationField82 = julianChronology76.weekyears();
        org.joda.time.DurationField durationField83 = julianChronology76.days();
        org.joda.time.DurationField durationField84 = julianChronology76.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField84);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220924800000L + "'", long15 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-357L) + "'", long71 == (-357L));
        org.junit.Assert.assertNotNull(locale72);
        org.junit.Assert.assertNotNull(calendar73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
        org.junit.Assert.assertNotNull(julianChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(julianChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(durationField83);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTimeISO();
        mutableDateTime10.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "1969", (-292275054), (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = zonedChronology16.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(7, locale6);
        long long10 = delegatedDateTimeField4.add((long) (-47326), (long) 336010791);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.hourOfDay();
        org.joda.time.DateTime dateTime18 = dateTime16.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime20 = dateTime16.plus((long) ' ');
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekyear(2);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int int24 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "7" + "'", str7.equals("7"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1209638847552674L + "'", long10 == 1209638847552674L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:47.634-07:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:31:47.634-07:00\" is malformed at \"19-06-12T05:31:47.634-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        long long11 = skipUndoDateTimeField4.set(3155760000000L, 4);
        long long13 = skipUndoDateTimeField4.roundHalfFloor((long) '#');
        long long15 = skipUndoDateTimeField4.roundHalfFloor((long) 366);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292269054) + "'", int8 == (-292269054));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62042284800000L) + "'", long11 == (-62042284800000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200000L + "'", long15 == 1123200000L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39, (int) 'a');
        long long44 = skipUndoDateTimeField41.add((long) 0, (long) 7);
        java.util.Locale locale45 = null;
        int int46 = skipUndoDateTimeField41.getMaximumTextLength(locale45);
        java.lang.String str48 = skipUndoDateTimeField41.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.append(dateTimeFormatter53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.withZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTimeISO();
        org.joda.time.DateTime.Property property64 = dateTime63.weekOfWeekyear();
        org.joda.time.DateTime dateTime65 = property64.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder52.appendShortText(dateTimeFieldType66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType66, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology72.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = julianChronology74.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology72, dateTimeField75);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology72.millisOfDay();
        org.joda.time.DurationField durationField78 = julianChronology72.weekyears();
        org.joda.time.DurationField durationField79 = julianChronology72.days();
        org.joda.time.DurationField durationField80 = julianChronology72.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField81 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType66);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 2563, (int) (short) 0, 3042);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField87 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType66);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 1275, 1603, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1275 for weekOfWeekyear must be in the range [1603,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 220924800000L + "'", long44 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
        org.joda.time.Instant instant8 = new org.joda.time.Instant((java.lang.Object) mutableDateTime6);
        org.joda.time.Instant instant10 = instant8.plus(268920001L);
        org.joda.time.Instant instant11 = instant8.toInstant();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39, (int) 'a');
        long long44 = skipUndoDateTimeField41.add((long) 0, (long) 7);
        java.util.Locale locale45 = null;
        int int46 = skipUndoDateTimeField41.getMaximumTextLength(locale45);
        java.lang.String str48 = skipUndoDateTimeField41.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.append(dateTimeFormatter53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.withZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTimeISO();
        org.joda.time.DateTime.Property property64 = dateTime63.weekOfWeekyear();
        org.joda.time.DateTime dateTime65 = property64.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder52.appendShortText(dateTimeFieldType66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType66, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology72.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = julianChronology74.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology72, dateTimeField75);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology72.millisOfDay();
        org.joda.time.DurationField durationField78 = julianChronology72.weekyears();
        org.joda.time.DurationField durationField79 = julianChronology72.days();
        org.joda.time.DurationField durationField80 = julianChronology72.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField81 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField80);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType66);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 2563, (int) (short) 0, 3042);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField31, dateTimeFieldType66);
        long long90 = dividedDateTimeField87.addWrapField(1560367904861L, 219);
        org.joda.time.DurationField durationField91 = dividedDateTimeField87.getDurationField();
        long long94 = dividedDateTimeField87.getDifferenceAsLong((long) ' ', 1560342704399L);
        int int96 = dividedDateTimeField87.get((-8668570L));
        int int97 = dividedDateTimeField87.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 220924800000L + "'", long44 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560367724861L + "'", long90 == 1560367724861L);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-8668570L) + "'", long94 == (-8668570L));
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 11 + "'", int96 == 11);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 19 + "'", int97 == 19);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.year();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfFloor();
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = mutableDateTime13.toCalendar(locale14);
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime13);
        java.lang.String str17 = jodaTimePermission1.toString();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.hourOfHalfday();
        org.joda.time.DurationField durationField21 = julianChronology18.days();
        jodaTimePermission1.checkGuard((java.lang.Object) durationField21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str2.equals("2019-06-12T05:31:45.337-07:00"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str5.equals("2019-06-12T05:31:45.337-07:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(calendar15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-12T05:31:45.337-07:00\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-12T05:31:45.337-07:00\")"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        java.lang.String str46 = unsupportedDateTimeField44.getName();
        java.lang.String str47 = unsupportedDateTimeField44.toString();
        java.lang.String str48 = unsupportedDateTimeField44.getName();
        try {
            long long50 = unsupportedDateTimeField44.roundHalfEven(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "weekOfWeekyear" + "'", str46.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "weekOfWeekyear" + "'", str48.equals("weekOfWeekyear"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) 'a', 1, 0, 753, 100, 0, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 753 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addHours((int) (byte) 100);
        mutableDateTime1.setSecondOfDay(1023);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfWeek();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = property6.set("-47326-02-26T03:39:21.668-07:52:58");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-47326-02-26T03:39:21.668-07:52:58\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gJChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, 331);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.weekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendTwoDigitYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendFractionOfMinute((int) '4', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.append(dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder24.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.withZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTimeISO();
        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
        org.joda.time.DateTime dateTime37 = property36.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.append(dateTimeFormatter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder43.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder43.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.withZone(dateTimeZone52);
        org.joda.time.DateTime dateTime54 = dateTime53.toDateTimeISO();
        org.joda.time.DateTime.Property property55 = dateTime54.weekOfWeekyear();
        org.joda.time.DateTime dateTime56 = property55.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder43.appendShortText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder20.appendDecimal(dateTimeFieldType57, 0, (int) ' ');
        org.joda.time.MutableDateTime.Property property63 = mutableDateTime6.property(dateTimeFieldType57);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "DateTimeField[dayOfWeek]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "-47326-02-26T03:39:06.002-07:52:58");
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(property63);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withFieldAdded(durationFieldType8, (-292269054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test095");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        java.lang.String str9 = property8.getAsText();
//        java.lang.String str10 = property8.getAsShortText();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
//        java.lang.String str23 = fixedDateTimeZone20.getShortName((long) 'a');
//        java.lang.String str25 = fixedDateTimeZone20.getNameKey((long) (byte) 100);
//        org.joda.time.Chronology chronology26 = iSOChronology15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.withZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
//        org.joda.time.DateTime.Property property32 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTime dateTime34 = property32.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.withZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime40 = dateTime38.plusHours((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime38.toDateTime(dateTimeZone41);
//        org.joda.time.DateTime dateTime44 = dateTime42.plusDays((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
//        java.util.Locale locale48 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology47, locale48, (java.lang.Integer) 0, 0);
//        dateTimeParserBucket51.setOffset((java.lang.Integer) 366);
//        long long56 = dateTimeParserBucket51.computeMillis(false, "11:59:08 PM -07:52:58");
//        java.util.Locale locale57 = dateTimeParserBucket51.getLocale();
//        java.util.Calendar calendar58 = dateTime44.toCalendar(locale57);
//        int int59 = property32.getMaximumShortTextLength(locale57);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket((long) (short) 100, chronology26, locale57, (java.lang.Integer) 1603, (int) '4');
//        try {
//            org.joda.time.DateTime dateTime63 = property8.setCopy("1603", locale57);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1603 for minuteOfDay must be in the range [0,1439]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "693" + "'", str9.equals("693"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "693" + "'", str10.equals("693"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str25.equals("2019-06-12T05:31:42.623-07:00"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-357L) + "'", long56 == (-357L));
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertNotNull(calendar58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) -1, 5, 3, 2019, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        mutableDateTime6.add(readablePeriod7, 331);
//        mutableDateTime6.setDate((long) 1969);
//        mutableDateTime6.setMillis((long) 2000);
//        org.joda.time.Chronology chronology14 = mutableDateTime6.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.withZone(dateTimeZone17);
//        int int19 = dateTime16.getMinuteOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime16.plusHours((int) '4');
//        java.util.Locale locale22 = null;
//        java.util.Calendar calendar23 = dateTime21.toCalendar(locale22);
//        mutableDateTime6.setMillis((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property25 = dateTime21.centuryOfEra();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 753 + "'", int19 == 753);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(calendar23);
//        org.junit.Assert.assertNotNull(property25);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property12 = dateTime9.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 1603);
//        org.joda.time.DateTimeField dateTimeField26 = offsetDateTimeField25.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField27 = offsetDateTimeField25.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField25.getWrappedField();
//        long long30 = offsetDateTimeField25.roundHalfEven(0L);
//        int int32 = offsetDateTimeField25.getLeapAmount((long) 271);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField35, (int) 'a');
//        long long40 = skipUndoDateTimeField37.add((long) 0, (long) 7);
//        long long43 = skipUndoDateTimeField37.getDifferenceAsLong((long) (short) 0, (long) (-292269054));
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = julianChronology46.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology44, dateTimeField47);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime50.withZone(dateTimeZone51);
//        org.joda.time.LocalTime localTime53 = dateTime52.toLocalTime();
//        boolean boolean54 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime53);
//        int[] intArray56 = null;
//        int[] intArray58 = skipDateTimeField48.addWrapPartial((org.joda.time.ReadablePartial) localTime53, 1603, intArray56, 0);
//        int int59 = skipUndoDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) localTime53);
//        org.joda.time.Chronology chronology61 = null;
//        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField63 = julianChronology62.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField(chronology61, dateTimeField63, (int) 'a');
//        long long68 = skipUndoDateTimeField65.add((long) 0, (long) 7);
//        long long71 = skipUndoDateTimeField65.add(0L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone72);
//        org.joda.time.DateTimeZone dateTimeZone74 = null;
//        org.joda.time.DateTime dateTime75 = dateTime73.withZone(dateTimeZone74);
//        int int76 = dateTime73.getMinuteOfDay();
//        org.joda.time.DateTime dateTime78 = dateTime73.plusHours((int) '4');
//        org.joda.time.DateTime dateTime81 = dateTime78.withDurationAdded(10L, (-1));
//        org.joda.time.TimeOfDay timeOfDay82 = dateTime81.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone85 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone85);
//        java.util.Locale locale87 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket90 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology86, locale87, (java.lang.Integer) 0, 0);
//        dateTimeParserBucket90.setOffset((java.lang.Integer) 366);
//        long long95 = dateTimeParserBucket90.computeMillis(false, "11:59:08 PM -07:52:58");
//        java.util.Locale locale96 = dateTimeParserBucket90.getLocale();
//        java.lang.String str97 = skipUndoDateTimeField65.getAsText((org.joda.time.ReadablePartial) timeOfDay82, 1603, locale96);
//        java.lang.String str98 = offsetDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) localTime53, 914, locale96);
//        java.lang.String str99 = dateTime9.toString("0", locale96);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 753 + "'", int4 == 753);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 220924800000L + "'", long40 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(julianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localTime53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-292269054) + "'", int59 == (-292269054));
//        org.junit.Assert.assertNotNull(julianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 220924800000L + "'", long68 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 3155760000000L + "'", long71 == 3155760000000L);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 753 + "'", int76 == 753);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertNotNull(timeOfDay82);
//        org.junit.Assert.assertNotNull(iSOChronology86);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-357L) + "'", long95 == (-357L));
//        org.junit.Assert.assertNotNull(locale96);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "1603" + "'", str97.equals("1603"));
//        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "914" + "'", str98.equals("914"));
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "0" + "'", str99.equals("0"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DurationField durationField17 = skipDateTimeField16.getDurationField();
        int int18 = skipDateTimeField16.getMaximumValue();
        long long21 = skipDateTimeField16.addWrapField(1560611700000L, (-292275054));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292272992 + "'", int18 == 292272992);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223246418973300000L + "'", long21 == 9223246418973300000L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("-47326-02-26T03:39:11.107-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) ' ');
        org.joda.time.DateTime dateTime9 = property6.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass11 = gJChronology10.getClass();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType28);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType28, 3);
        long long33 = remainderDateTimeField31.roundHalfCeiling((long) 960);
        int int34 = remainderDateTimeField31.getMinimumValue();
        long long36 = remainderDateTimeField31.roundHalfCeiling(100L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear(2000, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMonthOfYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendEraText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        dateTimeParserBucket10.setOffset((-292275054));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        dateTimeParserBucket10.saveField(dateTimeFieldType20, 2000);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology25, dateTimeField28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology25);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology25);
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology25, locale32);
        dateTimeParserBucket33.setOffset((-292275054));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.withZone(dateTimeZone38);
        org.joda.time.DateTime dateTime40 = dateTime39.toDateTimeISO();
        org.joda.time.DateTime.Property property41 = dateTime40.weekOfWeekyear();
        org.joda.time.DateTime dateTime42 = property41.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property41.getFieldType();
        dateTimeParserBucket33.saveField(dateTimeFieldType43, 2000);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass47 = gJChronology46.getClass();
        org.joda.time.DurationField durationField48 = gJChronology46.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField49 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField48);
        boolean boolean50 = dateTimeParserBucket10.restoreState((java.lang.Object) unsupportedDateTimeField49);
        long long53 = unsupportedDateTimeField49.add(100L, (-53399996L));
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-192239985599900L) + "'", long53 == (-192239985599900L));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        int int9 = dateTime8.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T12:33:19.719Z" + "'", str4.equals("2019-06-12T12:33:19.719Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 2245333152294979L, (java.lang.Number) 52, (java.lang.Number) 51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
        java.lang.String str11 = mutableDateTime10.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969-12-18T23:59:59.999Z" + "'", str11.equals("1969-12-18T23:59:59.999Z"));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long7 = fixedDateTimeZone5.convertUTCToLocal((long) '#');
//        int int9 = fixedDateTimeZone5.getOffsetFromLocal((long) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField15);
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology12);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        mutableDateTime17.add(readablePeriod18, 331);
//        mutableDateTime17.setDate((long) 1969);
//        mutableDateTime17.setMillis((long) 2000);
//        org.joda.time.Chronology chronology25 = mutableDateTime17.getChronology();
//        int int28 = dateTimeFormatter10.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime17, "Wednesday", 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter10.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.withZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime33.toDateTimeISO();
//        org.joda.time.DateTime dateTime36 = dateTime34.minusWeeks(331);
//        org.joda.time.DateTime dateTime37 = dateTime36.withTimeAtStartOfDay();
//        java.lang.String str38 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Feb 6, 2013 12:00:00 AM" + "'", str38.equals("Feb 6, 2013 12:00:00 AM"));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "1969", (-292275054), (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        org.joda.time.DateTime dateTime24 = property23.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField17, dateTimeFieldType25);
        long long29 = zeroIsMaxDateTimeField26.getDifferenceAsLong((long) 4, (-62042284800000L));
        long long31 = zeroIsMaxDateTimeField26.roundHalfFloor(1602L);
        int int34 = zeroIsMaxDateTimeField26.getDifference((long) 33097, (long) 914);
        org.joda.time.DurationField durationField35 = zeroIsMaxDateTimeField26.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone42);
        mutableDateTime43.setMillisOfDay((int) 'a');
        boolean boolean46 = gregorianChronology36.equals((java.lang.Object) mutableDateTime43);
        boolean boolean48 = gregorianChronology36.equals((java.lang.Object) (-1.0f));
        java.lang.String str49 = gregorianChronology36.toString();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.withZone(dateTimeZone52);
        org.joda.time.LocalTime localTime54 = dateTime53.toLocalTime();
        boolean boolean55 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime54);
        boolean boolean56 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime54);
        int[] intArray58 = gregorianChronology36.get((org.joda.time.ReadablePartial) localTime54, (long) 9);
        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime54);
        int int60 = zeroIsMaxDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime54);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 62042284800004L + "'", long29 == 62042284800004L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1602L + "'", long31 == 1602L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 32183 + "'", int34 == 32183);
        org.junit.Assert.assertNull(durationField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "GregorianChronology[UTC]" + "'", str49.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localTime54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(219);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = cachedDateTimeZone5.getOffset((long) 7);
        long long9 = cachedDateTimeZone5.nextTransition((-1595503680000L));
        long long11 = cachedDateTimeZone5.previousTransition((long) 18);
        java.lang.String str13 = cachedDateTimeZone5.getNameKey((-11581661222000L));
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone5.getUncachedZone();
        long long16 = cachedDateTimeZone5.nextTransition(0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1595503680000L) + "'", long9 == (-1595503680000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 18L + "'", long11 == 18L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str13.equals("2019-06-12T05:31:42.623-07:00"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        int int10 = property9.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField15);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology12.millisOfDay();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField21, (int) 'a');
        long long26 = skipUndoDateTimeField23.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, (org.joda.time.DateTimeField) skipUndoDateTimeField23, 331);
        boolean boolean29 = skipDateTimeField28.isLenient();
        int int31 = skipDateTimeField28.getMinimumValue((long) 2000);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.withZone(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime.Property property38 = dateTime37.weekOfWeekyear();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.withZone(dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = dateTime44.toDateTime(dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.util.Locale locale54 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology53, locale54, (java.lang.Integer) 0, 0);
        dateTimeParserBucket57.setOffset((java.lang.Integer) 366);
        long long62 = dateTimeParserBucket57.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale63 = dateTimeParserBucket57.getLocale();
        java.util.Calendar calendar64 = dateTime50.toCalendar(locale63);
        int int65 = property38.getMaximumShortTextLength(locale63);
        java.lang.String str66 = skipDateTimeField28.getAsText(271, locale63);
        java.lang.String str67 = property9.getAsText(locale63);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 220924800000L + "'", long26 == 220924800000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-292269054) + "'", int31 == (-292269054));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-357L) + "'", long62 == (-357L));
        org.junit.Assert.assertNotNull(locale63);
        org.junit.Assert.assertNotNull(calendar64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "271" + "'", str66.equals("271"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "23" + "'", str67.equals("23"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        int int6 = dateTimeZone3.getOffsetFromLocal(1560342760194L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        long long13 = offsetDateTimeField11.roundHalfCeiling((-60481942504213L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField11.getAsText((long) 3, locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField11.getLeapDurationField();
        int int19 = offsetDateTimeField11.getLeapAmount(2L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60481942500000L) + "'", long13 == (-60481942500000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1603" + "'", str16.equals("1603"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("year");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfDay(915);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (short) 100, (int) (byte) 0);
        long long6 = durationField0.subtract(3155760000000L, 0L);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3155760000000L + "'", long6 == 3155760000000L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("DateTimeField[dayOfWeek]");
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        org.joda.time.Instant instant10 = mutableDateTime9.toInstant();
        mutableDateTime9.setWeekOfWeekyear(9);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        java.lang.String str13 = offsetDateTimeField11.getAsShortText(1560342704861L);
        int int16 = offsetDateTimeField11.getDifference((long) 1969, (-1L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.append(dateTimeFormatter26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder25.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTimeISO();
        org.joda.time.DateTime.Property property37 = dateTime36.weekOfWeekyear();
        org.joda.time.DateTime dateTime38 = property37.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.append(dateTimeFormatter45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder44.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder44.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = dateTime52.withZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = dateTime54.toDateTimeISO();
        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = property56.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property56.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder44.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType58, 219, (int) (short) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField65 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType58, 4);
        int int67 = dividedDateTimeField65.get((long) 1275);
        org.joda.time.DurationField durationField68 = dividedDateTimeField65.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2354" + "'", str13.equals("2354"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 400 + "'", int67 == 400);
        org.junit.Assert.assertNotNull(durationField68);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
//        boolean boolean10 = dateTime8.isEqual(1L);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology11, dateTimeField14);
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology11.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.DateTime dateTime19 = dateTime8.withChronology((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendDayOfWeek((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendFractionOfSecond(9, 366);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendFractionOfMinute((int) (short) 0, 7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean34 = dateTimeFormatterBuilder33.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendHourOfHalfday((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendLiteral("year");
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendTimeZoneShortName(strMap39);
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendTimeZoneName(strMap39);
//        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology45.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology45, dateTimeField48);
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology45);
//        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology45);
//        java.util.Locale locale52 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology45, locale52);
//        dateTimeParserBucket53.setOffset((-292275054));
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime57.withZone(dateTimeZone58);
//        org.joda.time.DateTime dateTime60 = dateTime59.toDateTimeISO();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        org.joda.time.DateTime dateTime62 = property61.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property61.getFieldType();
//        dateTimeParserBucket53.saveField(dateTimeFieldType63, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder32.appendFixedDecimal(dateTimeFieldType63, 45104);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder25.appendFixedDecimal(dateTimeFieldType63, 960);
//        try {
//            org.joda.time.DateTime dateTime71 = dateTime8.withField(dateTimeFieldType63, 960);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T12:33:20.825Z" + "'", str4.equals("2019-06-12T12:33:20.825Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(strMap39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(julianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(julianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 62042284800004L, (java.lang.Number) (-30412800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(387, 45104, 101, 12, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45104 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "1969", (-292275054), (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        org.joda.time.DateTime dateTime24 = property23.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField17, dateTimeFieldType25);
        long long29 = zeroIsMaxDateTimeField26.getDifferenceAsLong((long) 4, (-62042284800000L));
        long long31 = zeroIsMaxDateTimeField26.roundHalfCeiling((long) 1275);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, 365, 0, 960);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 62042284800004L + "'", long29 == 62042284800004L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1275L + "'", long31 == 1275L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = property15.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.append(dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder22.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = dateTime32.toDateTimeISO();
        org.joda.time.DateTime.Property property34 = dateTime33.weekOfWeekyear();
        org.joda.time.DateTime dateTime35 = property34.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property34.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder22.appendShortText(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendMillisOfSecond(752);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(331);
        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        long long19 = skipDateTimeField16.getDifferenceAsLong(1L, (long) 0);
        int int20 = skipDateTimeField16.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292269055) + "'", int20 == (-292269055));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        boolean boolean17 = skipDateTimeField16.isLenient();
        org.joda.time.DurationField durationField18 = skipDateTimeField16.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(durationField18);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        int int6 = dateTime5.getEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        int int12 = fixedDateTimeZone4.getOffset(1560342704861L);
        int int14 = fixedDateTimeZone4.getOffset(1560342705542L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 101");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField11.getWrappedField();
        long long16 = offsetDateTimeField11.roundHalfEven(0L);
        int int18 = offsetDateTimeField11.getLeapAmount((long) 271);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField23, (int) 'a');
        long long28 = skipUndoDateTimeField25.add((long) 0, (long) 7);
        long long31 = skipUndoDateTimeField25.add(0L, (long) 100);
        int int32 = skipUndoDateTimeField25.getMinimumValue();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25);
        boolean boolean35 = delegatedDateTimeField33.isLeap((long) (short) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone42 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        int int44 = cachedDateTimeZone42.getOffset((-25462913025600000L));
        org.joda.time.DateTimeZone dateTimeZone45 = cachedDateTimeZone42.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime48.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = dateTime50.toDateTimeISO();
        org.joda.time.DateTime.Property property52 = dateTime51.weekOfWeekyear();
        org.joda.time.DateTime dateTime54 = property52.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.DateTime dateTime58 = dateTime56.withZone(dateTimeZone57);
        org.joda.time.DateTime dateTime60 = dateTime58.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime58.toDateTime(dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime62.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        java.util.Locale locale68 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology67, locale68, (java.lang.Integer) 0, 0);
        dateTimeParserBucket71.setOffset((java.lang.Integer) 366);
        long long76 = dateTimeParserBucket71.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale77 = dateTimeParserBucket71.getLocale();
        java.util.Calendar calendar78 = dateTime64.toCalendar(locale77);
        int int79 = property52.getMaximumShortTextLength(locale77);
        java.lang.String str80 = cachedDateTimeZone42.getName((long) 7, locale77);
        java.lang.String str81 = delegatedDateTimeField33.getAsShortText(1560342793355L, locale77);
        java.lang.String str82 = offsetDateTimeField11.getAsText(readablePartial19, 7, locale77);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 220924800000L + "'", long28 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3155760000000L + "'", long31 == 3155760000000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292269054) + "'", int32 == (-292269054));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-357L) + "'", long76 == (-357L));
        org.junit.Assert.assertNotNull(locale77);
        org.junit.Assert.assertNotNull(calendar78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "+00:00" + "'", str80.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "2019" + "'", str81.equals("2019"));
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "7" + "'", str82.equals("7"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = iSOChronology6.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime6.toCalendar(locale7);
//        org.joda.time.DateTime dateTime10 = dateTime6.minus((long) 101);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours(365);
//        org.joda.time.DateTime dateTime14 = dateTime10.minusHours(57600);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 753 + "'", int4 == 753);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime19);
        try {
            org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }
}

