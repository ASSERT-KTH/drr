import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0L, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) false, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test006");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            org.joda.time.DateTime.Property property6 = dateTime1.property(dateTimeFieldType5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T05:31:42.657-07:00" + "'", str4.equals("2019-06-12T05:31:42.657-07:00"));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime12.minus(readablePeriod17);
        try {
            org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.halfdays();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = julianChronology0.get(readablePartial2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        int int3 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 366 + "'", int3 == 366);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0d, (java.lang.Number) 100L, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((int) (short) 10, (int) (short) 0, (int) (short) 0, (int) '#', (int) 'a', (int) (short) 100, (int) 'a', (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(366, (int) (short) 10, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = julianChronology0.get(readablePeriod2, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.halfdays();
        org.joda.time.DurationField durationField3 = julianChronology1.seconds();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField5 = julianChronology4.halfdays();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        try {
            long long7 = skipUndoDateTimeField4.set((long) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            int int10 = mutableDateTime6.get(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology6, dateTimeField9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 10, 0, (int) (short) -1, (int) (short) 0, 0, (int) (byte) 100, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Positive hours must not have negative minutes: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime1.withHourOfDay((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 331 + "'", int4 == 331);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 100, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime3.withDayOfWeek((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560342705049L + "'", long4 == 1560342705049L);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) ' ', true, (long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            mutableDateTime9.set(dateTimeFieldType10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, 331);
        mutableDateTime6.setMillisOfDay((int) (byte) 10);
        try {
            mutableDateTime6.setMinuteOfHour(366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        try {
            mutableDateTime4.setDateTime((int) '4', (int) '#', 100, 9, 10, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime3.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = julianChronology0.get(readablePartial6, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Wed");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Wed' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZone(dateTimeZone5);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime7);
        int[] intArray13 = new int[] { 331, 1, 0, 10 };
        try {
            julianChronology0.validate((org.joda.time.ReadablePartial) localTime7, intArray13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 331 for hourOfDay must not be larger than 23");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-12T05:31:45.337-07:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-12T05:31:45.337-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundHalfFloor();
        try {
            mutableDateTime6.setTime(1969, (int) (byte) 100, 0, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-12T05:31:42.623-07:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-12T05:31:42.623-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        int int9 = skipUndoDateTimeField4.getMinimumValue((long) 1);
        int int10 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292269054) + "'", int9 == (-292269054));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269054) + "'", int10 == (-292269054));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) (byte) 1, (int) (byte) 0, (int) '#', 10, (-1), 9, 1603);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZone(dateTimeZone5);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime7);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.halfdays();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 0, 1, 1, (int) (short) 1, (int) (byte) 1, (int) ' ', (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1560342704861L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2458647.0220470023d + "'", double1 == 2458647.0220470023d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZone(dateTimeZone9);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        int[] intArray13 = new int[] { 10 };
        try {
            julianChronology0.validate((org.joda.time.ReadablePartial) localTime11, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 100);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
        boolean boolean7 = skipDateTimeField4.isLenient();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        boolean boolean13 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime12);
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime12);
        int[] intArray18 = new int[] { 1603, 'a' };
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = skipDateTimeField4.set((org.joda.time.ReadablePartial) localTime12, (int) (short) 1, intArray18, "2019-06-12T05:31:46.169-07:00", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:31:46.169-07:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (short) -1, (int) (byte) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-12T05:31:48.059-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T05:31:48.059-07:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        try {
            org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0, 1603, 1, 52, 52, 366, (int) '4', (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-12T05:31:42.993-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:31:42.993-07:00\" is malformed at \"19-06-12T05:31:42.993-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, (int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addHours((int) (byte) 100);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.monthOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology0.getZone();
        try {
            long long11 = julianChronology0.getDateTimeMillis((int) (byte) -1, 7, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        try {
//            org.joda.time.DateTime.Property property8 = dateTime6.property(dateTimeFieldType7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 331 + "'", int4 == 331);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        int int9 = skipUndoDateTimeField4.getMinimumValue((long) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray18 = new int[] { (byte) 0, 4 };
        try {
            int[] intArray20 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) localTime14, (int) (byte) 10, intArray18, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292269054) + "'", int9 == (-292269054));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(101L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 101 + "'", int1 == 101);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName(10L, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass11 = gJChronology10.getClass();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) fixedDateTimeZone4, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        long long6 = mutableDateTime4.getMillis();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
        long long9 = skipDateTimeField4.addWrapField((long) (byte) 1, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = skipDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 259200001L + "'", long9 == 259200001L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        boolean boolean10 = dateTime9.isBeforeNow();
//        boolean boolean12 = dateTime9.isBefore((long) ' ');
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 960 + "'", int4 == 960);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.millisOfDay();
        org.joda.time.DurationField durationField7 = julianChronology1.weekyears();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) julianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 220924800000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        mutableDateTime6.add(readablePeriod7, 331);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
//        java.lang.String str15 = dateTime12.toString();
//        org.joda.time.DateTime dateTime17 = dateTime12.withYearOfEra(366);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology18, dateTimeField21);
//        org.joda.time.DateTimeField dateTimeField23 = julianChronology18.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) julianChronology18);
//        int int25 = property10.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime17.withEra((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str15.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1602 + "'", int25 == 1602);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:31:48.059-07:00", (java.lang.Number) (-1595503694458L), (java.lang.Number) 100.0f, (java.lang.Number) 1.0f);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours(7);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withFieldAdded(durationFieldType9, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        try {
            long long10 = gJChronology0.getDateTimeMillis((int) ' ', (int) (short) -1, 292272992, (int) (byte) 10, (int) '4', (int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone13);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.year();
//        org.joda.time.MutableDateTime mutableDateTime17 = property15.set((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime19 = property15.add((int) (byte) -1);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField22, (int) 'a');
//        int int25 = mutableDateTime19.get(dateTimeField22);
//        int int26 = property5.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T05:31:48.059-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.addSeconds((int) (byte) -1);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.yearOfCentury();
//        long long9 = julianChronology0.add(35L, (long) (byte) 0, 101);
//        long long15 = julianChronology0.getDateTimeMillis((long) 1603, (int) (short) 1, (int) (byte) 10, (int) (byte) 0, 4);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-53399996L) + "'", long15 == (-53399996L));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:42.993-07:00");
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setDate((long) (byte) 10);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis((long) 331);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        try {
            mutableDateTime7.setDayOfWeek(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            mutableDateTime9.set(dateTimeFieldType10, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-292269054));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-25462913025600000L) + "'", long1 == (-25462913025600000L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withZone(dateTimeZone8);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime10);
        int[] intArray16 = new int[] { 331, (short) 0, 960 };
        try {
            int[] intArray18 = skipUndoDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localTime10, (int) (short) 0, intArray16, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "year" + "'", str5.equals("year"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray16);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        mutableDateTime6.add(readablePeriod7, 331);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
//        java.lang.String str15 = dateTime12.toString();
//        org.joda.time.DateTime dateTime17 = dateTime12.withYearOfEra(366);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology18, dateTimeField21);
//        org.joda.time.DateTimeField dateTimeField23 = julianChronology18.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) julianChronology18);
//        int int25 = property10.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime17.withDurationAdded(readableDuration26, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str15.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1602 + "'", int25 == 1602);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
        boolean boolean7 = skipDateTimeField4.isLenient();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField4, 366, (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for dayOfWeek must be in the range [-1,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.setMillisOfDay((int) 'a');
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfSecond();
        mutableDateTime6.addMinutes((int) (byte) -1);
        mutableDateTime6.setSecondOfMinute((int) (short) 1);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        try {
            long long10 = gJChronology0.getDateTimeMillis(9, 52, 7, (int) 'a', 366, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("DateTimeField[year]", (int) (short) 1, 4, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for DateTimeField[year] must be in the range [4,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField20 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType18, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int8 = skipUndoDateTimeField4.getMinimumValue();
//        long long11 = skipUndoDateTimeField4.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        boolean boolean17 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime16);
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime16, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292269054) + "'", int8 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62042285222000L) + "'", long11 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        boolean boolean17 = skipDateTimeField16.isLenient();
        long long20 = skipDateTimeField16.getDifferenceAsLong((long) 366, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, (int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T16:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.010-08:00\" is malformed at \"-12-31T16:00:00.010-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        java.util.TimeZone timeZone19 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        int int6 = property5.getMinimumValue();
        boolean boolean7 = property5.isLeap();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday(331);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType6, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, (int) (byte) 0);
        java.lang.String str5 = skipDateTimeField4.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str5.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(101, 0, (int) 'a', (int) (byte) 1, 1603, 1602, (int) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1603 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        long long6 = property5.remainder();
//        org.joda.time.DurationField durationField7 = property5.getRangeDurationField();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31507200010L + "'", long6 == 31507200010L);
//        org.junit.Assert.assertNull(durationField7);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        int int10 = property8.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.millisOfDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, (int) 'a');
        long long15 = skipUndoDateTimeField12.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField12, 331);
        org.joda.time.DurationField durationField18 = julianChronology1.millis();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 0, (org.joda.time.Chronology) julianChronology1, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            dateTimeParserBucket20.saveField(dateTimeFieldType21, 1603);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220924800000L + "'", long15 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime2 = mutableDateTime1.copy();
        try {
            mutableDateTime2.setDate(331, (int) (short) 100, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3, (int) 'a');
        long long8 = skipUndoDateTimeField5.add((long) 0, (long) 7);
        long long11 = skipUndoDateTimeField5.add(0L, (long) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        boolean boolean18 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime17);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipUndoDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localTime17, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 220924800000L + "'", long8 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3155760000000L + "'", long11 == 3155760000000L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1970", "2019-06-12T05:31:42.993-07:00", (int) (byte) 1, (int) ' ');
        java.lang.String str5 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970" + "'", str5.equals("1970"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(52, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusHours(7);
//        int int7 = dateTime3.getMinuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime3.withMillisOfDay(10);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        try {
//            java.lang.String str8 = dateTime6.toString("DateTimeField[dayOfWeek]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str4.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        int int9 = skipUndoDateTimeField4.get((long) 366);
        int int10 = skipUndoDateTimeField4.getMinimumValue();
        java.lang.String str11 = skipUndoDateTimeField4.getName();
        java.lang.String str12 = skipUndoDateTimeField4.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType13, (int) (short) -1, (int) (short) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269054) + "'", int10 == (-292269054));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[year]" + "'", str12.equals("DateTimeField[year]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.setMillisOfDay((int) 'a');
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        mutableDateTime11.add(readablePeriod12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            int int15 = mutableDateTime11.get(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
//        long long13 = dateTimeParserBucket10.computeMillis(true, "1969");
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560367904861L + "'", long13 == 1560367904861L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime7.toString("2019-06-12T05:31:44.677-07:00", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) (byte) 0, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology6, dateTimeField8, (int) 'a');
//        long long13 = skipUndoDateTimeField10.add((long) 0, (long) 7);
//        int int14 = skipUndoDateTimeField10.getMinimumValue();
//        long long17 = skipUndoDateTimeField10.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
//        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
//        boolean boolean23 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime22);
//        int[] intArray31 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray33 = skipUndoDateTimeField10.add((org.joda.time.ReadablePartial) localTime22, 4, intArray31, (int) ' ');
//        try {
//            julianChronology0.validate(readablePartial5, intArray31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 220924800000L + "'", long13 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292269054) + "'", int14 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62042285222000L) + "'", long17 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        try {
            long long7 = julianChronology0.getDateTimeMillis((int) (short) -1, 1, (int) (short) 0, 292272992);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272992 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(9, 366);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:31:48.059-07:00", (java.lang.Number) (-1595503694458L), (java.lang.Number) 100.0f, (java.lang.Number) 1.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("year");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(1603);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.convertUTCToLocal((long) '#');
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime8.addWeekyears(0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560342704399L);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
//        java.lang.String str9 = dateTime6.toString();
//        org.joda.time.DateTime dateTime11 = dateTime6.withYearOfEra(366);
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        org.joda.time.LocalTime localTime13 = dateTime11.toLocalTime();
//        int[] intArray16 = new int[] { 366 };
//        try {
//            int[] intArray18 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localTime13, (int) (short) 100, intArray16, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2068-11-20T17:03:39.902-08:00" + "'", str9.equals("2068-11-20T17:03:39.902-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 1.0d, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
//        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
//        boolean boolean10 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime9);
//        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime9);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, dateTimeField15, (int) 'a');
//        long long20 = skipUndoDateTimeField17.add((long) 0, (long) 7);
//        int int21 = skipUndoDateTimeField17.getMinimumValue();
//        long long24 = skipUndoDateTimeField17.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZone(dateTimeZone27);
//        org.joda.time.LocalTime localTime29 = dateTime28.toLocalTime();
//        boolean boolean30 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime29);
//        int[] intArray38 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray40 = skipUndoDateTimeField17.add((org.joda.time.ReadablePartial) localTime29, 4, intArray38, (int) ' ');
//        try {
//            int[] intArray42 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime9, 100, intArray38, 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 220924800000L + "'", long20 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292269054) + "'", int21 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62042285222000L) + "'", long24 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        long long9 = fixedDateTimeZone4.adjustOffset(0L, false);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) ' ', (int) (short) 10, 0, 52, (int) (byte) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(960, 366, 2000, (int) (short) -1, 0, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone11.getShortName((long) (byte) 0, locale20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        int int8 = mutableDateTime7.getMinuteOfHour();
        mutableDateTime7.addHours((int) (short) -1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        java.lang.String str10 = property5.getAsString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Instant instant3 = instant0.minus((-292269054L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '4', 960, 1602);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1603, number2, (java.lang.Number) 292272992);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTime((org.joda.time.Chronology) julianChronology7);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusWeeks(7);
//        org.joda.time.DateTime.Property property16 = dateTime6.centuryOfEra();
//        try {
//            org.joda.time.DateTime dateTime18 = property16.addToCopy(31507200010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3150720001000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2068-11-20T17:03:40.605-08:00" + "'", str4.equals("2068-11-20T17:03:40.605-08:00"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
        try {
            mutableDateTime4.setWeekOfWeekyear(1602);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1602 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.year();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.year();
        org.joda.time.MutableDateTime mutableDateTime9 = property8.roundHalfFloor();
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "Wednesday", 0);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        mutableDateTime9.add(readablePeriod13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.setMillisOfDay((int) 'a');
        mutableDateTime6.setTime((long) (byte) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime6.toMutableDateTime();
        try {
            mutableDateTime11.setDateTime(1439, 101, 366, (int) '4', 0, (int) (byte) -1, 331);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        mutableDateTime6.addMillis((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.hourOfDay();
        int int10 = property9.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = property9.set("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.setMillisOfDay((int) 'a');
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        mutableDateTime11.add(readablePeriod12);
        try {
            mutableDateTime11.setMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        mutableDateTime6.setMillisOfDay((int) 'a');
        mutableDateTime6.setTime((long) (byte) 10);
        try {
            mutableDateTime6.setDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        long long8 = julianChronology0.add(35L, 0L, (-292269054));
        org.joda.time.DurationField durationField9 = julianChronology0.eras();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dateTimeField17, dateTimeFieldType18, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.halfdays();
        org.joda.time.DurationField durationField9 = julianChronology7.seconds();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(1023, 0, (int) (byte) 1, (-292269054), (int) '#', (int) (byte) -1, 4, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269054 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2068-11-20T17:03:40.330-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2068-11-20T17:03:40.330-08:00\" is malformed at \"-11-20T17:03:40.330-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis((int) (short) -1);
        java.lang.Class<?> wildcardClass9 = dateTime8.getClass();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) (byte) -1, 960, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(220924800000L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        try {
            org.joda.time.LocalDateTime localDateTime7 = dateTimeFormatter4.parseLocalDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1781267517589L + "'", long0 == 1781267517589L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-62042285222000L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
//        int int7 = mutableDateTime6.getDayOfMonth();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZone(dateTimeZone9);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime11);
        int[] intArray14 = null;
        int[] intArray16 = skipDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localTime11, 1603, intArray14, 0);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(intArray16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        boolean boolean5 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
        int int8 = skipDateTimeField4.getMaximumValue((long) '#');
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = skipDateTimeField4.getAsShortText(100, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
//        mutableDateTime1.addMillis((int) (byte) 0);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60481942504213L) + "'", long4 == (-60481942504213L));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        long long9 = fixedDateTimeZone4.adjustOffset(0L, false);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("year");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendHourOfHalfday((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendFractionOfHour(0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime11 = dateTime7.withYear((int) 'a');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.halfdays();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        long long5 = durationField2.subtract(3155760000000L, 1560342704399L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1557186944399000L) + "'", long5 == (-1557186944399000L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:42.993-07:00");
        mutableDateTime1.setMillisOfDay(9);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
//        org.joda.time.DateTime dateTime11 = property9.getDateTime();
//        int int12 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long15 = fixedDateTimeZone13.convertUTCToLocal((long) '#');
//        long long19 = fixedDateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) 1);
//        org.joda.time.DateTime dateTime20 = dateTime3.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime3.withDate(4, 1603, 366);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1603 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60481942503750L) + "'", long4 == (-60481942503750L));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendClockhourOfDay(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendCenturyOfEra(9, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYearOfEra(1023, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-06-12T05:31:47.040-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime3.minusWeeks(9);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            int int13 = dateTime11.get(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(100, 2000, 366, 2, (-292269054), (int) (short) -1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269054 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.eras();
        try {
            long long4 = durationField1.subtract((-1L), 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withField(dateTimeFieldType6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (byte) -1, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 100, "Wed");
        java.lang.String str3 = illegalInstantException2.toString();
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException((long) 100, "Wed");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.100 (Wed)" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.100 (Wed)"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(2, (-28800000), 0, 2000, (int) ' ', (int) (short) 0, 1603);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        int int6 = property5.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime8 = property5.roundHalfCeiling();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField13);
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        mutableDateTime15.add(readablePeriod16, 331);
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.weekyear();
//        boolean boolean20 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
//        mutableDateTime8.addMillis((int) (short) 0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int9 = skipUndoDateTimeField4.getMinimumValue((long) 1);
//        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.withZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property18 = dateTime17.hourOfDay();
//        org.joda.time.DateTime dateTime19 = dateTime17.withTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime20 = dateTime17.toLocalTime();
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology23.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology22, dateTimeField24, (int) 'a');
//        long long29 = skipUndoDateTimeField26.add((long) 0, (long) 7);
//        int int30 = skipUndoDateTimeField26.getMinimumValue();
//        long long33 = skipUndoDateTimeField26.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime35.withZone(dateTimeZone36);
//        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
//        boolean boolean39 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime38);
//        int[] intArray47 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray49 = skipUndoDateTimeField26.add((org.joda.time.ReadablePartial) localTime38, 4, intArray47, (int) ' ');
//        java.util.Locale locale51 = null;
//        try {
//            int[] intArray52 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime20, 2, intArray49, "2019-06-12T05:31:46.169-07:00", locale51);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:31:46.169-07:00\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292269054) + "'", int9 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertNotNull(julianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 220924800000L + "'", long29 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-292269054) + "'", int30 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62042285222000L) + "'", long33 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology8, locale9, (java.lang.Integer) 0, 0);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.secondOfDay();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(4, 0, 0, 0, (int) (byte) -1, (int) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("year");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendHourOfHalfday((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfHour(1439, (int) '4');
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime11 = property5.add((long) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(32L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 2000);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology7.millisOfDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16, (int) 'a');
        long long21 = skipUndoDateTimeField18.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField18, 331);
        org.joda.time.DurationField durationField24 = julianChronology7.millis();
        org.joda.time.Chronology chronology25 = julianChronology7.withUTC();
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(0, 1439, 292272992, 292272992, (int) (byte) 0, 52, 0, chronology25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272992 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 220924800000L + "'", long21 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = gJChronology0.get(readablePeriod1, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        int int6 = property5.getMinimumValue();
//        java.lang.String str7 = property5.getAsText();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsShortText(locale8);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName(10L, locale8);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str7 = mutableDateTime6.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str7.equals("1970-01-01T00:00:00.032Z"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField9 = julianChronology6.days();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, 18, 271, (int) (byte) -1, 10, 1603, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        try {
            long long11 = julianChronology0.getDateTimeMillis((long) 2000, (int) '#', (int) (short) 1, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        org.joda.time.MutableDateTime mutableDateTime11 = property5.add((long) '#');
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "2019-06-12T05:31:48.059-07:00");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear((-28800000));
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(10.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-06-12T05:31:42.623-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:31:42.623-07:00\" is malformed at \"-06-12T05:31:42.623-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(9, (int) (short) 10, (int) (short) -1, 960, 0, 2, (org.joda.time.DateTimeZone) cachedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendPattern("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        int int6 = property5.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfEven();
        try {
            mutableDateTime7.setTime(52, 1969, (int) ' ', 331);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology7.millisOfDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16, (int) 'a');
        long long21 = skipUndoDateTimeField18.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField18, 331);
        org.joda.time.DateTime dateTime24 = dateTime6.toDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTime.Property property25 = dateTime6.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime27 = dateTime6.withYearOfCentury((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 220924800000L + "'", long21 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-1557186944399000L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (long) 1969);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1969L) + "'", long2 == (-1969L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DurationField durationField17 = skipDateTimeField16.getDurationField();
        try {
            long long20 = skipDateTimeField16.set(0L, 331);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 331 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField17);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
//        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
//        org.joda.time.DurationField durationField7 = julianChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getName((long) (byte) 10, locale10);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.year();
//        org.joda.time.MutableDateTime mutableDateTime18 = property17.roundHalfFloor();
//        java.util.Locale locale19 = null;
//        java.util.Calendar calendar20 = mutableDateTime18.toCalendar(locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.DateTimeField dateTimeField22 = mutableDateTime18.getRoundingField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(calendar20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNull(dateTimeField22);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (byte) 0, 1602, (int) '#', (int) ' ', (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Instant instant3 = instant0.plus((long) 366);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) 366);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-06-12T05:31:42.993-07:00");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T05:31:47.040-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "2019-06-12T05:31:48.059-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("1969-12-31T16:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.010-08:00\" is malformed at \"-12-31T16:00:00.010-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            int int10 = dateTime7.get(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 0, 0, 366);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        int int9 = skipUndoDateTimeField4.get((long) 366);
        int int10 = skipUndoDateTimeField4.getMinimumValue();
        java.lang.String str11 = skipUndoDateTimeField4.getName();
        java.lang.String str12 = skipUndoDateTimeField4.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        boolean boolean18 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime17);
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime17);
        int[] intArray20 = null;
        int int21 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime17, intArray20);
        int int22 = skipUndoDateTimeField4.getMinimumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField4, (int) (short) 0, 0, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year must be in the range [0,-292275054]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269054) + "'", int10 == (-292269054));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[year]" + "'", str12.equals("DateTimeField[year]"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 292272992 + "'", int21 == 292272992);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292269054) + "'", int22 == (-292269054));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (short) 100, (int) (byte) 0);
        long long6 = durationField0.subtract((-53399996L), 0);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53399996L) + "'", long6 == (-53399996L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField7 = julianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        org.joda.time.DurationField durationField15 = property14.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField16 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime3.minusWeeks(9);
        java.util.Date date12 = dateTime3.toDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        boolean boolean10 = dateTime9.isBeforeNow();
//        int int11 = dateTime9.getEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2019-06-12T05:31:45.337-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:31:45.337-07:00\" is malformed at \"19-06-12T05:31:45.337-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        long long10 = skipUndoDateTimeField4.add(0L, (long) 100);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000000L + "'", long10 == 3155760000000L);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(18);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
//        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
//        org.joda.time.DurationField durationField7 = julianChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getName((long) (byte) 10, locale10);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.year();
//        org.joda.time.MutableDateTime mutableDateTime18 = property17.roundHalfFloor();
//        java.util.Locale locale19 = null;
//        java.util.Calendar calendar20 = mutableDateTime18.toCalendar(locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime18);
//        mutableDateTime18.addYears(3);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(calendar20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0, 0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField8 = iSOChronology2.millis();
        long long11 = durationField8.subtract((-60481942504213L), 10L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-60481942504223L) + "'", long11 == (-60481942504223L));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean6 = dateTime3.equals((java.lang.Object) dateTimeFormatterBuilder5);
//        int int7 = dateTime3.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1555626601676148L) + "'", long4 == (-1555626601676148L));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-47326) + "'", int7 == (-47326));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
        org.joda.time.DurationField durationField8 = julianChronology6.minutes();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology6.year();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((-47326), (int) '#', 3, 1, 219, 100, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 219 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) (short) -1);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime11.withDate(0, 101, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 101 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(1152000000L);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-47326-02-26T03:39:06.002-07:52:58" + "'", str4.equals("-47326-02-26T03:39:06.002-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundFloor();
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime6.copy();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
//        int int6 = dateTimeFormatter4.getDefaultYear();
//        java.io.Writer writer7 = null;
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, (int) 'a');
//        long long15 = skipUndoDateTimeField12.add((long) 0, (long) 7);
//        int int17 = skipUndoDateTimeField12.get((long) 366);
//        int int18 = skipUndoDateTimeField12.getMinimumValue();
//        java.lang.String str19 = skipUndoDateTimeField12.getName();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZone(dateTimeZone22);
//        java.lang.String str24 = dateTime21.toString();
//        org.joda.time.DateTime dateTime26 = dateTime21.withYearOfEra(366);
//        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
//        org.joda.time.LocalTime localTime28 = dateTime26.toLocalTime();
//        int int29 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localTime28);
//        try {
//            dateTimeFormatter4.printTo(writer7, (org.joda.time.ReadablePartial) localTime28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220924800000L + "'", long15 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-292269054) + "'", int18 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "year" + "'", str19.equals("year"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-47326-02-26T03:39:06.150-07:52:58" + "'", str24.equals("-47326-02-26T03:39:06.150-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(localTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292269054) + "'", int29 == (-292269054));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DurationField durationField17 = julianChronology0.millis();
        org.joda.time.DurationField durationField18 = julianChronology0.seconds();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((-28800000), false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.convertUTCToLocal((long) '#');
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = fixedDateTimeZone5.isFixed();
        java.util.TimeZone timeZone10 = fixedDateTimeZone5.toTimeZone();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.millisOfDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, (int) 'a');
        long long15 = skipUndoDateTimeField12.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField12, 331);
        org.joda.time.DurationField durationField18 = julianChronology1.millis();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 0, (org.joda.time.Chronology) julianChronology1, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        java.util.Locale locale23 = null;
        try {
            dateTimeParserBucket20.saveField(dateTimeFieldType21, "Pacific Standard Time", locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 220924800000L + "'", long15 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadableInstant readableInstant8 = null;
        boolean boolean9 = dateTime7.isAfter(readableInstant8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime7.minusHours(1603);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1970");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("0051-12-31T16:00:00.010-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0051-12-31T16:00:00.010-07:52:58\" is malformed at \"T16:00:00.010-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipDateTimeField4.getAsText(0L, locale8);
//        long long12 = skipDateTimeField4.getDifferenceAsLong((long) (-292275054), (long) 1602);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = skipDateTimeField4.getAsText(259200001L, locale14);
//        int int17 = skipDateTimeField4.get((-1969L));
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wednesday" + "'", str9.equals("Wednesday"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3L) + "'", long12 == (-3L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Saturday" + "'", str15.equals("Saturday"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        java.lang.Class<?> wildcardClass8 = dateTime7.getClass();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        org.joda.time.Chronology chronology6 = gJChronology1.withZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (short) 1, dateTimeZone5);
        java.util.TimeZone timeZone8 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        long long10 = skipUndoDateTimeField4.add(0L, (long) 100);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField4.getAsShortText((long) (-292275054), locale12);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000000L + "'", long10 == 3155760000000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        long long10 = skipUndoDateTimeField4.set((long) 1969, "900");
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-33735053220031L) + "'", long10 == (-33735053220031L));
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        long long13 = offsetDateTimeField11.roundHalfCeiling((-60481942504213L));
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.withZone(dateTimeZone16);
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime18);
//        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime18);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology23.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology22, dateTimeField24, (int) 'a');
//        long long29 = skipUndoDateTimeField26.add((long) 0, (long) 7);
//        int int30 = skipUndoDateTimeField26.getMinimumValue();
//        long long33 = skipUndoDateTimeField26.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime35.withZone(dateTimeZone36);
//        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
//        boolean boolean39 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime38);
//        int[] intArray47 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray49 = skipUndoDateTimeField26.add((org.joda.time.ReadablePartial) localTime38, 4, intArray47, (int) ' ');
//        try {
//            int[] intArray51 = offsetDateTimeField11.addWrapField((org.joda.time.ReadablePartial) localTime18, (int) (byte) 100, intArray47, 101);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60481942502000L) + "'", long13 == (-60481942502000L));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(julianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 220924800000L + "'", long29 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-292269054) + "'", int30 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62042285222000L) + "'", long33 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str9 = fixedDateTimeZone6.getShortName((long) 'a');
        java.lang.String str11 = fixedDateTimeZone6.getNameKey((long) (byte) 100);
        org.joda.time.Chronology chronology12 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str11.equals("2019-06-12T05:31:42.623-07:00"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        int int6 = property5.getMinimumValue();
//        java.lang.String str7 = property5.getAsText();
//        int int8 = property5.getMinimumValue();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean2 = dateTimeFormatter1.isParser();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1969", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendPattern("9");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendHourOfDay(101);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology6, dateTimeField9);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology6.millisOfDay();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology6.millisOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, dateTimeField15, (int) 'a');
        long long20 = skipUndoDateTimeField17.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField17, 331);
        org.joda.time.DateTimeField dateTimeField23 = julianChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology6.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (short) 100, 9, 1, 9, 1602, (int) (byte) 10, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1602 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 220924800000L + "'", long20 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTimeZoneOffset("DateTimeField[dayOfWeek]", true, (int) (short) 10, 292272992);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfYear" + "'", str3.equals("dayOfYear"));
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getLeapDurationField();
        long long14 = offsetDateTimeField11.roundHalfEven((long) 366);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "1969", (-292275054), (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        try {
            long long21 = zonedChronology16.getDateTimeMillis((int) ' ', 0, (int) (short) 100, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4, (int) 'a');
        long long9 = skipUndoDateTimeField6.add((long) 0, (long) 7);
        int int11 = skipUndoDateTimeField6.get((long) 366);
        int int12 = skipUndoDateTimeField6.getMinimumValue();
        java.lang.String str13 = skipUndoDateTimeField6.getName();
        java.lang.String str14 = skipUndoDateTimeField6.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withZone(dateTimeZone17);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime19);
        boolean boolean21 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime19);
        int[] intArray22 = null;
        int int23 = skipUndoDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localTime19, intArray22);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 220924800000L + "'", long9 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292269054) + "'", int12 == (-292269054));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "year" + "'", str13.equals("year"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[year]" + "'", str14.equals("DateTimeField[year]"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292272992 + "'", int23 == 292272992);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560342704861L, (long) 1439);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2245333152294979L + "'", long2 == 2245333152294979L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) ' ');
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withDayOfYear(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) ' ');
        org.joda.time.DateTimeField dateTimeField9 = property6.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        long long4 = buddhistChronology0.add((long) (byte) 100, 1560342706954L, 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime12 = property9.withMaximumValue();
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
//        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone17);
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.year();
//        org.joda.time.MutableDateTime mutableDateTime21 = property19.set((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime23 = property19.add((int) (byte) -1);
//        mutableDateTime23.addHours(100);
//        java.lang.String str26 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1439 + "'", int11 == 1439);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11:59:08 PM -07:52:58" + "'", str13.equals("11:59:08 PM -07:52:58"));
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "8:00:00 PM -07:52:58" + "'", str26.equals("8:00:00 PM -07:52:58"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
        int int14 = offsetDateTimeField11.getMinimumValue(2440588L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1603 + "'", int14 == 1603);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfHour(1439, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeek(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (byte) 100, 18, (int) '4', (int) (byte) 10, (int) (byte) 100, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-62042285222000L), 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -62042285222000 * 2440588");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 10);
        mutableDateTime1.addMillis(7);
        mutableDateTime1.setWeekyear(2563);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("-47326-02-26T03:39:06.002-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-47326-02-26T03:39:06.002-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(3155760000000L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray35 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType29 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList36 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList36, dateTimeFieldTypeArray35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList36, false, true);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        boolean boolean7 = skipDateTimeField4.isLenient();
//        java.lang.String str9 = skipDateTimeField4.getAsText((long) (short) 10);
//        long long12 = skipDateTimeField4.add(1560342704861L, (long) 9);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wednesday" + "'", str9.equals("Wednesday"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561120304861L + "'", long12 == 1561120304861L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime3.minusWeeks(9);
        org.joda.time.DateTime dateTime12 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime14 = dateTime3.withMillisOfDay(960);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime3.plus(readablePeriod15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.yearOfEra();
        java.util.Date date7 = mutableDateTime4.toDate();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) '#');
        long long15 = fixedDateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.year();
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime21);
        int int24 = mutableDateTime4.getSecondOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 45104 + "'", int24 == 45104);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.LocalTime localTime10 = dateTime7.toLocalTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        java.util.Locale locale8 = null;
//        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
//        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.withZone(dateTimeZone37);
//        java.lang.String str39 = dateTime36.toString();
//        org.joda.time.DateTime dateTime41 = dateTime36.withYearOfEra(366);
//        org.joda.time.DateTime.Property property42 = dateTime41.minuteOfDay();
//        org.joda.time.LocalTime localTime43 = dateTime41.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.withZone(dateTimeZone47);
//        org.joda.time.DateTime dateTime50 = dateTime48.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime52 = dateTime50.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property53 = dateTime50.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField54 = property53.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 1603);
//        long long58 = offsetDateTimeField56.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = offsetDateTimeField56.getAsText((long) 3, locale60);
//        org.joda.time.Chronology chronology62 = null;
//        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField64 = julianChronology63.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField(chronology62, dateTimeField64, (int) 'a');
//        java.util.Locale locale67 = null;
//        int int68 = skipUndoDateTimeField66.getMaximumTextLength(locale67);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTime dateTime72 = dateTime70.withZone(dateTimeZone71);
//        org.joda.time.LocalTime localTime73 = dateTime72.toLocalTime();
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = skipUndoDateTimeField66.getAsText((org.joda.time.ReadablePartial) localTime73, 9, locale75);
//        int[] intArray78 = new int[] { (short) 100 };
//        int int79 = offsetDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) localTime73, intArray78);
//        java.util.Locale locale81 = null;
//        try {
//            int[] intArray82 = offsetDateTimeField34.set((org.joda.time.ReadablePartial) localTime43, 1, intArray78, "0051-12-31T16:00:00.010-07:52:58", locale81);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0051-12-31T16:00:00.010-07:52:58\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "-47326-02-26T03:39:10.702-07:52:58" + "'", str39.equals("-47326-02-26T03:39:10.702-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(localTime43);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-60481942502000L) + "'", long58 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2563" + "'", str61.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 9 + "'", int68 == 9);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(localTime73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "9" + "'", str76.equals("9"));
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3042 + "'", int79 == 3042);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:42.993-07:00");
        boolean boolean2 = mutableDateTime1.isEqualNow();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        boolean boolean9 = mutableDateTime7.isEqual(0L);
        boolean boolean11 = mutableDateTime7.isAfter((long) 3042);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(10);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 366, (java.lang.Number) 10, (java.lang.Number) 259200001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfWeek();
        try {
            long long9 = gJChronology0.getDateTimeMillis(31507200010L, (-28800000), (int) (short) 10, 3042, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addMillis((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property12 = dateTime9.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 1603);
        mutableDateTime1.setRounding(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
//        boolean boolean10 = dateTime8.isEqual(1L);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology11, dateTimeField14);
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology11.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.DateTime dateTime19 = dateTime8.withChronology((org.joda.time.Chronology) julianChronology11);
//        int int20 = dateTime19.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-47326-02-26T03:39:11.357-07:52:58" + "'", str4.equals("-47326-02-26T03:39:11.357-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology0.days();
        org.joda.time.DurationField durationField8 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology10 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.convertUTCToLocal((long) '#');
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = fixedDateTimeZone5.isFixed();
        java.lang.String str11 = fixedDateTimeZone5.getName((long) 2000);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        int int11 = skipUndoDateTimeField4.getLeapAmount((long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int11 = cachedDateTimeZone9.getOffset((-25462913025600000L));
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        java.lang.String str13 = dateTimeZone12.getID();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter3, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime3.minusWeeks(9);
        org.joda.time.DateTime dateTime12 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property13 = dateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 3042, 10, 45104);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3042 + "'", int4 == 3042);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMillisOfSecond(271);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1560367904861L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, (int) (byte) 0);
        boolean boolean5 = skipDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
        long long14 = offsetDateTimeField11.roundHalfCeiling((long) 271);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(9, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitYear(3042);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Instant instant2 = new org.joda.time.Instant(1L);
        long long3 = instant2.getMillis();
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00:00" + "'", str4.equals("00:00"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(1969);
        org.joda.time.MutableDateTime mutableDateTime10 = property5.roundCeiling();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.era();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        java.lang.String str13 = offsetDateTimeField11.getAsShortText(1560342704861L);
//        int int16 = offsetDateTimeField11.getDifference((long) 1969, (-1L));
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19, (int) 'a');
//        java.util.Locale locale22 = null;
//        int int23 = skipUndoDateTimeField21.getMaximumTextLength(locale22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.withZone(dateTimeZone26);
//        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField21.getAsText((org.joda.time.ReadablePartial) localTime28, 9, locale30);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.withZone(dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property41 = dateTime38.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = property41.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 1603);
//        long long46 = offsetDateTimeField44.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = offsetDateTimeField44.getAsText((long) 3, locale48);
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField(chronology50, dateTimeField52, (int) 'a');
//        java.util.Locale locale55 = null;
//        int int56 = skipUndoDateTimeField54.getMaximumTextLength(locale55);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime58.withZone(dateTimeZone59);
//        org.joda.time.LocalTime localTime61 = dateTime60.toLocalTime();
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = skipUndoDateTimeField54.getAsText((org.joda.time.ReadablePartial) localTime61, 9, locale63);
//        int[] intArray66 = new int[] { (short) 100 };
//        int int67 = offsetDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localTime61, intArray66);
//        java.util.Locale locale69 = null;
//        try {
//            int[] intArray70 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localTime28, (int) (short) 100, intArray66, "0053-05-27T04:31:58.826-07:52:58", locale69);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0053-05-27T04:31:58.826-07:52:58\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1934" + "'", str13.equals("1934"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localTime28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9" + "'", str31.equals("9"));
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-60481942502000L) + "'", long46 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2563" + "'", str49.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localTime61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9" + "'", str64.equals("9"));
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3042 + "'", int67 == 3042);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField44.getAsText(readablePartial45, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str2.equals("2019-06-12T05:31:45.337-07:00"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str3.equals("2019-06-12T05:31:45.337-07:00"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long16 = fixedDateTimeZone11.adjustOffset(0L, false);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone11, (long) (short) 100);
        java.lang.String str20 = fixedDateTimeZone11.getNameKey(1561120304861L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str20.equals("2019-06-12T05:31:42.623-07:00"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) '#');
        long long15 = fixedDateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.year();
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime4.minuteOfDay();
        java.lang.String str25 = property24.getAsText();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "751" + "'", str25.equals("751"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str7 = fixedDateTimeZone5.getID();
        int int9 = fixedDateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.Class<?> wildcardClass12 = julianChronology11.getClass();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(9, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime8 = property5.roundCeiling();
        mutableDateTime8.setHourOfDay(5);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        int int12 = fixedDateTimeZone4.getOffset(1560342704861L);
        int int14 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone14);
        org.joda.time.DurationField durationField17 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("0051-12-31T16:00:00.010-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 0051-12-31T16:00:00.010-07:52:58");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (-292269054), true);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-292269054L) + "'", long9 == (-292269054L));
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundHalfFloor((-1555626601676148L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((-28800000));
        java.lang.Class<?> wildcardClass10 = dateTime7.getClass();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        boolean boolean7 = skipDateTimeField4.isLenient();
//        java.lang.String str9 = skipDateTimeField4.getAsText((long) (short) 10);
//        java.util.Locale locale10 = null;
//        int int11 = skipDateTimeField4.getMaximumTextLength(locale10);
//        org.joda.time.DurationField durationField12 = skipDateTimeField4.getDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wednesday" + "'", str9.equals("Wednesday"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy("-47326-02-26T03:39:11.107-07:52:58");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-47326-02-26T03:39:11.107-07:52:58\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale10 = null;
        try {
            long long11 = skipUndoDateTimeField4.set((-60481942502000L), "DateTimeField[dayOfWeek]", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[dayOfWeek]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateMidnight dateMidnight7 = dateTime1.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-47326-02-26T03:39:14.833-07:52:58" + "'", str4.equals("-47326-02-26T03:39:14.833-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 1023);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) '#');
        long long15 = fixedDateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.year();
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime21);
        try {
            mutableDateTime21.setDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (short) 100, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundFloor();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        java.util.Locale locale8 = null;
//        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
//        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
//        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
//        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
//        org.joda.time.DurationField durationField42 = julianChronology35.days();
//        org.joda.time.DurationField durationField43 = julianChronology35.months();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.withZone(dateTimeZone47);
//        int int49 = dateTime46.getMinuteOfDay();
//        org.joda.time.DateTime dateTime51 = dateTime46.plusHours((int) '4');
//        org.joda.time.DateTime dateTime54 = dateTime51.withDurationAdded(10L, (-1));
//        org.joda.time.TimeOfDay timeOfDay55 = dateTime54.toTimeOfDay();
//        int[] intArray56 = null;
//        try {
//            int int57 = unsupportedDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay55, intArray56);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(julianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 219 + "'", int49 == 219);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(timeOfDay55);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        int int6 = property5.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfEven();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property5.set("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) '#');
        long long15 = fixedDateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.year();
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime4.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = property24.roundFloor();
        org.joda.time.MutableDateTime mutableDateTime27 = property24.add(1603);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(960);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay((-1), (-292269054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("year");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimePrinter7, dateTimeParser8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
//        java.lang.String str2 = jodaTimePermission1.getName();
//        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
//        java.lang.String str5 = jodaTimePermission4.getName();
//        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
//        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.year();
//        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfFloor();
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = mutableDateTime13.toCalendar(locale14);
//        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime13);
//        long long17 = mutableDateTime13.getMillis();
//        mutableDateTime13.setTime(28800000L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str2.equals("2019-06-12T05:31:45.337-07:00"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str5.equals("2019-06-12T05:31:45.337-07:00"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("271");
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        long long9 = skipDateTimeField4.addWrapField((long) (byte) 1, (int) (short) 10);
//        org.joda.time.DurationField durationField10 = skipDateTimeField4.getLeapDurationField();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = skipDateTimeField4.getAsShortText(0L, locale12);
//        long long15 = skipDateTimeField4.roundCeiling(0L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField4.getAsText((long) 2000, locale17);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 259200001L + "'", long9 == 259200001L);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed" + "'", str13.equals("Wed"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wednesday" + "'", str18.equals("Wednesday"));
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str10 = fixedDateTimeZone7.getShortName((long) 'a');
        java.lang.String str12 = fixedDateTimeZone7.getNameKey((long) (byte) 100);
        org.joda.time.Chronology chronology13 = iSOChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2000, (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str12.equals("2019-06-12T05:31:42.623-07:00"));
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int8 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.withZone(dateTimeZone11);
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField17, (int) 'a');
//        long long22 = skipUndoDateTimeField19.add((long) 0, (long) 7);
//        int int24 = skipUndoDateTimeField19.get((long) 366);
//        int int25 = skipUndoDateTimeField19.getMinimumValue();
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.withZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime32 = dateTime30.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property35 = dateTime32.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = property35.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1603);
//        long long40 = offsetDateTimeField38.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = offsetDateTimeField38.getAsText((long) 3, locale42);
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology45.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology44, dateTimeField46, (int) 'a');
//        java.util.Locale locale49 = null;
//        int int50 = skipUndoDateTimeField48.getMaximumTextLength(locale49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.withZone(dateTimeZone53);
//        org.joda.time.LocalTime localTime55 = dateTime54.toLocalTime();
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = skipUndoDateTimeField48.getAsText((org.joda.time.ReadablePartial) localTime55, 9, locale57);
//        int[] intArray60 = new int[] { (short) 100 };
//        int int61 = offsetDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localTime55, intArray60);
//        int int62 = skipUndoDateTimeField19.getMaximumValue(readablePartial26, intArray60);
//        java.util.Locale locale64 = null;
//        try {
//            int[] intArray65 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime13, (int) '#', intArray60, "", locale64);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292269054) + "'", int8 == (-292269054));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 220924800000L + "'", long22 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292269054) + "'", int25 == (-292269054));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-60481942502000L) + "'", long40 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2563" + "'", str43.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 9 + "'", int50 == 9);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localTime55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9" + "'", str58.equals("9"));
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 3042 + "'", int61 == 3042);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 292272992 + "'", int62 == 292272992);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology6, dateTimeField9);
        org.joda.time.DurationField durationField11 = julianChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology6.year();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, dateTimeField17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology14.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology14.getZone();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        org.joda.time.Chronology chronology22 = julianChronology6.withZone(dateTimeZone20);
        org.joda.time.DurationField durationField23 = julianChronology6.weeks();
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((int) (byte) 10, 2000, 271, 1602, 0, 366, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1602 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass10 = gJChronology9.getClass();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (short) 1, dateTimeZone13);
        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1970", "2019-06-12T05:31:42.993-07:00", (int) (byte) 1, (int) ' ');
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) "2019-06-12T05:31:42.993-07:00");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundCeiling((-53399996L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        java.lang.String str13 = offsetDateTimeField11.getAsText(220924800000L);
//        try {
//            long long16 = offsetDateTimeField11.set((long) 366, 1602);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1602 for minuteOfDay must be in the range [1603,3042]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2563" + "'", str13.equals("2563"));
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        try {
//            boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra(366);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-47326-02-26T03:39:16.953-07:52:58" + "'", str4.equals("-47326-02-26T03:39:16.953-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(292272992);
        mutableDateTime7.setTime((org.joda.time.ReadableInstant) dateTime11);
        boolean boolean13 = dateTime11.isAfterNow();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "900", "900");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Instant instant3 = instant0.plus((long) (byte) 1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant6 = instant0.withDurationAdded(readableDuration4, 1603);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        long long10 = skipUndoDateTimeField4.add(0L, (long) 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField13, (int) 'a');
        java.util.Locale locale16 = null;
        int int17 = skipUndoDateTimeField15.getMaximumTextLength(locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.withZone(dateTimeZone20);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField15.getAsText((org.joda.time.ReadablePartial) localTime22, 9, locale24);
        int[] intArray27 = null;
        try {
            int[] intArray29 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) localTime22, 2563, intArray27, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000000L + "'", long10 == 3155760000000L);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9" + "'", str25.equals("9"));
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfHalfday();
//        java.lang.String str3 = julianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.secondOfMinute();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
//        java.lang.String str7 = julianChronology0.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str7.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(366);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute((-292275054), 331);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        java.util.Locale locale8 = null;
//        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
//        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
//        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
//        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
//        org.joda.time.DurationField durationField42 = julianChronology35.days();
//        org.joda.time.DurationField durationField43 = julianChronology35.months();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = julianChronology46.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField(chronology45, dateTimeField47, (int) 'a');
//        long long52 = skipUndoDateTimeField49.add((long) 0, (long) 7);
//        int int54 = skipUndoDateTimeField49.get((long) 366);
//        int int55 = skipUndoDateTimeField49.getMinimumValue();
//        java.lang.String str56 = skipUndoDateTimeField49.getName();
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime58.withZone(dateTimeZone59);
//        java.lang.String str61 = dateTime58.toString();
//        org.joda.time.DateTime dateTime63 = dateTime58.withYearOfEra(366);
//        org.joda.time.DateTime.Property property64 = dateTime63.minuteOfDay();
//        org.joda.time.LocalTime localTime65 = dateTime63.toLocalTime();
//        int int66 = skipUndoDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) localTime65);
//        java.util.Locale locale68 = null;
//        try {
//            java.lang.String str69 = unsupportedDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localTime65, 100, locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(julianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
//        org.junit.Assert.assertNotNull(julianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 220924800000L + "'", long52 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-292269054) + "'", int55 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "year" + "'", str56.equals("year"));
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "-47326-02-26T03:39:17.550-07:52:58" + "'", str61.equals("-47326-02-26T03:39:17.550-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(localTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-292269054) + "'", int66 == (-292269054));
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 1560342705542L, 45104);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 45104");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundHalfCeiling((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        int int8 = skipDateTimeField4.getMaximumValue((long) '#');
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipDateTimeField4.getAsShortText((long) 366, locale10);
//        long long14 = skipDateTimeField4.add((long) (-1), 100L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Wed" + "'", str11.equals("Wed"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 8639999999L + "'", long14 == 8639999999L);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
        org.joda.time.DurationField durationField17 = julianChronology0.millis();
        org.joda.time.Chronology chronology18 = julianChronology0.withUTC();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property27 = dateTime26.hourOfDay();
        org.joda.time.DateTime dateTime28 = dateTime26.withTimeAtStartOfDay();
        org.joda.time.ReadableInstant readableInstant29 = null;
        boolean boolean30 = dateTime28.isAfter(readableInstant29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.plus(readablePeriod31);
        try {
            org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime20, (org.joda.time.ReadableDateTime) dateTime28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime32);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, chronology8, locale9, (java.lang.Integer) 9);
//        int int12 = dateTimeParserBucket11.getOffset();
//        long long15 = dateTimeParserBucket11.computeMillis(false, "7");
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800010L + "'", long15 == 28800010L);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((-292269054));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269054 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addMillis((int) (byte) 0);
        mutableDateTime1.setYear(271);
        org.joda.time.DateTimeZone dateTimeZone6 = mutableDateTime1.getZone();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        long long10 = skipUndoDateTimeField4.add(0L, (long) 100);
//        int int11 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField4.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
//        java.lang.String str17 = dateTime14.toString();
//        org.joda.time.DateTime dateTime19 = dateTime14.withYearOfEra(366);
//        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfDay();
//        org.joda.time.LocalTime localTime21 = dateTime19.toLocalTime();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField25, (int) 'a');
//        long long30 = skipUndoDateTimeField27.add((long) 0, (long) 7);
//        int int31 = skipUndoDateTimeField27.getMinimumValue();
//        long long34 = skipUndoDateTimeField27.set(3155760000000L, 4);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.withZone(dateTimeZone37);
//        org.joda.time.LocalTime localTime39 = dateTime38.toLocalTime();
//        boolean boolean40 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime39);
//        int[] intArray48 = new int[] { 331, 331, 4, 960, 1602, 1 };
//        int[] intArray50 = skipUndoDateTimeField27.add((org.joda.time.ReadablePartial) localTime39, 4, intArray48, (int) ' ');
//        java.util.Locale locale52 = null;
//        try {
//            int[] intArray53 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime21, (-292269054), intArray48, "Property[minuteOfDay]", locale52);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[minuteOfDay]\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000000L + "'", long10 == 3155760000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292269054) + "'", int11 == (-292269054));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-47326-02-26T03:39:18.378-07:52:58" + "'", str17.equals("-47326-02-26T03:39:18.378-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(localTime21);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 220924800000L + "'", long30 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-292269054) + "'", int31 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62042285222000L) + "'", long34 == (-62042285222000L));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(intArray50);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) ' ', true, (long) (short) -1);
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date10 = mutableDateTime9.toDate();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
//        int int15 = dateTime12.getMinuteOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime12.plusHours((int) '4');
//        mutableDateTime9.setMillis((org.joda.time.ReadableInstant) dateTime17);
//        try {
//            org.joda.time.DateTime dateTime22 = dateTime17.withDate((int) (short) 10, (int) '4', 2563);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 219 + "'", int15 == 219);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (-292269054), true);
        java.util.TimeZone timeZone10 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-292269054L) + "'", long9 == (-292269054L));
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property5.add((-33735053220031L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -33735053220031");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        mutableDateTime1.addHours((int) (byte) 100);
        mutableDateTime1.setSecondOfDay(1023);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        mutableDateTime1.setMinuteOfDay(1);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        long long6 = durationField3.subtract(0L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        long long13 = offsetDateTimeField11.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField11.getAsText((long) 3, locale15);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19, (int) 'a');
//        java.util.Locale locale22 = null;
//        int int23 = skipUndoDateTimeField21.getMaximumTextLength(locale22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.withZone(dateTimeZone26);
//        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField21.getAsText((org.joda.time.ReadablePartial) localTime28, 9, locale30);
//        int[] intArray33 = new int[] { (short) 100 };
//        int int34 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) localTime28, intArray33);
//        boolean boolean35 = offsetDateTimeField11.isSupported();
//        long long37 = offsetDateTimeField11.roundHalfFloor((long) '#');
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60481942502000L) + "'", long13 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2563" + "'", str16.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localTime28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9" + "'", str31.equals("9"));
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3042 + "'", int34 == 3042);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.yearOfEra();
//        java.lang.String str7 = mutableDateTime4.toString();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str7.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.DateTime.Property property11 = dateTime9.property(dateTimeFieldType10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
//        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
//        long long19 = skipUndoDateTimeField11.set((long) 3, (-47326));
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZone(dateTimeZone22);
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        boolean boolean25 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localTime24, 9, locale27);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1555631914021997L) + "'", long19 == (-1555631914021997L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9" + "'", str28.equals("9"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        try {
            int int46 = unsupportedDateTimeField44.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.year();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.year();
        org.joda.time.MutableDateTime mutableDateTime9 = property8.roundHalfFloor();
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "Wednesday", 0);
        int int13 = mutableDateTime9.getSecondOfMinute();
        mutableDateTime9.setMillis((long) 271);
        mutableDateTime9.addMillis(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getShortName((long) 331, locale13);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 10, 2, 1023, 3042, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3042 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours(7);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int9 = skipUndoDateTimeField4.get((long) 366);
//        int int10 = skipUndoDateTimeField4.getMinimumValue();
//        java.lang.String str11 = skipUndoDateTimeField4.getName();
//        long long13 = skipUndoDateTimeField4.roundHalfEven((-1555626601676148L));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269054) + "'", int10 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1555630762022000L) + "'", long13 == (-1555630762022000L));
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass7 = gJChronology6.getClass();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 100, (int) '4', 0, 0, 3042, (int) 'a', (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3042 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        java.util.Locale locale8 = null;
//        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
//        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
//        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
//        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
//        org.joda.time.DurationField durationField42 = julianChronology35.days();
//        org.joda.time.DurationField durationField43 = julianChronology35.months();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.withZone(dateTimeZone47);
//        java.lang.String str49 = dateTime46.toString();
//        org.joda.time.DateTime dateTime51 = dateTime46.withYearOfEra(366);
//        org.joda.time.DateTime.Property property52 = dateTime51.minuteOfDay();
//        org.joda.time.LocalTime localTime53 = dateTime51.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime55.withZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime59 = dateTime57.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime61 = dateTime59.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property62 = dateTime59.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField63 = property62.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, 1603);
//        long long67 = offsetDateTimeField65.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = offsetDateTimeField65.getAsText((long) 3, locale69);
//        org.joda.time.Chronology chronology71 = null;
//        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField73 = julianChronology72.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField75 = new org.joda.time.field.SkipUndoDateTimeField(chronology71, dateTimeField73, (int) 'a');
//        java.util.Locale locale76 = null;
//        int int77 = skipUndoDateTimeField75.getMaximumTextLength(locale76);
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime(dateTimeZone78);
//        org.joda.time.DateTimeZone dateTimeZone80 = null;
//        org.joda.time.DateTime dateTime81 = dateTime79.withZone(dateTimeZone80);
//        org.joda.time.LocalTime localTime82 = dateTime81.toLocalTime();
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = skipUndoDateTimeField75.getAsText((org.joda.time.ReadablePartial) localTime82, 9, locale84);
//        int[] intArray87 = new int[] { (short) 100 };
//        int int88 = offsetDateTimeField65.getMaximumValue((org.joda.time.ReadablePartial) localTime82, intArray87);
//        try {
//            int int89 = unsupportedDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localTime53, intArray87);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(julianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "-47326-02-26T03:39:19.266-07:52:58" + "'", str49.equals("-47326-02-26T03:39:19.266-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(localTime53);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-60481942502000L) + "'", long67 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2563" + "'", str70.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 9 + "'", int77 == 9);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertNotNull(localTime82);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "9" + "'", str85.equals("9"));
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 3042 + "'", int88 == 3042);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) '4');
        try {
            mutableDateTime7.setTime(0, 0, 219, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 219 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant1.plus(readableDuration3);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((-1555630762022000L), 1603);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        java.lang.String str13 = offsetDateTimeField11.getAsText(220924800000L);
//        java.lang.String str15 = offsetDateTimeField11.getAsShortText((long) 'a');
//        int int16 = offsetDateTimeField11.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2563" + "'", str13.equals("2563"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2563" + "'", str15.equals("2563"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1603 + "'", int16 == 1603);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField6 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField7 = julianChronology0.centuries();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = gJChronology0.getClass();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        try {
            long long10 = gJChronology0.getDateTimeMillis(292272992, (int) (byte) -1, 3, (int) 'a', 57600, 10, 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.minus(readablePeriod8);
        java.util.Date date10 = dateTime3.toDate();
        org.joda.time.DateTime dateTime12 = dateTime3.withMillisOfSecond(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.year();
        org.joda.time.MutableDateTime mutableDateTime18 = property16.set((int) '4');
        org.joda.time.MutableDateTime mutableDateTime19 = property16.roundHalfFloor();
        boolean boolean20 = dateTimeParserBucket10.restoreState((java.lang.Object) property16);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology23.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology21.millisOfDay();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField30, (int) 'a');
        long long35 = skipUndoDateTimeField32.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField32, 331);
        boolean boolean38 = skipDateTimeField37.isLenient();
        int int40 = skipDateTimeField37.getMinimumValue((long) 2000);
        dateTimeParserBucket10.saveField((org.joda.time.DateTimeField) skipDateTimeField37, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 220924800000L + "'", long35 == 220924800000L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292269054) + "'", int40 == (-292269054));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMillisOfSecond(52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(331);
//        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
//        int int8 = dateTime7.getMonthOfYear();
//        boolean boolean10 = dateTime7.isBefore(28800000L);
//        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(366);
//        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        dateTimeParserBucket10.setOffset((-292275054));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        dateTimeParserBucket10.saveField(dateTimeFieldType20, 2000);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass24 = gJChronology23.getClass();
        org.joda.time.DurationField durationField25 = gJChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField25);
        try {
            long long29 = unsupportedDateTimeField26.add(28800010L, 3120685421025L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 3120685421025 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
//        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
//        int int8 = skipUndoDateTimeField4.getMinimumValue();
//        long long11 = skipUndoDateTimeField4.set(3155760000000L, 4);
//        int int12 = skipUndoDateTimeField4.getMinimumValue();
//        java.lang.String str13 = skipUndoDateTimeField4.toString();
//        long long16 = skipUndoDateTimeField4.add(2440588L, (-1));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292269054) + "'", int8 == (-292269054));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62042285222000L) + "'", long11 == (-62042285222000L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292269054) + "'", int12 == (-292269054));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[year]" + "'", str13.equals("DateTimeField[year]"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31533559412L) + "'", long16 == (-31533559412L));
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        java.util.Locale locale46 = null;
        try {
            int int47 = unsupportedDateTimeField44.getMaximumShortTextLength(locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekOfWeekyear" + "'", str45.equals("weekOfWeekyear"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField11.getAsText(readablePartial12, 101, locale14);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField11.getWrappedField();
        try {
            long long19 = offsetDateTimeField11.set((long) 2000, "2019-06-12T05:31:46.169-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:31:46.169-07:00\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        try {
            int int46 = unsupportedDateTimeField44.getMinimumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.addWrapField((int) (byte) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay((-28800000), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long14 = fixedDateTimeZone12.convertUTCToLocal((long) '#');
        long long17 = fixedDateTimeZone12.adjustOffset(0L, false);
        long long19 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone12, (long) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(220924800000L, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) 'a');
        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfDay();
        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy(960);
        org.joda.time.DateTime dateTime28 = property24.setCopy("219");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField11.getAsText(readablePartial12, 101, locale14);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField11.getWrappedField();
//        long long18 = offsetDateTimeField11.remainder((long) 1602);
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology19, dateTimeField22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.withZone(dateTimeZone26);
//        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
//        boolean boolean29 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime28);
//        int[] intArray31 = null;
//        int[] intArray33 = skipDateTimeField23.addWrapPartial((org.joda.time.ReadablePartial) localTime28, 1603, intArray31, 0);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localTime28, locale34);
//        try {
//            long long38 = offsetDateTimeField11.set((long) 4, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for minuteOfDay must be in the range [1603,3042]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1602L + "'", long18 == 1602L);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNull(intArray33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "219" + "'", str35.equals("219"));
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology7.millisOfDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16, (int) 'a');
        long long21 = skipUndoDateTimeField18.add((long) 0, (long) 7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField18, 331);
        org.joda.time.DateTime dateTime24 = dateTime6.toDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTime.Property property25 = dateTime6.dayOfWeek();
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 220924800000L + "'", long21 == 220924800000L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.year();
        org.joda.time.DurationField durationField9 = julianChronology7.minutes();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology7.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((int) '#', (int) 'a', (int) (short) 10, 3042, (int) '4', 0, 7, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3042 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Class<?> wildcardClass2 = gJChronology1.getClass();
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology5, dateTimeField8);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int int11 = skipDateTimeField9.getMinimumValue(readablePartial10);
//        boolean boolean12 = skipDateTimeField9.isLenient();
//        java.lang.String str14 = skipDateTimeField9.getAsText((long) (short) 10);
//        mutableDateTime4.setRounding((org.joda.time.DateTimeField) skipDateTimeField9);
//        org.joda.time.DurationField durationField16 = skipDateTimeField9.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wednesday" + "'", str14.equals("Wednesday"));
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField44.getDurationField();
        try {
            int int47 = unsupportedDateTimeField44.getLeapAmount((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1603, chronology12);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long22 = fixedDateTimeZone18.convertLocalToUTC((long) ' ', true, (long) (short) -1);
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone18);
//        java.util.Date date24 = mutableDateTime23.toDate();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZone(dateTimeZone27);
//        int int29 = dateTime26.getMinuteOfDay();
//        org.joda.time.DateTime dateTime31 = dateTime26.plusHours((int) '4');
//        mutableDateTime23.setMillis((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.MutableDateTime mutableDateTime33 = mutableDateTime23.toMutableDateTime();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology2, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) mutableDateTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 32L + "'", long22 == 32L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 219 + "'", int29 == 219);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime12 = dateTime1.withChronology((org.joda.time.Chronology) buddhistChronology10);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime12.withTime((int) (short) 100, (int) '4', 219, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear(2000, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder7.appendFractionOfMinute((int) '4', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTimeZoneShortName(strMap17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.appendTimeZoneShortName(strMap17);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        boolean boolean10 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime9);
        int[] intArray12 = null;
        int[] intArray14 = skipDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localTime9, 1603, intArray12, 0);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = skipDateTimeField4.getAsText(1439, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1439");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(intArray14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        dateTimeParserBucket10.setOffset((-292275054));
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("2019-06-12T05:31:45.337-07:00");
        java.lang.String str15 = jodaTimePermission14.getName();
        boolean boolean16 = dateTimeParserBucket10.restoreState((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-12T05:31:45.337-07:00" + "'", str15.equals("2019-06-12T05:31:45.337-07:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfMonth((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Saturday");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology1.year();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = skipDateTimeField4.getMinimumValue(readablePartial5);
//        boolean boolean7 = skipDateTimeField4.isLenient();
//        java.lang.String str9 = skipDateTimeField4.getAsText((long) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZone(dateTimeZone12);
//        java.lang.String str14 = dateTime11.toString();
//        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfEra(366);
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
//        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField21, (int) 'a');
//        long long26 = skipUndoDateTimeField23.add((long) 0, (long) 7);
//        int int28 = skipUndoDateTimeField23.get((long) 366);
//        int int29 = skipUndoDateTimeField23.getMinimumValue();
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime38 = dateTime36.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property39 = dateTime36.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, 1603);
//        long long44 = offsetDateTimeField42.roundHalfCeiling((-60481942504213L));
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField42.getAsText((long) 3, locale46);
//        org.joda.time.Chronology chronology48 = null;
//        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = julianChronology49.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology48, dateTimeField50, (int) 'a');
//        java.util.Locale locale53 = null;
//        int int54 = skipUndoDateTimeField52.getMaximumTextLength(locale53);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = dateTime56.withZone(dateTimeZone57);
//        org.joda.time.LocalTime localTime59 = dateTime58.toLocalTime();
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = skipUndoDateTimeField52.getAsText((org.joda.time.ReadablePartial) localTime59, 9, locale61);
//        int[] intArray64 = new int[] { (short) 100 };
//        int int65 = offsetDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localTime59, intArray64);
//        int int66 = skipUndoDateTimeField23.getMaximumValue(readablePartial30, intArray64);
//        int int67 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18, intArray64);
//        org.joda.time.DurationField durationField68 = skipDateTimeField4.getLeapDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wednesday" + "'", str9.equals("Wednesday"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-47326-02-26T03:39:21.668-07:52:58" + "'", str14.equals("-47326-02-26T03:39:21.668-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 220924800000L + "'", long26 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292269054) + "'", int29 == (-292269054));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-60481942502000L) + "'", long44 == (-60481942502000L));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2563" + "'", str47.equals("2563"));
//        org.junit.Assert.assertNotNull(julianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localTime59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9" + "'", str62.equals("9"));
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3042 + "'", int65 == 3042);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 292272992 + "'", int66 == 292272992);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNull(durationField68);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone14);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.year();
//        org.joda.time.MutableDateTime mutableDateTime18 = property16.set((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.roundHalfFloor();
//        boolean boolean20 = dateTimeParserBucket10.restoreState((java.lang.Object) property16);
//        java.lang.Object obj21 = dateTimeParserBucket10.saveState();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Class<?> wildcardClass24 = gJChronology23.getClass();
//        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology23.getZone();
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime(1560342704861L, dateTimeZone25);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology27, dateTimeField30);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        int int33 = skipDateTimeField31.getMinimumValue(readablePartial32);
//        boolean boolean34 = skipDateTimeField31.isLenient();
//        java.lang.String str36 = skipDateTimeField31.getAsText((long) (short) 10);
//        mutableDateTime26.setRounding((org.joda.time.DateTimeField) skipDateTimeField31);
//        dateTimeParserBucket10.saveField((org.joda.time.DateTimeField) skipDateTimeField31, 52);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wednesday" + "'", str36.equals("Wednesday"));
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.yearOfEra();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.millisOfDay();
        org.joda.time.DurationField durationField13 = julianChronology7.weekyears();
        org.joda.time.DurationField durationField14 = julianChronology7.days();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology7.millisOfDay();
        org.joda.time.Chronology chronology17 = julianChronology7.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology18, dateTimeField21);
        org.joda.time.DateTimeField dateTimeField23 = julianChronology18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology18.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology18.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField26);
        boolean boolean28 = property6.equals((java.lang.Object) skipUndoDateTimeField27);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long15 = fixedDateTimeZone13.convertUTCToLocal((long) '#');
//        long long19 = fixedDateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) 1);
//        org.joda.time.DateTime dateTime20 = dateTime3.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusMonths((int) '4');
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime20.withMillisOfSecond(45104);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45104 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1555626601659852L) + "'", long4 == (-1555626601659852L));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField11.getAsText(readablePartial12, 101, locale14);
        int int16 = offsetDateTimeField11.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3042 + "'", int16 == 3042);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1555631914021997L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5564411504884224E7d) + "'", double1 == (-1.5564411504884224E7d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getLeapDurationField();
        long long14 = offsetDateTimeField11.roundHalfEven((long) 57600);
        int int15 = offsetDateTimeField11.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 60000L + "'", long14 == 60000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1603 + "'", int15 == 1603);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, (int) 'a');
        long long7 = skipUndoDateTimeField4.add((long) 0, (long) 7);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        java.lang.String str11 = skipUndoDateTimeField4.getAsShortText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("1970");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendMillisOfSecond(52);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType29);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, (int) (short) -1, (int) (short) 10, 9);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.millisOfDay();
        org.joda.time.DurationField durationField41 = julianChronology35.weekyears();
        org.joda.time.DurationField durationField42 = julianChronology35.days();
        org.joda.time.DurationField durationField43 = julianChronology35.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField43);
        try {
            long long47 = unsupportedDateTimeField44.set((long) 271, 387);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 220924800000L + "'", long7 == 220924800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        mutableDateTime7.setMillisOfDay((int) 'a');
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) mutableDateTime7);
        boolean boolean12 = gregorianChronology0.equals((java.lang.Object) (-1.0f));
        java.lang.String str13 = gregorianChronology0.toString();
        try {
            long long18 = gregorianChronology0.getDateTimeMillis((int) '#', 100, 57600, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(10L, (-1));
//        boolean boolean10 = dateTime6.isAfterNow();
//        org.joda.time.DateTime dateTime11 = dateTime6.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 219 + "'", int4 == 219);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, (int) 'a');
//        long long14 = skipUndoDateTimeField11.add((long) 0, (long) 7);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 331);
//        long long19 = skipDateTimeField16.getDifferenceAsLong(1L, (long) 0);
//        long long22 = skipDateTimeField16.set(0L, 3);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 220924800000L + "'", long14 == 220924800000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62042285222000L) + "'", long22 == (-62042285222000L));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        long long4 = dateTime3.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
//        long long15 = fixedDateTimeZone13.convertUTCToLocal((long) '#');
//        long long19 = fixedDateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) 1);
//        org.joda.time.DateTime dateTime20 = dateTime3.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime22 = dateTime3.withEra(101);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 101 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1555626601659409L) + "'", long4 == (-1555626601659409L));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) '#');
        long long17 = fixedDateTimeZone11.convertLocalToUTC((long) (byte) 0, false, (long) 1);
        int int19 = fixedDateTimeZone11.getOffset(1560342704861L);
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((-292269054), (int) '4', (-47326), 4, 271, (-292269054), 18, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 271 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime5.plus((long) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        mutableDateTime8.add(readablePeriod9, 331);
        mutableDateTime8.setMillisOfDay((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, dateTimeField17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology14.millisOfDay();
        org.joda.time.DurationField durationField20 = julianChronology14.weekyears();
        org.joda.time.DurationField durationField21 = julianChronology14.days();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology14.millisOfDay();
        org.joda.time.Chronology chronology24 = julianChronology14.withUTC();
        mutableDateTime8.setChronology(chronology24);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 0, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(1560342704861L, (org.joda.time.Chronology) julianChronology2, locale9);
        dateTimeParserBucket10.setOffset((-292275054));
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology13, dateTimeField16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology13.millisOfDay();
        org.joda.time.DurationField durationField19 = julianChronology13.weekyears();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology13.getZone();
        dateTimeParserBucket10.setZone(dateTimeZone20);
        dateTimeParserBucket10.setOffset((int) (short) -1);
        org.joda.time.Chronology chronology24 = dateTimeParserBucket10.getChronology();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:31:42.993-07:00");
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = mutableDateTime1.toCalendar(locale2);
        mutableDateTime1.addYears((-292275054));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(calendar3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) '#');
        long long9 = fixedDateTimeZone4.adjustOffset(0L, false);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology11 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) buddhistChronology10, chronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.halfdays();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 101L, (java.lang.Number) 2563, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField11.getWrappedField();
//        long long16 = offsetDateTimeField11.roundHalfEven(0L);
//        java.lang.String str18 = offsetDateTimeField11.getAsShortText((long) 1969);
//        int int19 = offsetDateTimeField11.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2563" + "'", str18.equals("2563"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1603 + "'", int19 == 1603);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 1603);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField11.getWrappedField();
        long long16 = offsetDateTimeField11.roundHalfEven(0L);
        int int18 = offsetDateTimeField11.getLeapAmount((long) 271);
        long long20 = offsetDateTimeField11.roundHalfEven((long) 100);
        boolean boolean21 = offsetDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0, 0);
        dateTimeParserBucket6.setOffset((java.lang.Integer) 366);
        long long11 = dateTimeParserBucket6.computeMillis(false, "11:59:08 PM -07:52:58");
        dateTimeParserBucket6.setOffset((java.lang.Integer) (-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long20 = fixedDateTimeZone18.convertUTCToLocal((long) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "2019-06-12T05:31:42.623-07:00", (int) (short) 0, (int) (byte) 100);
        long long27 = fixedDateTimeZone25.convertUTCToLocal((long) '#');
        long long30 = fixedDateTimeZone25.adjustOffset(0L, false);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone25, (long) (short) 100);
        java.util.TimeZone timeZone33 = fixedDateTimeZone25.toTimeZone();
        long long35 = fixedDateTimeZone25.previousTransition(0L);
        java.lang.String str37 = fixedDateTimeZone25.getNameKey((-1595503694458L));
        boolean boolean38 = fixedDateTimeZone25.isFixed();
        dateTimeParserBucket6.setZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-357L) + "'", long11 == (-357L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019-06-12T05:31:42.623-07:00" + "'", str37.equals("2019-06-12T05:31:42.623-07:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.year();
        int int6 = property5.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime8 = property5.roundHalfCeiling();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology12, locale13, (java.lang.Integer) 0, 0);
        dateTimeParserBucket16.setOffset((java.lang.Integer) 366);
        long long21 = dateTimeParserBucket16.computeMillis(false, "11:59:08 PM -07:52:58");
        java.util.Locale locale22 = dateTimeParserBucket16.getLocale();
        try {
            org.joda.time.MutableDateTime mutableDateTime23 = property5.set("-47326-02-26T03:39:11.357-07:52:58", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-47326-02-26T03:39:11.357-07:52:58\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-357L) + "'", long21 == (-357L));
        org.junit.Assert.assertNotNull(locale22);
    }
}

