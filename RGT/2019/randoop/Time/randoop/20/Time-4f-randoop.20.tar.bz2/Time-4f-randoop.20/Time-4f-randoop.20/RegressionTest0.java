import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 10, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) 0.0f, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField2 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (short) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (byte) 1, (java.lang.Number) 1560639719054L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 1, (java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 100, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((-1.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) (-1), (java.lang.Number) 62L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.io.Writer writer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant(obj2);
        org.joda.time.Instant instant4 = instant3.toInstant();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        try {
            long long9 = iSOChronology0.getDateTimeMillis(0, (int) (byte) 0, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType5, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, (int) (short) -1, 4, (int) (short) 1, 0, (int) (short) 10, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.Partial partial3 = new org.joda.time.Partial(dateTimeFieldType0, (int) (byte) 10, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        org.joda.time.Instant instant2 = instant1.toInstant();
//        long long3 = instant1.getMillis();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        try {
//            int int5 = instant1.get(dateTimeFieldType4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560639720502L + "'", long3 == 1560639720502L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', 1, (int) (byte) 100, 1, (int) (byte) 100, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 0, (int) (short) 1);
        try {
            long long11 = gJChronology3.getDateTimeMillis((int) (short) 0, (int) (short) 10, (int) ' ', (int) (short) 1, (int) (short) 0, (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) -1, (int) (short) 0, (int) (byte) 1, 1, (int) (short) 100, (int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
//        boolean boolean18 = iSOChronology15.equals((java.lang.Object) periodType16);
//        java.lang.String str19 = iSOChronology15.toString();
//        org.joda.time.DurationField durationField20 = iSOChronology15.years();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, durationField20, dateTimeFieldType21, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter6, dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray6 = new int[] { (short) 1, '#', (short) -1, 'a' };
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("19691231", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"19691231/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        try {
            org.joda.time.Partial partial5 = new org.joda.time.Partial(dateTimeFieldType0, (int) (short) 0, chronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime2.withEra((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57723 + "'", int4 == 57723);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        boolean boolean3 = instant1.isEqual((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTime dateTime10 = instant1.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(0);
        int int13 = dateTime10.getEra();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField14, (int) (byte) 100, 100, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfHalfday must be in the range [100,10]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray15 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder7.append(dateTimePrinter14, dateTimeParserArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeParserArray15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Chronology chronology0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant(obj1);
        boolean boolean4 = instant2.isEqual((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime11 = instant2.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.util.Locale locale12 = null;
        java.util.Calendar calendar13 = dateTime11.toCalendar(locale12);
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        try {
            org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime11, readableDateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(calendar13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneOffset("19691231", false, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        try {
            long long20 = limitChronology4.getDateTimeMillis(4, 57722, (int) (byte) 10, 57722);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57722 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1560639722730L, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType22 = null;
//        org.joda.time.PeriodType periodType23 = org.joda.time.DateTimeUtils.getPeriodType(periodType22);
//        boolean boolean24 = iSOChronology21.equals((java.lang.Object) periodType22);
//        java.lang.String str25 = iSOChronology21.toString();
//        org.joda.time.DurationField durationField26 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology21.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType29 = null;
//        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        boolean boolean31 = iSOChronology28.equals((java.lang.Object) periodType29);
//        java.lang.String str32 = iSOChronology28.toString();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology28.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology21, dateTimeField34);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType37 = null;
//        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType37);
//        boolean boolean39 = iSOChronology36.equals((java.lang.Object) periodType37);
//        java.lang.String str40 = iSOChronology36.toString();
//        org.joda.time.DurationField durationField41 = iSOChronology36.years();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology36.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType44 = null;
//        org.joda.time.PeriodType periodType45 = org.joda.time.DateTimeUtils.getPeriodType(periodType44);
//        boolean boolean46 = iSOChronology43.equals((java.lang.Object) periodType44);
//        java.lang.String str47 = iSOChronology43.toString();
//        org.joda.time.DurationField durationField48 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology36, dateTimeField49);
//        org.joda.time.Partial partial51 = new org.joda.time.Partial();
//        java.lang.Object obj52 = null;
//        boolean boolean53 = partial51.equals(obj52);
//        boolean boolean55 = partial51.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = skipUndoDateTimeField50.getAsShortText((org.joda.time.ReadablePartial) partial51, (int) (short) -1, locale57);
//        int[] intArray65 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int66 = skipUndoDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) partial51, intArray65);
//        try {
//            int[] intArray68 = skipUndoDateTimeField14.add(readablePartial19, 10, intArray65, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str25.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str32.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str40.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(periodType45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str47.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "-1" + "'", str58.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        boolean boolean4 = partial0.equals((java.lang.Object) 2440588L);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial0.withFieldAddWrapped(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        try {
//            java.lang.String str24 = partial15.toString("ISOChronology[America/Los_Angeles]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime5.plusYears((int) (byte) 10);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        boolean boolean13 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipUndoDateTimeField14.getAsText((long) 4, locale20);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField14, 57725, (int) (byte) 10, (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57725 for hourOfHalfday must be in the range [10,-1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4" + "'", str21.equals("4"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long6 = julianChronology0.getDateTimeMillis(57721, (int) '#', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        try {
            long long11 = limitChronology4.getDateTimeMillis((int) (byte) 1, (int) (byte) 100, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.append(dateTimeParser14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = skipUndoDateTimeField14.getAsText(readablePartial23, 0, locale25);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = julianChronology3.seconds();
        org.joda.time.DurationField durationField6 = julianChronology3.millis();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField6, dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.io.Writer writer1 = null;
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        java.lang.Object obj3 = null;
        boolean boolean4 = partial2.equals(obj3);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) partial2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.setCopy("10");
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.LocalDate.Property property13 = localDate11.property(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology12 = localDate11.getChronology();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) periodType15);
//        java.lang.String str18 = iSOChronology14.toString();
//        org.joda.time.DurationField durationField19 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 1);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField22.getAsShortText(1, locale24);
//        org.joda.time.Partial partial26 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType28 = null;
//        org.joda.time.PeriodType periodType29 = org.joda.time.DateTimeUtils.getPeriodType(periodType28);
//        boolean boolean30 = iSOChronology27.equals((java.lang.Object) periodType28);
//        java.lang.String str31 = iSOChronology27.toString();
//        org.joda.time.DurationField durationField32 = iSOChronology27.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology27.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType35 = null;
//        org.joda.time.PeriodType periodType36 = org.joda.time.DateTimeUtils.getPeriodType(periodType35);
//        boolean boolean37 = iSOChronology34.equals((java.lang.Object) periodType35);
//        java.lang.String str38 = iSOChronology34.toString();
//        org.joda.time.DurationField durationField39 = iSOChronology34.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology34.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology27, dateTimeField40);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType43 = null;
//        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType43);
//        boolean boolean45 = iSOChronology42.equals((java.lang.Object) periodType43);
//        java.lang.String str46 = iSOChronology42.toString();
//        org.joda.time.DurationField durationField47 = iSOChronology42.years();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology42.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType50 = null;
//        org.joda.time.PeriodType periodType51 = org.joda.time.DateTimeUtils.getPeriodType(periodType50);
//        boolean boolean52 = iSOChronology49.equals((java.lang.Object) periodType50);
//        java.lang.String str53 = iSOChronology49.toString();
//        org.joda.time.DurationField durationField54 = iSOChronology49.years();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology49.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField55);
//        org.joda.time.Partial partial57 = new org.joda.time.Partial();
//        java.lang.Object obj58 = null;
//        boolean boolean59 = partial57.equals(obj58);
//        boolean boolean61 = partial57.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = skipUndoDateTimeField56.getAsShortText((org.joda.time.ReadablePartial) partial57, (int) (short) -1, locale63);
//        int[] intArray71 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int72 = skipUndoDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) partial57, intArray71);
//        int int73 = offsetDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) partial26, intArray71);
//        java.util.Locale locale75 = null;
//        try {
//            int[] intArray76 = offsetDateTimeField8.set((org.joda.time.ReadablePartial) localDate11, 57729, intArray71, "UTC", locale75);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str31.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(periodType36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str38.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(periodType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str46.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(periodType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str53.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "-1" + "'", str64.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        org.joda.time.DurationField durationField19 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField14, durationField19, dateTimeFieldType20, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) 2019, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.LocalDate localDate12 = property9.setCopy("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        try {
//            org.joda.time.DateTime dateTime32 = property30.addToCopy((long) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis((int) (byte) 1);
//        long long5 = dateTime4.getMillis();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560639730754L + "'", long5 == 1560639730754L);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int int24 = skipUndoDateTimeField14.getMinimumValue(readablePartial23);
//        org.joda.time.Partial partial25 = new org.joda.time.Partial();
//        int[] intArray26 = partial25.getValues();
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) partial25, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 10, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        try {
//            org.joda.time.Partial partial25 = partial15.withField(dateTimeFieldType23, 57729);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 57722);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 0, 100, 57725, 2019, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundFloor((long) (short) 1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.Date date27 = localDate26.toDate();
//        org.joda.time.LocalDate.Property property28 = localDate26.yearOfCentury();
//        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType32 = null;
//        org.joda.time.PeriodType periodType33 = org.joda.time.DateTimeUtils.getPeriodType(periodType32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) periodType32);
//        java.lang.String str35 = iSOChronology31.toString();
//        org.joda.time.DurationField durationField36 = iSOChronology31.years();
//        boolean boolean37 = localDate30.equals((java.lang.Object) durationField36);
//        int[] intArray40 = new int[] { 57723 };
//        try {
//            int[] intArray42 = skipUndoDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localDate30, (int) (short) 0, intArray40, 57721);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str35.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(intArray40);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology4.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName((long) 57721);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.setCopy("10");
        try {
            org.joda.time.LocalDate localDate13 = property9.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfYear(1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((-57724));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        boolean boolean2 = localDate0.isSupported(dateTimeFieldType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, (long) 57721);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 577210L + "'", long2 == 577210L);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
//        boolean boolean20 = iSOChronology17.equals((java.lang.Object) periodType18);
//        java.lang.String str21 = iSOChronology17.toString();
//        org.joda.time.DurationField durationField22 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology17, dateTimeField30);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType33 = null;
//        org.joda.time.PeriodType periodType34 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
//        boolean boolean35 = iSOChronology32.equals((java.lang.Object) periodType33);
//        java.lang.String str36 = iSOChronology32.toString();
//        org.joda.time.DurationField durationField37 = iSOChronology32.years();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology32.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType40 = null;
//        org.joda.time.PeriodType periodType41 = org.joda.time.DateTimeUtils.getPeriodType(periodType40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) periodType40);
//        java.lang.String str43 = iSOChronology39.toString();
//        org.joda.time.DurationField durationField44 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology39.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology32, dateTimeField45);
//        org.joda.time.Partial partial47 = new org.joda.time.Partial();
//        java.lang.Object obj48 = null;
//        boolean boolean49 = partial47.equals(obj48);
//        boolean boolean51 = partial47.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = skipUndoDateTimeField46.getAsShortText((org.joda.time.ReadablePartial) partial47, (int) (short) -1, locale53);
//        int[] intArray61 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int62 = skipUndoDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) partial47, intArray61);
//        java.util.Locale locale63 = null;
//        try {
//            java.lang.String str64 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) partial47, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str21.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str36.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(periodType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str43.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "-1" + "'", str54.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumShortTextLength(locale7);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        java.lang.Object obj2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant(obj2);
        org.joda.time.Instant instant4 = instant3.toInstant();
        boolean boolean5 = instant1.isAfter((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant7 = instant1.minus((long) (-1));
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        try {
            java.lang.String str10 = dateTime8.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType24 = null;
//        org.joda.time.PeriodType periodType25 = org.joda.time.DateTimeUtils.getPeriodType(periodType24);
//        boolean boolean26 = iSOChronology23.equals((java.lang.Object) periodType24);
//        java.lang.String str27 = iSOChronology23.toString();
//        org.joda.time.DurationField durationField28 = iSOChronology23.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = offsetDateTimeField31.getAsShortText(1, locale33);
//        org.joda.time.Partial partial35 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType37 = null;
//        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType37);
//        boolean boolean39 = iSOChronology36.equals((java.lang.Object) periodType37);
//        java.lang.String str40 = iSOChronology36.toString();
//        org.joda.time.DurationField durationField41 = iSOChronology36.years();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology36.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType44 = null;
//        org.joda.time.PeriodType periodType45 = org.joda.time.DateTimeUtils.getPeriodType(periodType44);
//        boolean boolean46 = iSOChronology43.equals((java.lang.Object) periodType44);
//        java.lang.String str47 = iSOChronology43.toString();
//        org.joda.time.DurationField durationField48 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology36, dateTimeField49);
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType52 = null;
//        org.joda.time.PeriodType periodType53 = org.joda.time.DateTimeUtils.getPeriodType(periodType52);
//        boolean boolean54 = iSOChronology51.equals((java.lang.Object) periodType52);
//        java.lang.String str55 = iSOChronology51.toString();
//        org.joda.time.DurationField durationField56 = iSOChronology51.years();
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology51.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType59 = null;
//        org.joda.time.PeriodType periodType60 = org.joda.time.DateTimeUtils.getPeriodType(periodType59);
//        boolean boolean61 = iSOChronology58.equals((java.lang.Object) periodType59);
//        java.lang.String str62 = iSOChronology58.toString();
//        org.joda.time.DurationField durationField63 = iSOChronology58.years();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology58.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology51, dateTimeField64);
//        org.joda.time.Partial partial66 = new org.joda.time.Partial();
//        java.lang.Object obj67 = null;
//        boolean boolean68 = partial66.equals(obj67);
//        boolean boolean70 = partial66.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = skipUndoDateTimeField65.getAsShortText((org.joda.time.ReadablePartial) partial66, (int) (short) -1, locale72);
//        int[] intArray80 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int81 = skipUndoDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) partial66, intArray80);
//        int int82 = offsetDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) partial35, intArray80);
//        java.util.Locale locale83 = null;
//        try {
//            java.lang.String str84 = skipUndoDateTimeField20.getAsText((org.joda.time.ReadablePartial) partial35, locale83);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str27.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str40.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(periodType45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str47.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(periodType53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str55.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(periodType60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str62.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "-1" + "'", str73.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isAfterNow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.StringBuffer stringBuffer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant(obj2);
        java.lang.Object obj4 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant(obj4);
        org.joda.time.Instant instant6 = instant5.toInstant();
        boolean boolean7 = instant3.isAfter((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Instant instant9 = instant3.minus((long) (-1));
        org.joda.time.DateTime dateTime10 = instant9.toDateTimeISO();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.setCopy("10");
        try {
            java.lang.String str13 = localDate11.toString("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
//        boolean boolean18 = iSOChronology15.equals((java.lang.Object) periodType16);
//        java.lang.String str19 = iSOChronology15.toString();
//        org.joda.time.DurationField durationField20 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology15.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType23 = null;
//        org.joda.time.PeriodType periodType24 = org.joda.time.DateTimeUtils.getPeriodType(periodType23);
//        boolean boolean25 = iSOChronology22.equals((java.lang.Object) periodType23);
//        java.lang.String str26 = iSOChronology22.toString();
//        org.joda.time.DurationField durationField27 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology22.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology15, dateTimeField28);
//        org.joda.time.Partial partial30 = new org.joda.time.Partial();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = partial30.equals(obj31);
//        boolean boolean34 = partial30.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = skipUndoDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) partial30, (int) (short) -1, locale36);
//        int[] intArray44 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int45 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) partial30, intArray44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
//        try {
//            org.joda.time.Partial partial48 = partial30.withField(dateTimeFieldType46, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str26.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-1" + "'", str37.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        int int11 = offsetDateTimeField8.getMinimumValue();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField8.getAsText(0L, locale13);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5" + "'", str14.equals("5"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (byte) -1, (int) (byte) -1, 2019);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime9.minusMonths((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime19 = dateTime9.withSecondOfMinute((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfWeek();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.years();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology6, readableDateTime8, readableDateTime9);
        org.joda.time.DurationField durationField11 = limitChronology10.millis();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, durationField11, dateTimeFieldType12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        try {
            long long10 = julianChronology0.getDateTimeMillis((int) (short) 1, 0, 57734, 57729, 10, 4, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57729 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.util.Date date20 = localDate19.toDate();
        int int21 = property9.compareTo((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.ReadablePartial readablePartial22 = null;
        try {
            boolean boolean23 = localDate19.isBefore(readablePartial22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType4 = partial0.getFieldType(57726);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57726");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField6 = iSOChronology5.years();
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology5, readableDateTime7, readableDateTime8);
//        boolean boolean11 = limitChronology9.equals((java.lang.Object) (-1.0f));
//        java.lang.String str12 = limitChronology9.toString();
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(4, 0, 57734, (int) ' ', 57725, (org.joda.time.Chronology) limitChronology9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(limitChronology9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]" + "'", str12.equals("LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]"));
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType11 = null;
//        org.joda.time.PeriodType periodType12 = org.joda.time.DateTimeUtils.getPeriodType(periodType11);
//        boolean boolean13 = iSOChronology10.equals((java.lang.Object) periodType11);
//        java.lang.String str14 = iSOChronology10.toString();
//        org.joda.time.DurationField durationField15 = iSOChronology10.years();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology10.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
//        boolean boolean20 = iSOChronology17.equals((java.lang.Object) periodType18);
//        java.lang.String str21 = iSOChronology17.toString();
//        org.joda.time.DurationField durationField22 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType26 = null;
//        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType26);
//        boolean boolean28 = iSOChronology25.equals((java.lang.Object) periodType26);
//        java.lang.String str29 = iSOChronology25.toString();
//        org.joda.time.DurationField durationField30 = iSOChronology25.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology25.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType33 = null;
//        org.joda.time.PeriodType periodType34 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
//        boolean boolean35 = iSOChronology32.equals((java.lang.Object) periodType33);
//        java.lang.String str36 = iSOChronology32.toString();
//        org.joda.time.DurationField durationField37 = iSOChronology32.years();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology32.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology25, dateTimeField38);
//        org.joda.time.Partial partial40 = new org.joda.time.Partial();
//        java.lang.Object obj41 = null;
//        boolean boolean42 = partial40.equals(obj41);
//        boolean boolean44 = partial40.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = skipUndoDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) partial40, (int) (short) -1, locale46);
//        int[] intArray54 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int55 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) partial40, intArray54);
//        org.joda.time.Chronology chronology56 = partial40.getChronology();
//        try {
//            int int57 = localDate7.compareTo((org.joda.time.ReadablePartial) partial40);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str14.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str21.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str29.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str36.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "-1" + "'", str47.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(chronology56);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str10 = fixedDateTimeZone5.getName((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, 57722);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57722");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int13 = fixedDateTimeZone11.getOffsetFromLocal(100L);
        int int15 = fixedDateTimeZone11.getOffset(2440588L);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 0, 10, 0, 2019, 10, 57723, (int) '4', (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        try {
//            org.joda.time.DateTime dateTime32 = property30.setCopy((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        boolean boolean3 = instant1.isEqual((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTime dateTime10 = instant1.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        java.util.Locale locale11 = null;
//        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.DurationField durationField20 = iSOChronology13.weeks();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology13.yearOfEra();
//        java.lang.String str22 = iSOChronology13.toString();
//        org.joda.time.DateTime dateTime23 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DurationFieldType durationFieldType24 = null;
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime23.withFieldAdded(durationFieldType24, 1000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(calendar12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str22.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField7 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.halfdayOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str7 = dateTime2.toString(dateTimeFormatter6);
//        java.util.Locale locale9 = null;
//        try {
//            java.lang.String str10 = dateTime2.toString("LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]", locale9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: L");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57735 + "'", int4 == 57735);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "16:02" + "'", str7.equals("16:02"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        try {
            long long18 = limitChronology4.getDateTimeMillis(6, 4, 57723, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57723 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = dateTime14.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        int[] intArray3 = partial2.getValues();
        org.joda.time.Chronology chronology4 = null;
        try {
            org.joda.time.Partial partial5 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray3, chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.Appendable appendable3 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int10 = fixedDateTimeZone8.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.util.Date date12 = localDate11.toDate();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology1 = localDate0.getChronology();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = julianChronology3.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology3.getZone();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone6);
        int int8 = localDate7.getDayOfWeek();
        org.joda.time.DateTime dateTime9 = localDate7.toDateTimeAtMidnight();
        int int10 = localDate7.size();
        int int11 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate7);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        java.lang.Object obj32 = null;
//        org.joda.time.Instant instant33 = new org.joda.time.Instant(obj32);
//        boolean boolean35 = instant33.isEqual((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone40);
//        org.joda.time.DateTime dateTime42 = instant33.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone40);
//        java.util.Locale locale43 = null;
//        java.util.Calendar calendar44 = dateTime42.toCalendar(locale43);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType46 = null;
//        org.joda.time.PeriodType periodType47 = org.joda.time.DateTimeUtils.getPeriodType(periodType46);
//        boolean boolean48 = iSOChronology45.equals((java.lang.Object) periodType46);
//        java.lang.String str49 = iSOChronology45.toString();
//        org.joda.time.DurationField durationField50 = iSOChronology45.years();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology45.hourOfHalfday();
//        org.joda.time.DurationField durationField52 = iSOChronology45.weeks();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology45.yearOfEra();
//        java.lang.String str54 = iSOChronology45.toString();
//        org.joda.time.DateTime dateTime55 = dateTime42.withChronology((org.joda.time.Chronology) iSOChronology45);
//        try {
//            long long56 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime55);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(copticChronology41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(calendar44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(periodType47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str49.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str54.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime55);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        org.joda.time.ReadablePartial readablePartial3 = null;
//        try {
//            java.lang.String str4 = dateTimeFormatter0.print(readablePartial3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19691231" + "'", str2.equals("19691231"));
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfSecond();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2019, 57726, (-1), 2, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57726 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        java.io.Writer writer3 = null;
        java.lang.Object obj4 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant(obj4);
        boolean boolean7 = instant5.isEqual((long) (short) -1);
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) instant5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType5, (-57724), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        int int5 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime2.withField(dateTimeFieldType6, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57737 + "'", int4 == 57737);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57737 + "'", int5 == 57737);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.millis();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology4.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withWeekyear((int) '4');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) 0, true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        int int10 = localDate7.getEra();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DurationField durationField16 = limitChronology15.centuries();
        try {
            long long21 = limitChronology15.getDateTimeMillis(0, 6, 57721, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57721 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        try {
            long long11 = julianChronology0.getDateTimeMillis(3, (int) (short) 1, (-57730), 0, (-57724), (int) (byte) -1, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57724 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getRangeDurationField();
//        java.lang.String str13 = offsetDateTimeField8.getName();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone18);
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(localDate19);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField23, dateTimeFieldType24, 0, 1000, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
//        int int32 = dateTime31.getMillisOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 83222000 + "'", int32 == 83222000);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("+00:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.setCopy("10");
        java.util.Locale locale12 = null;
        int int13 = property9.getMaximumShortTextLength(locale12);
        java.lang.Object obj14 = null;
        org.joda.time.Instant instant15 = new org.joda.time.Instant(obj14);
        boolean boolean17 = instant15.isEqual((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTime dateTime24 = instant15.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
        try {
            int int26 = property9.compareTo((org.joda.time.ReadablePartial) yearMonthDay25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendFraction(dateTimeFieldType4, (int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) 57722);
//        long long13 = offsetDateTimeField8.add((long) (byte) 100, 97L);
//        long long15 = offsetDateTimeField8.roundHalfFloor(1560639738869L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 349200100L + "'", long13 == 349200100L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560639600000L + "'", long15 == 1560639600000L);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) 57722);
//        long long13 = offsetDateTimeField8.add((long) (byte) 100, 97L);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = julianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology15.getZone();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone18);
//        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType24 = null;
//        org.joda.time.PeriodType periodType25 = org.joda.time.DateTimeUtils.getPeriodType(periodType24);
//        boolean boolean26 = iSOChronology23.equals((java.lang.Object) periodType24);
//        java.lang.String str27 = iSOChronology23.toString();
//        org.joda.time.DurationField durationField28 = iSOChronology23.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
//        boolean boolean33 = iSOChronology30.equals((java.lang.Object) periodType31);
//        java.lang.String str34 = iSOChronology30.toString();
//        org.joda.time.DurationField durationField35 = iSOChronology30.years();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology30.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology23, dateTimeField36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType39 = null;
//        org.joda.time.PeriodType periodType40 = org.joda.time.DateTimeUtils.getPeriodType(periodType39);
//        boolean boolean41 = iSOChronology38.equals((java.lang.Object) periodType39);
//        java.lang.String str42 = iSOChronology38.toString();
//        org.joda.time.DurationField durationField43 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology38.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType46 = null;
//        org.joda.time.PeriodType periodType47 = org.joda.time.DateTimeUtils.getPeriodType(periodType46);
//        boolean boolean48 = iSOChronology45.equals((java.lang.Object) periodType46);
//        java.lang.String str49 = iSOChronology45.toString();
//        org.joda.time.DurationField durationField50 = iSOChronology45.years();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology45.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField51);
//        org.joda.time.Partial partial53 = new org.joda.time.Partial();
//        java.lang.Object obj54 = null;
//        boolean boolean55 = partial53.equals(obj54);
//        boolean boolean57 = partial53.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = skipUndoDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) partial53, (int) (short) -1, locale59);
//        int[] intArray67 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int68 = skipUndoDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) partial53, intArray67);
//        try {
//            int[] intArray70 = offsetDateTimeField8.add((org.joda.time.ReadablePartial) localDate21, (int) 'a', intArray67, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 349200100L + "'", long13 == 349200100L);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str27.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str34.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str42.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(periodType47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str49.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "-1" + "'", str60.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
//        long long16 = dateTime14.getMillis();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639739636L + "'", long16 == 1560639739636L);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = julianChronology1.add(readablePeriod3, (long) 57729, 19);
        org.joda.time.Chronology chronology7 = julianChronology1.withUTC();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(chronology7);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime(chronology7);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 57729L + "'", long6 == 57729L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology5.getZone();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime5.plusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime();
        org.joda.time.Instant instant11 = dateTime5.toInstant();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = julianChronology12.add(readablePeriod14, (long) 57729, 19);
        org.joda.time.Chronology chronology18 = julianChronology12.withUTC();
        org.joda.time.MutableDateTime mutableDateTime19 = instant11.toMutableDateTime(chronology18);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 57729L + "'", long17 == 57729L);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getName((long) (-1), locale22);
        org.joda.time.DateTime dateTime24 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.DateTime dateTime27 = dateTime24.withFieldAdded(durationFieldType25, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        try {
            long long11 = limitChronology4.getDateTimeMillis((int) (byte) 10, 57723, 70, (-57730));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57730 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1560639739636L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        boolean boolean4 = partial0.equals((java.lang.Object) 2440588L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.Partial.Property property6 = partial0.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        java.util.Locale locale30 = null;
//        int int31 = skipUndoDateTimeField20.getMaximumTextLength(locale30);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("19691231");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) -1, "19691231");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (byte) -1, "19691231");
        java.lang.String str6 = illegalInstantException5.toString();
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray8 = illegalInstantException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = illegalInstantException5.getSuppressed();
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        try {
            int int8 = localDate5.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 52");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute(4);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.DateTime dateTime20 = dateTime17.withField(dateTimeFieldType18, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57741 + "'", int4 == 57741);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        boolean boolean16 = offsetDateTimeField9.isLeap((long) (-57724));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int23 = fixedDateTimeZone21.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        org.joda.time.Chronology chronology25 = localDate24.getChronology();
//        java.util.Locale locale26 = null;
//        try {
//            java.lang.String str27 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate24, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 100, true);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(julianChronology9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.setCopy("10");
        java.util.Locale locale13 = null;
        try {
            org.joda.time.LocalDate localDate14 = property9.setCopy("UTC", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        try {
//            org.joda.time.DateTime dateTime33 = property30.addToCopy((long) 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long9 = julianChronology0.getDateTimeMillis((int) (short) 100, (int) 'a', (int) (short) 10, 3, 0, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
        org.joda.time.LocalDate localDate16 = localDate7.withFields((org.joda.time.ReadablePartial) localDate15);
        int int17 = localDate16.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfHalfday();
        try {
            long long14 = copticChronology5.getDateTimeMillis((int) (short) -1, 57726, 57721, (int) '4', (int) (byte) 10, (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        java.util.Locale locale11 = null;
//        int int12 = offsetDateTimeField8.getMaximumShortTextLength(locale11);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder7.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        try {
            long long10 = limitChronology4.getDateTimeMillis(97L, 3, 1970, 57721, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long13 = copticChronology5.getDateTimeMillis(0, 57721, (int) (short) -1, 57725, 4, 100, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57725 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        java.lang.String str13 = property9.getAsShortText();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "19" + "'", str13.equals("19"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
        int int8 = property7.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(57734);
        boolean boolean20 = dateTime19.isEqualNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        int[] intArray3 = partial2.getValues();
        try {
            org.joda.time.Partial partial4 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.withDayOfMonth(10);
        org.joda.time.LocalDate localDate5 = localDate3.minusWeeks((int) (short) -1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560639745460L + "'", long0 == 1560639745460L);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        try {
//            int int24 = partial15.get(dateTimeFieldType23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate.Property property7 = localDate5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        long long9 = durationField6.subtract((long) (-57724), (long) 57721);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-151791667679724L) + "'", long9 == (-151791667679724L));
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.weekyear();
        try {
            long long16 = copticChronology5.getDateTimeMillis(2, 1, 1, 1970, 0, 0, 57725);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.Chronology chronology26 = julianChronology24.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology24.getZone();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone27);
//        int int29 = localDate28.getDayOfWeek();
//        org.joda.time.DateTime dateTime30 = localDate28.toDateTimeAtMidnight();
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate28, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        boolean boolean3 = instant1.isEqual((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTime dateTime10 = instant1.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        long long11 = instant1.getMillis();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.Instant instant13 = instant1.plus(readableDuration12);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560639746276L + "'", long11 == 1560639746276L);
//        org.junit.Assert.assertNotNull(instant13);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(57734);
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) '4');
        try {
            org.joda.time.DateTime dateTime26 = dateTime21.withTime(1, 57745, 11, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57745 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int23 = fixedDateTimeZone21.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        java.util.Date date25 = localDate24.toDate();
//        org.joda.time.LocalDate.Property property26 = localDate24.yearOfCentury();
//        org.joda.time.LocalDate localDate28 = property26.addToCopy(0);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
//        boolean boolean33 = iSOChronology30.equals((java.lang.Object) periodType31);
//        java.lang.String str34 = iSOChronology30.toString();
//        org.joda.time.DurationField durationField35 = iSOChronology30.years();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology30.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType38 = null;
//        org.joda.time.PeriodType periodType39 = org.joda.time.DateTimeUtils.getPeriodType(periodType38);
//        boolean boolean40 = iSOChronology37.equals((java.lang.Object) periodType38);
//        java.lang.String str41 = iSOChronology37.toString();
//        org.joda.time.DurationField durationField42 = iSOChronology37.years();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology37.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology30, dateTimeField43);
//        org.joda.time.Partial partial45 = new org.joda.time.Partial();
//        java.lang.Object obj46 = null;
//        boolean boolean47 = partial45.equals(obj46);
//        boolean boolean49 = partial45.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = skipUndoDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) partial45, (int) (short) -1, locale51);
//        int[] intArray53 = partial45.getValues();
//        try {
//            int[] intArray55 = skipUndoDateTimeField14.set((org.joda.time.ReadablePartial) localDate28, 0, intArray53, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str34.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str41.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-1" + "'", str52.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray53);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        boolean boolean3 = instant1.isAfter(0L);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(1560639738869L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        boolean boolean3 = instant1.isEqual((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTime dateTime10 = instant1.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        java.util.Locale locale11 = null;
//        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.DurationField durationField20 = iSOChronology13.weeks();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology13.yearOfEra();
//        java.lang.String str22 = iSOChronology13.toString();
//        org.joda.time.DateTime dateTime23 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DurationFieldType durationFieldType24 = null;
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime10.withFieldAdded(durationFieldType24, 57746);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(calendar12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str22.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        long long16 = julianChronology11.add(readablePeriod13, (long) 57729, 19);
//        org.joda.time.Chronology chronology17 = julianChronology11.withUTC();
//        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(chronology17);
//        int[] intArray19 = null;
//        int int20 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate18, intArray19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int27 = fixedDateTimeZone25.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        java.util.Date date29 = localDate28.toDate();
//        org.joda.time.LocalDate.Property property30 = localDate28.yearOfCentury();
//        org.joda.time.Partial partial32 = new org.joda.time.Partial();
//        int[] intArray33 = partial32.getValues();
//        try {
//            int[] intArray35 = offsetDateTimeField8.set((org.joda.time.ReadablePartial) localDate28, (int) ' ', intArray33, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 57729L + "'", long16 == 57729L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField14.getWrappedField();
//        int int17 = skipUndoDateTimeField14.getMinimumValue(349200100L);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType21 = null;
//        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) periodType21);
//        java.lang.String str24 = iSOChronology20.toString();
//        org.joda.time.DurationField durationField25 = iSOChronology20.years();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology20.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 1);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField28.getAsShortText(1, locale30);
//        org.joda.time.Partial partial32 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.PeriodType periodType35 = org.joda.time.DateTimeUtils.getPeriodType(periodType34);
//        boolean boolean36 = iSOChronology33.equals((java.lang.Object) periodType34);
//        java.lang.String str37 = iSOChronology33.toString();
//        org.joda.time.DurationField durationField38 = iSOChronology33.years();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology33.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType41 = null;
//        org.joda.time.PeriodType periodType42 = org.joda.time.DateTimeUtils.getPeriodType(periodType41);
//        boolean boolean43 = iSOChronology40.equals((java.lang.Object) periodType41);
//        java.lang.String str44 = iSOChronology40.toString();
//        org.joda.time.DurationField durationField45 = iSOChronology40.years();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology40.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology33, dateTimeField46);
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType49 = null;
//        org.joda.time.PeriodType periodType50 = org.joda.time.DateTimeUtils.getPeriodType(periodType49);
//        boolean boolean51 = iSOChronology48.equals((java.lang.Object) periodType49);
//        java.lang.String str52 = iSOChronology48.toString();
//        org.joda.time.DurationField durationField53 = iSOChronology48.years();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology48.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType56 = null;
//        org.joda.time.PeriodType periodType57 = org.joda.time.DateTimeUtils.getPeriodType(periodType56);
//        boolean boolean58 = iSOChronology55.equals((java.lang.Object) periodType56);
//        java.lang.String str59 = iSOChronology55.toString();
//        org.joda.time.DurationField durationField60 = iSOChronology55.years();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology55.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology48, dateTimeField61);
//        org.joda.time.Partial partial63 = new org.joda.time.Partial();
//        java.lang.Object obj64 = null;
//        boolean boolean65 = partial63.equals(obj64);
//        boolean boolean67 = partial63.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = skipUndoDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) partial63, (int) (short) -1, locale69);
//        int[] intArray77 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int78 = skipUndoDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) partial63, intArray77);
//        int int79 = offsetDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) partial32, intArray77);
//        try {
//            int[] intArray81 = skipUndoDateTimeField14.addWrapPartial(readablePartial18, (-1), intArray77, 57729);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(periodType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str37.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(periodType42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str44.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(periodType50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str52.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(periodType57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str59.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "-1" + "'", str70.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 57746, (int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withDayOfMonth(1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = julianChronology4.withZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology4.getZone();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone7);
//        int int9 = localDate8.getDayOfWeek();
//        org.joda.time.DateTime dateTime10 = localDate8.toDateTimeAtMidnight();
//        int int11 = localDate8.size();
//        org.joda.time.DateTime dateTime12 = localDate8.toDateTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate14 = localDate8.plusWeeks(0);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
//        boolean boolean18 = iSOChronology15.equals((java.lang.Object) periodType16);
//        java.lang.String str19 = iSOChronology15.toString();
//        org.joda.time.DurationField durationField20 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology15.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType23 = null;
//        org.joda.time.PeriodType periodType24 = org.joda.time.DateTimeUtils.getPeriodType(periodType23);
//        boolean boolean25 = iSOChronology22.equals((java.lang.Object) periodType23);
//        java.lang.String str26 = iSOChronology22.toString();
//        org.joda.time.DurationField durationField27 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology22.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology15, dateTimeField28);
//        org.joda.time.Partial partial30 = new org.joda.time.Partial();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = partial30.equals(obj31);
//        boolean boolean34 = partial30.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = skipUndoDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) partial30, (int) (short) -1, locale36);
//        int[] intArray38 = partial30.getValues();
//        try {
//            julianChronology0.validate((org.joda.time.ReadablePartial) localDate8, intArray38);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str26.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-1" + "'", str37.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray38);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-61851571622000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-57730), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-577300) + "'", int2 == (-577300));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        try {
            long long11 = julianChronology0.getDateTimeMillis(1000, 4, (int) (byte) 10, 13, 70, 20, 57726);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        long long2 = instant1.getMillis();
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
//        org.joda.time.Chronology chronology4 = instant1.getChronology();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560639747574L + "'", long2 == 1560639747574L);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField7 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
//        java.lang.String str9 = iSOChronology0.toString();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        try {
//            int[] intArray13 = iSOChronology0.get(readablePeriod10, 101L, 1560639730754L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str9.equals("ISOChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        long long2 = instant1.getMillis();
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
//        boolean boolean4 = mutableDateTime3.isBeforeNow();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560639747812L + "'", long2 == 1560639747812L);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1560639730754L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.year();
//        java.util.Locale locale34 = null;
//        try {
//            org.joda.time.DateTime dateTime35 = property32.setCopy("160000.001-0800", locale34);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"160000.001-0800\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10, 57746, 57725, 57729, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57729 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int8 = fixedDateTimeZone6.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 1);
//        try {
//            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("6");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "160000.001-0800" + "'", str2.equals("160000.001-0800"));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate11 = localDate5.plusWeeks(0);
        int int12 = localDate11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getRangeDurationField();
//        java.lang.String str13 = offsetDateTimeField8.getName();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField8.getAsText((int) (byte) 10, locale15);
//        long long18 = offsetDateTimeField8.roundHalfCeiling((long) (short) -1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        java.lang.Object obj2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant(obj2);
        org.joda.time.Instant instant4 = instant3.toInstant();
        boolean boolean5 = instant1.isAfter((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant7 = instant1.minus((long) (-1));
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        int int5 = dateTime3.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime3.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str8 = dateTime3.toString(dateTimeFormatter7);
//        try {
//            org.joda.time.Instant instant9 = org.joda.time.Instant.parse("AD", dateTimeFormatter7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57748 + "'", int5 == 57748);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "16:02" + "'", str8.equals("16:02"));
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        try {
            org.joda.time.LocalDate localDate11 = localDate7.withYearOfEra((-577300));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -577300 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int int11 = localDate5.compareTo(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.util.Date date20 = localDate19.toDate();
        int int21 = property9.compareTo((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.LocalDate.Property property22 = localDate19.weekyear();
        org.joda.time.LocalDate localDate23 = property22.withMinimumValue();
        int int24 = property22.getMinimumValueOverall();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292275054) + "'", int24 == (-292275054));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        int int18 = localDate15.size();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) 'a');
//        org.joda.time.DateTime dateTime27 = localDate15.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        int int28 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate15);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int35 = fixedDateTimeZone33.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone33);
//        java.util.Date date37 = localDate36.toDate();
//        org.joda.time.LocalDate.Property property38 = localDate36.yearOfCentury();
//        org.joda.time.LocalDate localDate40 = property38.addToCopy(0);
//        org.joda.time.LocalDate localDate41 = property38.roundHalfCeilingCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType44 = null;
//        org.joda.time.PeriodType periodType45 = org.joda.time.DateTimeUtils.getPeriodType(periodType44);
//        boolean boolean46 = iSOChronology43.equals((java.lang.Object) periodType44);
//        java.lang.String str47 = iSOChronology43.toString();
//        org.joda.time.DurationField durationField48 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType51 = null;
//        org.joda.time.PeriodType periodType52 = org.joda.time.DateTimeUtils.getPeriodType(periodType51);
//        boolean boolean53 = iSOChronology50.equals((java.lang.Object) periodType51);
//        java.lang.String str54 = iSOChronology50.toString();
//        org.joda.time.DurationField durationField55 = iSOChronology50.years();
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology50.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology43, dateTimeField56);
//        org.joda.time.Partial partial58 = new org.joda.time.Partial();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = partial58.equals(obj59);
//        boolean boolean62 = partial58.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = skipUndoDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) partial58, (int) (short) -1, locale64);
//        int[] intArray66 = partial58.getValues();
//        try {
//            int[] intArray68 = offsetDateTimeField8.set((org.joda.time.ReadablePartial) localDate41, 2, intArray66, (-292275054));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(copticChronology24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(periodType45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str47.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(periodType52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str54.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "-1" + "'", str65.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray66);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTimeField dateTimeField23 = limitChronology4.weekyear();
//        org.joda.time.Chronology chronology24 = limitChronology4.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime9.minusMonths((int) (byte) 10);
        org.joda.time.Chronology chronology18 = dateTime9.getChronology();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("10");
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((-1));
        int int4 = dateTime1.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int15 = fixedDateTimeZone13.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.lang.String str18 = fixedDateTimeZone13.getName((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        boolean boolean20 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.joda.time.DurationField durationField4 = julianChronology0.centuries();
        org.joda.time.DurationField durationField5 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1560639747574L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getRangeDurationField();
//        java.lang.String str13 = offsetDateTimeField8.getName();
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        org.joda.time.DurationField durationField16 = offsetDateTimeField8.getLeapDurationField();
//        long long18 = offsetDateTimeField8.roundHalfFloor((long) 57734);
//        int int20 = offsetDateTimeField8.getMaximumValue(1560639722730L);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '#', 1, 13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfHalfday must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (-57730), true);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 1560639746276L, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28742270L + "'", long4 == 28742270L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType9 = null;
//        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
//        boolean boolean11 = iSOChronology8.equals((java.lang.Object) periodType9);
//        java.lang.String str12 = iSOChronology8.toString();
//        org.joda.time.DurationField durationField13 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField14);
//        org.joda.time.DateTimeField dateTimeField16 = skipUndoDateTimeField15.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField16, (-1));
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType19, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str12.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        long long16 = offsetDateTimeField9.roundHalfEven((-14400000L));
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getRangeDurationField();
//        boolean boolean19 = offsetDateTimeField9.isLeap((long) ' ');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-14400000L) + "'", long16 == (-14400000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 57729, 19);
        org.joda.time.Chronology chronology6 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 57729L + "'", long5 == 57729L);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.year();
//        org.joda.time.DateTime dateTime35 = dateTime31.withDurationAdded((long) (-57724), (int) '4');
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray3 = null;
        try {
            iSOChronology1.validate(readablePartial2, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology5.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, 4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal(100L);
        org.joda.time.Chronology chronology19 = gregorianChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.Chronology chronology20 = copticChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.lang.String str22 = fixedDateTimeZone16.getName((long) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.years();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology12);
        org.joda.time.DurationField durationField14 = limitChronology12.months();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) (byte) 0, (org.joda.time.Chronology) limitChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant2 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(instant2);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str7 = dateTime2.toString(dateTimeFormatter6);
//        org.joda.time.DateTime.Property property8 = dateTime2.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
//        java.util.Locale locale10 = null;
//        int int11 = property8.getMaximumShortTextLength(locale10);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57751 + "'", int4 == 57751);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "16:02" + "'", str7.equals("16:02"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        org.joda.time.Instant instant2 = instant1.toInstant();
//        long long3 = instant1.getMillis();
//        org.joda.time.Instant instant5 = instant1.minus((long) (short) 100);
//        org.joda.time.ReadableInterval readableInterval6 = null;
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
//        int int10 = dateTime8.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime8.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str13 = dateTime8.toString(dateTimeFormatter12);
//        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
//        boolean boolean16 = instant1.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560639751575L + "'", long3 == 1560639751575L);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57751 + "'", int10 == 57751);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "16:02" + "'", str13.equals("16:02"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime32 = property30.roundHalfFloorCopy();
//        java.lang.String str33 = property30.getAsString();
//        org.joda.time.DateTime dateTime34 = property30.withMaximumValue();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipUndoDateTimeField14.getAsText((long) 4, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField14.getAsText((int) (short) 1, locale23);
//        long long26 = skipUndoDateTimeField14.roundFloor((long) 100);
//        java.lang.String str27 = skipUndoDateTimeField14.toString();
//        int int28 = skipUndoDateTimeField14.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4" + "'", str21.equals("4"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str27.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.Partial partial12 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType21 = null;
//        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) periodType21);
//        java.lang.String str24 = iSOChronology20.toString();
//        org.joda.time.DurationField durationField25 = iSOChronology20.years();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology20.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType29 = null;
//        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        boolean boolean31 = iSOChronology28.equals((java.lang.Object) periodType29);
//        java.lang.String str32 = iSOChronology28.toString();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology28.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType36 = null;
//        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
//        boolean boolean38 = iSOChronology35.equals((java.lang.Object) periodType36);
//        java.lang.String str39 = iSOChronology35.toString();
//        org.joda.time.DurationField durationField40 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology35.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology28, dateTimeField41);
//        org.joda.time.Partial partial43 = new org.joda.time.Partial();
//        java.lang.Object obj44 = null;
//        boolean boolean45 = partial43.equals(obj44);
//        boolean boolean47 = partial43.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipUndoDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) partial43, (int) (short) -1, locale49);
//        int[] intArray57 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int58 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) partial43, intArray57);
//        int int59 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) partial12, intArray57);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone64 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int66 = fixedDateTimeZone64.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone64);
//        java.util.Date date68 = localDate67.toDate();
//        org.joda.time.LocalDate.Property property69 = localDate67.yearOfCentury();
//        org.joda.time.LocalDate localDate71 = property69.addToCopy((int) (byte) 10);
//        int[] intArray75 = new int[] { (-577300), 0 };
//        try {
//            int[] intArray77 = offsetDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate71, 57734, intArray75, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57734");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str32.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str39.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertNotNull(intArray75);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        int int3 = dateTime1.getEra();
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 57746, (int) (byte) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withCenturyOfEra(0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        long long16 = offsetDateTimeField9.roundHalfEven((-14400000L));
//        org.joda.time.Partial partial17 = new org.joda.time.Partial();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = partial17.equals(obj18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.Partial partial21 = partial17.plus(readablePeriod20);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType24 = null;
//        org.joda.time.PeriodType periodType25 = org.joda.time.DateTimeUtils.getPeriodType(periodType24);
//        boolean boolean26 = iSOChronology23.equals((java.lang.Object) periodType24);
//        java.lang.String str27 = iSOChronology23.toString();
//        org.joda.time.DurationField durationField28 = iSOChronology23.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
//        boolean boolean33 = iSOChronology30.equals((java.lang.Object) periodType31);
//        java.lang.String str34 = iSOChronology30.toString();
//        org.joda.time.DurationField durationField35 = iSOChronology30.years();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology30.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology23, dateTimeField36);
//        org.joda.time.Partial partial38 = new org.joda.time.Partial();
//        java.lang.Object obj39 = null;
//        boolean boolean40 = partial38.equals(obj39);
//        boolean boolean42 = partial38.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = skipUndoDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) partial38, (int) (short) -1, locale44);
//        int[] intArray46 = partial38.getValues();
//        java.util.Locale locale48 = null;
//        try {
//            int[] intArray49 = offsetDateTimeField9.set((org.joda.time.ReadablePartial) partial21, 0, intArray46, "UTC", locale48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-14400000L) + "'", long16 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(partial21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str27.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str34.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-1" + "'", str45.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray46);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int16 = fixedDateTimeZone12.getStandardOffset((-1L));
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.year();
//        org.joda.time.DateTime.Property property33 = dateTime31.weekyear();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property8 = dateTime7.year();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        java.lang.String str32 = property30.getAsShortText();
//        org.joda.time.DateTime dateTime33 = property30.roundHalfFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime35 = property30.setCopy((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AD" + "'", str32.equals("AD"));
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57754 + "'", int4 == 57754);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology1 = localDate0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) 57746);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) 0, (int) (short) 1);
//        java.lang.String str11 = gJChronology10.toString();
//        org.joda.time.Instant instant12 = gJChronology10.getGregorianCutover();
//        org.joda.time.Chronology chronology13 = gJChronology10.withUTC();
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(57722, (int) (short) 100, 20, (int) (byte) -1, 13, 11, (-1), chronology13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=1]" + "'", str11.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=1]"));
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.Chronology chronology4 = julianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology2.getZone();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone5);
//        int int7 = localDate6.getDayOfWeek();
//        org.joda.time.DateTime dateTime8 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime9 = null;
//        org.joda.time.DateTime dateTime10 = localDate6.toDateTime(localTime9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology12 = localDate11.getChronology();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(chronology12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
//        boolean boolean18 = iSOChronology15.equals((java.lang.Object) periodType16);
//        java.lang.String str19 = iSOChronology15.toString();
//        org.joda.time.DurationField durationField20 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology15.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 1);
//        boolean boolean24 = dateTime10.equals((java.lang.Object) dateTimeField21);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int31 = fixedDateTimeZone29.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        java.util.Date date33 = localDate32.toDate();
//        org.joda.time.LocalDate.Property property34 = localDate32.yearOfCentury();
//        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (byte) 10);
//        int int37 = property34.get();
//        org.joda.time.ReadableInterval readableInterval38 = null;
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(chronology39);
//        org.joda.time.DateTime dateTime42 = dateTime40.plusMillis((int) (byte) 1);
//        int int43 = property34.compareTo((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType44, (-11));
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField47 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 19 + "'", int37 == 19);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(57725, 57729, (-1), 0, 12, (-57724), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57724 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType2 = partial0.getFieldType(6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        int int13 = offsetDateTimeField8.getDifference(349200100L, 62L);
//        long long15 = offsetDateTimeField8.remainder((long) (byte) 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int10 = fixedDateTimeZone8.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate.Property property13 = localDate11.yearOfCentury();
        org.joda.time.LocalDate localDate15 = property13.addToCopy((int) (byte) 10);
        int int16 = property13.get();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
        org.joda.time.DateTime dateTime21 = dateTime19.plusMillis((int) (byte) 1);
        int int22 = property13.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 1.0f, "1970");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType23, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -292275054");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
        org.joda.time.TimeOfDay timeOfDay4 = dateTime2.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((-57724));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57724 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNotNull(timeOfDay4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        int int19 = property9.getLeapAmount();
        org.joda.time.LocalDate localDate20 = property9.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = localDate20.toDateTimeAtMidnight();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getRangeDurationField();
//        java.lang.String str13 = offsetDateTimeField8.getName();
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        try {
//            long long18 = offsetDateTimeField8.set(57729L, 57751);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57751 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial4 = partial0.plus(readablePeriod3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = partial4.getFormatter();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNull(dateTimeFormatter5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType13 = null;
//        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
//        boolean boolean15 = iSOChronology12.equals((java.lang.Object) periodType13);
//        java.lang.String str16 = iSOChronology12.toString();
//        org.joda.time.DurationField durationField17 = iSOChronology12.years();
//        boolean boolean18 = localDate11.equals((java.lang.Object) durationField17);
//        org.joda.time.LocalDate.Property property19 = localDate11.weekOfWeekyear();
//        org.joda.time.LocalDate localDate21 = property19.addToCopy((-1));
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        org.joda.time.DurationFieldType durationFieldType25 = null;
//        try {
//            org.joda.time.LocalDate localDate27 = localDate21.withFieldAdded(durationFieldType25, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str16.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
        org.joda.time.LocalDate localDate16 = localDate7.withFields((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate18 = localDate15.plusWeeks((int) '4');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate18.minus(readablePeriod19);
        try {
            org.joda.time.LocalDate localDate22 = localDate20.withEra(11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType12 = null;
//        org.joda.time.PeriodType periodType13 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
//        boolean boolean14 = iSOChronology11.equals((java.lang.Object) periodType12);
//        java.lang.String str15 = iSOChronology11.toString();
//        org.joda.time.DurationField durationField16 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) 1);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField19.getAsShortText(1, locale21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType32 = null;
//        org.joda.time.PeriodType periodType33 = org.joda.time.DateTimeUtils.getPeriodType(periodType32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) periodType32);
//        java.lang.String str35 = iSOChronology31.toString();
//        org.joda.time.DurationField durationField36 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology31.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology24, dateTimeField37);
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType40 = null;
//        org.joda.time.PeriodType periodType41 = org.joda.time.DateTimeUtils.getPeriodType(periodType40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) periodType40);
//        java.lang.String str43 = iSOChronology39.toString();
//        org.joda.time.DurationField durationField44 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology39.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType47 = null;
//        org.joda.time.PeriodType periodType48 = org.joda.time.DateTimeUtils.getPeriodType(periodType47);
//        boolean boolean49 = iSOChronology46.equals((java.lang.Object) periodType47);
//        java.lang.String str50 = iSOChronology46.toString();
//        org.joda.time.DurationField durationField51 = iSOChronology46.years();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology46.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology39, dateTimeField52);
//        org.joda.time.Partial partial54 = new org.joda.time.Partial();
//        java.lang.Object obj55 = null;
//        boolean boolean56 = partial54.equals(obj55);
//        boolean boolean58 = partial54.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = skipUndoDateTimeField53.getAsShortText((org.joda.time.ReadablePartial) partial54, (int) (short) -1, locale60);
//        int[] intArray68 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int69 = skipUndoDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) partial54, intArray68);
//        int int70 = offsetDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) partial23, intArray68);
//        int[] intArray71 = partial23.getValues();
//        int[] intArray78 = new int[] { 57734, (-577300), 4, (-11), ' ' };
//        java.util.Locale locale80 = null;
//        try {
//            int[] intArray81 = offsetDateTimeField8.set((org.joda.time.ReadablePartial) partial23, (int) (short) 10, intArray78, "Property[yearOfCentury]", locale80);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[yearOfCentury]\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str35.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(periodType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str43.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(periodType48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str50.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "-1" + "'", str61.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertNotNull(intArray78);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getName((long) (-1), locale22);
        org.joda.time.DateTime dateTime24 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMonths((int) '#');
        org.joda.time.DurationFieldType durationFieldType27 = null;
        try {
            org.joda.time.DateTime dateTime29 = dateTime24.withFieldAdded(durationFieldType27, (-577300));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        int int6 = localDate5.getDayOfWeek();
//        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
//        java.lang.String str8 = dateTime7.toString();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.000-08:00" + "'", str8.equals("1970-01-01T00:00:00.000-08:00"));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal(100L);
        org.joda.time.Chronology chronology12 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str13 = gregorianChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[+10:06]" + "'", str13.equals("GregorianChronology[+10:06]"));
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int7 = fixedDateTimeZone5.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        java.util.Date date9 = localDate8.toDate();
//        org.joda.time.LocalDate.Property property10 = localDate8.yearOfCentury();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.Chronology chronology14 = julianChronology12.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology12.getZone();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = localDate8.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.LocalDate localDate19 = localDate16.plusWeeks((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate19.minus(readablePeriod20);
//        long long23 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate19, (long) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        long long27 = iSOChronology0.add(readablePeriod24, 1560639751575L, 70);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31536000000L + "'", long23 == 31536000000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560639751575L + "'", long27 == 1560639751575L);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateMidnight dateMidnight18 = dateTime14.toDateMidnight();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        java.lang.String str4 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfCentury((int) '#', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        int int6 = localDate5.getDayOfWeek();
//        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology11 = localDate10.getChronology();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) periodType15);
//        java.lang.String str18 = iSOChronology14.toString();
//        org.joda.time.DurationField durationField19 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 1);
//        boolean boolean23 = dateTime9.equals((java.lang.Object) dateTimeField20);
//        org.joda.time.DateTime.Property property24 = dateTime9.secondOfDay();
//        int int25 = dateTime9.getDayOfYear();
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime9.withMillisOfDay((-57724));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57724 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        int[] intArray23 = partial15.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField32.getAsShortText(1, locale34);
//        org.joda.time.DurationField durationField36 = offsetDateTimeField32.getRangeDurationField();
//        java.lang.String str37 = offsetDateTimeField32.getName();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField32.getAsText((int) (byte) 10, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField32.getType();
//        try {
//            org.joda.time.Partial.Property property42 = partial15.property(dateTimeFieldType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1" + "'", str35.equals("1"));
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hourOfHalfday" + "'", str37.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.append(dateTimePrinter7, dateTimeParser8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str7 = dateTime2.toString(dateTimeFormatter6);
//        org.joda.time.LocalTime localTime8 = dateTime2.toLocalTime();
//        int int9 = dateTime2.getEra();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57758 + "'", int4 == 57758);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "16:02" + "'", str7.equals("16:02"));
//        org.junit.Assert.assertNotNull(localTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology5.secondOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology5, dateTimeField13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100, (org.joda.time.Chronology) limitChronology5);
//        org.joda.time.DateTime dateTime16 = limitChronology5.getUpperLimit();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(limitChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNull(dateTime16);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = julianChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology8.getZone();
        org.joda.time.DurationField durationField12 = julianChronology8.centuries();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime14 = dateTime7.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long16 = fixedDateTimeZone13.convertUTCToLocal((long) 'a');
        org.joda.time.DateTime dateTime17 = localDate5.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.LocalDate.Property property18 = localDate5.yearOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str20 = localDate5.toString(dateTimeFormatter19);
        java.lang.String str21 = localDate5.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01" + "'", str20.equals("1970-01"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01" + "'", str21.equals("1970-01-01"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DurationField durationField16 = limitChronology15.centuries();
        try {
            long long22 = limitChronology15.getDateTimeMillis((long) 10, 57745, (int) (short) -1, (int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-15T16:02:38.648-07:00 (LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(19);
        try {
            org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatterBuilder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 2019);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-57724), "-1");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (-57724), "-1");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray7 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.joda.time.DurationField durationField4 = julianChronology0.centuries();
        org.joda.time.DurationField durationField5 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime32 = property30.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime33 = property30.roundFloorCopy();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 100, 57722);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        int int19 = property9.getLeapAmount();
        org.joda.time.LocalDate localDate20 = property9.roundHalfEvenCopy();
        int int21 = localDate20.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfYear(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral('a');
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendTwoDigitYear(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((-577300));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType9 = null;
//        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
//        boolean boolean11 = iSOChronology8.equals((java.lang.Object) periodType9);
//        java.lang.String str12 = iSOChronology8.toString();
//        org.joda.time.DurationField durationField13 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField14);
//        org.joda.time.DateTimeField dateTimeField16 = skipUndoDateTimeField15.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField16, (-1));
//        int int20 = skipUndoDateTimeField18.get((long) (byte) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int27 = fixedDateTimeZone25.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        java.util.Date date29 = localDate28.toDate();
//        org.joda.time.LocalDate.Property property30 = localDate28.yearOfCentury();
//        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.PeriodType periodType35 = org.joda.time.DateTimeUtils.getPeriodType(periodType34);
//        boolean boolean36 = iSOChronology33.equals((java.lang.Object) periodType34);
//        java.lang.String str37 = iSOChronology33.toString();
//        org.joda.time.DurationField durationField38 = iSOChronology33.years();
//        boolean boolean39 = localDate32.equals((java.lang.Object) durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, durationField38, dateTimeFieldType40, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str12.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(periodType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str37.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getRangeDurationField();
//        java.lang.String str13 = offsetDateTimeField8.getName();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField8.getAsText((int) (byte) 10, locale15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
//        long long19 = offsetDateTimeField8.roundCeiling((long) (-292275054));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-291600000L) + "'", long19 == (-291600000L));
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int7 = fixedDateTimeZone5.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        java.util.Date date9 = localDate8.toDate();
//        org.joda.time.LocalDate.Property property10 = localDate8.yearOfCentury();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.Chronology chronology14 = julianChronology12.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology12.getZone();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = localDate8.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.LocalDate localDate19 = localDate16.plusWeeks((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate19.minus(readablePeriod20);
//        long long23 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate19, (long) (short) 0);
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.Chronology chronology27 = julianChronology25.withZone(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology25.getZone();
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone28);
//        long long32 = dateTimeZone28.convertLocalToUTC((long) 2019, false);
//        org.joda.time.DateTime dateTime33 = localDate19.toDateTimeAtStartOfDay(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31536000000L + "'", long23 == 31536000000L);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
//        int int4 = dateTime2.getDayOfWeek();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(localTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property9.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1.0f, "1970");
        java.lang.Throwable throwable23 = null;
        try {
            illegalFieldValueException22.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.appendWeekOfWeekyear(57745);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType2 = partial0.getFieldType((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getLeapDurationField();
//        int int17 = offsetDateTimeField9.getLeapAmount(62L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        long long19 = limitChronology4.add(2019L, (-61851571622000L), 2019);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-124878323104815981L) + "'", long19 == (-124878323104815981L));
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField14.getWrappedField();
//        int int17 = skipUndoDateTimeField14.getMinimumValue(349200100L);
//        org.joda.time.DurationField durationField18 = skipUndoDateTimeField14.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-57730), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        java.lang.Class<?> wildcardClass16 = dateTime9.getClass();
        try {
            org.joda.time.DateTime dateTime21 = dateTime9.withTime(57721, 12, 57745, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57721 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property9.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1.0f, "1970");
        java.lang.String str23 = illegalFieldValueException22.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1.0 for yearOfCentury is not supported: 1970" + "'", str23.equals("org.joda.time.IllegalFieldValueException: Value 1.0 for yearOfCentury is not supported: 1970"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        boolean boolean3 = instant1.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipUndoDateTimeField14.getAsText((long) 4, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField14.getAsText((int) (short) 1, locale23);
//        try {
//            org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) skipUndoDateTimeField14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipUndoDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4" + "'", str21.equals("4"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = partial0.equals(obj1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.Chronology chronology10 = buddhistChronology9.withUTC();
//        org.joda.time.Partial partial11 = partial0.withChronologyRetainFields(chronology10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.Chronology chronology23 = julianChronology21.withZone(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology21.getZone();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone24);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) (short) 0);
//        int int28 = localDate27.getYearOfCentury();
//        org.joda.time.LocalDate.Property property29 = localDate27.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.Chronology chronology33 = julianChronology31.withZone(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = julianChronology31.getZone();
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone34);
//        int int36 = localDate35.getDayOfWeek();
//        org.joda.time.DateTime dateTime37 = localDate35.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime38 = null;
//        org.joda.time.DateTime dateTime39 = localDate35.toDateTime(localTime38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology41 = localDate40.getChronology();
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(chronology41);
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime39, (org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType45 = null;
//        org.joda.time.PeriodType periodType46 = org.joda.time.DateTimeUtils.getPeriodType(periodType45);
//        boolean boolean47 = iSOChronology44.equals((java.lang.Object) periodType45);
//        java.lang.String str48 = iSOChronology44.toString();
//        org.joda.time.DurationField durationField49 = iSOChronology44.years();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology44.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) (byte) 1);
//        boolean boolean53 = dateTime39.equals((java.lang.Object) dateTimeField50);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone58 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int60 = fixedDateTimeZone58.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone58);
//        java.util.Date date62 = localDate61.toDate();
//        org.joda.time.LocalDate.Property property63 = localDate61.yearOfCentury();
//        org.joda.time.LocalDate localDate65 = property63.addToCopy((int) (byte) 10);
//        int int66 = property63.get();
//        org.joda.time.ReadableInterval readableInterval67 = null;
//        org.joda.time.Chronology chronology68 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval67);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(chronology68);
//        org.joda.time.DateTime dateTime71 = dateTime69.plusMillis((int) (byte) 1);
//        int int72 = property63.compareTo((org.joda.time.ReadableInstant) dateTime69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property63.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, dateTimeFieldType73, (-11));
//        boolean boolean76 = localDate27.isSupported(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder12.appendFixedDecimal(dateTimeFieldType73, 57725);
//        try {
//            org.joda.time.Partial.Property property79 = partial0.property(dateTimeFieldType73);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(partial11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 70 + "'", int28 == 70);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(julianChronology31);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(periodType46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str48.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 19 + "'", int66 == 19);
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime12);
        int int14 = dateTime9.getYearOfEra();
        org.joda.time.DateTime dateTime16 = dateTime9.plusDays(70);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DurationField durationField16 = limitChronology15.centuries();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) limitChronology15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("10");
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks((-1));
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(1382);
        org.joda.time.DateTime dateTime7 = dateTime3.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType13 = null;
//        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
//        boolean boolean15 = iSOChronology12.equals((java.lang.Object) periodType13);
//        java.lang.String str16 = iSOChronology12.toString();
//        org.joda.time.DurationField durationField17 = iSOChronology12.years();
//        boolean boolean18 = localDate11.equals((java.lang.Object) durationField17);
//        org.joda.time.Chronology chronology19 = localDate11.getChronology();
//        org.joda.time.LocalDate localDate21 = localDate11.withCenturyOfEra((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str16.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(localDate21);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("19691231", (int) (short) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("1", 57723);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder3.toDateTimeZone("hourOfHalfday", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = skipUndoDateTimeField14.getDurationField();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipUndoDateTimeField14.getAsText((int) (short) 10, locale17);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.Date date27 = localDate26.toDate();
//        org.joda.time.LocalDate.Property property28 = localDate26.yearOfCentury();
//        org.joda.time.LocalDate localDate30 = property28.addToCopy(0);
//        org.joda.time.LocalDate localDate31 = property28.roundHalfCeilingCopy();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate31, 6, locale33);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int41 = fixedDateTimeZone39.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone39);
//        java.util.Date date43 = localDate42.toDate();
//        org.joda.time.LocalDate.Property property44 = localDate42.yearOfCentury();
//        org.joda.time.LocalDate localDate46 = property44.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType48 = null;
//        org.joda.time.PeriodType periodType49 = org.joda.time.DateTimeUtils.getPeriodType(periodType48);
//        boolean boolean50 = iSOChronology47.equals((java.lang.Object) periodType48);
//        java.lang.String str51 = iSOChronology47.toString();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        boolean boolean53 = localDate46.equals((java.lang.Object) durationField52);
//        org.joda.time.LocalDate.Property property54 = localDate46.weekOfWeekyear();
//        org.joda.time.LocalDate.Property property55 = localDate46.weekOfWeekyear();
//        boolean boolean56 = localDate31.isEqual((org.joda.time.ReadablePartial) localDate46);
//        try {
//            org.joda.time.LocalDate localDate58 = localDate31.withWeekOfWeekyear((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "6" + "'", str34.equals("6"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str51.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        int int11 = offsetDateTimeField8.getMinimumValue((long) ' ');
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 1);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField21.getAsShortText(1, locale23);
//        org.joda.time.DurationField durationField25 = offsetDateTimeField21.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, (org.joda.time.DateTimeField) offsetDateTimeField21);
//        long long28 = offsetDateTimeField21.roundHalfEven((-14400000L));
//        org.joda.time.DurationField durationField29 = offsetDateTimeField21.getDurationField();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int36 = fixedDateTimeZone34.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        java.util.Date date38 = localDate37.toDate();
//        org.joda.time.LocalDate.Property property39 = localDate37.yearOfCentury();
//        org.joda.time.LocalDate localDate41 = property39.addToCopy((int) (byte) 10);
//        int int42 = property39.get();
//        org.joda.time.ReadableInterval readableInterval43 = null;
//        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval43);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(chronology44);
//        org.joda.time.DateTime dateTime47 = dateTime45.plusMillis((int) (byte) 1);
//        int int48 = property39.compareTo((org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property39.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) 1.0f, "1970");
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, durationField29, dateTimeFieldType49, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-14400000L) + "'", long28 == (-14400000L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 19 + "'", int42 == 19);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 97, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 0, (int) (short) 1);
//        java.lang.String str4 = gJChronology3.toString();
//        org.joda.time.Instant instant5 = gJChronology3.getGregorianCutover();
//        long long9 = gJChronology3.add((long) (byte) 0, 31536000000L, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=1]" + "'", str4.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=1]"));
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 315360000000L + "'", long9 == 315360000000L);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            long long8 = copticChronology0.getDateTimeMillis(57751, 57726, (int) '4', 57721, 20, (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57721 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("09:02:25.460");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"09:02:25.460\" is malformed at \":02:25.460\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 57757, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.util.Date date20 = localDate19.toDate();
        int int21 = property9.compareTo((org.joda.time.ReadablePartial) localDate19);
        int int22 = localDate19.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology30.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone32 = copticChronology30.getZone();
        org.joda.time.DateTimeZone dateTimeZone33 = copticChronology30.getZone();
        org.joda.time.DateTime dateTime34 = dateTime24.withZoneRetainFields(dateTimeZone33);
        org.joda.time.Interval interval35 = localDate19.toInterval(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(interval35);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 100, true);
        long long11 = fixedDateTimeZone4.adjustOffset((-14400000L), false);
        long long13 = fixedDateTimeZone4.previousTransition((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-14400000L) + "'", long11 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNotNull(iSOChronology14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1560639719054L);
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear(0);
        java.lang.Appendable appendable5 = null;
        try {
            dateTimeFormatter2.printTo(appendable5, 1560614545460L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int18 = fixedDateTimeZone16.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        java.util.Date date20 = localDate19.toDate();
//        org.joda.time.LocalDate.Property property21 = localDate19.yearOfCentury();
//        org.joda.time.LocalDate localDate23 = property21.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = localDate23.toDateTimeAtMidnight();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) -1, locale26);
//        org.joda.time.Partial partial28 = new org.joda.time.Partial();
//        java.lang.Object obj29 = null;
//        boolean boolean30 = partial28.equals(obj29);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone35);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone35);
//        org.joda.time.Chronology chronology38 = buddhistChronology37.withUTC();
//        org.joda.time.Partial partial39 = partial28.withChronologyRetainFields(chronology38);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int47 = fixedDateTimeZone45.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone45);
//        java.util.Date date49 = localDate48.toDate();
//        org.joda.time.LocalDate.Property property50 = localDate48.yearOfCentury();
//        org.joda.time.LocalDate localDate52 = property50.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime53 = localDate52.toDateTimeAtMidnight();
//        int[] intArray54 = localDate52.getValues();
//        try {
//            int[] intArray56 = offsetDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) partial39, 13, intArray54, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(copticChronology36);
//        org.junit.Assert.assertNotNull(buddhistChronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(partial39);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(intArray54);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int15 = fixedDateTimeZone13.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.lang.String str18 = fixedDateTimeZone13.getName((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        boolean boolean20 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter8);
        long long22 = fixedDateTimeZone4.nextTransition((long) 1);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long16 = fixedDateTimeZone13.convertUTCToLocal((long) 'a');
        org.joda.time.DateTime dateTime17 = localDate5.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.LocalDate.Property property18 = localDate5.yearOfEra();
        org.joda.time.LocalDate localDate19 = property18.roundCeilingCopy();
        java.lang.String str20 = property18.getAsString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970" + "'", str20.equals("1970"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendDayOfYear(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime16 = dateTime9.toDateTime();
        java.util.Date date17 = dateTime9.toDate();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        int int6 = localDate5.getDayOfWeek();
//        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology11 = localDate10.getChronology();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) periodType15);
//        java.lang.String str18 = iSOChronology14.toString();
//        org.joda.time.DurationField durationField19 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 1);
//        boolean boolean23 = dateTime9.equals((java.lang.Object) dateTimeField20);
//        org.joda.time.DateTime.Property property24 = dateTime9.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime9.plus(readableDuration25);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = julianChronology9.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology9.getZone();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone12);
        int int14 = localDate13.getDayOfWeek();
        org.joda.time.DateTime dateTime15 = localDate13.toDateTimeAtMidnight();
        int int16 = localDate13.size();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long24 = fixedDateTimeZone21.convertUTCToLocal((long) 'a');
        org.joda.time.DateTime dateTime25 = localDate13.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.LocalDate.Property property26 = localDate13.yearOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str28 = localDate13.toString(dateTimeFormatter27);
        boolean boolean29 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970-01" + "'", str28.equals("1970-01"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime32 = property30.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime33 = property30.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime34 = property30.roundFloorCopy();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) -1, "19691231");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (byte) -1, "19691231");
        java.lang.String str6 = illegalInstantException5.toString();
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray8 = illegalInstantException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = illegalInstantException5.getSuppressed();
        java.lang.Throwable[] throwableArray10 = illegalInstantException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (19691231)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970-01-01", 1000, 57751, 57721);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for 1970-01-01 must be in the range [57751,57721]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear(0);
        try {
            org.joda.time.LocalDate localDate6 = dateTimeFormatter4.parseLocalDate("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
        int int12 = property9.get();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (byte) 1);
        int int18 = property9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.minus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths((int) 'a');
        org.joda.time.DateMidnight dateMidnight23 = dateTime15.toDateMidnight();
        boolean boolean25 = dateTime15.isBefore((long) (short) 100);
        org.joda.time.DateTime dateTime26 = dateTime15.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear((-57730), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfMinute(11, 1000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendMinuteOfDay(6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("57751");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57751\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 4);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology4.get(readablePeriod5, (long) 100, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology8.getZone();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        boolean boolean7 = dateTime2.isSupported(dateTimeFieldType6);
//        int int8 = dateTime2.getEra();
//        int int9 = dateTime2.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57769 + "'", int4 == 57769);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 962 + "'", int9 == 962);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        org.joda.time.LocalDate localDate16 = localDate7.withFields((org.joda.time.ReadablePartial) localDate15);
//        int int17 = localDate15.getYear();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType19 = null;
//        org.joda.time.PeriodType periodType20 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) periodType19);
//        java.lang.String str22 = iSOChronology18.toString();
//        org.joda.time.DurationField durationField23 = iSOChronology18.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology18.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26);
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.Chronology chronology31 = julianChronology29.withZone(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = julianChronology29.getZone();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone32);
//        int int34 = localDate33.getDayOfWeek();
//        org.joda.time.DateTime dateTime35 = localDate33.toDateTimeAtMidnight();
//        int int36 = localDate33.size();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41);
//        long long44 = fixedDateTimeZone41.convertUTCToLocal((long) 'a');
//        org.joda.time.DateTime dateTime45 = localDate33.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone41);
//        int int46 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate33);
//        int int47 = localDate15.compareTo((org.joda.time.ReadablePartial) localDate33);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str22.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = julianChronology3.seconds();
        org.joda.time.DurationField durationField6 = julianChronology3.weekyears();
        org.joda.time.Partial partial7 = partial0.withChronologyRetainFields((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Partial partial10 = partial0.withFieldAdded(durationFieldType8, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(partial7);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        long long12 = offsetDateTimeField8.roundFloor((-14399968L));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int19 = fixedDateTimeZone17.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        java.util.Date date21 = localDate20.toDate();
//        org.joda.time.LocalDate.Property property22 = localDate20.yearOfCentury();
//        org.joda.time.LocalDate localDate24 = property22.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime25 = localDate24.toDateTimeAtMidnight();
//        org.joda.time.DateTime dateTime26 = localDate24.toDateTimeAtMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType29 = null;
//        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        boolean boolean31 = iSOChronology28.equals((java.lang.Object) periodType29);
//        java.lang.String str32 = iSOChronology28.toString();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology28.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType36 = null;
//        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
//        boolean boolean38 = iSOChronology35.equals((java.lang.Object) periodType36);
//        java.lang.String str39 = iSOChronology35.toString();
//        org.joda.time.DurationField durationField40 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology35.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology28, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType44 = null;
//        org.joda.time.PeriodType periodType45 = org.joda.time.DateTimeUtils.getPeriodType(periodType44);
//        boolean boolean46 = iSOChronology43.equals((java.lang.Object) periodType44);
//        java.lang.String str47 = iSOChronology43.toString();
//        org.joda.time.DurationField durationField48 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType51 = null;
//        org.joda.time.PeriodType periodType52 = org.joda.time.DateTimeUtils.getPeriodType(periodType51);
//        boolean boolean53 = iSOChronology50.equals((java.lang.Object) periodType51);
//        java.lang.String str54 = iSOChronology50.toString();
//        org.joda.time.DurationField durationField55 = iSOChronology50.years();
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology50.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology43, dateTimeField56);
//        org.joda.time.Partial partial58 = new org.joda.time.Partial();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = partial58.equals(obj59);
//        boolean boolean62 = partial58.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = skipUndoDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) partial58, (int) (short) -1, locale64);
//        int[] intArray72 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int73 = skipUndoDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) partial58, intArray72);
//        try {
//            int[] intArray75 = offsetDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate24, 57751, intArray72, 57729);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57751");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-14400000L) + "'", long12 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str32.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str39.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(periodType45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str47.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(periodType52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str54.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "-1" + "'", str65.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        long long16 = offsetDateTimeField9.roundHalfEven((-14400000L));
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getRangeDurationField();
//        long long20 = offsetDateTimeField9.add((long) '4', (long) 57729);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-14400000L) + "'", long16 == (-14400000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 207824400052L + "'", long20 == 207824400052L);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-57730));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial();
//        int[] intArray12 = partial11.getValues();
//        int int13 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) partial11);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType15 = partial11.getFieldType(57754);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57754");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getName((long) (byte) 1);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str13 = fixedDateTimeZone4.getNameKey((long) (short) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
        org.joda.time.LocalDate localDate16 = localDate7.withFields((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate18 = localDate15.minusMonths(2019);
        org.joda.time.LocalDate.Property property19 = localDate15.weekOfWeekyear();
        org.joda.time.LocalDate localDate20 = property19.withMaximumValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime33 = dateTime31.withYear(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime36 = dateTime33.withWeekyear(10);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getName((long) (byte) 1);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str12 = fixedDateTimeZone4.toString();
        java.lang.String str14 = fixedDateTimeZone4.getNameKey((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
//        int int8 = localDate7.getYearOfCentury();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        boolean boolean33 = dateTime19.equals((java.lang.Object) dateTimeField30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int40 = fixedDateTimeZone38.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        java.util.Date date42 = localDate41.toDate();
//        org.joda.time.LocalDate.Property property43 = localDate41.yearOfCentury();
//        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (byte) 10);
//        int int46 = property43.get();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 1);
//        int int52 = property43.compareTo((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType53, (-11));
//        boolean boolean56 = localDate7.isSupported(dateTimeFieldType53);
//        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.Chronology chronology59 = julianChronology57.withZone(dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology57.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology57.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField61);
//        try {
//            long long64 = unsupportedDateTimeField62.roundHalfEven(7268457729L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(julianChronology57);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekOfWeekyear((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType13 = null;
//        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
//        boolean boolean15 = iSOChronology12.equals((java.lang.Object) periodType13);
//        java.lang.String str16 = iSOChronology12.toString();
//        org.joda.time.DurationField durationField17 = iSOChronology12.years();
//        boolean boolean18 = localDate11.equals((java.lang.Object) durationField17);
//        org.joda.time.LocalDate.Property property19 = localDate11.weekOfWeekyear();
//        org.joda.time.LocalDate localDate21 = property19.addToCopy((-1));
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        int int25 = dateTime24.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str16.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2029 + "'", int25 == 2029);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        java.lang.String str32 = property30.getAsShortText();
//        org.joda.time.DateTime dateTime33 = property30.roundHalfFloorCopy();
//        org.joda.time.DateTimeField dateTimeField34 = property30.getField();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AD" + "'", str32.equals("AD"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime6.toString("[]", locale8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime6.toYearMonthDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime16 = dateTime9.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withYear(57721);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType20 = null;
//        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType20);
//        boolean boolean22 = iSOChronology19.equals((java.lang.Object) periodType20);
//        java.lang.String str23 = iSOChronology19.toString();
//        org.joda.time.DurationField durationField24 = iSOChronology19.years();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.hourOfHalfday();
//        org.joda.time.DurationField durationField26 = iSOChronology19.weeks();
//        org.joda.time.DateTime dateTime27 = dateTime16.toDateTime((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTime.Property property28 = dateTime27.millisOfSecond();
//        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) '#');
//        boolean boolean31 = property28.isLeap();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTimeZoneName(strMap2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute(4);
//        java.lang.String str18 = dateTime17.toString();
//        java.util.Locale locale19 = null;
//        java.util.Calendar calendar20 = dateTime17.toCalendar(locale19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime17.minus(readablePeriod21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15T16:02:04.344-07:00" + "'", str18.equals("2019-06-15T16:02:04.344-07:00"));
//        org.junit.Assert.assertNotNull(calendar20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology1 = localDate0.getChronology();
        org.joda.time.LocalDate.Property property2 = localDate0.centuryOfEra();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 315360000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) 57722);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField8.getDurationField();
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField8.getMaximumShortTextLength(locale12);
//        java.lang.String str15 = offsetDateTimeField8.getAsShortText(31536000000L);
//        java.util.Locale locale16 = null;
//        int int17 = offsetDateTimeField8.getMaximumShortTextLength(locale16);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5" + "'", str15.equals("5"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology1 = localDate0.getChronology();
        org.joda.time.LocalDate localDate3 = localDate0.withYear((-57724));
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(localDate3);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) 57722);
//        boolean boolean12 = offsetDateTimeField8.isLeap((long) (byte) 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) (short) 10);
//        long long13 = offsetDateTimeField8.add((long) 57726, 57723);
//        int int14 = offsetDateTimeField8.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 207802857726L + "'", long13 == 207802857726L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        int int17 = skipUndoDateTimeField14.getDifference((long) 57725, 1L);
//        java.lang.String str18 = skipUndoDateTimeField14.getName();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.Chronology chronology22 = julianChronology20.withZone(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology20.getZone();
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone23);
//        int int25 = localDate24.getDayOfWeek();
//        org.joda.time.DateTime dateTime26 = localDate24.toDateTimeAtMidnight();
//        org.joda.time.Partial partial27 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate24);
//        int[] intArray35 = new int[] { 4, 57769, 2, (byte) 10, (short) -1, 19 };
//        try {
//            int[] intArray37 = skipUndoDateTimeField14.add((org.joda.time.ReadablePartial) partial27, 0, intArray35, 83222000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfHalfday" + "'", str18.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology1 = localDate0.getChronology();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
//        int int3 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(0L);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1382 + "'", int3 == 1382);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology4.secondOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, dateTimeField12);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField13, 57725, 57757, 2029);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57725 for hourOfHalfday must be in the range [57757,2029]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        long long24 = skipUndoDateTimeField14.roundHalfCeiling(31536000000L);
//        try {
//            long long27 = skipUndoDateTimeField14.set((long) (-57730), "1970-01");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 31536000000L + "'", long24 == 31536000000L);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        java.lang.Object obj4 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant(obj4);
        boolean boolean7 = instant5.isEqual((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime8 = instant5.toMutableDateTimeISO();
        int int11 = dateTimeFormatter3.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "hourOfHalfday", 57723);
        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "+00:00", 57729);
        try {
            long long16 = dateTimeFormatter0.parseMillis("1970-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01\" is malformed at \"70-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-57724) + "'", int11 == (-57724));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-57730) + "'", int14 == (-57730));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendFractionOfHour((int) (short) 10, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder15.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.Chronology chronology26 = julianChronology24.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology24.getZone();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks((int) (short) 0);
//        int int31 = localDate30.getYearOfCentury();
//        org.joda.time.LocalDate.Property property32 = localDate30.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.Chronology chronology36 = julianChronology34.withZone(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology34.getZone();
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone37);
//        int int39 = localDate38.getDayOfWeek();
//        org.joda.time.DateTime dateTime40 = localDate38.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime41 = null;
//        org.joda.time.DateTime dateTime42 = localDate38.toDateTime(localTime41);
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology44 = localDate43.getChronology();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now(chronology44);
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime42, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType48 = null;
//        org.joda.time.PeriodType periodType49 = org.joda.time.DateTimeUtils.getPeriodType(periodType48);
//        boolean boolean50 = iSOChronology47.equals((java.lang.Object) periodType48);
//        java.lang.String str51 = iSOChronology47.toString();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology47.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) (byte) 1);
//        boolean boolean56 = dateTime42.equals((java.lang.Object) dateTimeField53);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int63 = fixedDateTimeZone61.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone61);
//        java.util.Date date65 = localDate64.toDate();
//        org.joda.time.LocalDate.Property property66 = localDate64.yearOfCentury();
//        org.joda.time.LocalDate localDate68 = property66.addToCopy((int) (byte) 10);
//        int int69 = property66.get();
//        org.joda.time.ReadableInterval readableInterval70 = null;
//        org.joda.time.Chronology chronology71 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval70);
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime(chronology71);
//        org.joda.time.DateTime dateTime74 = dateTime72.plusMillis((int) (byte) 1);
//        int int75 = property66.compareTo((org.joda.time.ReadableInstant) dateTime72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property66.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, dateTimeFieldType76, (-11));
//        boolean boolean79 = localDate30.isSupported(dateTimeFieldType76);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder15.appendFixedDecimal(dateTimeFieldType76, 57725);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType76, (int) (short) 0, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 70 + "'", int31 == 70);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str51.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(localDate68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 19 + "'", int69 == 19);
//        org.junit.Assert.assertNotNull(chronology71);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial();
//        int[] intArray12 = partial11.getValues();
//        int int13 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) partial11);
//        long long16 = offsetDateTimeField8.add(57729L, 2019);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int23 = fixedDateTimeZone21.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        java.util.Date date25 = localDate24.toDate();
//        org.joda.time.LocalDate.Property property26 = localDate24.yearOfCentury();
//        org.joda.time.LocalDate localDate28 = property26.addToCopy((int) (byte) 10);
//        int int29 = property26.get();
//        org.joda.time.ReadableInterval readableInterval30 = null;
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(chronology31);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusMillis((int) (byte) 1);
//        int int35 = property26.compareTo((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 1.0f, "1970");
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType36, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 7268457729L + "'", long16 == 7268457729L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) '#', 57746, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57746 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
//        int int8 = localDate7.getYearOfCentury();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        boolean boolean33 = dateTime19.equals((java.lang.Object) dateTimeField30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int40 = fixedDateTimeZone38.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        java.util.Date date42 = localDate41.toDate();
//        org.joda.time.LocalDate.Property property43 = localDate41.yearOfCentury();
//        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (byte) 10);
//        int int46 = property43.get();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 1);
//        int int52 = property43.compareTo((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType53, (-11));
//        boolean boolean56 = localDate7.isSupported(dateTimeFieldType53);
//        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.Chronology chronology59 = julianChronology57.withZone(dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology57.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology57.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField61);
//        int int65 = unsupportedDateTimeField62.getDifference((long) 57757, 1560639751575L);
//        try {
//            long long68 = unsupportedDateTimeField62.addWrapField((long) (-577300), 1000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(julianChronology57);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        long long16 = skipUndoDateTimeField14.roundHalfFloor(0L);
//        long long18 = skipUndoDateTimeField14.roundCeiling((long) '4');
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.Chronology chronology22 = julianChronology20.withZone(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology20.getZone();
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone23);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate24.plusWeeks((int) (short) -1);
//        org.joda.time.LocalDate localDate30 = localDate24.minusDays(13);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int38 = fixedDateTimeZone36.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone36);
//        java.util.Date date40 = localDate39.toDate();
//        org.joda.time.LocalDate.Property property41 = localDate39.yearOfCentury();
//        org.joda.time.LocalDate localDate43 = property41.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = localDate43.toDateTimeAtMidnight();
//        int[] intArray45 = localDate43.getValues();
//        try {
//            int[] intArray47 = skipUndoDateTimeField14.addWrapField((org.joda.time.ReadablePartial) localDate24, (-57724), intArray45, (-57724));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -57724");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600000L + "'", long18 == 3600000L);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        boolean boolean11 = offsetDateTimeField8.isLeap(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        int int16 = skipUndoDateTimeField14.getMinimumValue(1560639722730L);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
//        boolean boolean20 = iSOChronology17.equals((java.lang.Object) periodType18);
//        java.lang.String str21 = iSOChronology17.toString();
//        org.joda.time.DurationField durationField22 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) 1);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField25.getAsShortText(1, locale27);
//        org.joda.time.Partial partial29 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
//        boolean boolean33 = iSOChronology30.equals((java.lang.Object) periodType31);
//        java.lang.String str34 = iSOChronology30.toString();
//        org.joda.time.DurationField durationField35 = iSOChronology30.years();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology30.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType38 = null;
//        org.joda.time.PeriodType periodType39 = org.joda.time.DateTimeUtils.getPeriodType(periodType38);
//        boolean boolean40 = iSOChronology37.equals((java.lang.Object) periodType38);
//        java.lang.String str41 = iSOChronology37.toString();
//        org.joda.time.DurationField durationField42 = iSOChronology37.years();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology37.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology30, dateTimeField43);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType46 = null;
//        org.joda.time.PeriodType periodType47 = org.joda.time.DateTimeUtils.getPeriodType(periodType46);
//        boolean boolean48 = iSOChronology45.equals((java.lang.Object) periodType46);
//        java.lang.String str49 = iSOChronology45.toString();
//        org.joda.time.DurationField durationField50 = iSOChronology45.years();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology45.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType53 = null;
//        org.joda.time.PeriodType periodType54 = org.joda.time.DateTimeUtils.getPeriodType(periodType53);
//        boolean boolean55 = iSOChronology52.equals((java.lang.Object) periodType53);
//        java.lang.String str56 = iSOChronology52.toString();
//        org.joda.time.DurationField durationField57 = iSOChronology52.years();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology52.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology45, dateTimeField58);
//        org.joda.time.Partial partial60 = new org.joda.time.Partial();
//        java.lang.Object obj61 = null;
//        boolean boolean62 = partial60.equals(obj61);
//        boolean boolean64 = partial60.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = skipUndoDateTimeField59.getAsShortText((org.joda.time.ReadablePartial) partial60, (int) (short) -1, locale66);
//        int[] intArray74 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int75 = skipUndoDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) partial60, intArray74);
//        int int76 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) partial29, intArray74);
//        java.lang.String str77 = partial29.toString();
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial29, (int) (short) 10, locale79);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str21.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str34.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str41.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(periodType47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str49.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(periodType54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str56.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "-1" + "'", str67.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "[]" + "'", str77.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "10" + "'", str80.equals("10"));
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType13 = null;
//        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
//        boolean boolean15 = iSOChronology12.equals((java.lang.Object) periodType13);
//        java.lang.String str16 = iSOChronology12.toString();
//        org.joda.time.DurationField durationField17 = iSOChronology12.years();
//        boolean boolean18 = localDate11.equals((java.lang.Object) durationField17);
//        org.joda.time.LocalDate.Property property19 = localDate11.weekOfWeekyear();
//        org.joda.time.LocalDate.Property property20 = localDate11.dayOfMonth();
//        int int21 = localDate11.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str16.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.Chronology chronology8 = julianChronology6.withZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology6.getZone();
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone9);
//        int int11 = localDate10.getDayOfWeek();
//        org.joda.time.DateTime dateTime12 = localDate10.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTime(localTime13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(chronology16);
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType20 = null;
//        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType20);
//        boolean boolean22 = iSOChronology19.equals((java.lang.Object) periodType20);
//        java.lang.String str23 = iSOChronology19.toString();
//        org.joda.time.DurationField durationField24 = iSOChronology19.years();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) (byte) 1);
//        boolean boolean28 = dateTime14.equals((java.lang.Object) dateTimeField25);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int35 = fixedDateTimeZone33.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone33);
//        java.util.Date date37 = localDate36.toDate();
//        org.joda.time.LocalDate.Property property38 = localDate36.yearOfCentury();
//        org.joda.time.LocalDate localDate40 = property38.addToCopy((int) (byte) 10);
//        int int41 = property38.get();
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime dateTime46 = dateTime44.plusMillis((int) (byte) 1);
//        int int47 = property38.compareTo((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property38.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType48, (-11));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType48, 83222000, (-1));
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendClockhourOfDay((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 19 + "'", int41 == 19);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((long) (byte) -1, 57729);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial();
//        int[] intArray12 = partial11.getValues();
//        int int13 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) partial11);
//        long long15 = offsetDateTimeField8.roundHalfCeiling(2019L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        long long10 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        long long16 = julianChronology11.add(readablePeriod13, (long) 57729, 19);
//        org.joda.time.Chronology chronology17 = julianChronology11.withUTC();
//        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(chronology17);
//        int[] intArray19 = null;
//        int int20 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate18, intArray19);
//        long long22 = offsetDateTimeField8.roundCeiling((-124878323104815981L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 57729L + "'", long16 == 57729L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-124878323102822000L) + "'", long22 == (-124878323102822000L));
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = skipUndoDateTimeField14.getDurationField();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipUndoDateTimeField14.getAsText((int) (short) 10, locale17);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.Date date27 = localDate26.toDate();
//        org.joda.time.LocalDate.Property property28 = localDate26.yearOfCentury();
//        org.joda.time.LocalDate localDate30 = property28.addToCopy(0);
//        org.joda.time.LocalDate localDate31 = property28.roundHalfCeilingCopy();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate31, 6, locale33);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int41 = fixedDateTimeZone39.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone39);
//        java.util.Date date43 = localDate42.toDate();
//        org.joda.time.LocalDate.Property property44 = localDate42.yearOfCentury();
//        org.joda.time.LocalDate localDate46 = property44.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType48 = null;
//        org.joda.time.PeriodType periodType49 = org.joda.time.DateTimeUtils.getPeriodType(periodType48);
//        boolean boolean50 = iSOChronology47.equals((java.lang.Object) periodType48);
//        java.lang.String str51 = iSOChronology47.toString();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        boolean boolean53 = localDate46.equals((java.lang.Object) durationField52);
//        org.joda.time.LocalDate.Property property54 = localDate46.weekOfWeekyear();
//        org.joda.time.LocalDate.Property property55 = localDate46.weekOfWeekyear();
//        boolean boolean56 = localDate31.isEqual((org.joda.time.ReadablePartial) localDate46);
//        org.joda.time.LocalDate.Property property57 = localDate31.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "6" + "'", str34.equals("6"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str51.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(property57);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) periodType2);
//        java.lang.String str5 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField9.getAsShortText(1, locale11);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        boolean boolean16 = offsetDateTimeField9.isLeap((long) (-57724));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int23 = fixedDateTimeZone21.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        java.util.Date date25 = localDate24.toDate();
//        org.joda.time.LocalDate.Property property26 = localDate24.yearOfCentury();
//        org.joda.time.LocalDate localDate28 = property26.addToCopy((int) (byte) 10);
//        int int29 = property26.get();
//        org.joda.time.ReadableInterval readableInterval30 = null;
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(chronology31);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusMillis((int) (byte) 1);
//        int int35 = property26.compareTo((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 207802857726L, (java.lang.Number) 62L, (java.lang.Number) (short) 10);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType36, (int) ' ', 57726, 70);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText(1, locale10);
//        org.joda.time.Partial partial12 = new org.joda.time.Partial();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType21 = null;
//        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) periodType21);
//        java.lang.String str24 = iSOChronology20.toString();
//        org.joda.time.DurationField durationField25 = iSOChronology20.years();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology20.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType29 = null;
//        org.joda.time.PeriodType periodType30 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        boolean boolean31 = iSOChronology28.equals((java.lang.Object) periodType29);
//        java.lang.String str32 = iSOChronology28.toString();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology28.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType36 = null;
//        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
//        boolean boolean38 = iSOChronology35.equals((java.lang.Object) periodType36);
//        java.lang.String str39 = iSOChronology35.toString();
//        org.joda.time.DurationField durationField40 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology35.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology28, dateTimeField41);
//        org.joda.time.Partial partial43 = new org.joda.time.Partial();
//        java.lang.Object obj44 = null;
//        boolean boolean45 = partial43.equals(obj44);
//        boolean boolean47 = partial43.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipUndoDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) partial43, (int) (short) -1, locale49);
//        int[] intArray57 = new int[] { (short) 10, ' ', '#', (short) 0, (short) 10, (short) -1 };
//        int int58 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) partial43, intArray57);
//        int int59 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) partial12, intArray57);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType61 = partial12.getFieldType(57758);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57758");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str32.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str39.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
        org.joda.time.DurationField durationField6 = limitChronology4.months();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTime dateTime16 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks(11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(0);
//        boolean boolean13 = limitChronology4.equals((java.lang.Object) dateTimeFormatterBuilder7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder7.appendFractionOfMinute(70, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendWeekyear((int) '#', (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.Chronology chronology28 = julianChronology26.withZone(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology26.getZone();
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone29);
//        org.joda.time.LocalDate localDate32 = localDate30.minusWeeks((int) (short) 0);
//        int int33 = localDate32.getYearOfCentury();
//        org.joda.time.LocalDate.Property property34 = localDate32.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.Chronology chronology38 = julianChronology36.withZone(dateTimeZone37);
//        org.joda.time.DateTimeZone dateTimeZone39 = julianChronology36.getZone();
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone39);
//        int int41 = localDate40.getDayOfWeek();
//        org.joda.time.DateTime dateTime42 = localDate40.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime43 = null;
//        org.joda.time.DateTime dateTime44 = localDate40.toDateTime(localTime43);
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology46 = localDate45.getChronology();
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(chronology46);
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime44, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType50 = null;
//        org.joda.time.PeriodType periodType51 = org.joda.time.DateTimeUtils.getPeriodType(periodType50);
//        boolean boolean52 = iSOChronology49.equals((java.lang.Object) periodType50);
//        java.lang.String str53 = iSOChronology49.toString();
//        org.joda.time.DurationField durationField54 = iSOChronology49.years();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology49.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (byte) 1);
//        boolean boolean58 = dateTime44.equals((java.lang.Object) dateTimeField55);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone63 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int65 = fixedDateTimeZone63.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone63);
//        java.util.Date date67 = localDate66.toDate();
//        org.joda.time.LocalDate.Property property68 = localDate66.yearOfCentury();
//        org.joda.time.LocalDate localDate70 = property68.addToCopy((int) (byte) 10);
//        int int71 = property68.get();
//        org.joda.time.ReadableInterval readableInterval72 = null;
//        org.joda.time.Chronology chronology73 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval72);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(chronology73);
//        org.joda.time.DateTime dateTime76 = dateTime74.plusMillis((int) (byte) 1);
//        int int77 = property68.compareTo((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property68.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType78, (-11));
//        boolean boolean81 = localDate32.isSupported(dateTimeFieldType78);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder17.appendFixedDecimal(dateTimeFieldType78, 57725);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType78, (int) '#', (-577300));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(periodType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str53.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 19 + "'", int71 == 19);
//        org.junit.Assert.assertNotNull(chronology73);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.Chronology chronology4 = julianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology2.getZone();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (short) 0);
//        int int9 = localDate8.getYearOfCentury();
//        org.joda.time.LocalDate.Property property10 = localDate8.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.Chronology chronology14 = julianChronology12.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology12.getZone();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone15);
//        int int17 = localDate16.getDayOfWeek();
//        org.joda.time.DateTime dateTime18 = localDate16.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime19 = null;
//        org.joda.time.DateTime dateTime20 = localDate16.toDateTime(localTime19);
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology22 = localDate21.getChronology();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType26 = null;
//        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType26);
//        boolean boolean28 = iSOChronology25.equals((java.lang.Object) periodType26);
//        java.lang.String str29 = iSOChronology25.toString();
//        org.joda.time.DurationField durationField30 = iSOChronology25.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology25.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 1);
//        boolean boolean34 = dateTime20.equals((java.lang.Object) dateTimeField31);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int41 = fixedDateTimeZone39.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone39);
//        java.util.Date date43 = localDate42.toDate();
//        org.joda.time.LocalDate.Property property44 = localDate42.yearOfCentury();
//        org.joda.time.LocalDate localDate46 = property44.addToCopy((int) (byte) 10);
//        int int47 = property44.get();
//        org.joda.time.ReadableInterval readableInterval48 = null;
//        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(chronology49);
//        org.joda.time.DateTime dateTime52 = dateTime50.plusMillis((int) (byte) 1);
//        int int53 = property44.compareTo((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property44.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, dateTimeFieldType54, (-11));
//        boolean boolean57 = localDate8.isSupported(dateTimeFieldType54);
//        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.Chronology chronology60 = julianChronology58.withZone(dateTimeZone59);
//        org.joda.time.DateTimeZone dateTimeZone61 = julianChronology58.getZone();
//        org.joda.time.DurationField durationField62 = julianChronology58.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType54, durationField62);
//        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField65 = iSOChronology64.years();
//        org.joda.time.ReadableDateTime readableDateTime66 = null;
//        org.joda.time.ReadableDateTime readableDateTime67 = null;
//        org.joda.time.chrono.LimitChronology limitChronology68 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology64, readableDateTime66, readableDateTime67);
//        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology68);
//        org.joda.time.DurationField durationField70 = limitChronology68.months();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField71 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField62, durationField70);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str29.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 19 + "'", int47 == 19);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(julianChronology58);
//        org.junit.Assert.assertNotNull(chronology60);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertNotNull(iSOChronology64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(limitChronology68);
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(durationField70);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtMidnight(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = fixedDateTimeZone4.getShortName(2440588L);
        java.lang.String str9 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        int int4 = dateTime2.getSecondOfDay();
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.String str7 = dateTime2.toString(dateTimeFormatter6);
//        org.joda.time.DateTime.Property property8 = dateTime2.minuteOfDay();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime2.withMonthOfYear(19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57777 + "'", int4 == 57777);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "16:02" + "'", str7.equals("16:02"));
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-577300));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str10 = fixedDateTimeZone5.getName((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter11.withZoneUTC();
        java.lang.StringBuffer stringBuffer13 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = julianChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology15.getZone();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone18);
        int int20 = localDate19.getDayOfWeek();
        org.joda.time.DateTime dateTime21 = localDate19.toDateTimeAtMidnight();
        int int22 = localDate19.size();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        long long30 = fixedDateTimeZone27.convertUTCToLocal((long) 'a');
        org.joda.time.DateTime dateTime31 = localDate19.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.joda.time.LocalDate.Property property32 = localDate19.yearOfEra();
        org.joda.time.LocalDate.Property property33 = localDate19.yearOfCentury();
        try {
            dateTimeFormatter12.printTo(stringBuffer13, (org.joda.time.ReadablePartial) localDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("19691231", (int) (short) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("1", 57723);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("1970-01", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        boolean boolean4 = partial0.equals((java.lang.Object) 2440588L);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = partial0.toString("", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfYear(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute(57751, 57769);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-57724), 6, (int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate9 = localDate5.plusWeeks((int) (short) -1);
        org.joda.time.LocalDate.Property property10 = localDate5.dayOfMonth();
        java.lang.String str11 = localDate5.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01" + "'", str11.equals("1970-01-01"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.years();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology6, readableDateTime8, readableDateTime9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology10);
        org.joda.time.DurationField durationField12 = limitChronology10.months();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusMillis((int) (byte) 1);
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology10, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.withSecondOfMinute(4);
        try {
            org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime23, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy(0);
        org.joda.time.LocalDate localDate12 = property9.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate13 = property9.getLocalDate();
        java.util.Locale locale15 = null;
        try {
            org.joda.time.LocalDate localDate16 = property9.setCopy("2019-06-15T16:02:04.851-07:00", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T16:02:04.851-07:00\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        try {
            org.joda.time.LocalDate localDate7 = localDate5.withYearOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = partial0.equals(obj1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.Partial partial4 = partial0.plus(readablePeriod3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
//        boolean boolean8 = iSOChronology5.equals((java.lang.Object) periodType6);
//        java.lang.String str9 = iSOChronology5.toString();
//        org.joda.time.DurationField durationField10 = iSOChronology5.years();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 1);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField13.getAsShortText(1, locale15);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField13.getRangeDurationField();
//        java.lang.String str18 = offsetDateTimeField13.getName();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField13.getAsText((int) (byte) 10, locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField13.getType();
//        try {
//            org.joda.time.Partial.Property property23 = partial0.property(dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(partial4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str9.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfHalfday" + "'", str18.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        long long7 = iSOChronology1.add(readablePeriod4, 0L, (-1));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate11 = localDate5.plusWeeks(0);
        int int12 = localDate5.getDayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
//        java.lang.String str32 = property30.getAsString();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(57754, 1970, 4, 10, 57757, (-292275054), 1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57757 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone7);
        try {
            org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        int int10 = offsetDateTimeField8.getLeapAmount((long) 57722);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField8.getDurationField();
//        long long13 = offsetDateTimeField8.roundHalfEven(1560639722433L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560639600000L + "'", long13 == 1560639600000L);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis(57723);
        java.lang.String str11 = dateTime9.toString("6");
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6" + "'", str11.equals("6"));
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
//        int int8 = localDate7.getYearOfCentury();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        boolean boolean33 = dateTime19.equals((java.lang.Object) dateTimeField30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int40 = fixedDateTimeZone38.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        java.util.Date date42 = localDate41.toDate();
//        org.joda.time.LocalDate.Property property43 = localDate41.yearOfCentury();
//        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (byte) 10);
//        int int46 = property43.get();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 1);
//        int int52 = property43.compareTo((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType53, (-11));
//        boolean boolean56 = localDate7.isSupported(dateTimeFieldType53);
//        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.Chronology chronology59 = julianChronology57.withZone(dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology57.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology57.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField61);
//        org.joda.time.ReadablePartial readablePartial63 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone68 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int70 = fixedDateTimeZone68.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone68);
//        java.util.Date date72 = localDate71.toDate();
//        org.joda.time.LocalDate.Property property73 = localDate71.yearOfCentury();
//        org.joda.time.LocalDate localDate75 = property73.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime76 = localDate75.toDateTimeAtMidnight();
//        int[] intArray77 = localDate75.getValues();
//        try {
//            int int78 = unsupportedDateTimeField62.getMinimumValue(readablePartial63, intArray77);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(julianChronology57);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(intArray77);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.year();
//        org.joda.time.DateTime dateTime33 = property32.withMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime35 = dateTime33.withDayOfMonth((-292275054));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis(57723);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        int int6 = localDate5.getDayOfWeek();
//        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology11 = localDate10.getChronology();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) periodType15);
//        java.lang.String str18 = iSOChronology14.toString();
//        org.joda.time.DurationField durationField19 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 1);
//        boolean boolean23 = dateTime9.equals((java.lang.Object) dateTimeField20);
//        org.joda.time.DateTime.Property property24 = dateTime9.secondOfDay();
//        int int25 = dateTime9.getDayOfYear();
//        java.lang.String str26 = dateTime9.toString();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T16:02:59.577-08:00" + "'", str26.equals("1970-01-01T16:02:59.577-08:00"));
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.DurationField durationField6 = limitChronology4.months();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (byte) 1);
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime16 = dateTime9.toDateTime();
//        int int17 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTime.Property property18 = dateTime9.millisOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        boolean boolean26 = fixedDateTimeZone23.isFixed();
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        try {
//            int int28 = property18.compareTo((org.joda.time.ReadablePartial) localDate27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 59);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210861662400000L) + "'", long1 == (-210861662400000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone5);
        int int7 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology13.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone15);
        try {
            long long24 = zonedChronology16.getDateTimeMillis((int) (byte) -1, 19, (-57730), 57751, 57721, 19, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57751 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Date date8 = localDate7.toDate();
        org.joda.time.LocalDate.Property property9 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate11 = property9.addToCopy(0);
        java.lang.String str12 = property9.getAsString();
        org.joda.time.LocalDate localDate14 = property9.setCopy(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear((-57730), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfMinute(11, 1000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendFractionOfHour(57754, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = skipUndoDateTimeField14.getDurationField();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipUndoDateTimeField14.getAsText((int) (short) 10, locale17);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.Date date27 = localDate26.toDate();
//        org.joda.time.LocalDate.Property property28 = localDate26.yearOfCentury();
//        org.joda.time.LocalDate localDate30 = property28.addToCopy(0);
//        org.joda.time.LocalDate localDate31 = property28.roundHalfCeilingCopy();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate31, 6, locale33);
//        org.joda.time.ReadablePartial readablePartial35 = null;
//        java.util.Locale locale36 = null;
//        try {
//            java.lang.String str37 = skipUndoDateTimeField14.getAsShortText(readablePartial35, locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "6" + "'", str34.equals("6"));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 1.0 for yearOfCentury is not supported: 1970", "2019-06-15", (int) (byte) 10, 100);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear(10, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("3");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"3\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime12);
        int int14 = dateTime9.getYearOfEra();
        org.joda.time.LocalDate localDate15 = dateTime9.toLocalDate();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfYear(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral('a');
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
//        int int8 = localDate7.getYearOfCentury();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        boolean boolean33 = dateTime19.equals((java.lang.Object) dateTimeField30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int40 = fixedDateTimeZone38.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        java.util.Date date42 = localDate41.toDate();
//        org.joda.time.LocalDate.Property property43 = localDate41.yearOfCentury();
//        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (byte) 10);
//        int int46 = property43.get();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 1);
//        int int52 = property43.compareTo((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType53, (-11));
//        boolean boolean56 = localDate7.isSupported(dateTimeFieldType53);
//        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.Chronology chronology59 = julianChronology57.withZone(dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology57.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology57.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField61);
//        java.util.Locale locale64 = null;
//        try {
//            java.lang.String str65 = unsupportedDateTimeField62.getAsShortText((long) (byte) -1, locale64);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(julianChronology57);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int7 = fixedDateTimeZone5.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        java.util.Date date9 = localDate8.toDate();
//        org.joda.time.LocalDate.Property property10 = localDate8.yearOfCentury();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.Chronology chronology14 = julianChronology12.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology12.getZone();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = localDate8.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.LocalDate localDate19 = localDate16.plusWeeks((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate19.minus(readablePeriod20);
//        long long23 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate19, (long) (short) 0);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology0.millisOfDay();
//        java.lang.String str25 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31536000000L + "'", long23 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str25.equals("ISOChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) (short) 0);
//        int int8 = localDate7.getYearOfCentury();
//        org.joda.time.LocalDate.Property property9 = localDate7.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = julianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology11.getZone();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone14);
//        int int16 = localDate15.getDayOfWeek();
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTimeAtMidnight();
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        boolean boolean27 = iSOChronology24.equals((java.lang.Object) periodType25);
//        java.lang.String str28 = iSOChronology24.toString();
//        org.joda.time.DurationField durationField29 = iSOChronology24.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        boolean boolean33 = dateTime19.equals((java.lang.Object) dateTimeField30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int40 = fixedDateTimeZone38.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        java.util.Date date42 = localDate41.toDate();
//        org.joda.time.LocalDate.Property property43 = localDate41.yearOfCentury();
//        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (byte) 10);
//        int int46 = property43.get();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((int) (byte) 1);
//        int int52 = property43.compareTo((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType53, (-11));
//        boolean boolean56 = localDate7.isSupported(dateTimeFieldType53);
//        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.Chronology chronology59 = julianChronology57.withZone(dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology57.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology57.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField61);
//        try {
//            long long64 = unsupportedDateTimeField62.roundCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str28.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(julianChronology57);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone4);
        int int6 = localDate5.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtMidnight();
        int int8 = localDate5.size();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long16 = fixedDateTimeZone13.convertUTCToLocal((long) 'a');
        org.joda.time.DateTime dateTime17 = localDate5.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.LocalDate.Property property18 = localDate5.yearOfEra();
        java.util.Date date19 = localDate5.toDate();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear((-57730), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfMinute(11, 1000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime dateTime5 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = partial21.equals(obj22);
//        boolean boolean25 = partial21.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) partial21, (int) (short) -1, locale27);
//        int int29 = dateTime2.get((org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.DateTime.Property property30 = dateTime2.era();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
//        java.lang.String str32 = property30.getAsShortText();
//        org.joda.time.DurationField durationField33 = property30.getRangeDurationField();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AD" + "'", str32.equals("AD"));
//        org.junit.Assert.assertNull(durationField33);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = skipUndoDateTimeField14.getDurationField();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipUndoDateTimeField14.getAsText((int) (short) 10, locale17);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int25 = fixedDateTimeZone23.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.Date date27 = localDate26.toDate();
//        org.joda.time.LocalDate.Property property28 = localDate26.yearOfCentury();
//        org.joda.time.LocalDate localDate30 = property28.addToCopy(0);
//        org.joda.time.LocalDate localDate31 = property28.roundHalfCeilingCopy();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate31, 6, locale33);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int41 = fixedDateTimeZone39.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone39);
//        java.util.Date date43 = localDate42.toDate();
//        org.joda.time.LocalDate.Property property44 = localDate42.yearOfCentury();
//        org.joda.time.LocalDate localDate46 = property44.addToCopy((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType48 = null;
//        org.joda.time.PeriodType periodType49 = org.joda.time.DateTimeUtils.getPeriodType(periodType48);
//        boolean boolean50 = iSOChronology47.equals((java.lang.Object) periodType48);
//        java.lang.String str51 = iSOChronology47.toString();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        boolean boolean53 = localDate46.equals((java.lang.Object) durationField52);
//        org.joda.time.LocalDate.Property property54 = localDate46.weekOfWeekyear();
//        org.joda.time.LocalDate.Property property55 = localDate46.weekOfWeekyear();
//        boolean boolean56 = localDate31.isEqual((org.joda.time.ReadablePartial) localDate46);
//        org.joda.time.LocalDate localDate58 = localDate46.plusMonths((int) (short) -1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "6" + "'", str34.equals("6"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str51.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(localDate58);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1970);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("DateTimeField[hourOfHalfday]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[hourOfHalfday]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.Object obj1 = null;
        boolean boolean2 = partial0.equals(obj1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = julianChronology3.seconds();
        org.joda.time.DurationField durationField6 = julianChronology3.weekyears();
        org.joda.time.Partial partial7 = partial0.withChronologyRetainFields((org.joda.time.Chronology) julianChronology3);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType9 = partial7.getFieldType((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(partial7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology8 = localDate7.getChronology();
        org.joda.time.DateTime dateTime9 = localDate7.toDateTimeAtMidnight();
        try {
            org.joda.time.LocalDate localDate11 = localDate7.withWeekOfWeekyear((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        boolean boolean7 = limitChronology5.equals((java.lang.Object) (-1.0f));
        org.joda.time.DurationField durationField8 = limitChronology5.halfdays();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField8, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType8 = null;
//        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) periodType8);
//        java.lang.String str11 = iSOChronology7.toString();
//        org.joda.time.DurationField durationField12 = iSOChronology7.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = partial15.equals(obj16);
//        boolean boolean19 = partial15.equals((java.lang.Object) 2440588L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) partial15, (int) (short) -1, locale21);
//        try {
//            org.joda.time.DateTimeField dateTimeField24 = partial15.getField(57729);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57729");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType7 = null;
//        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) periodType7);
//        java.lang.String str10 = iSOChronology6.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.hourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
//        boolean boolean16 = iSOChronology13.equals((java.lang.Object) periodType14);
//        java.lang.String str17 = iSOChronology13.toString();
//        org.joda.time.DurationField durationField18 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField19);
//        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        org.joda.time.Chronology chronology24 = localDate23.getChronology();
//        org.joda.time.LocalDate localDate26 = localDate23.withCenturyOfEra(6);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int34 = fixedDateTimeZone32.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone32);
//        java.util.Date date36 = localDate35.toDate();
//        org.joda.time.LocalDate.Property property37 = localDate35.yearOfCentury();
//        org.joda.time.LocalDate localDate39 = property37.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime40 = localDate39.toDateTimeAtMidnight();
//        int[] intArray41 = localDate39.getValues();
//        try {
//            int[] intArray43 = skipUndoDateTimeField20.add((org.joda.time.ReadablePartial) localDate26, (int) (short) -1, intArray41, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(intArray41);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeField dateTimeField5 = limitChronology4.secondOfDay();
        org.joda.time.DateTime dateTime6 = limitChronology4.getUpperLimit();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(dateTime6);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) periodType1);
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, 4);
//        int int16 = fixedDateTimeZone14.getOffsetFromLocal(100L);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        java.util.Date date18 = localDate17.toDate();
//        org.joda.time.LocalDate.Property property19 = localDate17.yearOfCentury();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.Chronology chronology23 = julianChronology21.withZone(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology21.getZone();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 1, dateTimeZone24);
//        org.joda.time.LocalDate localDate26 = localDate17.withFields((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.LocalDate localDate28 = localDate25.plusWeeks((int) '4');
//        int int29 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
//        java.lang.String str30 = offsetDateTimeField8.getName();
//        int int31 = offsetDateTimeField8.getMaximumValue();
//        long long34 = offsetDateTimeField8.add((long) (short) 0, (-14399968L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hourOfHalfday" + "'", str30.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-51839884800000L) + "'", long34 == (-51839884800000L));
//    }
//}

