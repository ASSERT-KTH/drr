import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.Period period5 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        org.joda.time.Period period8 = period6.withMonths((int) (byte) 0);
        org.joda.time.Period period10 = period8.minusWeeks((int) (byte) 10);
        org.joda.time.Period period11 = period5.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period13 = period5.plusDays(58);
        int[] intArray15 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period13, 0L);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        boolean boolean18 = periodType16.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType19 = periodType16.withHoursRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant21, readableDuration22);
        org.joda.time.Period period25 = period23.plusDays(0);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period23.toDurationTo(readableInstant26);
        int int28 = period23.size();
        org.joda.time.Period period29 = period23.normalizedStandard();
        boolean boolean30 = periodType20.equals((java.lang.Object) period29);
        org.joda.time.Days days31 = period29.toStandardDays();
        long long34 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period29, (-65L), 7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(days31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-65L) + "'", long34 == (-65L));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        int int37 = remainderDateTimeField19.getLeapAmount((long) (byte) 100);
        int int38 = remainderDateTimeField19.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 349199999 + "'", int38 == 349199999);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
        org.joda.time.DurationField durationField39 = unsupportedDateTimeField37.getDurationField();
        org.joda.time.PeriodType periodType42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.secondOfMinute();
        org.joda.time.DurationField durationField47 = gregorianChronology45.days();
        org.joda.time.chrono.LenientChronology lenientChronology48 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.Period period49 = org.joda.time.Period.ZERO;
        boolean boolean50 = lenientChronology48.equals((java.lang.Object) period49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) -1, 349260000L, periodType42, (org.joda.time.Chronology) lenientChronology48);
        org.joda.time.DateTimeField dateTimeField52 = lenientChronology48.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (-1));
        java.lang.String str59 = offsetDateTimeField58.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField58.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableInstant63, readableDuration64);
        org.joda.time.Period period67 = period65.plusDays(0);
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableDuration readableDuration69 = null;
        org.joda.time.Period period70 = new org.joda.time.Period(readableInstant68, readableDuration69);
        org.joda.time.Period period72 = period70.plusDays(0);
        org.joda.time.ReadableInstant readableInstant73 = null;
        org.joda.time.Duration duration74 = period70.toDurationTo(readableInstant73);
        int int75 = period70.size();
        org.joda.time.Period period76 = period67.minus((org.joda.time.ReadablePeriod) period70);
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.ReadableDuration readableDuration78 = null;
        org.joda.time.Period period79 = new org.joda.time.Period(readableInstant77, readableDuration78);
        org.joda.time.Period period81 = period79.plusDays(0);
        org.joda.time.PeriodType periodType82 = period79.getPeriodType();
        org.joda.time.PeriodType periodType83 = periodType82.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType85 = periodType83.getFieldType((int) (short) 0);
        org.joda.time.Period period87 = period67.withFieldAdded(durationFieldType85, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField89 = new org.joda.time.field.PreciseDurationField(durationFieldType85, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField90 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType60, (org.joda.time.DurationField) preciseDurationField89);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, dateTimeFieldType60, (-1));
        org.joda.time.IllegalFieldValueException illegalFieldValueException96 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) 7L, (java.lang.Number) 18L, (java.lang.Number) (-53646796800000L));
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField97 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField37, dateTimeFieldType60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(lenientChronology48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str59.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(duration74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 8 + "'", int75 == 8);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(period81);
        org.junit.Assert.assertNotNull(periodType82);
        org.junit.Assert.assertNotNull(periodType83);
        org.junit.Assert.assertNotNull(durationFieldType85);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField90);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.size();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        int int18 = period3.get(durationFieldType17);
        org.joda.time.Duration duration19 = period3.toStandardDuration();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
        boolean boolean22 = periodType20.equals((java.lang.Object) 100.0f);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType20);
        org.joda.time.PeriodType periodType24 = periodType20.withMinutesRemoved();
        org.joda.time.PeriodType periodType25 = periodType20.withHoursRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0L, locale12);
        try {
            long long16 = offsetDateTimeField5.set((long) (-1), "PT0.011S");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0.011S\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        try {
            long long39 = unsupportedDateTimeField37.roundHalfEven((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.PeriodType periodType9 = period6.getPeriodType();
        int int10 = period6.getMonths();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, chronology11);
        org.joda.time.Period period13 = period6.toPeriod();
        int[] intArray16 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period13, 2032L, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (-1));
        long long25 = offsetDateTimeField22.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField26 = offsetDateTimeField22.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField22.getMaximumValue(readablePartial27);
        int int29 = offsetDateTimeField22.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (-1));
        java.lang.String str36 = offsetDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField35.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, dateTimeFieldType37, 8, (int) '4', (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "Standard");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16, dateTimeFieldType37);
        int int49 = dividedDateTimeField16.getDifference(3122385774357L, (-61856080018000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9999L + "'", long25 == 9999L);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 58 + "'", int28 == 58);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 58 + "'", int29 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str36.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        long long40 = preciseDurationField35.add((long) (-1), 3155760000032L);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone41);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField44 = gregorianChronology43.centuries();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.dayOfYear();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.secondOfMinute();
        boolean boolean47 = preciseDurationField35.equals((java.lang.Object) dateTimeField46);
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.minutes();
        boolean boolean52 = periodType50.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Chronology chronology54 = org.joda.time.DateTimeUtils.getChronology(chronology53);
        org.joda.time.Period period55 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType50, chronology53);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period(readableInstant56, readableDuration57);
        org.joda.time.Period period60 = period58.plusDays(0);
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.ReadableDuration readableDuration62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableInstant61, readableDuration62);
        org.joda.time.Period period65 = period63.plusDays(0);
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.Duration duration67 = period63.toDurationTo(readableInstant66);
        int int68 = period63.size();
        org.joda.time.Period period69 = period60.minus((org.joda.time.ReadablePeriod) period63);
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.ReadableDuration readableDuration71 = null;
        org.joda.time.Period period72 = new org.joda.time.Period(readableInstant70, readableDuration71);
        org.joda.time.Period period74 = period72.plusDays(0);
        org.joda.time.PeriodType periodType75 = period72.getPeriodType();
        org.joda.time.PeriodType periodType76 = periodType75.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType78 = periodType76.getFieldType((int) (short) 0);
        org.joda.time.Period period80 = period60.withFieldAdded(durationFieldType78, 0);
        boolean boolean81 = periodType50.isSupported(durationFieldType78);
        org.joda.time.field.DecoratedDurationField decoratedDurationField82 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField35, durationFieldType78);
        int int84 = preciseDurationField35.getValue((long) (-10));
        int int87 = preciseDurationField35.getValue((long) (short) 100, (long) (byte) 10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164099520001663L + "'", long40 == 164099520001663L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(duration67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 8 + "'", int68 == 8);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertNotNull(durationFieldType78);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField5.getAsShortText((long) 32, locale13);
        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.previousTransition(2678400000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2678400000L + "'", long4 == 2678400000L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        int int45 = preciseDurationField35.getValue((long) (-8));
        long long48 = preciseDurationField35.getDifferenceAsLong(1000L, (long) 58);
        long long51 = preciseDurationField35.add(2440588L, (long) '4');
        long long54 = preciseDurationField35.getValueAsLong(32416L, 10L);
        boolean boolean55 = preciseDurationField35.isPrecise();
        long long57 = preciseDurationField35.getValueAsLong(980L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 18L + "'", long48 == 18L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2443292L + "'", long51 == 2443292L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 623L + "'", long54 == 623L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 18L + "'", long57 == 18L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1664L, "PeriodType[StandardNoMillis]");
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("10", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology3.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology3.millis();
        org.joda.time.Period period8 = org.joda.time.Period.hours((int) (short) 1);
        org.joda.time.Period period10 = period8.minusYears((-1));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant11, readableDuration12);
        org.joda.time.Period period15 = period13.plusDays(0);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period13.toDurationTo(readableInstant16);
        int int18 = period13.size();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        int int28 = period13.get(durationFieldType27);
        boolean boolean29 = period10.isSupported(durationFieldType27);
        boolean boolean30 = iSOChronology3.equals((java.lang.Object) boolean29);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Period period6 = period4.multipliedBy((int) (short) 10);
        org.joda.time.Period period8 = period4.minusSeconds(4);
        org.joda.time.DurationFieldType durationFieldType10 = period4.getFieldType(4);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.lang.String str12 = offsetDateTimeField5.getAsText(1560628793872L);
        long long14 = offsetDateTimeField5.roundHalfFloor(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField5.getMinimumValue(readablePartial15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        long long40 = unsupportedDateTimeField37.add((-65L), (int) (short) -1);
        try {
            int int42 = unsupportedDateTimeField37.get(9999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1560628794937L) + "'", long40 == (-1560628794937L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period8 = new org.joda.time.Period(10, (int) (short) 1, 10, 0, (int) (byte) 1, (int) (short) 1, (int) (short) 10, (int) ' ');
        org.joda.time.Period period10 = period8.plusSeconds((int) (short) 100);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period10.withFields(readablePeriod12);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "LenientChronology[GregorianChronology[UTC]]", "DateTimeField[secondOfMinute]");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        long long40 = preciseDurationField35.add((long) (-1), 3155760000032L);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone41);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField44 = gregorianChronology43.centuries();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.dayOfYear();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.secondOfMinute();
        boolean boolean47 = preciseDurationField35.equals((java.lang.Object) dateTimeField46);
        long long50 = preciseDurationField35.getMillis(8, 0L);
        long long53 = preciseDurationField35.getValueAsLong(100L, (long) (-100));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164099520001663L + "'", long40 == 164099520001663L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 416L + "'", long50 == 416L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.Period period15 = org.joda.time.Period.ZERO;
//        org.joda.time.Weeks weeks16 = period15.toStandardWeeks();
//        boolean boolean17 = iSOChronology3.equals((java.lang.Object) period15);
//        org.joda.time.Chronology chronology18 = iSOChronology3.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(weeks16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.Period period6 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology3.getZone();
        org.joda.time.DurationField durationField9 = gregorianChronology3.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(4L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        org.joda.time.Period period10 = period8.plusDays(0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationTo(readableInstant11);
        int int13 = period8.size();
        org.joda.time.Period period14 = period8.normalizedStandard();
        int[] intArray17 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period14, 10964622240000052L, (long) ' ');
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        int int10 = offsetDateTimeField5.getMaximumValue((long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 58 + "'", int10 == 58);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearWeekDayTime]", "Standard", 2, 349199999);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        int int4 = period3.getMonths();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType27, 0L);
        int int32 = period3.get(durationFieldType27);
        int int33 = period3.getMinutes();
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType31 = unsupportedDurationField30.getType();
        long long32 = unsupportedDurationField30.getUnitMillis();
        try {
            long long35 = unsupportedDurationField30.add(5000L, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, (long) 1);
        org.joda.time.Period period4 = period2.minusHours(10);
        org.joda.time.Period period6 = period2.plusYears(0);
        org.joda.time.Period period8 = period6.plusYears((int) (short) -1);
        org.joda.time.Period period10 = period8.minusMonths(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getLeapAmount(1560628791973L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText(4, locale17);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField5.getMaximumShortTextLength(locale19);
        long long23 = offsetDateTimeField5.getDifferenceAsLong(164099520001663L, (long) (short) 10);
        int int24 = offsetDateTimeField5.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 164099520001L + "'", long23 == 164099520001L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (-1));
        java.lang.String str12 = offsetDateTimeField11.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusDays(0);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant21, readableDuration22);
        org.joda.time.Period period25 = period23.plusDays(0);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period23.toDurationTo(readableInstant26);
        int int28 = period23.size();
        org.joda.time.Period period29 = period20.minus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant30, readableDuration31);
        org.joda.time.Period period34 = period32.plusDays(0);
        org.joda.time.PeriodType periodType35 = period32.getPeriodType();
        org.joda.time.PeriodType periodType36 = periodType35.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType38 = periodType36.getFieldType((int) (short) 0);
        org.joda.time.Period period40 = period20.withFieldAdded(durationFieldType38, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField42 = new org.joda.time.field.PreciseDurationField(durationFieldType38, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, (org.joda.time.DurationField) preciseDurationField42);
        java.lang.String str44 = unsupportedDateTimeField43.toString();
        boolean boolean45 = gregorianChronology2.equals((java.lang.Object) unsupportedDateTimeField43);
        long long48 = unsupportedDateTimeField43.getDifferenceAsLong((-62135247590100000L), 3155760000032L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str12.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(durationFieldType38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UnsupportedDateTimeField" + "'", str44.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-39816L) + "'", long48 == (-39816L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.PeriodType periodType7 = period4.getPeriodType();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType7);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        long long41 = unsupportedDateTimeField37.add(0L, (int) (short) -1);
        int int44 = unsupportedDateTimeField37.getDifference(2032L, 993L);
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField37.getAsShortText(9, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1560628794872L) + "'", long41 == (-1560628794872L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.add((long) (-17), (long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-17L) + "'", long47 == (-17L));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long5 = dateTimeZone1.convertLocalToUTC(6983L, false, (long) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6983L + "'", long5 == 6983L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.PeriodType periodType7 = period4.getPeriodType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.Period period10 = new org.joda.time.Period((-1000L), (long) 58, periodType7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DurationField durationField11 = gregorianChronology8.halfdays();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder2.setFixedSavings("UnsupportedDurationField[years]", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.PeriodType periodType34 = periodType2.withSecondsRemoved();
        org.joda.time.DurationFieldType durationFieldType35 = null;
        int int36 = periodType2.indexOf(durationFieldType35);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        int int6 = period2.getMonths();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period2, chronology7);
        try {
            int int10 = period8.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
        org.joda.time.DurationField durationField39 = unsupportedDateTimeField37.getDurationField();
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray41 = null;
        try {
            int int42 = unsupportedDateTimeField37.getMaximumValue(readablePartial40, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period15 = period7.minusMinutes((int) (short) 100);
        org.joda.time.Period period17 = period7.withDays((int) (short) 0);
        org.joda.time.Period period19 = period7.withYears(52);
        int int20 = period19.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
        org.joda.time.DurationField durationField7 = gregorianChronology2.seconds();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.PreciseDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType4 = periodType1.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        boolean boolean30 = periodType4.isSupported(durationFieldType27);
        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.PeriodType periodType32 = periodType4.withSecondsRemoved();
        org.joda.time.Period period33 = new org.joda.time.Period((long) (-1), periodType4);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant34, readableDuration35);
        org.joda.time.Period period38 = period36.plusDays(0);
        org.joda.time.PeriodType periodType39 = period36.getPeriodType();
        org.joda.time.Period period40 = period33.normalizedStandard(periodType39);
        org.joda.time.Period period42 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Period period43 = org.joda.time.Period.ZERO;
        org.joda.time.Period period45 = period43.withMonths((int) (byte) 0);
        org.joda.time.Period period47 = period45.minusWeeks((int) (byte) 10);
        org.joda.time.Period period48 = period42.plus((org.joda.time.ReadablePeriod) period45);
        org.joda.time.Period period50 = period48.multipliedBy((int) (byte) 100);
        org.joda.time.PeriodType periodType51 = period48.getPeriodType();
        java.lang.Object obj52 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        org.joda.time.DurationField durationField56 = gregorianChronology55.millis();
        java.lang.String str57 = gregorianChronology55.toString();
        org.joda.time.Period period58 = new org.joda.time.Period(obj52, (org.joda.time.Chronology) gregorianChronology55);
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology55.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology55.getZone();
        org.joda.time.Period period61 = new org.joda.time.Period((java.lang.Object) period33, periodType51, (org.joda.time.Chronology) gregorianChronology55);
        org.joda.time.DurationField durationField62 = gregorianChronology55.days();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[UTC]" + "'", str57.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(durationField62);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        long long38 = remainderDateTimeField19.addWrapField(0L, 1);
        long long40 = remainderDateTimeField19.roundHalfEven((-903L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2678400000L + "'", long38 == 2678400000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        try {
            long long39 = unsupportedDateTimeField37.roundHalfFloor(416L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField37.getType();
        long long41 = unsupportedDateTimeField37.getDifferenceAsLong(520L, (long) 1000);
        try {
            int int43 = unsupportedDateTimeField37.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long42 = decoratedDurationField38.getUnitMillis();
        java.lang.String str43 = decoratedDurationField38.toString();
        long long45 = decoratedDurationField38.getValueAsLong(5000L);
        long long48 = decoratedDurationField38.add(349260000L, 1);
        long long51 = decoratedDurationField38.getValueAsLong((long) (short) 0, (long) 5900000);
        long long52 = decoratedDurationField38.getUnitMillis();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3155695200000L + "'", long42 == 3155695200000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DurationField[years]" + "'", str43.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3156109260000L + "'", long48 == 3156109260000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3155695200000L + "'", long52 == 3155695200000L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        long long10 = offsetDateTimeField5.add(1560628793872L, (long) (short) 1);
        int int12 = offsetDateTimeField5.getMinimumValue((long) '#');
        long long14 = offsetDateTimeField5.roundHalfCeiling(53000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628794872L + "'", long10 == 1560628794872L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 53000L + "'", long14 == 53000L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        int int3 = period2.getMonths();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.lang.String str11 = dateTimeZone0.getShortName(1000L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        boolean boolean42 = decoratedDurationField38.isPrecise();
        org.joda.time.DurationFieldType durationFieldType43 = decoratedDurationField38.getType();
        long long46 = decoratedDurationField38.getDifferenceAsLong(0L, 164099520001L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        long long40 = unsupportedDateTimeField37.add((-65L), (int) (short) -1);
        int int43 = unsupportedDateTimeField37.getDifference((long) (byte) 0, 10052L);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField37.getAsShortText(4, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1560628794937L) + "'", long40 == (-1560628794937L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = offsetDateTimeField5.getAsText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Period period4 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period6 = period4.withSeconds(0);
        org.joda.time.Days days7 = period6.toStandardDays();
        org.joda.time.Duration duration8 = period6.toStandardDuration();
        org.joda.time.Period period10 = period6.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType12 = period6.getFieldType(4);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "PT0.011S");
        org.joda.time.Period period16 = period1.withField(durationFieldType12, (int) '4');
        org.joda.time.Period period18 = period1.withYears(1000);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.getMillis((int) (short) 0, 0L);
        boolean boolean48 = decoratedDurationField38.isPrecise();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField4 = gregorianChronology2.halfdays();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.days();
        org.joda.time.Period period5 = period3.normalizedStandard(periodType4);
        org.joda.time.PeriodType periodType6 = periodType4.withMillisRemoved();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.Period period8 = new org.joda.time.Period((int) ' ', (int) (short) -1, (int) (short) 100, 100, 1000, (int) ' ', 0, (int) ' ');
        org.joda.time.Period period10 = period8.withMinutes(0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology4.equals(obj5);
        org.joda.time.DurationField durationField7 = iSOChronology4.millis();
        java.lang.String str8 = iSOChronology4.toString();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) (-1000L), (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        long long40 = unsupportedDateTimeField37.add((-65L), (int) (short) -1);
        boolean boolean41 = unsupportedDateTimeField37.isSupported();
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.secondOfMinute();
        org.joda.time.DurationField durationField47 = gregorianChronology45.days();
        org.joda.time.chrono.LenientChronology lenientChronology48 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology45.halfdayOfDay();
        org.joda.time.DurationField durationField50 = gregorianChronology45.minutes();
        org.joda.time.PeriodType periodType52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 0, periodType52);
        int[] intArray55 = gregorianChronology45.get((org.joda.time.ReadablePeriod) period53, (long) '4');
        try {
            int int56 = unsupportedDateTimeField37.getMaximumValue(readablePartial42, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1560628794937L) + "'", long40 == (-1560628794937L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(lenientChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period10 = period8.withSeconds(0);
        org.joda.time.Days days11 = period10.toStandardDays();
        org.joda.time.Duration duration12 = period10.toStandardDuration();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant5, (org.joda.time.ReadableDuration) duration12, periodType15);
        boolean boolean18 = iSOChronology3.equals((java.lang.Object) duration12);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(days11);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField37.getAsText(readablePartial38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        try {
            int int40 = unsupportedDateTimeField37.getMinimumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        long long8 = durationField5.subtract(0L, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-136771200000L) + "'", long8 == (-136771200000L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType8.withWeeksRemoved();
        java.lang.String str12 = periodType8.toString();
        org.joda.time.PeriodType periodType13 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withDaysRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[Minutes]" + "'", str12.equals("PeriodType[Minutes]"));
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        long long40 = unsupportedDateTimeField37.add((-65L), (int) (short) -1);
        int int43 = unsupportedDateTimeField37.getDifference((long) (byte) 0, 10052L);
        try {
            boolean boolean45 = unsupportedDateTimeField37.isLeap((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1560628794937L) + "'", long40 == (-1560628794937L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((int) (byte) -1, (int) (short) 1, (int) (short) 10, 97, (int) '#', (int) ' ', 0, 0);
        long long18 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period15, (long) (short) 100, 7);
        org.joda.time.Period period20 = period15.minusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-100710959900L) + "'", long18 == (-100710959900L));
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        long long41 = unsupportedDateTimeField37.add(0L, (int) (short) -1);
        int int44 = unsupportedDateTimeField37.getDifference(2032L, 993L);
        try {
            java.lang.String str46 = unsupportedDateTimeField37.getAsShortText(32416L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1560628794872L) + "'", long41 == (-1560628794872L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray38 = null;
        try {
            int[] intArray40 = remainderDateTimeField19.set(readablePartial36, 365, intArray38, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Weeks weeks14 = period4.toStandardWeeks();
        int int15 = period4.getHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.toString();
        java.util.TimeZone timeZone5 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1128184613L, 32416L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1128217029L + "'", long2 == 1128217029L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.year();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "0", 10, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffset((long) '4');
        long long8 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType7, 0, 0, (int) (byte) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "97");
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 367869L, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 4, (java.lang.Number) (-52L), (java.lang.Number) 2440588L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone14.getUncachedZone();
//        int int17 = cachedDateTimeZone14.getOffset((-65317017600000L));
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
//        boolean boolean20 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str44 = preciseDurationField35.toString();
        long long47 = preciseDurationField35.add((long) (byte) 100, 7);
        long long50 = preciseDurationField35.getValueAsLong((long) (-10), (-1670400000L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DurationField[years]" + "'", str44.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 464L + "'", long47 == 464L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        int int37 = remainderDateTimeField19.getLeapAmount((long) (byte) 100);
        long long39 = remainderDateTimeField19.roundHalfEven((long) 2440588);
        long long41 = remainderDateTimeField19.roundHalfCeiling((long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Days days5 = period4.toStandardDays();
        org.joda.time.Period period6 = period4.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone15.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (-1), locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone(dateTimeZone15);
//        int int23 = dateTimeZone15.getOffsetFromLocal((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone15.getName(151381342362584L, locale26);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        long long40 = unsupportedDateTimeField37.add((-65L), (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray43 = null;
        try {
            int[] intArray45 = unsupportedDateTimeField37.set(readablePartial41, (int) '#', intArray43, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1560628794937L) + "'", long40 == (-1560628794937L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = lenientChronology5.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, 0, 128);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = periodType3.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.Period period7 = period2.normalizedStandard(periodType3);
        org.joda.time.PeriodType periodType8 = periodType3.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("PT0S", 9, 97, 10, ' ', (-100), (-100), (int) (byte) -1, false, 97);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder2.toDateTimeZone("-01:00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder2.setFixedSavings("", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = dateTimeZoneBuilder2.addRecurringSavings("DurationField[hours]", 9, 349199999, 3, ' ', (int) (short) 10, (int) (byte) 100, (-32), false, (-1));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder30);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.PeriodType periodType19 = period16.getPeriodType();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period4.withFieldAdded(durationFieldType22, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType22, 1560628794872L);
        long long29 = preciseDurationField26.getDifferenceAsLong(623L, (long) (byte) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
        long long6 = dateTimeZone0.convertUTCToLocal(11L);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = dateTimeZone0.getOffset(readableInstant7);
        java.util.TimeZone timeZone9 = dateTimeZone0.toTimeZone();
        int int11 = dateTimeZone0.getOffsetFromLocal(1128184613L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((long) (-8));
        boolean boolean18 = offsetDateTimeField5.isLeap((long) 97);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfMinute();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (-1));
        java.lang.String str32 = offsetDateTimeField31.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField31.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 349200000);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone36);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (-1));
        long long44 = offsetDateTimeField41.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField45 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial46 = null;
        int int47 = offsetDateTimeField41.getMaximumValue(readablePartial46);
        int int48 = offsetDateTimeField41.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone49);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (-1));
        java.lang.String str55 = offsetDateTimeField54.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField54.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField41, dateTimeFieldType56, 8, (int) '4', (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, "Standard");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35, dateTimeFieldType56);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType56, 10, (int) (short) 1, (int) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, "5900000");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "58" + "'", str16.equals("58"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str32.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9999L + "'", long44 == 9999L);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 58 + "'", int47 == 58);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 58 + "'", int48 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str55.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        try {
            long long35 = remainderDateTimeField19.addWrapField(935L, (-3600000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 345600001 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology2.centuries();
        org.joda.time.DurationField durationField8 = gregorianChronology2.years();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long42 = decoratedDurationField38.getUnitMillis();
        java.lang.String str43 = decoratedDurationField38.toString();
        long long45 = decoratedDurationField38.getValueAsLong(5000L);
        long long48 = decoratedDurationField38.add(164099520001L, (long) (byte) 1);
        long long51 = decoratedDurationField38.getValueAsLong(34712647200000L, (long) 349200000);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3155695200000L + "'", long42 == 3155695200000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DurationField[years]" + "'", str43.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3319859520001L + "'", long48 == 3319859520001L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.Period period1 = org.joda.time.Period.millis(58);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone15.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (-1), locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone(dateTimeZone15);
//        org.joda.time.Chronology chronology22 = iSOChronology3.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        long long18 = dividedDateTimeField16.remainder((long) 52);
        int int20 = dividedDateTimeField16.get((long) 2440588);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) 'a');
        org.joda.time.Period period6 = period4.minusYears(8);
        org.joda.time.Period period8 = period4.withMillis((-17));
        int int9 = period4.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        try {
            long long21 = dividedDateTimeField16.roundHalfCeiling(9000L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField37.getAsShortText((-1560628794937L), locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNull(durationField38);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        int int37 = remainderDateTimeField19.getLeapAmount((long) (byte) 100);
        long long39 = remainderDateTimeField19.roundHalfEven((long) 2440588);
        long long41 = remainderDateTimeField19.remainder((-65L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2678399935L + "'", long41 == 2678399935L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.year();
        try {
            long long14 = gregorianChronology2.getDateTimeMillis((int) '4', (int) (short) 100, 10, 0, 0, (int) ' ', (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant3, readableDuration4);
        org.joda.time.Period period7 = period5.plusDays(0);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period5.toDurationTo(readableInstant8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration9, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withDaysRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType12);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.Period period8 = new org.joda.time.Period(32, (int) (byte) 0, 4, 10, (int) (short) 10, 7, (int) (byte) 1, (int) (short) 100);
        int int9 = period8.getMillis();
        int[] intArray10 = period8.getValues();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.PeriodType periodType19 = period16.getPeriodType();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period4.withFieldAdded(durationFieldType22, 0);
        org.joda.time.Period period26 = period24.minusHours((-100));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (long) (short) 1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationTo(readableInstant12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration13, periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withDaysRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType18);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField37.getAsText((-28800000), locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNull(durationField38);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test115");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone15.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (-1), locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone(dateTimeZone15);
//        int int23 = dateTimeZone15.getOffsetFromLocal((long) '#');
//        java.lang.String str25 = dateTimeZone15.getShortName(0L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone15.getShortName(3155760000000L, locale27);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        long long41 = unsupportedDateTimeField37.add((long) (-1), (-100));
        long long44 = unsupportedDateTimeField37.add(349260000L, 97);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField37.getRangeDurationField();
        boolean boolean46 = unsupportedDateTimeField37.isSupported();
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone49);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (-1));
        long long57 = offsetDateTimeField54.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField58 = offsetDateTimeField54.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = offsetDateTimeField54.getMaximumValue(readablePartial59);
        int int61 = offsetDateTimeField54.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int[] intArray69 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int70 = offsetDateTimeField54.getMaximumValue(readablePartial62, intArray69);
        try {
            int[] intArray72 = unsupportedDateTimeField37.set(readablePartial47, 7, intArray69, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-156062879487201L) + "'", long41 == (-156062879487201L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 151381342362584L + "'", long44 == 151381342362584L);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9999L + "'", long57 == 9999L);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 58 + "'", int60 == 58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 58 + "'", int61 == 58);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 58 + "'", int70 == 58);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField16 = gregorianChronology14.days();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.halfdayOfDay();
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant21 = null;
        int int22 = dateTimeZone20.getOffset(readableInstant21);
        org.joda.time.Chronology chronology23 = gregorianChronology14.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology14.dayOfYear();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        org.joda.time.Period period29 = period27.plusDays(0);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period27.toDurationTo(readableInstant30);
        int int32 = period27.size();
        org.joda.time.Period period33 = period27.normalizedStandard();
        int int34 = period27.getDays();
        org.joda.time.Period period36 = period27.minusMonths((int) (short) 1);
        int[] intArray38 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period36, 7L);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant39, readableDuration40);
        org.joda.time.Period period43 = period41.plusDays(0);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period(readableInstant44, readableDuration45);
        org.joda.time.Period period48 = period46.plusDays(0);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Duration duration50 = period46.toDurationTo(readableInstant49);
        int int51 = period46.size();
        org.joda.time.Period period52 = period43.minus((org.joda.time.ReadablePeriod) period46);
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant53, readableDuration54);
        org.joda.time.Period period57 = period55.plusDays(0);
        org.joda.time.PeriodType periodType58 = period55.getPeriodType();
        org.joda.time.PeriodType periodType59 = periodType58.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType61 = periodType59.getFieldType((int) (short) 0);
        org.joda.time.Period period63 = period43.withFieldAdded(durationFieldType61, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(durationFieldType61, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.Period period67 = period36.withField(durationFieldType61, (int) (short) -1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(duration50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 8 + "'", int51 == 8);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(durationFieldType61);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period67);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        boolean boolean31 = unsupportedDurationField30.isSupported();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (-1));
        java.lang.String str38 = offsetDateTimeField37.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField37.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.minutes();
        boolean boolean46 = periodType44.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType44, chronology47);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant50, readableDuration51);
        org.joda.time.Period period54 = period52.plusDays(0);
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period(readableInstant55, readableDuration56);
        org.joda.time.Period period59 = period57.plusDays(0);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Duration duration61 = period57.toDurationTo(readableInstant60);
        int int62 = period57.size();
        org.joda.time.Period period63 = period54.minus((org.joda.time.ReadablePeriod) period57);
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.ReadableDuration readableDuration65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period(readableInstant64, readableDuration65);
        org.joda.time.Period period68 = period66.plusDays(0);
        org.joda.time.PeriodType periodType69 = period66.getPeriodType();
        org.joda.time.PeriodType periodType70 = periodType69.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType72 = periodType70.getFieldType((int) (short) 0);
        org.joda.time.Period period74 = period54.withFieldAdded(durationFieldType72, 0);
        boolean boolean75 = periodType44.isSupported(durationFieldType72);
        org.joda.time.field.PreciseDurationField preciseDurationField77 = new org.joda.time.field.PreciseDurationField(durationFieldType72, (long) '4');
        long long79 = preciseDurationField77.getMillis(58);
        int int82 = preciseDurationField77.getValue((-65L), (-210866760000000L));
        long long85 = preciseDurationField77.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str86 = preciseDurationField77.toString();
        long long89 = preciseDurationField77.add((long) (byte) 100, 7);
        long long92 = preciseDurationField77.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField93 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField77);
        int int94 = unsupportedDurationField30.compareTo((org.joda.time.DurationField) preciseDurationField77);
        java.lang.String str95 = unsupportedDurationField30.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str38.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(duration61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 8 + "'", int62 == 8);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(durationFieldType72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 3016L + "'", long79 == 3016L);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-17L) + "'", long85 == (-17L));
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "DurationField[years]" + "'", str86.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 464L + "'", long89 == 464L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 0L + "'", long92 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "years" + "'", str95.equals("years"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = unsupportedDateTimeField37.getAsText(readablePartial39, (-7), locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNull(durationField38);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getDurationField();
        boolean boolean39 = unsupportedDateTimeField37.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField37.getType();
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField37.getAsText(readablePartial41, (int) (byte) -1, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        long long41 = unsupportedDateTimeField37.add(0L, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField37.getType();
        long long45 = unsupportedDateTimeField37.getDifferenceAsLong(1560628793872L, 1560628791973L);
        try {
            int int47 = unsupportedDateTimeField37.getLeapAmount((-1128184612L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1560628794872L) + "'", long41 == (-1560628794872L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DateTimeField[secondOfMinute]", "DurationField[years]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "PT10M", "Minutes");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "ISOChronology[UTC]", "PeriodType[YearDayTime]");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "5900000", "");
        java.util.Locale locale17 = null;
        java.lang.String str20 = defaultNameProvider0.getName(locale17, "58", "PT0.010S");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        org.joda.time.Period period18 = new org.joda.time.Period(0, 100, (int) (byte) 10, 0, (int) (byte) -1, 0, 0, (int) (byte) 0, periodType15);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str20 = gregorianChronology19.toString();
        org.joda.time.Period period21 = new org.joda.time.Period((long) 7, periodType15, (org.joda.time.Chronology) gregorianChronology19);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GregorianChronology[UTC]" + "'", str20.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        java.lang.String str41 = preciseDurationField35.getName();
        boolean boolean42 = preciseDurationField35.isSupported();
        long long45 = preciseDurationField35.getDifferenceAsLong((long) (byte) 1, (-61711196229903L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "years" + "'", str41.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1186753773652L + "'", long45 == 1186753773652L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.standard();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) gregorianChronology4, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText(readablePartial14, (int) (short) 100, locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (-1));
        long long26 = offsetDateTimeField23.add((long) 'a', (long) (-1));
        java.lang.String str28 = offsetDateTimeField23.getAsText((long) 0);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField23.getAsText((int) (short) 100, locale30);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray34 = new int[] { '#' };
        int int35 = offsetDateTimeField23.getMinimumValue(readablePartial32, intArray34);
        org.joda.time.DurationField durationField36 = offsetDateTimeField23.getRangeDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone39);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (-1));
        long long47 = offsetDateTimeField44.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField48 = offsetDateTimeField44.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = offsetDateTimeField44.getMaximumValue(readablePartial49);
        int int51 = offsetDateTimeField44.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone52);
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (-1));
        java.lang.String str58 = offsetDateTimeField57.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = offsetDateTimeField57.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, dateTimeFieldType59, 8, (int) '4', (int) (short) 1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, dateTimeFieldType59, 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType59, 10, 97, 3);
        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) (-1670400000L), "");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-903L) + "'", long26 == (-903L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "100" + "'", str31.equals("100"));
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9999L + "'", long47 == 9999L);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 58 + "'", int50 == 58);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 58 + "'", int51 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str58.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
        long long6 = dateTimeZone0.convertUTCToLocal(11L);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = dateTimeZone0.getOffset(readableInstant7);
        long long12 = dateTimeZone0.convertLocalToUTC(0L, true, (-61856080018000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone1.getName((long) (byte) 0, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        long long10 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, 0L);
//        long long13 = dateTimeZone8.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone15.getUncachedZone();
//        org.joda.time.Chronology chronology17 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
//        int int19 = cachedDateTimeZone15.getOffset(34712647200000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(59000L, 2032L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56968L + "'", long2 == 56968L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (-1));
        long long25 = offsetDateTimeField22.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField26 = offsetDateTimeField22.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField22.getMaximumValue(readablePartial27);
        int int29 = offsetDateTimeField22.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (-1));
        java.lang.String str36 = offsetDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField35.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, dateTimeFieldType37, 8, (int) '4', (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "Standard");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16, dateTimeFieldType37);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField46, dateTimeFieldType47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9999L + "'", long25 == 9999L);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 58 + "'", int28 == 58);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 58 + "'", int29 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str36.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(60787497600058L, 1560628795000L, chronology2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        int int4 = period3.getMonths();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType27, 0L);
        int int32 = period3.get(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField33 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        java.lang.String str34 = unsupportedDurationField33.toString();
        org.joda.time.DurationFieldType durationFieldType35 = unsupportedDurationField33.getType();
        boolean boolean36 = unsupportedDurationField33.isPrecise();
        java.lang.String str37 = unsupportedDurationField33.getName();
        try {
            long long40 = unsupportedDurationField33.getMillis(0, 1560628794872L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDurationField[years]" + "'", str34.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "years" + "'", str37.equals("years"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType31 = unsupportedDurationField30.getType();
        long long32 = unsupportedDurationField30.getUnitMillis();
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.minutes();
        boolean boolean35 = periodType33.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType36 = periodType33.withHoursRemoved();
        boolean boolean37 = unsupportedDurationField30.equals((java.lang.Object) periodType33);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone38);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        org.joda.time.DurationField durationField41 = gregorianChronology40.centuries();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.minutes();
        boolean boolean46 = periodType44.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType44, chronology47);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant50, readableDuration51);
        org.joda.time.Period period54 = period52.plusDays(0);
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period(readableInstant55, readableDuration56);
        org.joda.time.Period period59 = period57.plusDays(0);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Duration duration61 = period57.toDurationTo(readableInstant60);
        int int62 = period57.size();
        org.joda.time.Period period63 = period54.minus((org.joda.time.ReadablePeriod) period57);
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.ReadableDuration readableDuration65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period(readableInstant64, readableDuration65);
        org.joda.time.Period period68 = period66.plusDays(0);
        org.joda.time.PeriodType periodType69 = period66.getPeriodType();
        org.joda.time.PeriodType periodType70 = periodType69.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType72 = periodType70.getFieldType((int) (short) 0);
        org.joda.time.Period period74 = period54.withFieldAdded(durationFieldType72, 0);
        boolean boolean75 = periodType44.isSupported(durationFieldType72);
        org.joda.time.field.DecoratedDurationField decoratedDurationField76 = new org.joda.time.field.DecoratedDurationField(durationField41, durationFieldType72);
        int int77 = unsupportedDurationField30.compareTo((org.joda.time.DurationField) decoratedDurationField76);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(duration61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 8 + "'", int62 == 8);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(durationFieldType72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        int int16 = period10.getDays();
        jodaTimePermission7.checkGuard((java.lang.Object) period10);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        org.joda.time.DurationField durationField22 = gregorianChronology20.days();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.halfdayOfDay();
        boolean boolean25 = jodaTimePermission7.equals((java.lang.Object) gregorianChronology20);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant27 = null;
        int int28 = dateTimeZone26.getOffset(readableInstant27);
        org.joda.time.Chronology chronology29 = gregorianChronology20.withZone(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone26);
        try {
            long long36 = zonedChronology30.getDateTimeMillis((long) 9, 8, 97, (-7), 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(zonedChronology30);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long39 = decoratedDurationField38.getUnitMillis();
        org.joda.time.DurationField durationField40 = decoratedDurationField38.getWrappedField();
        long long43 = decoratedDurationField38.getMillis((int) '#', (-210866846400000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3155695200000L + "'", long39 == 3155695200000L);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 110449267200000L + "'", long43 == 110449267200000L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withDaysRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(10052L, periodType12, chronology13);
        org.joda.time.Weeks weeks15 = period14.toStandardWeeks();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(weeks15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-1128184612L), "Standard");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 365);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 360000000 + "'", int3 == 360000000);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        long long21 = dividedDateTimeField16.remainder(8533175040086476L);
        try {
            long long23 = dividedDateTimeField16.roundFloor(10010L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8533175040086476L + "'", long21 == 8533175040086476L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "0", 10, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey(1128184613L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str44 = preciseDurationField35.toString();
        long long47 = preciseDurationField35.add((long) (byte) 100, 7);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone48);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField51 = gregorianChronology50.centuries();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.clockhourOfDay();
        org.joda.time.DurationField durationField53 = gregorianChronology50.hours();
        boolean boolean54 = preciseDurationField35.equals((java.lang.Object) durationField53);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DurationField[years]" + "'", str44.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 464L + "'", long47 == 464L);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong((long) 5900000, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        java.lang.String str3 = dateTimeZone0.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        long long6 = cachedDateTimeZone4.nextTransition(9000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9000L + "'", long6 == 9000L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "+97:01");
        illegalFieldValueException11.prependMessage("");
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException11.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.DurationFieldType durationFieldType32 = illegalFieldValueException31.getDurationFieldType();
        boolean boolean33 = gregorianChronology0.equals((java.lang.Object) illegalFieldValueException31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = gregorianChronology2.set(readablePartial7, 164099520001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException10.getDurationFieldType();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str13 = illegalFieldValueException10.getIllegalValueAsString();
        java.lang.String str14 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str15 = illegalFieldValueException10.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException10.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        boolean boolean18 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = illegalFieldValueException10.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(dateTimeFieldType19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.PeriodType periodType19 = period16.getPeriodType();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period4.withFieldAdded(durationFieldType22, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(durationFieldType22, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.DurationFieldType durationFieldType27 = illegalFieldValueException26.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 100L, (java.lang.Number) 58, (java.lang.Number) 5200L);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType27);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        org.joda.time.DurationField durationField18 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (-1));
        long long29 = offsetDateTimeField26.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField30 = offsetDateTimeField26.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = offsetDateTimeField26.getMaximumValue(readablePartial31);
        int int33 = offsetDateTimeField26.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone34);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (-1));
        java.lang.String str40 = offsetDateTimeField39.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField39.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, dateTimeFieldType41, 8, (int) '4', (int) (short) 1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType41, 2);
        int int50 = offsetDateTimeField5.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9999L + "'", long29 == 9999L);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 58 + "'", int32 == 58);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 58 + "'", int33 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str40.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int16 = cachedDateTimeZone14.getStandardOffset(97000L);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder17.setStandardOffset(32);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = dateTimeZoneBuilder19.addRecurringSavings("PT0S", 9, 97, 10, ' ', (-100), (-100), (int) (byte) -1, false, 97);
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeZoneBuilder19.toDateTimeZone("-01:00", false);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder36 = dateTimeZoneBuilder19.setFixedSavings("", 0);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder38 = dateTimeZoneBuilder36.setStandardOffset(0);
//        boolean boolean39 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int16, (java.lang.Object) dateTimeZoneBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) periodType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58" + "'", str3.equals("58"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        org.joda.time.Period period7 = period4.minusMillis((-1));
        int int8 = period7.getWeeks();
        org.joda.time.Period period10 = period7.minusMonths((int) (short) 100);
        org.joda.time.Period period12 = period7.minusMillis((int) (short) 1);
        org.joda.time.Period period14 = period7.withMinutes((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.PeriodType periodType28 = period25.getPeriodType();
        org.joda.time.PeriodType periodType29 = periodType28.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        int int32 = period17.get(durationFieldType31);
        int int33 = period7.get(durationFieldType31);
        int int34 = period7.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField37.getType();
        long long41 = unsupportedDateTimeField37.getDifferenceAsLong(520L, (long) 1000);
        try {
            long long43 = unsupportedDateTimeField37.roundFloor(323913770L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0, locale12);
        int int14 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-1));
        long long24 = offsetDateTimeField21.add((long) 'a', (long) (-1));
        java.lang.String str26 = offsetDateTimeField21.getAsText((long) 0);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText(0, locale28);
        long long32 = offsetDateTimeField21.set((long) ' ', (int) '#');
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField21.getAsText(readablePartial33, 4, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone38);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        org.joda.time.DurationField durationField41 = gregorianChronology40.centuries();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.dayOfYear();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.minuteOfDay();
        org.joda.time.DurationField durationField44 = gregorianChronology40.weekyears();
        org.joda.time.DurationField durationField45 = gregorianChronology40.seconds();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology40.minuteOfDay();
        org.joda.time.Period period47 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray48 = period47.getFieldTypes();
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.minutes();
        boolean boolean51 = periodType49.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType52 = periodType49.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant53, readableDuration54);
        org.joda.time.Period period57 = period55.plusDays(0);
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period(readableInstant58, readableDuration59);
        org.joda.time.Period period62 = period60.plusDays(0);
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.Duration duration64 = period60.toDurationTo(readableInstant63);
        int int65 = period60.size();
        org.joda.time.Period period66 = period57.minus((org.joda.time.ReadablePeriod) period60);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.ReadableDuration readableDuration68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period(readableInstant67, readableDuration68);
        org.joda.time.Period period71 = period69.plusDays(0);
        org.joda.time.PeriodType periodType72 = period69.getPeriodType();
        org.joda.time.PeriodType periodType73 = periodType72.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType75 = periodType73.getFieldType((int) (short) 0);
        org.joda.time.Period period77 = period57.withFieldAdded(durationFieldType75, 0);
        boolean boolean78 = periodType52.isSupported(durationFieldType75);
        org.joda.time.Period period80 = period47.withFieldAdded(durationFieldType75, 0);
        int[] intArray82 = gregorianChronology40.get((org.joda.time.ReadablePeriod) period80, (long) 32);
        int int83 = offsetDateTimeField21.getMaximumValue(readablePartial37, intArray82);
        int int84 = offsetDateTimeField5.getMinimumValue(readablePartial15, intArray82);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-903L) + "'", long24 == (-903L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-1" + "'", str26.equals("-1"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 36032L + "'", long32 == 36032L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "4" + "'", str36.equals("4"));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationFieldTypeArray48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(duration64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 8 + "'", int65 == 8);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(durationFieldType75);
        org.junit.Assert.assertNotNull(period77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 58 + "'", int83 == 58);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        int int4 = period3.getMonths();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType27, 0L);
        int int32 = period3.get(durationFieldType27);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.Period period34 = period3.minus(readablePeriod33);
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant11, readableDuration12);
        org.joda.time.Period period15 = period13.plusDays(0);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusDays(0);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Duration duration22 = period18.toDurationTo(readableInstant21);
        int int23 = period18.size();
        org.joda.time.Period period24 = period15.minus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        org.joda.time.Period period29 = period27.plusDays(0);
        org.joda.time.PeriodType periodType30 = period27.getPeriodType();
        org.joda.time.PeriodType periodType31 = periodType30.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType((int) (short) 0);
        org.joda.time.Period period35 = period15.withFieldAdded(durationFieldType33, 0);
        boolean boolean36 = period10.isSupported(durationFieldType33);
        org.joda.time.field.PreciseDurationField preciseDurationField38 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField39 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType33);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(duration22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField39);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField37.getType();
        long long41 = unsupportedDateTimeField37.getDifferenceAsLong(520L, (long) 1000);
        try {
            long long44 = unsupportedDateTimeField37.set(1560628795000L, (-3600000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        boolean boolean19 = offsetDateTimeField5.isLeap(31556952000000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long35 = dividedDateTimeField32.getDifferenceAsLong((-210858120000000L), 464L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        int int16 = period10.getDays();
        jodaTimePermission7.checkGuard((java.lang.Object) period10);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        org.joda.time.DurationField durationField22 = gregorianChronology20.days();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.halfdayOfDay();
        boolean boolean25 = jodaTimePermission7.equals((java.lang.Object) gregorianChronology20);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant27 = null;
        int int28 = dateTimeZone26.getOffset(readableInstant27);
        org.joda.time.Chronology chronology29 = gregorianChronology20.withZone(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone26);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.minutes();
        boolean boolean35 = periodType33.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology(chronology36);
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType33, chronology36);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant39, readableDuration40);
        org.joda.time.Period period43 = period41.plusDays(0);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period(readableInstant44, readableDuration45);
        org.joda.time.Period period48 = period46.plusDays(0);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Duration duration50 = period46.toDurationTo(readableInstant49);
        int int51 = period46.size();
        org.joda.time.Period period52 = period43.minus((org.joda.time.ReadablePeriod) period46);
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant53, readableDuration54);
        org.joda.time.Period period57 = period55.plusDays(0);
        org.joda.time.PeriodType periodType58 = period55.getPeriodType();
        org.joda.time.PeriodType periodType59 = periodType58.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType61 = periodType59.getFieldType((int) (short) 0);
        org.joda.time.Period period63 = period43.withFieldAdded(durationFieldType61, 0);
        boolean boolean64 = periodType33.isSupported(durationFieldType61);
        org.joda.time.field.PreciseDurationField preciseDurationField66 = new org.joda.time.field.PreciseDurationField(durationFieldType61, (long) '4');
        long long68 = preciseDurationField66.getMillis(58);
        int int71 = preciseDurationField66.getValue((-65L), (-210866760000000L));
        long long74 = preciseDurationField66.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str75 = preciseDurationField66.toString();
        long long78 = preciseDurationField66.add((long) (byte) 100, 7);
        java.lang.String str79 = preciseDurationField66.getName();
        boolean boolean80 = zonedChronology30.equals((java.lang.Object) str79);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(duration50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 8 + "'", int51 == 8);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(durationFieldType61);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 3016L + "'", long68 == 3016L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-17L) + "'", long74 == (-17L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "DurationField[years]" + "'", str75.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 464L + "'", long78 == 464L);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "years" + "'", str79.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0, locale12);
        long long16 = offsetDateTimeField5.set((long) ' ', (int) '#');
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText(readablePartial17, 32, locale19);
        long long22 = offsetDateTimeField5.roundHalfEven((-1128234612L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 36032L + "'", long16 == 36032L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "32" + "'", str20.equals("32"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1128235000L) + "'", long22 == (-1128235000L));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long6 = dateTimeZone3.adjustOffset((long) '4', false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone3.getName((-784L), locale9);
//        java.lang.String str12 = dateTimeZone3.getShortName((-65L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.PeriodType periodType9 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        int int11 = periodType10.size();
        org.joda.time.PeriodType periodType12 = periodType10.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long40 = decoratedDurationField38.getMillis(11L);
        int int42 = decoratedDurationField38.getValue(22089887999999L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 34712647200000L + "'", long40 == 34712647200000L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 7 + "'", int42 == 7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        int int16 = period10.getDays();
        jodaTimePermission7.checkGuard((java.lang.Object) period10);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        org.joda.time.DurationField durationField22 = gregorianChronology20.days();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.halfdayOfDay();
        boolean boolean25 = jodaTimePermission7.equals((java.lang.Object) gregorianChronology20);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant27 = null;
        int int28 = dateTimeZone26.getOffset(readableInstant27);
        org.joda.time.Chronology chronology29 = gregorianChronology20.withZone(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone31 = zonedChronology30.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.getMillis((int) (short) 0, 0L);
        long long49 = decoratedDurationField38.getValueAsLong(0L);
        boolean boolean50 = decoratedDurationField38.isPrecise();
        long long51 = decoratedDurationField38.getUnitMillis();
        long long53 = decoratedDurationField38.getMillis(7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 3155695200000L + "'", long51 == 3155695200000L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 22089866400000L + "'", long53 == 22089866400000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor(367869L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 368000L + "'", long14 == 368000L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        int int9 = period2.getDays();
        org.joda.time.Period period11 = period2.withWeeks((int) '#');
        org.joda.time.Period period12 = period2.toPeriod();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType14 = periodType13.withMillisRemoved();
        java.lang.String str15 = periodType13.toString();
        org.joda.time.PeriodType periodType16 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.Period period18 = period12.normalizedStandard(periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        java.lang.String str21 = periodType19.toString();
        org.joda.time.PeriodType periodType22 = periodType19.withYearsRemoved();
        org.joda.time.Period period23 = period12.withPeriodType(periodType19);
        try {
            org.joda.time.Period period25 = period23.withYears(32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PeriodType[Minutes]" + "'", str15.equals("PeriodType[Minutes]"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PeriodType[Minutes]" + "'", str21.equals("PeriodType[Minutes]"));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "0", 10, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffset((long) '4');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationTo(readableInstant12);
        int int14 = period9.size();
        org.joda.time.Period period15 = period9.normalizedStandard();
        org.joda.time.Period period17 = period15.withMonths((int) (short) 100);
        boolean boolean18 = fixedDateTimeZone4.equals((java.lang.Object) period15);
        boolean boolean19 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.getMillis((int) (short) 0, 0L);
        long long50 = decoratedDurationField38.getDifferenceAsLong((long) 3, 3155695200000L);
        long long53 = decoratedDurationField38.getDifferenceAsLong(1560628794872L, 1L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getLeapAmount(1560628791973L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText(4, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField5.getAsShortText((int) '4', locale20);
        int int23 = offsetDateTimeField5.getMaximumValue(5000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "52" + "'", str21.equals("52"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        int int4 = period3.getMonths();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period12.toDurationTo(readableInstant15);
        int int17 = period12.size();
        org.joda.time.Period period18 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableDuration20);
        org.joda.time.Period period23 = period21.plusDays(0);
        org.joda.time.PeriodType periodType24 = period21.getPeriodType();
        org.joda.time.PeriodType periodType25 = periodType24.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period9.withFieldAdded(durationFieldType27, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType27, 0L);
        int int32 = period3.get(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField33 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        java.lang.String str34 = unsupportedDurationField33.toString();
        try {
            long long36 = unsupportedDurationField33.getValueAsLong((-65317017600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDurationField[years]" + "'", str34.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = lenientChronology5.centuries();
        org.joda.time.DurationField durationField7 = lenientChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology5.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        int int15 = period11.getMonths();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period11, chronology16);
        boolean boolean18 = lenientChronology5.equals((java.lang.Object) period11);
        org.joda.time.DurationField durationField19 = lenientChronology5.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.Period period1 = new org.joda.time.Period(3155695200000L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        org.joda.time.Period period7 = period4.minusMillis((-1));
        org.joda.time.Period period9 = period7.plusYears((int) (byte) 0);
        org.joda.time.Period period10 = period9.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        java.lang.String str39 = decoratedDurationField38.getName();
        long long40 = decoratedDurationField38.getUnitMillis();
        int int43 = decoratedDurationField38.getDifference(7L, 53735L);
        boolean boolean44 = decoratedDurationField38.isPrecise();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "years" + "'", str39.equals("years"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 3155695200000L + "'", long40 == 3155695200000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int36 = remainderDateTimeField19.get((long) (-7));
        try {
            long long39 = remainderDateTimeField19.set(244059000L, 1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getDurationField();
        boolean boolean39 = unsupportedDateTimeField37.isLenient();
        try {
            int int40 = unsupportedDateTimeField37.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.getMonths();
        org.joda.time.Period period3 = period0.withMinutes(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        int int45 = preciseDurationField35.getValue((long) (-8));
        long long48 = preciseDurationField35.getDifferenceAsLong((long) (-32), 12691057600L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-244058800L) + "'", long48 == (-244058800L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period2 = period0.normalizedStandard();
        org.joda.time.Period period4 = period0.withHours((int) (short) -1);
        org.joda.time.Hours hours5 = period0.toStandardHours();
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(hours5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        long long14 = offsetDateTimeField5.roundFloor(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.secondOfMinute();
        org.joda.time.DurationField durationField20 = gregorianChronology18.days();
        org.joda.time.chrono.LenientChronology lenientChronology21 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.halfdayOfDay();
        org.joda.time.DurationField durationField23 = gregorianChronology18.minutes();
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, periodType25);
        int[] intArray28 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period26, (long) '4');
        int int29 = offsetDateTimeField5.getMaximumValue(readablePartial15, intArray28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int int31 = offsetDateTimeField5.getMaximumValue(readablePartial30);
        long long34 = offsetDateTimeField5.add((-1000L), (long) 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (-47200000));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(lenientChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 58 + "'", int29 == 58);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 58 + "'", int31 == 58);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 51000L + "'", long34 == 51000L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "0", 10, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffset((long) '4');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationTo(readableInstant12);
        int int14 = period9.size();
        org.joda.time.Period period15 = period9.normalizedStandard();
        org.joda.time.Period period17 = period15.withMonths((int) (short) 100);
        boolean boolean18 = fixedDateTimeZone4.equals((java.lang.Object) period15);
        int int19 = period15.getMinutes();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        long long34 = remainderDateTimeField19.roundHalfFloor(3016L);
        int int35 = remainderDateTimeField19.getMinimumValue();
        long long38 = remainderDateTimeField19.addWrapField(0L, 1);
        java.util.Locale locale39 = null;
        int int40 = remainderDateTimeField19.getMaximumShortTextLength(locale39);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2678400000L + "'", long38 == 2678400000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType31 = unsupportedDurationField30.getType();
        long long32 = unsupportedDurationField30.getUnitMillis();
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.minutes();
        boolean boolean35 = periodType33.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType36 = periodType33.withHoursRemoved();
        boolean boolean37 = unsupportedDurationField30.equals((java.lang.Object) periodType33);
        try {
            long long40 = unsupportedDurationField30.getMillis((long) 0, 323913770031L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        java.lang.String str8 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number9 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        org.joda.time.PeriodType periodType6 = periodType5.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.PeriodType periodType9 = periodType6.withMillisRemoved();
        org.joda.time.PeriodType periodType10 = periodType6.withWeeksRemoved();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType14, 349200000);
        int int18 = dividedDateTimeField16.get(35032L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.lang.String str26 = offsetDateTimeField25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType27);
        org.joda.time.DurationField durationField33 = dividedDateTimeField32.getDurationField();
        int int35 = dividedDateTimeField32.get((long) 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str26.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }
}

