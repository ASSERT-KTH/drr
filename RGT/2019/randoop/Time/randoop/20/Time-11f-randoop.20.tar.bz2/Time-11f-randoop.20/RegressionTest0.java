import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 100, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) (-1.0f), (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType5 = periodType0.getFieldType((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        int int5 = period2.getWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PT0S", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        java.lang.String str4 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Minutes" + "'", str4.equals("Minutes"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        boolean boolean3 = periodType1.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology4 = null;
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) nameProvider0, periodType1, chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.DefaultNameProvider");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nameProvider0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (byte) 0, (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '#', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-65L) + "'", long2 == (-65L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withField(durationFieldType4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = periodType8.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType11 = periodType8.withHoursRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(1, (int) (short) 0, (int) (byte) 1, (int) '#', 10, (int) (short) -1, (int) (byte) -1, (-1), periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone0.getOffset(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Minutes", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Minutes/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        try {
            long long9 = gregorianChronology2.getDateTimeMillis((long) 8, (int) '#', 0, (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 10, locale4);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        long long6 = durationField3.subtract(10L, (long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("Coordinated Universal Time");
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 1, "");
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628791973L + "'", long1 == 1560628791973L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        int int6 = period2.getMonths();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period2, chronology7);
        org.joda.time.Period period10 = period2.plusSeconds(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((long) 100, (int) ' ', (int) (short) 10, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        try {
            long long6 = durationField3.subtract(349260000L, 3155760000032L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -315576000003200");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        org.joda.time.Period period7 = period4.minusMillis((-1));
        int int8 = period7.getWeeks();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.minutes();
        boolean boolean11 = periodType9.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType12 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        try {
            org.joda.time.Period period14 = period7.withPeriodType(periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.PeriodType periodType6 = period3.getPeriodType();
        org.joda.time.PeriodType periodType7 = periodType6.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType9, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560628793872L + "'", long0 == 1560628793872L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        long long5 = dateTimeZone2.getMillisKeepLocal(dateTimeZone3, (long) 0);
        java.lang.String str7 = dateTimeZone2.getShortName((long) (byte) -1);
        java.lang.String str8 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 349260000L + "'", long5 == 349260000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+97:01" + "'", str7.equals("+97:01"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+97:01" + "'", str8.equals("+97:01"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        int int6 = period2.getMonths();
        org.joda.time.Period period8 = period2.plusDays((int) (short) 1);
        try {
            int int10 = period2.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.field.FieldUtils.verifyValueBounds("+97:01", 10, (int) (byte) 1, 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        java.lang.String str15 = offsetDateTimeField14.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str15.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = offsetDateTimeField5.getAsText(readablePartial9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray11 = new int[] {};
        java.util.Locale locale13 = null;
        try {
            int[] intArray14 = offsetDateTimeField5.set(readablePartial9, 0, intArray11, "UTC", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("UTC");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Coordinated Universal Time");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText(readablePartial14, (int) (short) 100, locale16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray20 = null;
        try {
            int[] intArray22 = offsetDateTimeField5.addWrapField(readablePartial18, 10, intArray20, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField4 = gregorianChronology2.halfdays();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis((int) 'a', (int) (byte) 0, (int) (short) 100, 0, 1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField5.getAsText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = offsetDateTimeField5.getAsShortText(readablePartial6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period2.toString(periodFormatter6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        org.joda.time.Period period16 = period10.normalizedStandard();
        org.joda.time.Period period17 = period2.withFields((org.joda.time.ReadablePeriod) period16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period17.toDurationFrom(readableInstant18);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("+97:01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+97:01\" is malformed at \"97:01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        try {
            long long14 = offsetDateTimeField5.set((long) (short) 10, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, (int) (byte) -1, (-1), (int) (short) 0);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType1.isSupported(durationFieldType3);
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) 100.0f, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.field.FieldUtils.verifyValueBounds("-1", (int) (byte) -1, (-1), (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2440588L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 244058800L + "'", long2 == 244058800L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.halfdayOfDay();
        try {
            long long11 = gregorianChronology2.getDateTimeMillis((int) (byte) 0, (int) (byte) 10, (int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        long long6 = durationField3.subtract((long) ' ', (int) (short) -1);
        long long9 = durationField3.subtract(59000L, 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3155760000032L + "'", long6 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 59000L + "'", long9 == 59000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 10);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT10M" + "'", str3.equals("PT10M"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType2);
        try {
            int int5 = period3.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant41, readableDuration42);
        org.joda.time.Period period45 = period43.plusDays(0);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period43.toDurationTo(readableInstant46);
        int int48 = period43.size();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableInstant49, readableDuration50);
        org.joda.time.Period period53 = period51.plusDays(0);
        org.joda.time.PeriodType periodType54 = period51.getPeriodType();
        org.joda.time.PeriodType periodType55 = periodType54.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType57 = periodType55.getFieldType((int) (short) 0);
        int int58 = period43.get(durationFieldType57);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField60 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) preciseDurationField35, durationFieldType57, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        long long15 = offsetDateTimeField5.add(0L, (long) 97);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97000L + "'", long15 == 97000L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        long long10 = offsetDateTimeField5.add(1560628793872L, (long) (short) 1);
        try {
            long long13 = offsetDateTimeField5.set((long) (short) 0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628794872L + "'", long10 == 1560628794872L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.PeriodType periodType9 = periodType2.withWeeksRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType11 = periodType9.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = periodType3.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.Period period7 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period9 = period2.minusDays((int) ' ');
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        long long10 = offsetDateTimeField5.add(1560628793872L, (long) (short) 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (short) 0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfMinute must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628794872L + "'", long10 == 1560628794872L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(100L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period13 = period11.withSeconds(0);
        org.joda.time.Days days14 = period13.toStandardDays();
        org.joda.time.Duration duration15 = period13.toStandardDuration();
        org.joda.time.Period period17 = period13.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType19 = period13.getFieldType(4);
        try {
            org.joda.time.Period period21 = period8.withField(durationFieldType19, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(days14);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.eras();
        try {
            long long13 = gregorianChronology2.getDateTimeMillis((int) (short) 10, (int) (byte) 1, (int) 'a', 97, 32, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(59000L, (-65L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58935L + "'", long2 == 58935L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(4, (int) (byte) 100, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-210866760000000L), (java.lang.Number) 3016L, number3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.halfdayOfDay();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-17L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) 'a');
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        boolean boolean7 = periodType5.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType8 = periodType5.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationTo(readableInstant19);
        int int21 = period16.size();
        org.joda.time.Period period22 = period13.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.PeriodType periodType28 = period25.getPeriodType();
        org.joda.time.PeriodType periodType29 = periodType28.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        org.joda.time.Period period33 = period13.withFieldAdded(durationFieldType31, 0);
        boolean boolean34 = periodType8.isSupported(durationFieldType31);
        org.joda.time.PeriodType periodType35 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        try {
            org.joda.time.Period period36 = period4.withPeriodType(periodType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(periodType35);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 0);
        int int11 = period8.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long13 = dateTimeZone0.convertLocalToUTC(97000L, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97000L + "'", long13 == 97000L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Class<?> wildcardClass5 = illegalFieldValueException2.getClass();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.PeriodType periodType14 = periodType13.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        int int17 = period2.get(durationFieldType16);
        org.joda.time.Duration duration18 = period2.toStandardDuration();
        org.joda.time.Period period19 = period2.negated();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.Period period9 = period8.toPeriod();
        try {
            org.joda.time.Period period11 = period8.withWeeks((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (byte) 100);
        try {
            int int3 = period1.getValue((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0, locale12);
        int int15 = offsetDateTimeField5.getMaximumValue((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 58 + "'", int15 == 58);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        int int10 = offsetDateTimeField5.getLeapAmount((long) '#');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long5 = dateTimeZone0.convertUTCToLocal((long) 1000);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1000L + "'", long5 == 1000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("DurationField[years]", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getMinimumValue((long) 8);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText(100, locale17);
        java.lang.String str20 = offsetDateTimeField5.getAsText((-17L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "58" + "'", str20.equals("58"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-8));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("58", (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        org.joda.time.PeriodType periodType4 = period0.getPeriodType();
        int int5 = period0.getSeconds();
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        long long11 = offsetDateTimeField5.addWrapField(0L, (int) (byte) -1);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = offsetDateTimeField5.getAsText(readablePartial12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 59000L + "'", long11 == 59000L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        int int14 = offsetDateTimeField5.get(10L);
        java.util.Locale locale17 = null;
        try {
            long long18 = offsetDateTimeField5.set(1000L, "", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean2 = dateTimeZone0.isStandardOffset(100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType2);
        try {
            org.joda.time.Period period5 = period3.minusMonths((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField4 = gregorianChronology2.halfdays();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "LenientChronology[GregorianChronology[UTC]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) 'a');
        org.joda.time.Period period6 = period4.minusYears(8);
        int int7 = period6.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType8, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField16 = gregorianChronology14.days();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.halfdayOfDay();
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology14);
        boolean boolean21 = jodaTimePermission1.equals((java.lang.Object) "DateTimeField[secondOfMinute]");
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology3.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology3.millis();
        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) 100L, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 100);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Period period6 = period4.plus(readablePeriod5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.PeriodType periodType19 = period16.getPeriodType();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period4.withFieldAdded(durationFieldType22, 0);
        org.joda.time.Period period26 = period4.plusMillis(7);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 10);
        int int2 = period1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((-100), (int) (short) 1, (-8), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = lenientChronology5.weeks();
        long long13 = lenientChronology5.getDateTimeMillis((int) '4', (-100), (int) '4', (-1));
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology5.era();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60787497600001L) + "'", long13 == (-60787497600001L));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GregorianChronology[UTC]", 100, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for GregorianChronology[UTC] must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) -1, 'a', 0, (int) (short) 1, (int) (byte) 0, false, (int) (short) -1);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = lenientChronology5.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = lenientChronology5.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray13 = new int[] { (byte) 0, ' ', '#', (-8), 10 };
        try {
            gregorianChronology2.validate(readablePartial7, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        try {
            long long13 = gregorianChronology2.getDateTimeMillis(97, (int) (byte) 1, 58, (int) (byte) 10, 0, (int) (short) 100, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        org.joda.time.Period period7 = period4.minusMillis((-1));
        org.joda.time.Period period9 = period7.plusYears((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        long long12 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 58665600001L + "'", long12 == 58665600001L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "+97:01");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        org.joda.time.Period period7 = period4.minusMillis((-1));
        int int8 = period7.getWeeks();
        org.joda.time.Period period10 = period7.minusMonths((int) (short) 100);
        org.joda.time.Period period12 = period7.minusMillis((int) (short) 1);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.minutes();
        org.joda.time.Chronology chronology14 = null;
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period7, periodType13, chronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.Period period15 = org.joda.time.Period.ZERO;
        boolean boolean16 = lenientChronology14.equals((java.lang.Object) period15);
        org.joda.time.DurationField durationField17 = lenientChronology14.weeks();
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField5, (org.joda.time.Chronology) lenientChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1000, (int) '4', (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        long long10 = offsetDateTimeField5.add(1560628793872L, (long) (short) 1);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField5.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628794872L + "'", long10 == 1560628794872L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Period period6 = period4.multipliedBy((int) (short) 10);
        org.joda.time.Period period8 = period4.minusSeconds(4);
        org.joda.time.Weeks weeks9 = period8.toStandardWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(weeks9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 10, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for secondOfMinute must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        org.joda.time.Period period5 = period0.minusMonths((int) (byte) 100);
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        int int7 = offsetDateTimeField5.getOffset();
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (-1));
        long long18 = offsetDateTimeField15.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField19 = offsetDateTimeField15.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial20 = null;
        int int21 = offsetDateTimeField15.getMaximumValue(readablePartial20);
        int int22 = offsetDateTimeField15.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray30 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int31 = offsetDateTimeField15.getMaximumValue(readablePartial23, intArray30);
        try {
            int[] intArray33 = offsetDateTimeField5.set(readablePartial8, (int) (byte) 1, intArray30, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9999L + "'", long18 == 9999L);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 58 + "'", int21 == 58);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 58 + "'", int22 == 58);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 58 + "'", int31 == 58);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone0.getName((long) (short) 0, locale11);
//        org.joda.time.LocalDateTime localDateTime13 = null;
//        boolean boolean14 = dateTimeZone0.isLocalDateTimeGap(localDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int16 = cachedDateTimeZone14.getStandardOffset(97000L);
//        int int18 = cachedDateTimeZone14.getStandardOffset(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray20 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int21 = offsetDateTimeField5.getMaximumValue(readablePartial13, intArray20);
        long long23 = offsetDateTimeField5.roundHalfEven(10L);
        java.util.Locale locale26 = null;
        try {
            long long27 = offsetDateTimeField5.set((long) (byte) 0, "+97:01", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+97:01\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 58 + "'", int21 == 58);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.String str15 = dateTimeZone7.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "+97:01");
        java.lang.Number number12 = illegalFieldValueException11.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long42 = preciseDurationField35.getMillis(32);
        int int45 = preciseDurationField35.getValue((-1L), (long) (-8));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1664L + "'", long42 == 1664L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Period period6 = period4.multipliedBy((int) (short) 10);
        int int7 = period4.getMillis();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "hi!");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT0.011S");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        int int6 = period2.getMonths();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period2, chronology7);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(hours9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getLeapAmount(1560628791973L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (-1));
        long long26 = offsetDateTimeField23.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField27 = offsetDateTimeField23.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = offsetDateTimeField23.getMaximumValue(readablePartial28);
        int int30 = offsetDateTimeField23.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int[] intArray38 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int39 = offsetDateTimeField23.getMaximumValue(readablePartial31, intArray38);
        try {
            int[] intArray41 = offsetDateTimeField5.addWrapField(readablePartial16, (int) (short) 0, intArray38, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9999L + "'", long26 == 9999L);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 58 + "'", int29 == 58);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 58 + "'", int30 == 58);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 58 + "'", int39 == 58);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.size();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        int int18 = period3.get(durationFieldType17);
        org.joda.time.Duration duration19 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.Period period24 = period22.plusDays(0);
        org.joda.time.PeriodType periodType25 = period22.getPeriodType();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType25);
        int int27 = period26.getDays();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.minutes();
        boolean boolean32 = periodType30.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getChronology(chronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType30, chronology33);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant36, readableDuration37);
        org.joda.time.Period period40 = period38.plusDays(0);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant41, readableDuration42);
        org.joda.time.Period period45 = period43.plusDays(0);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period43.toDurationTo(readableInstant46);
        int int48 = period43.size();
        org.joda.time.Period period49 = period40.minus((org.joda.time.ReadablePeriod) period43);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant50, readableDuration51);
        org.joda.time.Period period54 = period52.plusDays(0);
        org.joda.time.PeriodType periodType55 = period52.getPeriodType();
        org.joda.time.PeriodType periodType56 = periodType55.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType58 = periodType56.getFieldType((int) (short) 0);
        org.joda.time.Period period60 = period40.withFieldAdded(durationFieldType58, 0);
        boolean boolean61 = periodType30.isSupported(durationFieldType58);
        org.joda.time.Period period63 = period26.withFieldAdded(durationFieldType58, (int) ' ');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(durationFieldType58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(period63);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 58, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        boolean boolean7 = period4.equals((java.lang.Object) chronology5);
        org.joda.time.Period period9 = period4.plusHours((int) (byte) -1);
        try {
            int int11 = period4.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("100", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"100/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField5.getAsShortText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(58, (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        int int5 = period2.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.PeriodType periodType9 = periodType2.withWeeksRemoved();
        java.lang.String str10 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Minutes" + "'", str10.equals("Minutes"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long7 = offsetDateTimeField5.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.Period period2 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period2.getFieldTypes();
        org.joda.time.Period period5 = period2.multipliedBy((int) '4');
        jodaTimePermission1.checkGuard((java.lang.Object) period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(3155760000032L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3155760000032");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField16 = gregorianChronology14.days();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.halfdayOfDay();
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant21 = null;
        int int22 = dateTimeZone20.getOffset(readableInstant21);
        org.joda.time.Chronology chronology23 = gregorianChronology14.withZone(dateTimeZone20);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Period period6 = period2.plusMinutes(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getShortName((long) '#');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", (java.lang.Number) 1000, (java.lang.Number) 349260000L, (java.lang.Number) (byte) -1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        int int8 = period7.getDays();
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = period7.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.PeriodType periodType19 = period16.getPeriodType();
        org.joda.time.PeriodType periodType20 = periodType19.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period4.withFieldAdded(durationFieldType22, 0);
        org.joda.time.Weeks weeks25 = period24.toStandardWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(weeks25);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        long long14 = offsetDateTimeField5.roundFloor(0L);
        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.DurationField durationField16 = offsetDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        try {
            org.joda.time.Period period34 = new org.joda.time.Period((java.lang.Object) boolean33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Days days5 = period4.toStandardDays();
        org.joda.time.Duration duration6 = period4.toStandardDuration();
        org.joda.time.Period period8 = period4.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType10 = period4.getFieldType(4);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        boolean boolean13 = period4.equals((java.lang.Object) dateTimeZone11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = lenientChronology5.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = lenientChronology5.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField13 = lenientChronology5.seconds();
        long long16 = durationField13.subtract(36032L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35032L + "'", long16 == 35032L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        try {
            int int10 = period2.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone15.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (-1), locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone(dateTimeZone15);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone23);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfMinute();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-1));
//        long long31 = offsetDateTimeField28.add((long) 'a', (long) (-1));
//        java.lang.String str33 = offsetDateTimeField28.getAsText((long) 0);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField28.getAsText((int) (short) 100, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray39 = new int[] { '#' };
//        int int40 = offsetDateTimeField28.getMinimumValue(readablePartial37, intArray39);
//        try {
//            iSOChronology3.validate(readablePartial22, intArray39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-903L) + "'", long31 == (-903L));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-1" + "'", str33.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        long long11 = offsetDateTimeField5.addWrapField(0L, (int) (byte) -1);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.Period period15 = org.joda.time.Period.minutes((int) (byte) 10);
        int[] intArray16 = period15.getValues();
        try {
            int[] intArray18 = offsetDateTimeField5.set(readablePartial12, (int) '4', intArray16, 1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for secondOfMinute must be in the range [-1,58]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 59000L + "'", long11 == 59000L);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        boolean boolean5 = periodType0.equals((java.lang.Object) dateTimeZone1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Minutes");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Period period1 = org.joda.time.Period.millis(10);
        try {
            org.joda.time.DurationFieldType durationFieldType3 = period1.getFieldType(58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        int int7 = offsetDateTimeField5.getOffset();
        int int8 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 58 + "'", int8 == 58);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getMinimumValue((long) 8);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText(100, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (-1));
        long long29 = offsetDateTimeField26.add((long) 'a', (long) (-1));
        java.lang.String str31 = offsetDateTimeField26.getAsText((long) 0);
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField26.getAsText((int) (short) 100, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int[] intArray37 = new int[] { '#' };
        int int38 = offsetDateTimeField26.getMinimumValue(readablePartial35, intArray37);
        try {
            int[] intArray40 = offsetDateTimeField5.addWrapField(readablePartial19, 32, intArray37, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-903L) + "'", long29 == (-903L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "100" + "'", str34.equals("100"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withMonths((int) (byte) 0);
        int int3 = period2.getMinutes();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset(4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        int int7 = offsetDateTimeField5.getOffset();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField5.getAsText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period2.toString(periodFormatter6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        org.joda.time.Period period16 = period10.normalizedStandard();
        org.joda.time.Period period17 = period2.withFields((org.joda.time.ReadablePeriod) period16);
        int int18 = period16.getHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = gregorianChronology2.get(readablePartial6, 35032L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField5.getAsText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.Period period8 = new org.joda.time.Period(10, (int) (short) 1, 10, 0, (int) (byte) 1, (int) (short) 1, (int) (short) 10, (int) ' ');
        org.joda.time.Period period10 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period12 = period8.minusWeeks((int) (byte) 10);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.time();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 0, 464L, periodType15);
        try {
            org.joda.time.Period period17 = period8.normalizedStandard(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(7, (int) '4', 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        long long16 = offsetDateTimeField5.add(416L, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32416L + "'", long16 == 32416L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        long long15 = offsetDateTimeField5.roundCeiling((long) 32);
        org.joda.time.DurationField durationField16 = offsetDateTimeField5.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1000L + "'", long15 == 1000L);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 52, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis(58, (int) (byte) -1, (-100), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        boolean boolean14 = offsetDateTimeField5.isLeap((long) 58);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long15 = offsetDateTimeField5.add((long) 4, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText(97, locale17);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4L + "'", long15 == 4L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Days days5 = period4.toStandardDays();
        org.joda.time.Duration duration6 = period4.toStandardDuration();
        org.joda.time.Period period8 = period4.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType10 = period4.getFieldType(4);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(durationFieldType10, "PT0.011S");
        org.joda.time.field.PreciseDurationField preciseDurationField14 = new org.joda.time.field.PreciseDurationField(durationFieldType10, 0L);
        java.lang.String str15 = preciseDurationField14.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DurationField[hours]" + "'", str15.equals("DurationField[hours]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.PeriodType periodType12 = period9.getPeriodType();
        org.joda.time.PeriodType periodType13 = periodType12.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        int int16 = period2.get(durationFieldType15);
        org.joda.time.Period period18 = period2.withHours((int) (byte) 0);
        int int20 = period2.getValue((int) (short) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withMonths((int) (byte) 0);
        org.joda.time.Period period11 = new org.joda.time.Period(10, (int) (short) 1, 10, 0, (int) (byte) 1, (int) (short) 1, (int) (short) 10, (int) ' ');
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 100);
        org.joda.time.Period period14 = period0.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period13.normalizedStandard();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) (-8));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        try {
            org.joda.time.Period period10 = period8.minusDays(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        int int6 = dateTimeZone0.getOffsetFromLocal((long) (byte) -1);
//        java.lang.String str7 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        long long9 = offsetDateTimeField5.roundHalfFloor(244058800L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 10);
        int[] intArray14 = period13.getValues();
        try {
            int[] intArray16 = offsetDateTimeField5.set(readablePartial10, 10, intArray14, (-8));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for secondOfMinute must be in the range [-1,58]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 244059000L + "'", long9 == 244059000L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        int int16 = offsetDateTimeField5.getMinimumValue(1560628794872L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        long long16 = offsetDateTimeField5.set(59000L, 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5000L + "'", long16 == 5000L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        long long40 = preciseDurationField35.add((long) (-1), 3155760000032L);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone41);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField44 = gregorianChronology43.centuries();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.dayOfYear();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.secondOfMinute();
        boolean boolean47 = preciseDurationField35.equals((java.lang.Object) dateTimeField46);
        long long50 = preciseDurationField35.getMillis(8, 0L);
        java.lang.Object obj51 = null;
        boolean boolean52 = preciseDurationField35.equals(obj51);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164099520001663L + "'", long40 == 164099520001663L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 416L + "'", long50 == 416L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        long long14 = offsetDateTimeField5.roundFloor(0L);
        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getRangeDurationField();
        java.util.Locale locale18 = null;
        try {
            long long19 = offsetDateTimeField5.set((long) 1000, "GregorianChronology[UTC]", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        int int15 = offsetDateTimeField5.getMaximumValue((long) (short) 10);
        long long17 = offsetDateTimeField5.roundHalfFloor((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 58 + "'", int15 == 58);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getShortName((long) (-1), locale4);
//        long long7 = dateTimeZone0.convertUTCToLocal((long) 'a');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType9 = periodType8.withMillisRemoved();
        java.lang.String str10 = periodType8.toString();
        org.joda.time.PeriodType periodType11 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((int) (short) 0, 0, 8, 10, (int) (short) 1, 0, 1000, (int) (byte) 0, periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[Minutes]" + "'", str10.equals("PeriodType[Minutes]"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.toString();
        long long8 = dateTimeZone0.convertLocalToUTC(11L, false, (long) 9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 7, 52, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for secondOfMinute must be in the range [52,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long16 = cachedDateTimeZone14.nextTransition((long) 4);
//        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone14.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 4L + "'", long16 == 4L);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.Weeks weeks10 = period8.toStandardWeeks();
        org.joda.time.Duration duration11 = period8.toStandardDuration();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(weeks10);
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology2.minutes();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 0, periodType9);
        int[] intArray12 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period10, (long) '4');
        org.joda.time.Period period14 = period10.withWeeks((-100));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology0.days();
        org.joda.time.DurationField durationField6 = gregorianChronology0.months();
        org.joda.time.DurationField durationField7 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-62135247590100L), "LenientChronology[GregorianChronology[UTC]]");
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        int int6 = dateTimeZone0.getOffsetFromLocal((long) (byte) -1);
//        org.joda.time.LocalDateTime localDateTime7 = null;
//        boolean boolean8 = dateTimeZone0.isLocalDateTimeGap(localDateTime7);
//        java.lang.String str9 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        org.joda.time.PeriodType periodType4 = period0.getPeriodType();
        org.joda.time.Period period6 = period0.withSeconds(8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Days days5 = period4.toStandardDays();
        org.joda.time.Duration duration6 = period4.toStandardDuration();
        org.joda.time.Period period8 = period4.minusDays((int) (byte) 100);
        org.joda.time.Period period10 = period4.withMonths((int) (byte) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = periodType8.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType11 = periodType8.withHoursRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(7, (int) (short) 1, 0, 1, (int) (byte) -1, 4, (int) (short) -1, (-1), periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        boolean boolean19 = offsetDateTimeField5.isLeap((-903L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.PeriodType periodType6 = periodType2.withDaysRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType6);
        int int8 = period7.getSeconds();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField16 = gregorianChronology14.days();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.halfdayOfDay();
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.ReadablePartial readablePartial20 = null;
        try {
            long long22 = gregorianChronology14.set(readablePartial20, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission4.newPermissionCollection();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.PeriodType periodType12 = period9.getPeriodType();
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period9.toString(periodFormatter13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period17.normalizedStandard();
        org.joda.time.Period period24 = period9.withFields((org.joda.time.ReadablePeriod) period23);
        jodaTimePermission1.checkGuard((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period(readableInstant31, readableDuration32);
        org.joda.time.Period period35 = period33.plusDays(0);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Duration duration37 = period33.toDurationTo(readableInstant36);
        int int38 = period33.size();
        org.joda.time.Period period39 = period30.minus((org.joda.time.ReadablePeriod) period33);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant40, readableDuration41);
        org.joda.time.Period period44 = period42.plusDays(0);
        org.joda.time.PeriodType periodType45 = period42.getPeriodType();
        org.joda.time.PeriodType periodType46 = periodType45.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType48 = periodType46.getFieldType((int) (short) 0);
        org.joda.time.Period period50 = period30.withFieldAdded(durationFieldType48, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField52 = new org.joda.time.field.PreciseDurationField(durationFieldType48, 0L);
        org.joda.time.Period period54 = period9.withField(durationFieldType48, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(duration37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period54);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        long long7 = durationField4.subtract(0L, 1664L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-143769600000L) + "'", long7 == (-143769600000L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("52", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"52/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology3.equals(obj4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology3.set(readablePartial6, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period4.getFieldTypes();
        org.joda.time.Period period16 = period4.plusHours(2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2443292L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282788426d + "'", double1 == 2440587.5282788426d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str44 = preciseDurationField35.toString();
        long long47 = preciseDurationField35.add((long) (byte) 100, 7);
        long long50 = preciseDurationField35.getMillis((int) (byte) 0, 1000L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DurationField[years]" + "'", str44.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 464L + "'", long47 == 464L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder0.writeTo("97", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getLeapAmount(1560628791973L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText(4, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField5.getAsShortText((-143769600000L), locale20);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
        java.lang.String str4 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfDay();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(10, (int) (short) 1, 0, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        int int9 = period2.getDays();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period2.toString(periodFormatter12);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0S" + "'", str13.equals("PT0S"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long15 = offsetDateTimeField5.add((long) 4, 0L);
        java.lang.String str17 = offsetDateTimeField5.getAsShortText(244059000L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField5.getAsText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4L + "'", long15 == 4L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "38" + "'", str17.equals("38"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT10M", "GregorianChronology[UTC]");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        long long46 = preciseDurationField35.getMillis((int) (short) 1, 0L);
        long long49 = preciseDurationField35.subtract(4L, (long) 0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 52L + "'", long46 == 52L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 4L + "'", long49 == 4L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PeriodType[Minutes]");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period2.plusYears(52);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(32, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "+97:01");
        java.lang.Number number12 = illegalFieldValueException11.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        boolean boolean6 = periodType4.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField10 = gregorianChronology9.centuries();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfYear();
        org.joda.time.Chronology chronology12 = gregorianChronology9.withUTC();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 2, 349260000L, periodType4, chronology12);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        java.lang.String str15 = offsetDateTimeField14.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str15.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-1));
        java.lang.String str7 = offsetDateTimeField6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, (int) (byte) -1, (-1), (int) (short) 0);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType8, (int) (short) 100, (-1), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str7.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException10.getDurationFieldType();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str13 = illegalFieldValueException10.getIllegalValueAsString();
        java.lang.String str14 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str15 = illegalFieldValueException10.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException10.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.Number number18 = illegalFieldValueException10.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.size();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        int int18 = period3.get(durationFieldType17);
        org.joda.time.Duration duration19 = period3.toStandardDuration();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
        boolean boolean22 = periodType20.equals((java.lang.Object) 100.0f);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType20);
        org.joda.time.PeriodType periodType24 = periodType20.withMinutesRemoved();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        org.joda.time.Period period29 = period27.plusDays(0);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period27.toDurationTo(readableInstant30);
        int int32 = period27.size();
        org.joda.time.Period period33 = period27.normalizedStandard();
        org.joda.time.Period period35 = period33.plusMonths((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant36, readableDuration37);
        org.joda.time.Period period40 = period38.plusDays(0);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant41, readableDuration42);
        org.joda.time.Period period45 = period43.plusDays(0);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period43.toDurationTo(readableInstant46);
        int int48 = period43.size();
        org.joda.time.Period period49 = period40.minus((org.joda.time.ReadablePeriod) period43);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant50, readableDuration51);
        org.joda.time.Period period54 = period52.plusDays(0);
        org.joda.time.PeriodType periodType55 = period52.getPeriodType();
        org.joda.time.PeriodType periodType56 = periodType55.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType58 = periodType56.getFieldType((int) (short) 0);
        org.joda.time.Period period60 = period40.withFieldAdded(durationFieldType58, 0);
        boolean boolean61 = period35.isSupported(durationFieldType58);
        int int62 = periodType20.indexOf(durationFieldType58);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(durationFieldType58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = null;
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.BufferedReader bufferedReader4 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType2);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        org.joda.time.Period period6 = period3.plusSeconds(8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (-8));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.secondOfMinute();
        org.joda.time.Period period6 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period6.getFieldTypes();
        long long10 = gregorianChronology2.add((org.joda.time.ReadablePeriod) period6, 164099520001663L, (-1));
        org.joda.time.Period period12 = period6.minusDays(97);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 164099520001663L + "'", long10 == 164099520001663L);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        boolean boolean7 = period4.equals((java.lang.Object) chronology5);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.get(durationFieldType8);
        int int11 = period4.getValue((int) (byte) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int16 = cachedDateTimeZone14.getStandardOffset(97000L);
//        java.lang.String str17 = cachedDateTimeZone14.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long15 = offsetDateTimeField5.add((long) 4, 0L);
        long long18 = offsetDateTimeField5.add((-17L), 7);
        org.joda.time.DurationField durationField19 = offsetDateTimeField5.getLeapDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 97, 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4L + "'", long15 == 4L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 6983L + "'", long18 == 6983L);
        org.junit.Assert.assertNull(durationField19);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str4 = dateTimeZone0.getName((long) (-1));
//        int int6 = dateTimeZone0.getOffsetFromLocal(3016L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder4.setFixedSavings("", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder7.addRecurringSavings("0", 2, (int) (byte) 1, 0, ' ', (int) (byte) 10, (int) (byte) -1, 0, true, (int) (byte) 100);
        jodaTimePermission1.checkGuard((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.size();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        int int18 = period3.get(durationFieldType17);
        org.joda.time.Duration duration19 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.Period period24 = period22.plusDays(0);
        org.joda.time.PeriodType periodType25 = period22.getPeriodType();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType25);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
        boolean boolean30 = periodType28.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType31 = periodType28.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant37, readableDuration38);
        org.joda.time.Period period41 = period39.plusDays(0);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period39.toDurationTo(readableInstant42);
        int int44 = period39.size();
        org.joda.time.Period period45 = period36.minus((org.joda.time.ReadablePeriod) period39);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(readableInstant46, readableDuration47);
        org.joda.time.Period period50 = period48.plusDays(0);
        org.joda.time.PeriodType periodType51 = period48.getPeriodType();
        org.joda.time.PeriodType periodType52 = periodType51.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType54 = periodType52.getFieldType((int) (short) 0);
        org.joda.time.Period period56 = period36.withFieldAdded(durationFieldType54, 0);
        boolean boolean57 = periodType31.isSupported(durationFieldType54);
        org.joda.time.PeriodType periodType58 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.PeriodType periodType59 = periodType31.withSecondsRemoved();
        org.joda.time.Period period60 = new org.joda.time.Period((long) (-1), periodType31);
        org.joda.time.Period period61 = period26.normalizedStandard(periodType31);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(period61);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.String str16 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str18 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str20 = cachedDateTimeZone14.getName(0L);
//        org.joda.time.LocalDateTime localDateTime21 = null;
//        boolean boolean22 = cachedDateTimeZone14.isLocalDateTimeGap(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.era();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis((int) (byte) 10, 0, 2, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[YearWeekDayTime]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[YearWeekDayTime]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Weeks weeks14 = period4.toStandardWeeks();
        org.joda.time.Period period16 = period4.plusSeconds(52);
        int int17 = period16.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        long long40 = preciseDurationField35.add((long) (-1), 3155760000032L);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone41);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField44 = gregorianChronology43.centuries();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.dayOfYear();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.secondOfMinute();
        boolean boolean47 = preciseDurationField35.equals((java.lang.Object) dateTimeField46);
        boolean boolean48 = preciseDurationField35.isSupported();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164099520001663L + "'", long40 == 164099520001663L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-1), 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        java.lang.Number number10 = illegalFieldValueException9.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = org.joda.time.Period.millis(97);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(weeks2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        try {
            int int33 = unsupportedDurationField30.getDifference((long) (short) 0, 1664L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0L, locale12);
        long long15 = offsetDateTimeField5.roundHalfFloor((long) 32);
        java.lang.String str17 = offsetDateTimeField5.getAsText((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1" + "'", str17.equals("-1"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-17L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-17) + "'", int1 == (-17));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '4', 9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.lang.String str11 = dateTimeZone0.getShortName(1000L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.halfdayOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (-1));
        java.lang.String str19 = offsetDateTimeField18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType20, 8, (int) '4', (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-8), "PeriodType[YearDayTime]");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str19.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField5.getAsShortText((long) 32, locale13);
        boolean boolean15 = offsetDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.String str16 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str18 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str20 = cachedDateTimeZone14.getName((-60787497600001L));
//        int int22 = cachedDateTimeZone14.getOffset(1560628794872L);
//        boolean boolean23 = cachedDateTimeZone14.isFixed();
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
//        org.joda.time.Period period28 = period26.plusWeeks((int) 'a');
//        org.joda.time.DurationFieldType[] durationFieldTypeArray29 = period28.getFieldTypes();
//        org.joda.time.Period period31 = period28.minusMillis((-1));
//        boolean boolean32 = cachedDateTimeZone14.equals((java.lang.Object) (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(durationFieldTypeArray29);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        int int14 = offsetDateTimeField5.get(10L);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-1));
        java.lang.String str21 = offsetDateTimeField20.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField20.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str21.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        long long13 = offsetDateTimeField5.addWrapField((-60787497600001L), (int) (byte) 100);
        java.lang.String str15 = offsetDateTimeField5.getAsText(3155695200000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60787497620001L) + "'", long13 == (-60787497620001L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        try {
            long long33 = unsupportedDurationField30.add(3016L, 58665600001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1000, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (byte) 100);
        org.joda.time.Period period3 = period1.withDays(0);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = lenientChronology5.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = lenientChronology5.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField13 = lenientChronology5.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        boolean boolean7 = period4.equals((java.lang.Object) chronology5);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = periodType8.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType11 = periodType8.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType11.isSupported(durationFieldType34);
        org.joda.time.Period period39 = period4.withField(durationFieldType34, 10);
        org.joda.time.Period period41 = period4.minusHours((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period41.toDurationTo(readableInstant42);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(duration43);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone15.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (-1), locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField22 = iSOChronology3.halfdays();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withMonths((int) (byte) 0);
        org.joda.time.Period period4 = period2.minusWeeks((int) (byte) 10);
        try {
            int int6 = period4.getValue(58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-01:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-01:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 32, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        java.lang.String str31 = unsupportedDurationField30.getName();
        try {
            long long34 = unsupportedDurationField30.getMillis((-1), (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        java.lang.String str31 = unsupportedDurationField30.getName();
        try {
            long long34 = unsupportedDurationField30.getDifferenceAsLong(2443292L, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str44 = preciseDurationField35.toString();
        long long47 = preciseDurationField35.add((long) (byte) 100, 7);
        java.lang.String str48 = preciseDurationField35.getName();
        long long49 = preciseDurationField35.getUnitMillis();
        org.joda.time.Period period51 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Period period52 = org.joda.time.Period.ZERO;
        org.joda.time.Period period54 = period52.withMonths((int) (byte) 0);
        org.joda.time.Period period56 = period54.minusWeeks((int) (byte) 10);
        org.joda.time.Period period57 = period51.plus((org.joda.time.ReadablePeriod) period54);
        boolean boolean58 = preciseDurationField35.equals((java.lang.Object) period51);
        long long61 = preciseDurationField35.getDifferenceAsLong(58665600001L, (long) (short) 100);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DurationField[years]" + "'", str44.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 464L + "'", long47 == 464L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "years" + "'", str48.equals("years"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 52L + "'", long49 == 52L);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1128184613L + "'", long61 == 1128184613L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField16 = gregorianChronology14.days();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.halfdayOfDay();
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant21 = null;
        int int22 = dateTimeZone20.getOffset(readableInstant21);
        org.joda.time.Chronology chronology23 = gregorianChronology14.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology14.dayOfYear();
        long long32 = gregorianChronology14.getDateTimeMillis(4, 3, 9, 1, 0, 0, 97);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62035109999903L) + "'", long32 == (-62035109999903L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfDay();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = lenientChronology5.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = lenientChronology5.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField13 = lenientChronology5.seconds();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = lenientChronology5.get(readablePartial14, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        int int7 = offsetDateTimeField5.getOffset();
        int int9 = offsetDateTimeField5.get(10964622240000052L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException10.getDurationFieldType();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str13 = illegalFieldValueException10.getIllegalValueAsString();
        java.lang.String str14 = illegalFieldValueException10.getIllegalStringValue();
        java.lang.String str15 = illegalFieldValueException10.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException10.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str18 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone40);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (-1));
        long long48 = offsetDateTimeField45.add((long) 'a', (long) (-1));
        java.lang.String str50 = offsetDateTimeField45.getAsText((long) 0);
        org.joda.time.ReadablePartial readablePartial51 = null;
        int[] intArray56 = new int[] { 4, 9, 2, (-28800000) };
        int int57 = offsetDateTimeField45.getMinimumValue(readablePartial51, intArray56);
        try {
            int int58 = unsupportedDateTimeField37.getMinimumValue(readablePartial39, intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-903L) + "'", long48 == (-903L));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology0.days();
        org.joda.time.DurationField durationField6 = gregorianChronology0.months();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        try {
            java.lang.String str63 = unsupportedDateTimeField61.getAsShortText((long) (-8));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(59000L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59000L + "'", long2 == 59000L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (-1));
        java.lang.String str19 = offsetDateTimeField18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType20, 8, (int) '4', (int) (short) 1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField26.getAsShortText((long) (-17), locale28);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str19.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "66" + "'", str29.equals("66"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-1000L), "58");
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
        long long19 = offsetDateTimeField5.add(0L, (-62135247590100L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135247590100000L) + "'", long19 == (-62135247590100000L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((long) 0, locale12);
        int int15 = offsetDateTimeField5.getMinimumValue((long) 8);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText(100, locale17);
        int int20 = offsetDateTimeField5.get((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 58 + "'", int20 == 58);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        boolean boolean39 = unsupportedDateTimeField37.isSupported();
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = unsupportedDateTimeField37.getAsText(2, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (-1));
        long long19 = offsetDateTimeField16.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField20 = offsetDateTimeField16.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = offsetDateTimeField16.getMaximumValue(readablePartial21);
        int int23 = offsetDateTimeField16.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray31 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int32 = offsetDateTimeField16.getMaximumValue(readablePartial24, intArray31);
        try {
            int[] intArray34 = offsetDateTimeField5.addWrapField(readablePartial9, 0, intArray31, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9999L + "'", long19 == 9999L);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 58 + "'", int22 == 58);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 58 + "'", int32 == 58);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withMonths((int) (byte) 0);
        org.joda.time.Period period4 = period2.minusWeeks((int) (byte) 10);
        org.joda.time.Period period6 = period2.minusMinutes((int) (byte) 1);
        org.joda.time.Days days7 = period2.toStandardDays();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        int int20 = offsetDateTimeField5.getDifference((long) 3, 32416L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-32) + "'", int20 == (-32));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone40);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (-1));
        long long48 = offsetDateTimeField45.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = offsetDateTimeField45.getMinimumValue(readablePartial49);
        org.joda.time.DurationField durationField51 = offsetDateTimeField45.getLeapDurationField();
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField45.getAsShortText((long) 32, locale53);
        org.joda.time.ReadablePartial readablePartial55 = null;
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone56);
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.secondOfMinute();
        org.joda.time.DurationField durationField60 = gregorianChronology58.days();
        org.joda.time.chrono.LenientChronology lenientChronology61 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology58);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology58.halfdayOfDay();
        org.joda.time.DurationField durationField63 = gregorianChronology58.minutes();
        org.joda.time.PeriodType periodType65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period((long) (byte) 0, periodType65);
        int[] intArray68 = gregorianChronology58.get((org.joda.time.ReadablePeriod) period66, (long) '4');
        int int69 = offsetDateTimeField45.getMaximumValue(readablePartial55, intArray68);
        try {
            int int70 = unsupportedDateTimeField37.getMinimumValue(readablePartial39, intArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-903L) + "'", long48 == (-903L));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "-1" + "'", str54.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(lenientChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 58 + "'", int69 == 58);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.PeriodType periodType14 = periodType13.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = new org.joda.time.Period(0, 100, (int) (byte) 10, 0, (int) (byte) -1, 0, 0, (int) (byte) 0, periodType14);
        java.lang.String str18 = periodType14.toString();
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PeriodType[StandardNoMillis]" + "'", str18.equals("PeriodType[StandardNoMillis]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        boolean boolean7 = dateTimeZone0.isStandardOffset(244059000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        int int15 = offsetDateTimeField5.getMaximumValue((long) 97);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 58 + "'", int15 == 58);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = period0.getFieldTypes();
        org.joda.time.Period period3 = period0.multipliedBy((int) '4');
        org.joda.time.PeriodType periodType4 = period0.getPeriodType();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str6 = lenientChronology5.toString();
        long long10 = lenientChronology5.add(0L, (long) 58, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str6.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1670400000L) + "'", long10 == (-1670400000L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        try {
            long long63 = unsupportedDateTimeField61.roundHalfFloor(1560628794872L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withHoursRemoved();
        int int12 = periodType11.size();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = lenientChronology5.centuries();
        org.joda.time.DurationField durationField7 = lenientChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = lenientChronology5.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        org.joda.time.ReadablePartial readablePartial62 = null;
        java.util.Locale locale63 = null;
        try {
            java.lang.String str64 = unsupportedDateTimeField61.getAsText(readablePartial62, locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((-17));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (-1));
        java.lang.String str13 = offsetDateTimeField12.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        boolean boolean21 = periodType19.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getChronology(chronology22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType19, chronology22);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        org.joda.time.Period period29 = period27.plusDays(0);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant30, readableDuration31);
        org.joda.time.Period period34 = period32.plusDays(0);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period32.toDurationTo(readableInstant35);
        int int37 = period32.size();
        org.joda.time.Period period38 = period29.minus((org.joda.time.ReadablePeriod) period32);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant39, readableDuration40);
        org.joda.time.Period period43 = period41.plusDays(0);
        org.joda.time.PeriodType periodType44 = period41.getPeriodType();
        org.joda.time.PeriodType periodType45 = periodType44.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType47 = periodType45.getFieldType((int) (short) 0);
        org.joda.time.Period period49 = period29.withFieldAdded(durationFieldType47, 0);
        boolean boolean50 = periodType19.isSupported(durationFieldType47);
        org.joda.time.field.PreciseDurationField preciseDurationField52 = new org.joda.time.field.PreciseDurationField(durationFieldType47, (long) '4');
        long long54 = preciseDurationField52.getMillis(58);
        int int57 = preciseDurationField52.getValue((-65L), (-210866760000000L));
        long long60 = preciseDurationField52.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str61 = preciseDurationField52.toString();
        long long64 = preciseDurationField52.add((long) (byte) 100, 7);
        long long67 = preciseDurationField52.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, (org.joda.time.DurationField) preciseDurationField52);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType14, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str13.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 3016L + "'", long54 == 3016L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-17L) + "'", long60 == (-17L));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "DurationField[years]" + "'", str61.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 464L + "'", long64 == 464L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.PeriodType periodType15 = period12.getPeriodType();
        org.joda.time.PeriodType periodType16 = periodType15.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType((int) (short) 0);
        int int19 = period4.get(durationFieldType18);
        org.joda.time.Duration duration20 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant21, readableDuration22);
        org.joda.time.Period period25 = period23.plusDays(0);
        org.joda.time.PeriodType periodType26 = period23.getPeriodType();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration20, periodType26);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
        boolean boolean30 = periodType28.equals((java.lang.Object) 100.0f);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration20, periodType28);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        try {
            int int32 = unsupportedDurationField30.getValue((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        try {
            long long64 = unsupportedDateTimeField61.set(0L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        long long40 = preciseDurationField35.add((long) (-1), 3155760000032L);
        long long43 = preciseDurationField35.subtract((long) 0, 1128184613L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164099520001663L + "'", long40 == 164099520001663L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-58665599876L) + "'", long43 == (-58665599876L));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-8));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 0);
        org.joda.time.Period period11 = period8.normalizedStandard();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        boolean boolean39 = unsupportedDateTimeField37.isSupported();
        try {
            long long41 = unsupportedDateTimeField37.roundCeiling((-60787497600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(11L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        boolean boolean7 = period4.equals((java.lang.Object) chronology5);
        org.joda.time.Period period9 = period4.plusHours((int) (byte) -1);
        org.joda.time.Period period11 = period9.minusSeconds(1000);
        org.joda.time.Period period12 = period9.toPeriod();
        org.joda.time.Period period14 = period12.multipliedBy(7);
        org.joda.time.Duration duration15 = period12.toStandardDuration();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Period period2 = new org.joda.time.Period(4L, 349260000L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType7, (int) (byte) -1, (-1), (int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 10964622240000052L, "DurationField[years]");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) 'a');
        org.joda.time.Period period6 = period4.minusYears(8);
        org.joda.time.Period period8 = period4.plusYears(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        boolean boolean39 = unsupportedDateTimeField37.isSupported();
        try {
            long long41 = unsupportedDateTimeField37.roundFloor((long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withMonths((int) (byte) 0);
        org.joda.time.Period period11 = new org.joda.time.Period(10, (int) (short) 1, 10, 0, (int) (byte) 1, (int) (short) 1, (int) (short) 10, (int) ' ');
        org.joda.time.Period period13 = period11.plusSeconds((int) (short) 100);
        org.joda.time.Period period14 = period0.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period16 = period14.withMinutes((int) 'a');
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period4 = period2.withSeconds(0);
        org.joda.time.Days days5 = period4.toStandardDays();
        org.joda.time.Duration duration6 = period4.toStandardDuration();
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period4.toString(periodFormatter7);
        int int9 = period4.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0.011S" + "'", str8.equals("PT0.011S"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DurationField[hours]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.size();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.PeriodType periodType14 = period11.getPeriodType();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        int int18 = period3.get(durationFieldType17);
        org.joda.time.Duration duration19 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.Period period24 = period22.plusDays(0);
        org.joda.time.PeriodType periodType25 = period22.getPeriodType();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType25);
        org.joda.time.PeriodType periodType27 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str30 = gregorianChronology29.toString();
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.weekyearOfCentury();
        boolean boolean34 = periodType28.equals((java.lang.Object) dateTimeField33);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant36 = null;
        int int37 = dateTimeZone35.getOffset(readableInstant36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.util.TimeZone timeZone39 = dateTimeZone35.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.minuteOfHour();
        try {
            org.joda.time.Period period42 = new org.joda.time.Period((java.lang.Object) periodType27, periodType28, (org.joda.time.Chronology) gregorianChronology40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[UTC]" + "'", str30.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        java.lang.String str12 = offsetDateTimeField5.getName();
        int int15 = offsetDateTimeField5.getDifference(0L, (long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationTo(readableInstant13);
        int int15 = period10.size();
        org.joda.time.Period period16 = period10.normalizedStandard();
        int int17 = period10.getDays();
        org.joda.time.Period period19 = period10.withWeeks((int) '#');
        org.joda.time.Period period20 = period10.toPeriod();
        org.joda.time.Period period22 = period20.minusMonths(0);
        int[] intArray24 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period22, (long) 'a');
        int int25 = period22.getDays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "Coordinated Universal Time");
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str13 = illegalFieldValueException2.toString();
        java.lang.String str14 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported" + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long42 = preciseDurationField35.getMillis(32);
        long long44 = preciseDurationField35.getMillis((long) ' ');
        long long47 = preciseDurationField35.subtract(52L, (-210858120000000L));
        int int50 = preciseDurationField35.getValue((long) (byte) 1, 4L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1664L + "'", long42 == 1664L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1664L + "'", long44 == 1664L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10964622240000052L + "'", long47 == 10964622240000052L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str44 = preciseDurationField35.toString();
        long long47 = preciseDurationField35.add((long) (byte) 100, 7);
        java.lang.String str48 = preciseDurationField35.getName();
        org.joda.time.Period period50 = org.joda.time.Period.days(2);
        boolean boolean51 = preciseDurationField35.equals((java.lang.Object) period50);
        java.lang.String str52 = preciseDurationField35.getName();
        try {
            int int54 = preciseDurationField35.getValue((-60787497620001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1168990338846");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DurationField[years]" + "'", str44.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 464L + "'", long47 == 464L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "years" + "'", str48.equals("years"));
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "years" + "'", str52.equals("years"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.PeriodType periodType9 = periodType2.withWeeksRemoved();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.PeriodType periodType15 = period12.getPeriodType();
        org.joda.time.PeriodType periodType16 = periodType15.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType((int) (short) 0);
        int int19 = periodType9.indexOf(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) (-62135247590100000L), (java.lang.Number) (byte) 100, (java.lang.Number) 2440588L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        try {
            long long39 = unsupportedDateTimeField37.roundCeiling((long) (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long15 = offsetDateTimeField5.add((long) 4, 0L);
        long long18 = offsetDateTimeField5.add((-17L), 7);
        org.joda.time.DurationField durationField19 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale22 = null;
        try {
            long long23 = offsetDateTimeField5.set(2440588L, "Coordinated Universal Time", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4L + "'", long15 == 4L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 6983L + "'", long18 == 6983L);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        int int5 = period4.getMinutes();
        org.joda.time.Period period6 = new org.joda.time.Period();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period6.getFieldTypes();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.minutes();
        boolean boolean10 = periodType8.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType11 = periodType8.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType11.isSupported(durationFieldType34);
        org.joda.time.Period period39 = period6.withFieldAdded(durationFieldType34, 0);
        int int40 = period4.get(durationFieldType34);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((-1L), (int) (short) 10);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMaximumValue(readablePartial10);
        int int12 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray20 = new int[] { (-100), 97, 1000, 9, 'a', (-8) };
        int int21 = offsetDateTimeField5.getMaximumValue(readablePartial13, intArray20);
        int int23 = offsetDateTimeField5.getLeapAmount((-60787497600001L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9999L + "'", long8 == 9999L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58 + "'", int11 == 58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58 + "'", int12 == 58);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 58 + "'", int21 == 58);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        try {
            long long40 = unsupportedDateTimeField37.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 1, 1128184613L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1128184612L) + "'", long2 == (-1128184612L));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.String str16 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str18 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str20 = cachedDateTimeZone14.getName((-60787497600001L));
//        boolean boolean21 = cachedDateTimeZone14.isFixed();
//        java.util.TimeZone timeZone22 = cachedDateTimeZone14.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(timeZone22);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 0, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        long long13 = dateTimeZone4.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Chronology chronology14 = iSOChronology3.withZone(dateTimeZone4);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        int int16 = dateTimeZone4.getOffset(readableInstant15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
//        org.joda.time.Period period22 = period20.plusDays(0);
//        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
//        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
//        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType26, (java.lang.Number) 100.0f, (java.lang.Number) 1L, (java.lang.Number) (short) -1);
//        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) cachedDateTimeZone17, (java.lang.Object) (short) -1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertNotNull(durationFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
        java.lang.String str18 = offsetDateTimeField5.getAsText(3155760000032L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1" + "'", str18.equals("-1"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Period period1 = org.joda.time.Period.hours(2);
        org.joda.time.Period period3 = period1.minusMonths(58);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
        long long18 = offsetDateTimeField5.roundHalfEven(18L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        long long11 = offsetDateTimeField5.addWrapField(0L, (int) (byte) -1);
        long long14 = offsetDateTimeField5.set((-1128184612L), 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 59000L + "'", long11 == 59000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1128234612L) + "'", long14 == (-1128234612L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        org.joda.time.PeriodType periodType6 = periodType5.withMillisRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period((-1L), (long) (short) 10);
        org.joda.time.Period period11 = period9.withSeconds(0);
        org.joda.time.Days days12 = period11.toStandardDays();
        org.joda.time.Duration duration13 = period11.toStandardDuration();
        org.joda.time.Period period15 = period11.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType17 = period11.getFieldType(4);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "PT0.011S");
        org.joda.time.field.PreciseDurationField preciseDurationField21 = new org.joda.time.field.PreciseDurationField(durationFieldType17, 0L);
        int int22 = periodType6.indexOf(durationFieldType17);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.String str16 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str18 = cachedDateTimeZone14.getNameKey(1560628794872L);
//        java.lang.String str20 = cachedDateTimeZone14.getName((-60787497600001L));
//        boolean boolean21 = cachedDateTimeZone14.isFixed();
//        int int23 = cachedDateTimeZone14.getOffsetFromLocal((-210866760000000L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology3.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology3.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("38");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"38\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.joda.time.Duration duration9 = period2.toStandardDuration();
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.getValueAsLong((-903L), 1560628794872L);
        long long46 = preciseDurationField35.getMillis((int) (short) 1, 0L);
        long long49 = preciseDurationField35.add(7L, (-60787497600001L));
        long long52 = preciseDurationField35.getValueAsLong((long) (-17), (-1000L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-17L) + "'", long43 == (-17L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 52L + "'", long46 == 52L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3160949875200045L) + "'", long49 == (-3160949875200045L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = periodType3.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.Period period7 = period2.normalizedStandard(periodType3);
        int int8 = period7.getMinutes();
        org.joda.time.Minutes minutes9 = period7.toStandardMinutes();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(minutes9);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone0.getName((long) (short) 0, locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.PeriodType periodType5 = period2.getPeriodType();
        int int6 = period2.getMonths();
        try {
            int int8 = period2.getValue(1000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) -1, 'a', 0, (int) (short) 1, (int) (byte) 0, false, (int) (short) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long15 = offsetDateTimeField5.add((long) 4, 0L);
        boolean boolean17 = offsetDateTimeField5.isLeap(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4L + "'", long15 == 4L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((int) 'a');
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        boolean boolean7 = period4.equals((java.lang.Object) chronology5);
        org.joda.time.PeriodType periodType8 = period4.getPeriodType();
        org.joda.time.Period period10 = period4.withDays((-32));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusDays(0);
        org.joda.time.PeriodType periodType12 = period9.getPeriodType();
        org.joda.time.PeriodType periodType13 = periodType12.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        int int16 = period2.get(durationFieldType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.PeriodType periodType22 = period19.getPeriodType();
        org.joda.time.PeriodType periodType23 = periodType22.withMillisRemoved();
        org.joda.time.Period period24 = period2.normalizedStandard(periodType22);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) 'a');
        org.joda.time.Period period6 = period4.minusYears(8);
        org.joda.time.Period period8 = period4.withMillis((-17));
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.Object obj13 = null;
        boolean boolean14 = iSOChronology12.equals(obj13);
        boolean boolean15 = period4.equals((java.lang.Object) boolean14);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DateTimeField[secondOfMinute]");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        boolean boolean14 = periodType12.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType12, chronology15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
        org.joda.time.Period period27 = period25.plusDays(0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationTo(readableInstant28);
        int int30 = period25.size();
        org.joda.time.Period period31 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusDays(0);
        org.joda.time.PeriodType periodType37 = period34.getPeriodType();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        org.joda.time.Period period42 = period22.withFieldAdded(durationFieldType40, 0);
        boolean boolean43 = periodType12.isSupported(durationFieldType40);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType40, (long) '4');
        long long47 = preciseDurationField45.getMillis(58);
        int int50 = preciseDurationField45.getValue((-65L), (-210866760000000L));
        long long53 = preciseDurationField45.getValueAsLong((-903L), 1560628794872L);
        java.lang.String str54 = preciseDurationField45.toString();
        long long57 = preciseDurationField45.add((long) (byte) 100, 7);
        long long60 = preciseDurationField45.getDifferenceAsLong(0L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField45);
        try {
            java.lang.String str63 = unsupportedDateTimeField61.getAsShortText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3016L + "'", long47 == 3016L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-17L) + "'", long53 == (-17L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 464L + "'", long57 == 464L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField5.getMinimumValue(readablePartial9);
        long long13 = offsetDateTimeField5.addWrapField((-60787497600001L), (int) (byte) 100);
        long long16 = offsetDateTimeField5.set((long) (byte) 0, (int) (byte) -1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField5.getAsText(349260000L, locale18);
        int int21 = offsetDateTimeField5.getLeapAmount(32416L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60787497620001L) + "'", long13 == (-60787497620001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.getValueAsLong(59000L, (long) 100);
        long long50 = decoratedDurationField38.getMillis((-17), (long) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-53646796800000L) + "'", long50 == (-53646796800000L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported");
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "58");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58" + "'", str3.equals("58"));
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        long long12 = dateTimeZone7.adjustOffset((long) (short) -1, true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (-17), (-100), 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-7) + "'", int4 == (-7));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.Period period6 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.yearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology3.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.lang.String str11 = dateTimeZone0.getShortName(1000L);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone0.getShortName(18L, locale13);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology9 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.Period period10 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType2.isSupported(durationFieldType4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology6);
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) 1, periodType2, chronology6);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.Period period11 = period9.plusHours((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.minusMillis((int) 'a');
        org.joda.time.Period period17 = period11.withFields((org.joda.time.ReadablePeriod) period14);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(lenientChronology12);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfMinute();
        org.joda.time.DurationField durationField6 = gregorianChronology4.days();
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.year();
        org.joda.time.DurationField durationField10 = gregorianChronology4.seconds();
        long long15 = gregorianChronology4.getDateTimeMillis((-100), 3, (int) (byte) 10, 0);
        org.joda.time.Period period16 = new org.joda.time.Period(323913770031L, (long) (-28800000), (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-65317017600000L) + "'", long15 == (-65317017600000L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Period period2 = org.joda.time.Period.ZERO;
        org.joda.time.Period period4 = period2.withMonths((int) (byte) 0);
        org.joda.time.Period period6 = period4.minusWeeks((int) (byte) 10);
        org.joda.time.Period period7 = period1.plus((org.joda.time.ReadablePeriod) period4);
        org.joda.time.Period period9 = period7.multipliedBy((int) (byte) 100);
        org.joda.time.Hours hours10 = period9.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(hours10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.monthOfYear();
        org.joda.time.Period period11 = new org.joda.time.Period(1000, (int) (short) -1, (int) (short) 0, 10);
        int[] intArray13 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period11, 1560628794872L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        boolean boolean2 = periodType0.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType3 = periodType0.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusDays(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        int int16 = period11.size();
        org.joda.time.Period period17 = period8.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusDays(0);
        org.joda.time.PeriodType periodType23 = period20.getPeriodType();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period8.withFieldAdded(durationFieldType26, 0);
        boolean boolean29 = periodType3.isSupported(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField30 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        java.lang.String str31 = unsupportedDurationField30.getName();
        try {
            long long34 = unsupportedDurationField30.getMillis((-1560628794937L), (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-100));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210875400000000L) + "'", long1 == (-210875400000000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long42 = preciseDurationField35.getMillis(32);
        org.joda.time.DurationFieldType durationFieldType43 = preciseDurationField35.getType();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1664L + "'", long42 == 1664L);
        org.junit.Assert.assertNotNull(durationFieldType43);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = periodType3.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.Period period7 = period2.normalizedStandard(periodType3);
        int int8 = period7.getMinutes();
        try {
            org.joda.time.Period period10 = period7.minusHours((-8));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        boolean boolean4 = periodType2.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType2, chronology5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        int int20 = period15.size();
        org.joda.time.Period period21 = period12.minus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.PeriodType periodType27 = period24.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period12.withFieldAdded(durationFieldType30, 0);
        boolean boolean33 = periodType2.isSupported(durationFieldType30);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType30, (long) '4');
        long long37 = preciseDurationField35.getMillis(58);
        int int40 = preciseDurationField35.getValue((-65L), (-210866760000000L));
        long long43 = preciseDurationField35.add((-1670400000L), (long) (byte) 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3016L + "'", long37 == 3016L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1670399948L) + "'", long43 == (-1670399948L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant11, readableDuration12);
        org.joda.time.Period period15 = period13.plusDays(0);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusDays(0);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Duration duration22 = period18.toDurationTo(readableInstant21);
        int int23 = period18.size();
        org.joda.time.Period period24 = period15.minus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        org.joda.time.Period period29 = period27.plusDays(0);
        org.joda.time.PeriodType periodType30 = period27.getPeriodType();
        org.joda.time.PeriodType periodType31 = periodType30.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType((int) (short) 0);
        org.joda.time.Period period35 = period15.withFieldAdded(durationFieldType33, 0);
        boolean boolean36 = period10.isSupported(durationFieldType33);
        org.joda.time.field.PreciseDurationField preciseDurationField38 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 8);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType40 = periodType39.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str42 = gregorianChronology41.toString();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.weekyearOfCentury();
        try {
            org.joda.time.Period period44 = new org.joda.time.Period((java.lang.Object) preciseDurationField38, periodType39, (org.joda.time.Chronology) gregorianChronology41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.PreciseDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(duration22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "GregorianChronology[UTC]" + "'", str42.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (-100), 244059000L, chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableDuration15);
        org.joda.time.Period period18 = period16.plusDays(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationTo(readableInstant19);
        int int21 = period16.size();
        int int22 = period16.getDays();
        jodaTimePermission13.checkGuard((java.lang.Object) period16);
        boolean boolean24 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission13);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.ReadableInstant readableInstant1 = null;
        int int2 = dateTimeZone0.getOffset(readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology3.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology3.millis();
        try {
            long long11 = iSOChronology3.getDateTimeMillis(97, (int) '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) -1, 'a', 0, (int) (short) 1, (int) (byte) 0, false, (int) (short) -1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("58", 7, (-28800000), (-7), '4', 0, 58, 52, false, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText((int) (short) 100, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { '#' };
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial14, intArray16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField5.getMinimumValue(readablePartial18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField5.getAsText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-32));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusDays(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        int int9 = period4.size();
        int int10 = period4.getDays();
        jodaTimePermission1.checkGuard((java.lang.Object) period4);
        org.joda.time.Period period13 = period4.plusYears((int) (byte) -1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        long long41 = unsupportedDateTimeField37.add((long) (-1), (-100));
        org.joda.time.ReadablePartial readablePartial42 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField37.getAsShortText(readablePartial42, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-156062879487201L) + "'", long41 == (-156062879487201L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
        boolean boolean8 = periodType6.equals((java.lang.Object) 100.0f);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 100, (long) 10, periodType6, chronology9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusDays(0);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusDays(0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period19.toDurationTo(readableInstant22);
        int int24 = period19.size();
        org.joda.time.Period period25 = period16.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.Period period30 = period28.plusDays(0);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period16.withFieldAdded(durationFieldType34, 0);
        boolean boolean37 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.DecoratedDurationField decoratedDurationField38 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType34);
        long long41 = decoratedDurationField38.getValueAsLong(58665600001L, (-1L));
        long long44 = decoratedDurationField38.getValueAsLong((-65L), 164099520001663L);
        long long47 = decoratedDurationField38.getMillis((int) (short) 1, 349260000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3155760000000L + "'", long47 == 3155760000000L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        boolean boolean5 = periodType3.equals((java.lang.Object) 100.0f);
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.Period period7 = period2.normalizedStandard(periodType3);
        org.joda.time.PeriodType periodType8 = periodType3.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        java.lang.String str6 = offsetDateTimeField5.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Coordinated Universal Time");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusDays(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusDays(0);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period17.toDurationTo(readableInstant20);
        int int22 = period17.size();
        org.joda.time.Period period23 = period14.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant24, readableDuration25);
        org.joda.time.Period period28 = period26.plusDays(0);
        org.joda.time.PeriodType periodType29 = period26.getPeriodType();
        org.joda.time.PeriodType periodType30 = periodType29.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period14.withFieldAdded(durationFieldType32, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType32, 1560628794872L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, (org.joda.time.DurationField) preciseDurationField36);
        java.lang.String str38 = unsupportedDateTimeField37.toString();
        try {
            int int40 = unsupportedDateTimeField37.getMaximumValue(8L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str6.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnsupportedDateTimeField" + "'", str38.equals("UnsupportedDateTimeField"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (byte) 0, locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, 0L);
//        java.lang.String str11 = dateTimeZone0.getShortName(1000L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        int int7 = period2.size();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.PeriodType periodType14 = periodType13.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        int int17 = period2.get(durationFieldType16);
        org.joda.time.Duration duration18 = period2.toStandardDuration();
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Period period1 = org.joda.time.Period.months(2);
        try {
            org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfDay();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(100L, 0, 0, 3, (-17));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -17 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("58", (java.lang.Number) (byte) 1, (java.lang.Number) (-65L), (java.lang.Number) (-10));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusDays(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.plusDays(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        int int12 = period7.size();
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period15 = period7.minusMinutes((int) (short) 100);
        org.joda.time.Period period17 = period7.withDays((int) (short) 0);
        int int18 = period17.getMinutes();
        try {
            org.joda.time.DurationFieldType durationFieldType20 = period17.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getName((long) 4, locale7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (-1));
        long long8 = offsetDateTimeField5.add((long) 'a', (long) (-1));
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 0);
        long long12 = offsetDateTimeField5.roundFloor((long) (-1));
        long long14 = offsetDateTimeField5.roundHalfFloor((long) 0);
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((long) (-8));
        java.lang.String str17 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-903L) + "'", long8 == (-903L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "58" + "'", str16.equals("58"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str17.equals("DateTimeField[secondOfMinute]"));
    }
}

