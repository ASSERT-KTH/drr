import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider4 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider4);
//        boolean boolean6 = property3.equals((java.lang.Object) defaultNameProvider4);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMillis(1970);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 0, chronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime21.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 0, chronology27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        java.lang.Class<?> wildcardClass32 = dateTime30.getClass();
        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.plus(readableDuration34);
        org.joda.time.DateTime dateTime37 = dateTime35.plus((long) (short) -1);
        int int38 = dateTime35.getYear();
        int int39 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime35);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendTimeZoneOffset("T������", "Thursday", false, (-69), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        long long13 = offsetDateTimeField5.roundCeiling(35L);
        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31536000000L + "'", long13 == 31536000000L);
        org.junit.Assert.assertNull(durationField14);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = iSOChronology7.years();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean13 = dateTimeZone11.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology14 = iSOChronology7.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology15 = gregorianChronology4.withZone(dateTimeZone11);
        long long19 = dateTimeZone11.convertLocalToUTC(1560638641245L, true, 11L);
        try {
            org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) iSOChronology0, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560642241245L + "'", long19 == 1560642241245L);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
//        long long9 = property8.remainder();
//        java.lang.String str10 = property8.getAsShortText();
//        org.joda.time.LocalDate localDate12 = property8.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology16);
//        int int18 = localDate17.getCenturyOfEra();
//        int[] intArray19 = localDate17.getValues();
//        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate12, intArray19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType21);
//        long long25 = skipUndoDateTimeField4.add((long) 5, (-6));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType26, 151);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 17020800000L + "'", long9 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-518399995L) + "'", long25 == (-518399995L));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        try {
            java.lang.String str8 = dateTime4.toString("Tue");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
//        try {
//            java.lang.String str4 = partial2.toString("Mon");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str1.equals("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime.Property property8 = dateTime2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
        java.lang.String str12 = skipDateTimeField10.getAsShortText(1560638641245L);
        long long14 = skipDateTimeField10.roundFloor(32054400000L);
        int int15 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32054400000L + "'", long14 == 32054400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
        long long10 = dateTimeZone1.convertLocalToUTC(0L, false);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        try {
            long long17 = copticChronology11.getDateTimeMillis(5, (int) (short) 1, 50, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 50 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTimeZoneShortName(strMap19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = iSOChronology21.years();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        int int28 = offsetDateTimeField26.get(100L);
        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
//        java.lang.String str12 = skipUndoDateTimeField4.getAsShortText(3121220641245L);
//        java.util.Locale locale13 = null;
//        int int14 = skipUndoDateTimeField4.getMaximumTextLength(locale13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
//        int int22 = offsetDateTimeField20.get(100L);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight24 = localDate23.toDateMidnight();
//        java.lang.String str25 = localDate23.toString();
//        org.joda.time.LocalDate localDate27 = localDate23.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate29 = localDate27.minus(readablePeriod28);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate29, locale30);
//        boolean boolean32 = offsetDateTimeField20.isSupported();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology34);
//        int int36 = localDate35.getCenturyOfEra();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate35, locale37);
//        int int40 = offsetDateTimeField20.getLeapAmount((long) '#');
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight42 = localDate41.toDateMidnight();
//        java.lang.String str43 = localDate41.toString();
//        org.joda.time.DateTime dateTime44 = localDate41.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateMidnight dateMidnight46 = localDate41.toDateMidnight(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateMidnight dateMidnight48 = localDate41.toDateMidnight(dateTimeZone47);
//        org.joda.time.LocalDate.Property property49 = localDate41.dayOfMonth();
//        int int50 = property49.getMinimumValue();
//        org.joda.time.LocalDate localDate51 = property49.withMinimumValue();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate51, 2, locale53);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate51, (int) (byte) 1, locale56);
//        int[] intArray58 = localDate51.getValues();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Tue" + "'", str12.equals("Tue"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 122 + "'", int22 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-07-17" + "'", str25.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19" + "'", str31.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "69" + "'", str38.equals("69"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019-07-17" + "'", str43.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertNotNull(dateMidnight48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2" + "'", str54.equals("2"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Mon" + "'", str57.equals("Mon"));
//        org.junit.Assert.assertNotNull(intArray58);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        int int9 = dateTimeZone6.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str12 = cachedDateTimeZone10.getNameKey((long) 151);
        int int14 = cachedDateTimeZone10.getOffset((long) 69);
        long long18 = cachedDateTimeZone10.convertLocalToUTC(10L, true, 0L);
        java.lang.String str20 = cachedDateTimeZone10.getNameKey((long) 122);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((-292275054), 99, 2000, 0, 86399, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-3600000) + "'", int14 == (-3600000));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600010L + "'", long18 == 3600010L);
        org.junit.Assert.assertNull(str20);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        java.lang.String str6 = skipUndoDateTimeField4.getAsText((long) '#');
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyear();
//        org.joda.time.DurationField durationField15 = iSOChronology12.months();
//        long long18 = durationField15.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property20 = localDate19.yearOfCentury();
//        long long21 = property20.remainder();
//        java.lang.String str22 = property20.getAsShortText();
//        java.util.Locale locale23 = null;
//        int int24 = property20.getMaximumTextLength(locale23);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, durationField15, dateTimeFieldType25, 7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType25, 1);
//        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thursday" + "'", str6.equals("Thursday"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2682000000L) + "'", long18 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 17020800000L + "'", long21 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getLeapDurationField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField4.getAsText((long) 6, locale9);
        boolean boolean11 = skipUndoDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thursday" + "'", str10.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(1560582000000L);
        org.joda.time.DateTime dateTime10 = property7.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateTime dateTime11 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        java.lang.String str13 = property10.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "millisOfDay" + "'", str13.equals("millisOfDay"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateMidnight5.getZone();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
//        java.lang.String str13 = gJChronology12.toString();
//        org.joda.time.Instant instant14 = gJChronology12.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder15.appendFractionOfMinute(3, (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.appendTwoDigitYear((int) ' ', false);
//        boolean boolean26 = gJChronology12.equals((java.lang.Object) ' ');
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str13.equals("GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((-6));
        boolean boolean10 = dateTime7.isAfterNow();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime7.withDurationAdded(readableDuration11, 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime2.withYear(19);
        org.joda.time.DateTime.Property property8 = dateTime2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.year();
//        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight26 = localDate25.toDateMidnight();
//        java.lang.String str27 = localDate25.toString();
//        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateMidnight dateMidnight30 = localDate25.toDateMidnight(dateTimeZone29);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.monthOfYear();
//        int int34 = dateMidnight30.get(dateTimeField33);
//        org.joda.time.DateTimeZone dateTimeZone35 = dateMidnight30.getZone();
//        boolean boolean36 = fixedDateTimeZone24.equals((java.lang.Object) dateMidnight30);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime19.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.DurationFieldType durationFieldType39 = null;
//        try {
//            org.joda.time.DateTime dateTime41 = dateTime19.withFieldAdded(durationFieldType39, 68);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019-07-17" + "'", str27.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField11 = iSOChronology10.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
//        int int17 = offsetDateTimeField15.get(100L);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
//        java.lang.String str20 = localDate18.toString();
//        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.LocalDate localDate24 = localDate22.minus(readablePeriod23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate24, locale25);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField28 = iSOChronology27.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology27.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) '4');
//        int int34 = offsetDateTimeField32.get(100L);
//        long long36 = offsetDateTimeField32.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField32.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType37, 15);
//        org.joda.time.DurationField durationField40 = dividedDateTimeField39.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField42 = iSOChronology41.years();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.weekyear();
//        org.joda.time.DurationField durationField44 = iSOChronology41.months();
//        long long47 = durationField44.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField50 = iSOChronology49.years();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology48, dateTimeField51);
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField54 = iSOChronology53.years();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology53.weekyear();
//        org.joda.time.DurationField durationField56 = iSOChronology53.months();
//        long long59 = durationField56.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property61 = localDate60.yearOfCentury();
//        long long62 = property61.remainder();
//        java.lang.String str63 = property61.getAsShortText();
//        java.util.Locale locale64 = null;
//        int int65 = property61.getMaximumTextLength(locale64);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property61.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(dateTimeField51, durationField56, dateTimeFieldType66, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39, durationField44, dateTimeFieldType66);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType66, 3);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, "hi!");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 122 + "'", int17 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-07-17" + "'", str20.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "19" + "'", str26.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 122 + "'", int34 == 122);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 31536000000L + "'", long36 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2682000000L) + "'", long47 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-2682000000L) + "'", long59 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 17020800000L + "'", long62 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "19" + "'", str63.equals("19"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology6);
//        int int8 = localDate7.getCenturyOfEra();
//        org.joda.time.LocalDate localDate10 = localDate7.minusDays(19);
//        int int11 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology12, dateTimeField14, (int) (short) 100);
//        long long19 = skipUndoDateTimeField16.add((long) 24, (long) ' ');
//        int int22 = skipUndoDateTimeField16.getDifference((long) 4, (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField16.getType();
//        int int24 = localDate10.indexOf(dateTimeFieldType23);
//        org.joda.time.LocalDate.Property property25 = localDate10.era();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2764800024L + "'", long19 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(property25);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DurationFieldType durationFieldType3 = null;
//        try {
//            org.joda.time.Partial partial5 = partial2.withFieldAddWrapped(durationFieldType3, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str1.equals("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        java.util.Date date5 = dateTime2.toDate();
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = iSOChronology5.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.weekyear();
//        org.joda.time.DurationField durationField8 = iSOChronology5.months();
//        long long11 = durationField8.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
//        long long14 = property13.remainder();
//        java.lang.String str15 = property13.getAsShortText();
//        java.util.Locale locale16 = null;
//        int int17 = property13.getMaximumTextLength(locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField20 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, durationField8, dateTimeFieldType18, 7);
//        int int23 = dividedDateTimeField20.getDifference(0L, (long) (byte) -1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2682000000L) + "'", long11 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 17020800000L + "'", long14 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19" + "'", str15.equals("19"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.minus(readablePeriod8);
        try {
            org.joda.time.LocalDate localDate11 = localDate6.withEra(5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate2.toDateMidnight(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.monthOfYear();
//        int int11 = dateMidnight7.get(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateMidnight7.getZone();
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology0.era();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology0.centuryOfEra();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-07-17" + "'", str4.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        long long9 = property7.remainder();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 999L + "'", long9 == 999L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 10, "");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        int int8 = localDate6.getWeekyear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1686 + "'", int8 == 1686);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str3 = dateTimeZone2.getID();
        int int5 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) 151);
        int int10 = cachedDateTimeZone6.getOffset((long) 69);
        long long14 = cachedDateTimeZone6.convertLocalToUTC(10L, true, 0L);
        java.lang.String str16 = cachedDateTimeZone6.getNameKey((long) 122);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(35L, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:00" + "'", str3.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-3600000) + "'", int5 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-3600000) + "'", int10 == (-3600000));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600010L + "'", long14 == 3600010L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.years();
        try {
            long long6 = gJChronology0.getDateTimeMillis(11, (-69), (-6), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = iSOChronology5.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.minuteOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.DateTime dateTime17 = localDate14.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateMidnight dateMidnight19 = localDate14.toDateMidnight(dateTimeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = iSOChronology20.years();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.monthOfYear();
//        int int23 = dateMidnight19.get(dateTimeField22);
//        org.joda.time.DateTimeZone dateTimeZone24 = dateMidnight19.getZone();
//        boolean boolean25 = fixedDateTimeZone13.equals((java.lang.Object) dateMidnight19);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(2440942, (int) (byte) -1, (-32), (int) (short) 10, 1959, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1959 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-07-17" + "'", str16.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        java.lang.String str8 = skipUndoDateTimeField4.getAsShortText((long) 52);
        int int9 = skipUndoDateTimeField4.getMinimumValue();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = skipUndoDateTimeField4.getAsShortText(1970, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1970");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Thu" + "'", str8.equals("Thu"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        java.lang.String str8 = skipUndoDateTimeField4.getAsShortText((long) 52);
        int int9 = skipUndoDateTimeField4.getMinimumValue();
        boolean boolean10 = skipUndoDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Thu" + "'", str8.equals("Thu"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 0, chronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight13 = dateTime10.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.years();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) '4');
        int int21 = offsetDateTimeField19.get(100L);
        long long23 = offsetDateTimeField19.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField19.getType();
        boolean boolean25 = dateTime10.isSupported(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 122 + "'", int21 == 122);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31536000000L + "'", long23 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        int int6 = skipUndoDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(122, 2, 4, 1969, (-292275054), 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.year();
//        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight26 = localDate25.toDateMidnight();
//        java.lang.String str27 = localDate25.toString();
//        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateMidnight dateMidnight30 = localDate25.toDateMidnight(dateTimeZone29);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.monthOfYear();
//        int int34 = dateMidnight30.get(dateTimeField33);
//        org.joda.time.DateTimeZone dateTimeZone35 = dateMidnight30.getZone();
//        boolean boolean36 = fixedDateTimeZone24.equals((java.lang.Object) dateMidnight30);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime19.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        java.lang.String str40 = fixedDateTimeZone24.getNameKey((long) 70);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019-07-17" + "'", str27.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "15" + "'", str40.equals("15"));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(10);
        long long9 = dateTimeZone6.adjustOffset(14256000000L, true);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 10, (int) (byte) 100, (int) (byte) 10, 1970, (int) (short) 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 14256000000L + "'", long9 == 14256000000L);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField5.getLeapDurationField();
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
//        java.lang.String str20 = localDate18.toString();
//        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = localDate18.isSupported(dateTimeFieldType23);
//        int int25 = localDate18.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property26 = localDate18.yearOfCentury();
//        int[] intArray27 = new int[] {};
//        int int28 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate18, intArray27);
//        java.lang.String str29 = offsetDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-07-17" + "'", str10.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-07-17" + "'", str20.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 29 + "'", int25 == 29);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 151 + "'", int28 == 151);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyearOfCentury" + "'", str29.equals("weekyearOfCentury"));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        long long13 = offsetDateTimeField5.roundCeiling(35L);
        long long15 = offsetDateTimeField5.roundCeiling((long) 2440942);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31536000000L + "'", long13 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31536000000L + "'", long15 == 31536000000L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
//        int int11 = offsetDateTimeField9.get(100L);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        int int28 = offsetDateTimeField26.get(100L);
//        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 15);
//        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.weekyear();
//        org.joda.time.DurationField durationField38 = iSOChronology35.months();
//        long long41 = durationField38.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField48 = iSOChronology47.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.weekyear();
//        org.joda.time.DurationField durationField50 = iSOChronology47.months();
//        long long53 = durationField50.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property55 = localDate54.yearOfCentury();
//        long long56 = property55.remainder();
//        java.lang.String str57 = property55.getAsShortText();
//        java.util.Locale locale58 = null;
//        int int59 = property55.getMaximumTextLength(locale58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property55.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(dateTimeField45, durationField50, dateTimeFieldType60, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, durationField38, dateTimeFieldType60);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType60, 3);
//        long long67 = remainderDateTimeField65.roundCeiling(3600000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-07-17" + "'", str14.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "19" + "'", str20.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2682000000L) + "'", long41 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-2682000000L) + "'", long53 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 17020800000L + "'", long56 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19" + "'", str57.equals("19"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600000L + "'", long67 == 3600000L);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        int int61 = remainderDateTimeField59.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-07-17" + "'", str10.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 17020800000L + "'", long52 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
//        java.lang.String str12 = skipUndoDateTimeField4.getAsShortText(3121220641245L);
//        java.util.Locale locale13 = null;
//        int int14 = skipUndoDateTimeField4.getMaximumTextLength(locale13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
//        int int22 = offsetDateTimeField20.get(100L);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight24 = localDate23.toDateMidnight();
//        java.lang.String str25 = localDate23.toString();
//        org.joda.time.LocalDate localDate27 = localDate23.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate29 = localDate27.minus(readablePeriod28);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate29, locale30);
//        boolean boolean32 = offsetDateTimeField20.isSupported();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology34);
//        int int36 = localDate35.getCenturyOfEra();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate35, locale37);
//        int int40 = offsetDateTimeField20.getLeapAmount((long) '#');
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight42 = localDate41.toDateMidnight();
//        java.lang.String str43 = localDate41.toString();
//        org.joda.time.DateTime dateTime44 = localDate41.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateMidnight dateMidnight46 = localDate41.toDateMidnight(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateMidnight dateMidnight48 = localDate41.toDateMidnight(dateTimeZone47);
//        org.joda.time.LocalDate.Property property49 = localDate41.dayOfMonth();
//        int int50 = property49.getMinimumValue();
//        org.joda.time.LocalDate localDate51 = property49.withMinimumValue();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate51, 2, locale53);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate51, (int) (byte) 1, locale56);
//        java.util.Locale locale59 = null;
//        try {
//            java.lang.String str60 = skipUndoDateTimeField4.getAsText(53, locale59);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Tue" + "'", str12.equals("Tue"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 122 + "'", int22 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-07-17" + "'", str25.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19" + "'", str31.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "69" + "'", str38.equals("69"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019-07-17" + "'", str43.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertNotNull(dateMidnight48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2" + "'", str54.equals("2"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Mon" + "'", str57.equals("Mon"));
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime11.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 0, chronology18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime19.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 0, chronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.toDateTime(dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime28.secondOfDay();
//        java.lang.Class<?> wildcardClass30 = dateTime28.getClass();
//        boolean boolean31 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime28.plus(readableDuration32);
//        org.joda.time.DateTime.Property property34 = dateTime28.year();
//        org.joda.time.DateTime dateTime36 = dateTime28.withYearOfCentury(0);
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 0, chronology38);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime39.toDateTime(dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
//        java.lang.Class<?> wildcardClass43 = dateTime41.getClass();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight50 = localDate49.toDateMidnight();
//        java.lang.String str51 = localDate49.toString();
//        org.joda.time.DateTime dateTime52 = localDate49.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateMidnight dateMidnight54 = localDate49.toDateMidnight(dateTimeZone53);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField56 = iSOChronology55.years();
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.monthOfYear();
//        int int58 = dateMidnight54.get(dateTimeField57);
//        org.joda.time.DateTimeZone dateTimeZone59 = dateMidnight54.getZone();
//        boolean boolean60 = fixedDateTimeZone48.equals((java.lang.Object) dateMidnight54);
//        java.lang.String str62 = fixedDateTimeZone48.getNameKey(0L);
//        org.joda.time.DateTime dateTime63 = dateTime41.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        org.joda.time.DateTime dateTime64 = dateTime28.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        org.joda.time.Chronology chronology65 = buddhistChronology16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        org.joda.time.ReadablePartial readablePartial66 = null;
//        try {
//            int[] intArray68 = buddhistChronology16.get(readablePartial66, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019-07-17" + "'", str51.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateMidnight54);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 7 + "'", int58 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "15" + "'", str62.equals("15"));
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(chronology65);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(82200, 4, 53, 0, (int) (byte) -1, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime6.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime.Property property17 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime19 = property17.setCopy("19691231");
        org.joda.time.DateTime dateTime20 = property17.getDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        org.joda.time.LocalDate localDate10 = property8.withMinimumValue();
//        org.joda.time.LocalDate.Property property11 = localDate10.monthOfYear();
//        org.joda.time.DurationField durationField12 = property11.getDurationField();
//        int int13 = property11.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(99L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime18.withZone(dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfSecond();
        boolean boolean23 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            org.joda.time.DateTime dateTime26 = dateTime11.withFieldAdded(durationFieldType24, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DurationField durationField5 = iSOChronology1.weekyears();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) (short) 100);
//        java.lang.String str12 = skipUndoDateTimeField10.getAsText((long) '#');
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField16);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField19 = iSOChronology18.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.weekyear();
//        org.joda.time.DurationField durationField21 = iSOChronology18.months();
//        long long24 = durationField21.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property26 = localDate25.yearOfCentury();
//        long long27 = property26.remainder();
//        java.lang.String str28 = property26.getAsShortText();
//        java.util.Locale locale29 = null;
//        int int30 = property26.getMaximumTextLength(locale29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property26.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField21, dateTimeFieldType31, 7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType31, 1);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField5, dateTimeFieldType31, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Thursday" + "'", str12.equals("Thursday"));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2682000000L) + "'", long24 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 14256000000L + "'", long27 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19" + "'", str28.equals("19"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
//        java.lang.String str25 = offsetDateTimeField5.getAsText(100L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "122" + "'", str25.equals("122"));
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        java.lang.String str10 = property8.getAsString();
//        org.joda.time.LocalDate localDate12 = property8.addToCopy(53);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "15" + "'", str10.equals("15"));
//        org.junit.Assert.assertNotNull(localDate12);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        int int8 = offsetDateTimeField6.get(100L);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.LocalDate localDate13 = localDate9.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.LocalDate localDate15 = localDate13.minus(readablePeriod14);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate15, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField6.getLeapDurationField();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        java.lang.String str21 = localDate19.toString();
//        org.joda.time.LocalDate localDate23 = localDate19.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
//        boolean boolean25 = localDate19.isSupported(dateTimeFieldType24);
//        int int26 = localDate19.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property27 = localDate19.yearOfCentury();
//        int[] intArray28 = new int[] {};
//        int int29 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate19, intArray28);
//        boolean boolean31 = offsetDateTimeField6.isLeap((long) 'a');
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property33 = localDate32.yearOfCentury();
//        long long34 = property33.remainder();
//        java.lang.String str35 = property33.getAsShortText();
//        org.joda.time.LocalDate localDate37 = property33.addWrapFieldToCopy(365);
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight46 = localDate45.toDateMidnight();
//        java.lang.String str47 = localDate45.toString();
//        org.joda.time.LocalDate localDate49 = localDate45.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = null;
//        boolean boolean51 = localDate45.isSupported(dateTimeFieldType50);
//        int int52 = localDate45.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property53 = localDate45.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.LocalDate localDate55 = localDate45.minus(readablePeriod54);
//        org.joda.time.Chronology chronology57 = null;
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology57);
//        int int59 = localDate58.getCenturyOfEra();
//        int[] intArray60 = localDate58.getValues();
//        int int61 = offsetDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localDate45, intArray60);
//        int[] intArray63 = offsetDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localDate37, (int) (byte) 0, intArray60, 0);
//        try {
//            org.joda.time.Partial partial64 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray63);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 122 + "'", int8 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-06-15" + "'", str21.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 151 + "'", int29 == 151);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 14256000000L + "'", long34 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19" + "'", str35.equals("19"));
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019-06-15" + "'", str47.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 19 + "'", int59 == 19);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 52 + "'", int61 == 52);
//        org.junit.Assert.assertNotNull(intArray63);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        java.util.Date date7 = localDate6.toDate();
        org.joda.time.DateTime dateTime8 = localDate6.toDateTimeAtStartOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendFractionOfDay((int) 'a', 292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendHourOfDay((int) (byte) 0);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 0, chronology23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.toDateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight29 = dateTime26.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField31 = iSOChronology30.years();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) '4');
        int int37 = offsetDateTimeField35.get(100L);
        long long39 = offsetDateTimeField35.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField35.getType();
        boolean boolean41 = dateTime26.isSupported(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder21.appendText(dateTimeFieldType40);
        int int43 = dateTime8.get(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 122 + "'", int37 == 122);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31536000000L + "'", long39 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 87 + "'", int43 == 87);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone9.getID();
        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
        long long15 = dateTimeZone9.convertLocalToUTC(0L, false);
        org.joda.time.DateMidnight dateMidnight16 = localDate6.toDateMidnight(dateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600000L + "'", long15 == 3600000L);
        org.junit.Assert.assertNotNull(dateMidnight16);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        long long62 = dividedDateTimeField29.getDifferenceAsLong((long) 2440942, (long) 1);
//        boolean boolean63 = dividedDateTimeField29.isSupported();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear((-1), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendLiteral("-01:00");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Object obj0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(obj0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        boolean boolean11 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.DateTime dateTime13 = dateTime7.withMinuteOfHour((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfEra((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime9.minus((long) (short) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar16);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertNotNull(localDate17);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property8 = localDate0.yearOfCentury();
//        org.joda.time.LocalDate localDate10 = localDate0.withYearOfEra(69);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
//        int int8 = dateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateMidnight dateMidnight14 = dateTime11.toDateMidnight();
//        org.joda.time.DateTime dateTime16 = dateTime11.plusMonths((int) '#');
//        int int17 = dateTime11.getMonthOfYear();
//        boolean boolean18 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime20 = dateTime11.plusYears(15);
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight22 = localDate21.toDateMidnight();
//        java.lang.String str23 = localDate21.toString();
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateMidnight dateMidnight26 = localDate21.toDateMidnight(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField28 = iSOChronology27.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.monthOfYear();
//        int int30 = dateMidnight26.get(dateTimeField29);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateMidnight26.getZone();
//        org.joda.time.ReadableInstant readableInstant32 = null;
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
//        java.lang.String str34 = gJChronology33.toString();
//        org.joda.time.Instant instant35 = gJChronology33.getGregorianCutover();
//        boolean boolean36 = dateTime20.isAfter((org.joda.time.ReadableInstant) instant35);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019-06-15" + "'", str23.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str34.equals("GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.monthOfYear();
        org.joda.time.Chronology chronology8 = copticChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(68, (int) ' ', 68, 69, (-292275054), 17, chronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2440490L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 87, 5);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(10);
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime4.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 99);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
//        int int9 = offsetDateTimeField7.get(100L);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight11 = localDate10.toDateMidnight();
//        java.lang.String str12 = localDate10.toString();
//        org.joda.time.LocalDate localDate14 = localDate10.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.LocalDate localDate16 = localDate14.minus(readablePeriod15);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate16, locale17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField20 = iSOChronology19.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        int int26 = offsetDateTimeField24.get(100L);
//        long long28 = offsetDateTimeField24.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField24.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 15);
//        int int32 = localDate1.indexOf(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15" + "'", str12.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19" + "'", str18.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 122 + "'", int26 == 122);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31536000000L + "'", long28 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.toString();
        java.lang.String str6 = jodaTimePermission3.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField5.getAsShortText(14256000000L, locale11);
        long long14 = offsetDateTimeField5.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "122" + "'", str12.equals("122"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) ' ');
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds(99);
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) (short) 10);
        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.DateTime dateTime11 = dateTime4.plusDays(6);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour(19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
//        long long9 = property8.remainder();
//        java.lang.String str10 = property8.getAsShortText();
//        org.joda.time.LocalDate localDate12 = property8.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology16);
//        int int18 = localDate17.getCenturyOfEra();
//        int[] intArray19 = localDate17.getValues();
//        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate12, intArray19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType21);
//        org.joda.time.DurationField durationField23 = delegatedDateTimeField22.getRangeDurationField();
//        long long26 = durationField23.subtract(0L, 86399);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 14256000000L + "'", long9 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-52254115200000L) + "'", long26 == (-52254115200000L));
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        long long62 = remainderDateTimeField59.roundHalfFloor((-86399900L));
//        int int63 = remainderDateTimeField59.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
//        java.lang.String str12 = skipUndoDateTimeField4.getAsShortText(3121220641245L);
//        java.util.Locale locale13 = null;
//        int int14 = skipUndoDateTimeField4.getMaximumTextLength(locale13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
//        int int22 = offsetDateTimeField20.get(100L);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight24 = localDate23.toDateMidnight();
//        java.lang.String str25 = localDate23.toString();
//        org.joda.time.LocalDate localDate27 = localDate23.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate29 = localDate27.minus(readablePeriod28);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate29, locale30);
//        boolean boolean32 = offsetDateTimeField20.isSupported();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology34);
//        int int36 = localDate35.getCenturyOfEra();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate35, locale37);
//        int int40 = offsetDateTimeField20.getLeapAmount((long) '#');
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight42 = localDate41.toDateMidnight();
//        java.lang.String str43 = localDate41.toString();
//        org.joda.time.DateTime dateTime44 = localDate41.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateMidnight dateMidnight46 = localDate41.toDateMidnight(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateMidnight dateMidnight48 = localDate41.toDateMidnight(dateTimeZone47);
//        org.joda.time.LocalDate.Property property49 = localDate41.dayOfMonth();
//        int int50 = property49.getMinimumValue();
//        org.joda.time.LocalDate localDate51 = property49.withMinimumValue();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate51, 2, locale53);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate51, (int) (byte) 1, locale56);
//        org.joda.time.LocalDate localDate59 = localDate51.withEra((int) (short) 1);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Tue" + "'", str12.equals("Tue"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 122 + "'", int22 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-06-15" + "'", str25.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19" + "'", str31.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "69" + "'", str38.equals("69"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019-06-15" + "'", str43.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertNotNull(dateMidnight48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2" + "'", str54.equals("2"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Mon" + "'", str57.equals("Mon"));
//        org.junit.Assert.assertNotNull(localDate59);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        long long18 = offsetDateTimeField5.roundCeiling(32054400000L);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int int20 = offsetDateTimeField5.getMaximumValue(readablePartial19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 63072000000L + "'", long18 == 63072000000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 151 + "'", int20 == 151);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        try {
//            org.joda.time.DateTime dateTime5 = dateTime3.withMinuteOfHour(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
//        int int3 = dateTimeFormatter0.getDefaultYear();
//        boolean boolean4 = dateTimeFormatter0.isOffsetParsed();
//        java.lang.String str6 = dateTimeFormatter0.print((long) 1970);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19700101" + "'", str6.equals("19700101"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate11.plus(readablePeriod13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate11, 52, locale16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 151 + "'", int10 == 151);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52" + "'", str17.equals("52"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime20.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 0, chronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.toDateTime(dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        java.lang.Class<?> wildcardClass31 = dateTime29.getClass();
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime34 = dateTime24.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime37 = dateTime24.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime39 = dateTime24.plusMonths((int) (short) 100);
        int int40 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField43 = iSOChronology42.years();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology42.minuteOfDay();
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int48 = gregorianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField49, 20);
        java.lang.String str53 = skipDateTimeField51.getAsShortText(1560638641245L);
        long long55 = skipDateTimeField51.roundFloor(32054400000L);
        int int56 = dateTime24.get((org.joda.time.DateTimeField) skipDateTimeField51);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-69) + "'", int40 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 32054400000L + "'", long55 == 32054400000L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendFractionOfHour(68, 3);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendClockhourOfHalfday(68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        java.lang.String str9 = dateTime4.toString("19700101");
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19700101" + "'", str9.equals("19700101"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
        java.lang.String str12 = skipDateTimeField10.getAsShortText(1560638641245L);
        boolean boolean14 = skipDateTimeField10.isLeap(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        org.joda.time.Chronology chronology14 = dateTime11.getChronology();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter6.withChronology(chronology14);
//        org.joda.time.DateTime dateTime16 = dateTime4.withChronology(chronology14);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfWeek();
//        int int9 = localDate0.getCenturyOfEra();
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate0);
//        org.joda.time.DurationFieldType durationFieldType11 = null;
//        try {
//            org.joda.time.Partial partial13 = partial10.withFieldAdded(durationFieldType11, 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        int int19 = fixedDateTimeZone4.getOffsetFromLocal(0L);
//        int int21 = fixedDateTimeZone4.getStandardOffset(2764800001L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 69 + "'", int21 == 69);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        try {
            long long11 = zonedChronology3.getDateTimeMillis(1, (int) '#', (-292275054), 122, 10, 6, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 122 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 5, dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        try {
            java.lang.String str7 = dateTime4.toString(dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:00" + "'", str3.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(dateTimePrinter6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        int int7 = property5.getMinimumValueOverall();
        int int8 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime21 = dateTime19.plusHours(4);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        long long19 = fixedDateTimeZone4.previousTransition((long) 11);
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 11L + "'", long19 == 11L);
//        org.junit.Assert.assertNotNull(gJChronology20);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(2764800024L);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
//        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
//        long long9 = dateTime8.getMillis();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusHours((-1));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-86399999L) + "'", long9 == (-86399999L));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
//        int int8 = dateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateMidnight dateMidnight14 = dateTime11.toDateMidnight();
//        org.joda.time.DateTime dateTime16 = dateTime11.plusMonths((int) '#');
//        int int17 = dateTime11.getMonthOfYear();
//        boolean boolean18 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime2.toMutableDateTime();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        java.lang.String str5 = skipUndoDateTimeField4.getName();
//        boolean boolean6 = skipUndoDateTimeField4.isLenient();
//        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getLeapDurationField();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField4.getAsText((long) 6, locale9);
//        long long13 = skipUndoDateTimeField4.getDifferenceAsLong(0L, (-210858379200000L));
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.LocalDate localDate18 = localDate14.minusDays((int) '#');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology20);
//        int int22 = localDate21.getCenturyOfEra();
//        org.joda.time.LocalDate localDate24 = localDate21.minusDays(19);
//        int int25 = localDate14.compareTo((org.joda.time.ReadablePartial) localDate24);
//        org.joda.time.LocalDate localDate27 = localDate24.withYearOfEra(20);
//        org.joda.time.LocalDate localDate29 = localDate27.withDayOfYear(122);
//        int int30 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate29);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thursday" + "'", str10.equals("Thursday"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2440490L + "'", long13 == 2440490L);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        long long3 = property1.remainder();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14256000000L + "'", long3 == 14256000000L);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getMonthOfYear();
//        int int8 = localDate0.getEra();
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType10 = localDate0.getFieldType(53);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 53");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.era();
//        java.lang.String str3 = dateTime1.toString();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15T22:45:03.096-00:00:00.001" + "'", str3.equals("2019-06-15T22:45:03.096-00:00:00.001"));
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
//        long long7 = skipUndoDateTimeField4.getDifferenceAsLong(10L, 0L);
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology8, dateTimeField10, (int) (short) 100);
//        long long15 = skipUndoDateTimeField12.add((long) 24, (long) ' ');
//        int int18 = skipUndoDateTimeField12.getDifference((long) 4, (long) 'a');
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        java.lang.String str21 = localDate19.toString();
//        org.joda.time.LocalDate localDate23 = localDate19.minusDays((int) '#');
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology25);
//        int int27 = localDate26.getCenturyOfEra();
//        org.joda.time.LocalDate localDate29 = localDate26.minusDays(19);
//        int int30 = localDate19.compareTo((org.joda.time.ReadablePartial) localDate29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate19, (int) (byte) 1, locale32);
//        int int34 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate19);
//        try {
//            int int36 = localDate19.getValue((-69));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -69");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2764800024L + "'", long15 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-06-15" + "'", str21.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Mon" + "'", str33.equals("Mon"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292275054) + "'", int34 == (-292275054));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
//        long long16 = property15.remainder();
//        java.lang.String str17 = property15.getAsShortText();
//        org.joda.time.LocalDate localDate19 = property15.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = localDate19.isSupported(dateTimeFieldType20);
//        org.joda.time.LocalDate localDate23 = localDate19.withEra(0);
//        int int24 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
//        try {
//            int int26 = localDate19.getValue(99);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 99");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000000L + "'", long16 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText(1560638641245L);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight14 = localDate13.toDateMidnight();
//        java.lang.String str15 = localDate13.toString();
//        org.joda.time.LocalDate localDate17 = localDate13.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = localDate13.isSupported(dateTimeFieldType18);
//        int int20 = localDate13.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property21 = localDate13.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.LocalDate localDate23 = localDate13.minus(readablePeriod22);
//        java.util.Locale locale24 = null;
//        try {
//            java.lang.String str25 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate13, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-15" + "'", str15.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.plusMonths(0);
        try {
            org.joda.time.LocalDate localDate5 = localDate0.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addWrapFieldToCopy(365);
//        int int6 = localDate5.getYear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2084 + "'", int6 == 2084);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText(readablePartial10, 24, locale12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "24" + "'", str13.equals("24"));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight7 = localDate6.toDateMidnight();
//        java.lang.String str8 = localDate6.toString();
//        org.joda.time.DateTime dateTime9 = localDate6.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateMidnight dateMidnight11 = localDate6.toDateMidnight(dateTimeZone10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.monthOfYear();
//        int int15 = dateMidnight11.get(dateTimeField14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateMidnight11.getZone();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        java.lang.String str19 = gJChronology18.toString();
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology18);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(1959, (-69), 1970, (int) (byte) 1, (int) (byte) 1, 7, (org.joda.time.Chronology) gJChronology18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -69 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str19.equals("GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.minus(readablePeriod8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int int11 = localDate9.compareTo(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
//        long long16 = property15.remainder();
//        java.lang.String str17 = property15.getAsShortText();
//        org.joda.time.LocalDate localDate19 = property15.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = localDate19.isSupported(dateTimeFieldType20);
//        org.joda.time.LocalDate localDate23 = localDate19.withEra(0);
//        int int24 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
//        int int25 = localDate19.getDayOfMonth();
//        org.joda.time.DateTime dateTime26 = localDate19.toDateTimeAtCurrentTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000000L + "'", long16 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField5.getAsShortText((long) (-6), locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.weekyearOfCentury();
//        org.joda.time.Chronology chronology26 = iSOChronology22.withUTC();
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendEraText();
//        boolean boolean33 = iSOChronology22.equals((java.lang.Object) dateTimeFormatterBuilder32);
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology22);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate34, 52, locale36);
//        org.joda.time.DurationField durationField38 = offsetDateTimeField5.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "121" + "'", str20.equals("121"));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "52" + "'", str37.equals("52"));
//        org.junit.Assert.assertNull(durationField38);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTime dateTime8 = localDate2.toDateTimeAtStartOfDay(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str2 = dateTimeZone1.getID();
//        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(11, '#', (int) (byte) 100, (int) (byte) 0, (-292275054), true, 365);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addCutover(0, 'a', (int) (short) -1, (int) (short) 1, 2084, false, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        long long8 = durationField5.subtract((-86400000L), (long) 24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-757468800000L) + "'", long8 == (-757468800000L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfWeek\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
//        int[] intArray3 = partial2.getValues();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str1.equals("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//        org.junit.Assert.assertNotNull(intArray3);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        boolean boolean8 = dateTime4.isEqual(1L);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str11 = dateTimeZone10.getID();
        int int13 = dateTimeZone10.getOffsetFromLocal((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillis(86400000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-01:00" + "'", str11.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-3600000) + "'", int13 == (-3600000));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) 'a', 292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfDay((int) (byte) 0);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 0, chronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight20 = dateTime17.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = iSOChronology21.years();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        int int28 = offsetDateTimeField26.get(100L);
        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
        boolean boolean32 = dateTime17.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatter34.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.append(dateTimePrinter35, dateTimeParser37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter40 = dateTimeFormatter39.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder41.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear((-6));
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatterBuilder48.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder33.append(dateTimePrinter40, dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimePrinter35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimePrinter40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime1.toMutableDateTime();
        java.lang.String str5 = dateTime1.toString("1969-12-31");
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31" + "'", str5.equals("1969-12-31"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        java.lang.Class<?> wildcardClass17 = dateTime15.getClass();
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime15.getZone();
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime3.withMillis((long) (short) 0);
        org.joda.time.DateTime dateTime24 = dateTime22.minus(1560638641245L);
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        boolean boolean8 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        java.lang.Class<?> wildcardClass24 = dateTime22.getClass();
        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime27 = dateTime17.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime30 = dateTime17.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime32 = dateTime17.plusMonths((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder33.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendFractionOfDay((int) 'a', 292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder40.appendHourOfDay((int) (byte) 0);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (short) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime48.toDateTime(dateTimeZone49);
        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
        org.joda.time.DateTime.Property property52 = dateTime50.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight53 = dateTime50.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField55 = iSOChronology54.years();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology54.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology54.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, (int) '4');
        int int61 = offsetDateTimeField59.get(100L);
        long long63 = offsetDateTimeField59.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField59.getType();
        boolean boolean65 = dateTime50.isSupported(dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder45.appendText(dateTimeFieldType64);
        org.joda.time.DateTime dateTime68 = dateTime17.withField(dateTimeFieldType64, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType64, 0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateMidnight53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 122 + "'", int61 == 122);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 31536000000L + "'", long63 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        long long9 = offsetDateTimeField5.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField5.getType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(1L, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText(0L, locale15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31536000000L + "'", long9 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "122" + "'", str13.equals("122"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "122" + "'", str16.equals("122"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime2.withMillisOfSecond((int) 'a');
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear((-1), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendWeekyear(48, 1);
        boolean boolean13 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology5);
        long long8 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate6, (long) 100);
        org.joda.time.DurationField durationField9 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-86399900L) + "'", long8 == (-86399900L));
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
//        long long16 = property15.remainder();
//        java.lang.String str17 = property15.getAsShortText();
//        org.joda.time.LocalDate localDate19 = property15.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = localDate19.isSupported(dateTimeFieldType20);
//        org.joda.time.LocalDate localDate23 = localDate19.withEra(0);
//        int int24 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.LocalDate.Property property25 = localDate19.dayOfMonth();
//        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology27, dateTimeField29, (int) (short) 100);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology27);
//        java.util.Date date33 = localDate32.toDate();
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight35 = localDate34.toDateMidnight();
//        java.lang.String str36 = localDate34.toString();
//        org.joda.time.DateTime dateTime37 = localDate34.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateMidnight dateMidnight39 = localDate34.toDateMidnight(dateTimeZone38);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField41 = iSOChronology40.years();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.monthOfYear();
//        int int43 = dateMidnight39.get(dateTimeField42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateMidnight39.getZone();
//        org.joda.time.DateTime dateTime45 = localDate32.toDateTimeAtCurrentTime(dateTimeZone44);
//        org.joda.time.Interval interval46 = localDate19.toInterval(dateTimeZone44);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000000L + "'", long16 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(copticChronology27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(dateMidnight35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019-06-15" + "'", str36.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateMidnight39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(interval46);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1970-02-01");
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField5.getLeapDurationField();
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
//        java.lang.String str20 = localDate18.toString();
//        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = localDate18.isSupported(dateTimeFieldType23);
//        int int25 = localDate18.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property26 = localDate18.yearOfCentury();
//        int[] intArray27 = new int[] {};
//        int int28 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate18, intArray27);
//        org.joda.time.DurationField durationField29 = offsetDateTimeField5.getRangeDurationField();
//        long long31 = offsetDateTimeField5.roundHalfCeiling(100L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-06-15" + "'", str20.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 151 + "'", int28 == 151);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) ' ');
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds(99);
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) (short) 10);
        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant11 = instant8.plus(1560642241245L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        int int10 = offsetDateTimeField5.getMaximumValue();
        long long12 = offsetDateTimeField5.remainder(259200006L);
        long long15 = offsetDateTimeField5.add((long) 50, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 151 + "'", int10 == 151);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200006L + "'", long12 == 259200006L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 50L + "'", long15 == 50L);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        long long18 = offsetDateTimeField5.roundHalfCeiling((long) 11);
//        int int19 = offsetDateTimeField5.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getName();
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission3.newPermissionCollection();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((-1));
        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) (-1));
        java.lang.String str11 = jodaTimePermission3.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
//        int int25 = offsetDateTimeField5.getMinimumValue((long) '#');
//        long long28 = offsetDateTimeField5.addWrapField(17020800000L, (int) '#');
//        int int29 = offsetDateTimeField5.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2034201600000L) + "'", long28 == (-2034201600000L));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        boolean boolean4 = dateTime2.isAfter(readableInstant3);
//        int int5 = dateTime2.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3, 6);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.dayOfWeek();
        try {
            long long11 = julianChronology0.getDateTimeMillis((int) 'a', 0, 48, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField5.getAsShortText(0L, locale9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "122" + "'", str10.equals("122"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusSeconds(10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        java.lang.String str6 = skipUndoDateTimeField4.getAsText((long) '#');
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyear();
//        org.joda.time.DurationField durationField15 = iSOChronology12.months();
//        long long18 = durationField15.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property20 = localDate19.yearOfCentury();
//        long long21 = property20.remainder();
//        java.lang.String str22 = property20.getAsShortText();
//        java.util.Locale locale23 = null;
//        int int24 = property20.getMaximumTextLength(locale23);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, durationField15, dateTimeFieldType25, 7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType25, 1);
//        long long31 = offsetDateTimeField29.roundHalfEven((long) (-6));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thursday" + "'", str6.equals("Thursday"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2682000000L) + "'", long18 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 14256000000L + "'", long21 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime2.withYear(19);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendFractionOfHour(68, 3);
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("19");
        int int2 = localDate1.getYear();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = localDate0.isSupported(dateTimeFieldType8);
//        org.joda.time.LocalDate localDate11 = localDate0.plusMonths(17);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology13);
//        int int15 = localDate14.getCenturyOfEra();
//        org.joda.time.LocalDate localDate17 = localDate14.minusDays(19);
//        boolean boolean18 = localDate11.isEqual((org.joda.time.ReadablePartial) localDate17);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 0, chronology20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime21.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 0, chronology27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
//        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
//        java.lang.Class<?> wildcardClass32 = dateTime30.getClass();
//        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.plus(readableDuration34);
//        org.joda.time.DateTime.Property property36 = dateTime30.year();
//        org.joda.time.DateTime dateTime37 = localDate11.toDateTime((org.joda.time.ReadableInstant) dateTime30);
//        int int38 = dateTime37.getYear();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2020 + "'", int38 == 2020);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology6);
//        int int8 = localDate7.getCenturyOfEra();
//        org.joda.time.LocalDate localDate10 = localDate7.minusDays(19);
//        int int11 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.LocalDate localDate13 = localDate10.withYearOfEra(20);
//        org.joda.time.LocalDate localDate15 = localDate13.withDayOfYear(122);
//        org.joda.time.LocalDate localDate17 = localDate15.plusYears((-32));
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
//        java.lang.String str20 = localDate18.toString();
//        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        org.joda.time.LocalDate localDate28 = localDate25.minusDays(19);
//        int int29 = localDate18.compareTo((org.joda.time.ReadablePartial) localDate28);
//        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology30, dateTimeField32, (int) (short) 100);
//        long long37 = skipUndoDateTimeField34.add((long) 24, (long) ' ');
//        int int40 = skipUndoDateTimeField34.getDifference((long) 4, (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField34.getType();
//        int int42 = localDate28.indexOf(dateTimeFieldType41);
//        try {
//            org.joda.time.LocalDate localDate44 = localDate17.withField(dateTimeFieldType41, 68);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-06-15" + "'", str20.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(copticChronology30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2764800024L + "'", long37 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long7 = cachedDateTimeZone5.previousTransition(0L);
        int int9 = cachedDateTimeZone5.getStandardOffset(2761200024L);
        long long11 = cachedDateTimeZone5.nextTransition(2764800024L);
        int int13 = cachedDateTimeZone5.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2764800024L + "'", long11 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-3600000) + "'", int13 == (-3600000));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        boolean boolean8 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder0.toFormatter();
        java.util.Locale locale10 = dateTimeFormatter9.getLocale();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withLocale(locale11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(locale10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField59.getAsText(70, locale61);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField64 = copticChronology63.centuries();
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField59, durationField64, dateTimeFieldType65);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "70" + "'", str62.equals("70"));
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(durationField64);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-1));
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter2.parseDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        java.util.Date date7 = localDate6.toDate();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.fromDateFields(date7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(122);
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtMidnight(dateTimeZone10);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = iSOChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 100L, (java.lang.Number) 2764800024L, (java.lang.Number) 0.0d);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
//        int int4 = localDate3.getDayOfMonth();
//        org.joda.time.LocalDate.Property property5 = localDate3.centuryOfEra();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        try {
//            long long12 = unsupportedDateTimeField9.set((long) 69, "weekyearOfCentury");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        int int5 = partial4.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 0, chronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        java.lang.Class<?> wildcardClass12 = dateTime10.getClass();
        boolean boolean14 = dateTime10.isEqual(1L);
        org.joda.time.DateTime dateTime16 = dateTime10.withDayOfYear(6);
        org.joda.time.DateTime dateTime18 = dateTime10.plus((long) (short) 10);
        boolean boolean19 = partial4.isMatch((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        int[] intArray4 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        int int9 = dateTimeZone6.getOffsetFromLocal((long) (short) 10);
        long long12 = dateTimeZone6.convertLocalToUTC(0L, false);
        org.joda.time.DateTime dateTime13 = localDate2.toDateTimeAtCurrentTime(dateTimeZone6);
        long long17 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (long) 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600000L + "'", long12 == 3600000L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3600001L + "'", long17 == 3600001L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateMidnight5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
//        int int25 = dateMidnight21.get(dateTimeField24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
//        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) long10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int30 = fixedDateTimeZone15.getOffset((-1L));
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str33 = dateTimeZone32.getID();
//        int int35 = dateTimeZone32.getOffsetFromLocal((long) (short) 10);
//        long long38 = dateTimeZone32.convertLocalToUTC(0L, false);
//        long long40 = fixedDateTimeZone15.getMillisKeepLocal(dateTimeZone32, (long) (-292275054));
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560556800001L + "'", long10 == 1560556800001L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-01:00" + "'", str33.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-3600000) + "'", int35 == (-3600000));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3600000L + "'", long38 == 3600000L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-288675055L) + "'", long40 == (-288675055L));
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField5.getAsShortText((long) (-6), locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.weekyearOfCentury();
//        org.joda.time.Chronology chronology26 = iSOChronology22.withUTC();
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendEraText();
//        boolean boolean33 = iSOChronology22.equals((java.lang.Object) dateTimeFormatterBuilder32);
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology22);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate34, 52, locale36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.LocalDate localDate60 = localDate34.withField(dateTimeFieldType56, 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "121" + "'", str20.equals("121"));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "52" + "'", str37.equals("52"));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(localDate60);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeek(7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendYearOfEra(2084, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendClockhourOfDay(6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
//        java.lang.String str3 = localDate1.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        java.lang.String str5 = localDate1.toString(dateTimeFormatter4);
//        try {
//            org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("2", dateTimeFormatter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-W24-6T��:��:��" + "'", str5.equals("2019-W24-6T��:��:��"));
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.LocalDate localDate9 = localDate5.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = localDate5.isSupported(dateTimeFieldType10);
//        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = localDate5.getFieldType((int) (byte) 1);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.year();
//        java.util.Locale locale9 = null;
//        int int10 = property8.getMaximumShortTextLength(locale9);
//        java.lang.String str11 = property8.toString();
//        try {
//            org.joda.time.LocalDate localDate13 = property8.setCopy("ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[year]" + "'", str11.equals("Property[year]"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        long long62 = dividedDateTimeField29.getDifferenceAsLong((long) 2440942, (long) 1);
//        int int64 = dividedDateTimeField29.get(31536000000L);
//        int int67 = dividedDateTimeField29.getDifference((-1L), 2764800001L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 8 + "'", int64 == 8);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 0, chronology2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        java.lang.Class<?> wildcardClass7 = dateTime5.getClass();
//        org.joda.time.Chronology chronology8 = dateTime5.getChronology();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded(readableDuration9, 69);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight18 = localDate17.toDateMidnight();
//        java.lang.String str19 = localDate17.toString();
//        org.joda.time.DateTime dateTime20 = localDate17.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateMidnight dateMidnight22 = localDate17.toDateMidnight(dateTimeZone21);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField24 = iSOChronology23.years();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.monthOfYear();
//        int int26 = dateMidnight22.get(dateTimeField25);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateMidnight22.getZone();
//        boolean boolean28 = fixedDateTimeZone16.equals((java.lang.Object) dateMidnight22);
//        int int30 = fixedDateTimeZone16.getOffset((long) 99);
//        org.joda.time.DateTime dateTime31 = dateTime5.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime5.toMutableDateTime();
//        int int35 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime32, "JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]", 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15" + "'", str19.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-3) + "'", int35 == (-3));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology5, dateTimeField8, 6);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) 'a', 99, (int) 'a', 24, 2084, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 15, "GJChronology[-01:00]");
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendTwoDigitYear((-6), false);
        jodaTimePermission1.checkGuard((java.lang.Object) (-6));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone9.getID();
        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) 151);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        long long20 = cachedDateTimeZone13.convertLocalToUTC(2764800001L, true, (long) 122);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 100L, (org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2768400001L + "'", long20 == 2768400001L);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        java.lang.String str5 = skipUndoDateTimeField4.getName();
//        int int8 = skipUndoDateTimeField4.getDifference(31536000000L, (-210865896000000L));
//        long long10 = skipUndoDateTimeField4.roundHalfFloor((long) 365);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
//        int int18 = offsetDateTimeField16.get(100L);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        java.lang.String str21 = localDate19.toString();
//        org.joda.time.LocalDate localDate23 = localDate19.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.LocalDate localDate25 = localDate23.minus(readablePeriod24);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate25, locale26);
//        boolean boolean28 = offsetDateTimeField16.isSupported();
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight30 = localDate29.toDateMidnight();
//        java.lang.String str31 = localDate29.toString();
//        org.joda.time.LocalDate localDate33 = localDate29.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate33.minus(readablePeriod34);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField37 = iSOChronology36.years();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) '4');
//        int int43 = offsetDateTimeField41.get(100L);
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight45 = localDate44.toDateMidnight();
//        java.lang.String str46 = localDate44.toString();
//        org.joda.time.LocalDate localDate48 = localDate44.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.LocalDate localDate50 = localDate48.minus(readablePeriod49);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = offsetDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) localDate50, locale51);
//        org.joda.time.DurationField durationField53 = offsetDateTimeField41.getLeapDurationField();
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight55 = localDate54.toDateMidnight();
//        java.lang.String str56 = localDate54.toString();
//        org.joda.time.LocalDate localDate58 = localDate54.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = null;
//        boolean boolean60 = localDate54.isSupported(dateTimeFieldType59);
//        int int61 = localDate54.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property62 = localDate54.yearOfCentury();
//        int[] intArray63 = new int[] {};
//        int int64 = offsetDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) localDate54, intArray63);
//        int int65 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate35, intArray63);
//        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField67 = copticChronology66.monthOfYear();
//        org.joda.time.Chronology chronology69 = null;
//        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology69);
//        int int71 = localDate70.getCenturyOfEra();
//        org.joda.time.LocalDate localDate73 = localDate70.minusDays(19);
//        int int74 = localDate70.getMonthOfYear();
//        int[] intArray76 = copticChronology66.get((org.joda.time.ReadablePartial) localDate70, 99L);
//        int int77 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate35, intArray76);
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime79 = localDate35.toDateTimeAtMidnight(dateTimeZone78);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2440942 + "'", int8 == 2440942);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 122 + "'", int18 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-06-15" + "'", str21.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "19" + "'", str27.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019-06-15" + "'", str31.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 122 + "'", int43 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019-06-15" + "'", str46.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "19" + "'", str52.equals("19"));
//        org.junit.Assert.assertNull(durationField53);
//        org.junit.Assert.assertNotNull(dateMidnight55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019-06-15" + "'", str56.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 24 + "'", int61 == 24);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 151 + "'", int64 == 151);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 52 + "'", int65 == 52);
//        org.junit.Assert.assertNotNull(copticChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 19 + "'", int71 == 19);
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(dateTime79);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1968 + "'", int2 == 1968);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.util.TimeZone timeZone18 = fixedDateTimeZone4.toTimeZone();
//        boolean boolean20 = fixedDateTimeZone4.isStandardOffset((-210858120000000L));
//        java.lang.String str22 = fixedDateTimeZone4.getNameKey((long) 50);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "15" + "'", str22.equals("15"));
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
//        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(readableDuration8, 69);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
//        int int25 = dateMidnight21.get(dateTimeField24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
//        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
//        int int29 = fixedDateTimeZone15.getOffset((long) 99);
//        org.joda.time.DateTime dateTime30 = dateTime4.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int31 = dateTime30.getDayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime33 = dateTime30.withHourOfDay(1959);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1959 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.toString();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj8 = null;
        jodaTimePermission7.checkGuard(obj8);
        boolean boolean10 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int8 = offsetDateTimeField5.getOffset();
//        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = localDate12.isSupported(dateTimeFieldType17);
//        org.joda.time.LocalDate.Property property19 = localDate12.year();
//        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate12, locale21);
//        int int24 = offsetDateTimeField5.getLeapAmount((long) (short) 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.plus((long) (short) -1);
        org.joda.time.DateTime dateTime20 = dateTime16.withDayOfYear(20);
        int int21 = dateTime16.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(100);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        long long62 = remainderDateTimeField59.roundHalfFloor((-86399900L));
//        boolean boolean63 = remainderDateTimeField59.isSupported();
//        org.joda.time.DurationField durationField64 = remainderDateTimeField59.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(durationField64);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(10);
        org.joda.time.DateTime dateTime12 = dateTime4.withTime(20, 50, 15, (int) ' ');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
        java.lang.String str12 = skipDateTimeField10.getAsShortText(1560638641245L);
        long long14 = skipDateTimeField10.roundFloor(32054400000L);
        long long17 = skipDateTimeField10.add(2764800001L, (-518399995L));
        int int18 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32054400000L + "'", long14 == 32054400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1866237217199999L) + "'", long17 == (-1866237217199999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3600052L, 1970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7092102440L + "'", long2 == 7092102440L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder0.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        try {
//            long long12 = unsupportedDateTimeField9.addWrapField(0L, 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
//        org.joda.time.LocalDate localDate7 = property1.addToCopy(69);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate7);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-210865896000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210865896000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        illegalFieldValueException2.prependMessage("CopticChronology[America/Los_Angeles]");
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        try {
//            long long12 = unsupportedDateTimeField9.addWrapField((long) 68, 48);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
//        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(readableDuration8, 69);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
//        int int25 = dateMidnight21.get(dateTimeField24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
//        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
//        int int29 = fixedDateTimeZone15.getOffset((long) 99);
//        org.joda.time.DateTime dateTime30 = dateTime4.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, (-69));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -69");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
//        java.lang.String str12 = skipUndoDateTimeField4.getAsShortText(3121220641245L);
//        java.util.Locale locale13 = null;
//        int int14 = skipUndoDateTimeField4.getMaximumTextLength(locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight16 = localDate15.toDateMidnight();
//        java.lang.String str17 = localDate15.toString();
//        org.joda.time.LocalDate localDate19 = localDate15.minusDays((int) '#');
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology21);
//        int int23 = localDate22.getCenturyOfEra();
//        org.joda.time.LocalDate localDate25 = localDate22.minusDays(19);
//        int int26 = localDate15.compareTo((org.joda.time.ReadablePartial) localDate25);
//        int int27 = localDate25.getWeekyear();
//        int int28 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate25);
//        long long30 = skipUndoDateTimeField4.roundHalfEven((long) 7);
//        java.lang.String str31 = skipUndoDateTimeField4.toString();
//        int int34 = skipUndoDateTimeField4.getDifference(2764800000L, 7092102440L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Tue" + "'", str12.equals("Tue"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-06-15" + "'", str17.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str31.equals("DateTimeField[dayOfWeek]"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-50) + "'", int34 == (-50));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
//        int int25 = offsetDateTimeField5.getMinimumValue((long) '#');
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight27 = localDate26.toDateMidnight();
//        java.lang.String str28 = localDate26.toString();
//        org.joda.time.LocalDate localDate30 = localDate26.minusDays((int) '#');
//        org.joda.time.LocalDate localDate32 = localDate30.plusWeeks(19);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019-06-15" + "'", str28.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "19" + "'", str34.equals("19"));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime11.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
        org.joda.time.Chronology chronology17 = buddhistChronology16.withUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = buddhistChronology16.withZone(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        org.joda.time.LocalDate.Property property7 = localDate2.era();
        java.lang.String str8 = property7.getAsShortText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AD" + "'", str8.equals("AD"));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        try {
//            long long12 = unsupportedDateTimeField9.roundHalfCeiling((long) 99);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight32 = localDate31.toDateMidnight();
//        java.lang.String str33 = localDate31.toString();
//        org.joda.time.LocalDate localDate35 = localDate31.minusDays((int) '#');
//        int[] intArray36 = localDate35.getValues();
//        org.joda.time.LocalDate.Property property37 = localDate35.weekOfWeekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) '4');
//        int int45 = offsetDateTimeField43.get(100L);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight47 = localDate46.toDateMidnight();
//        java.lang.String str48 = localDate46.toString();
//        org.joda.time.LocalDate localDate50 = localDate46.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.LocalDate localDate52 = localDate50.minus(readablePeriod51);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) localDate52, locale53);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField56 = iSOChronology55.years();
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology55.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, (int) '4');
//        int int62 = offsetDateTimeField60.get(100L);
//        long long64 = offsetDateTimeField60.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = offsetDateTimeField60.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, dateTimeFieldType65, 15);
//        boolean boolean68 = localDate35.isSupported(dateTimeFieldType65);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField30, dateTimeFieldType65);
//        long long72 = dividedDateTimeField69.add((long) 2440942, 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-06-15" + "'", str33.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 122 + "'", int45 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019-06-15" + "'", str48.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "19" + "'", str54.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 122 + "'", int62 == 122);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 31536000000L + "'", long64 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2440942L + "'", long72 == 2440942L);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str2 = dateTimeZone1.getID();
//        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
//        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
//        long long10 = dateTimeZone1.convertLocalToUTC(0L, false);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusMillis((int) (short) 100);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 0, chronology17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime18.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 0, chronology24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.toDateTime(dateTimeZone26);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        java.lang.Class<?> wildcardClass29 = dateTime27.getClass();
//        boolean boolean30 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime27.getZone();
//        org.joda.time.DateTime dateTime32 = dateTime15.withZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime15.withMillis((long) (short) 0);
//        java.lang.String str35 = dateTime15.toString();
//        boolean boolean36 = copticChronology11.equals((java.lang.Object) str35);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019-06-15T22:45:14.764-00:00:00.001" + "'", str35.equals("2019-06-15T22:45:14.764-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy("19691231", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19691231 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
//        boolean boolean8 = skipUndoDateTimeField4.isLeap((long) 15);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateMidnight dateMidnight16 = localDate9.toDateMidnight(dateTimeZone15);
//        org.joda.time.LocalDate.Property property17 = localDate9.dayOfWeek();
//        int int18 = localDate9.getCenturyOfEra();
//        org.joda.time.DurationFieldType durationFieldType19 = null;
//        boolean boolean20 = localDate9.isSupported(durationFieldType19);
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate9, 31, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getWeekOfWeekyear();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate.Property property11 = localDate8.dayOfWeek();
//        org.joda.time.LocalDate localDate12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight14 = localDate13.toDateMidnight();
//        java.lang.String str15 = localDate13.toString();
//        org.joda.time.LocalDate localDate17 = localDate13.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = localDate13.isSupported(dateTimeFieldType18);
//        int int20 = localDate12.compareTo((org.joda.time.ReadablePartial) localDate13);
//        boolean boolean21 = localDate0.isBefore((org.joda.time.ReadablePartial) localDate12);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-15" + "'", str15.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-32));
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate5 = property3.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate6 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate8 = property3.addWrapFieldToCopy(69);
//        int int9 = localDate8.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(4, (-3), 29, (int) ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
//        java.lang.String str13 = localDate11.toString();
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateMidnight dateMidnight16 = localDate11.toDateMidnight(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateMidnight dateMidnight18 = localDate11.toDateMidnight(dateTimeZone17);
//        org.joda.time.LocalDate.Property property19 = localDate11.dayOfMonth();
//        int int20 = property19.getMinimumValue();
//        org.joda.time.LocalDate localDate21 = property19.withMinimumValue();
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) (short) 100);
//        long long30 = skipUndoDateTimeField27.add((long) 24, (long) ' ');
//        int int33 = skipUndoDateTimeField27.getDifference((long) 4, (long) 'a');
//        java.lang.String str35 = skipUndoDateTimeField27.getAsShortText(3121220641245L);
//        java.util.Locale locale36 = null;
//        int int37 = skipUndoDateTimeField27.getMaximumTextLength(locale36);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight39 = localDate38.toDateMidnight();
//        java.lang.String str40 = localDate38.toString();
//        org.joda.time.LocalDate localDate42 = localDate38.minusDays((int) '#');
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology44);
//        int int46 = localDate45.getCenturyOfEra();
//        org.joda.time.LocalDate localDate48 = localDate45.minusDays(19);
//        int int49 = localDate38.compareTo((org.joda.time.ReadablePartial) localDate48);
//        int int50 = localDate48.getWeekyear();
//        int int51 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate48);
//        int[] intArray52 = localDate48.getValues();
//        try {
//            int[] intArray54 = unsupportedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDate21, (-6), intArray52, 292278993);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15" + "'", str13.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2764800024L + "'", long30 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Tue" + "'", str35.equals("Tue"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
//        org.junit.Assert.assertNotNull(dateMidnight39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019-06-15" + "'", str40.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        java.util.Locale locale11 = null;
//        try {
//            int int12 = unsupportedDateTimeField9.getMaximumShortTextLength(locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 151);
        int int9 = cachedDateTimeZone5.getOffset((long) 69);
        long long13 = cachedDateTimeZone5.convertLocalToUTC(10L, true, 0L);
        java.lang.String str15 = cachedDateTimeZone5.getNameKey((long) 122);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = localDate10.getFieldTypes();
        int[] intArray12 = new int[] {};
        try {
            org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldTypeArray11, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.era();
//        boolean boolean4 = gJChronology0.equals((java.lang.Object) dateTime2);
//        int int5 = gJChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) (short) 100);
//        long long12 = skipUndoDateTimeField10.roundHalfCeiling((long) (byte) 10);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property14 = localDate13.yearOfCentury();
//        long long15 = property14.remainder();
//        java.lang.String str16 = property14.getAsShortText();
//        org.joda.time.LocalDate localDate18 = property14.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        boolean boolean20 = localDate18.isSupported(dateTimeFieldType19);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology22);
//        int int24 = localDate23.getCenturyOfEra();
//        int[] intArray25 = localDate23.getValues();
//        int int26 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate18, intArray25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType27);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField28);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 14256000000L + "'", long15 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1969, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = iSOChronology1.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) 10, (-1));
        org.joda.time.Instant instant9 = instant4.withMillis((-210865896000000L));
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant4.minus(readableDuration10);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        boolean boolean32 = dividedDateTimeField29.isLeap(100L);
//        try {
//            long long35 = dividedDateTimeField29.add((-2034201600000L), (-1866237217199999L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -27993558257999985");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
//        java.lang.String str5 = localDate3.toString();
//        org.joda.time.LocalDate localDate7 = localDate3.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = localDate3.isSupported(dateTimeFieldType8);
//        int int10 = localDate3.getMonthOfYear();
//        org.joda.time.LocalDate localDate12 = localDate3.withWeekyear((int) (short) 1);
//        try {
//            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-15" + "'", str5.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        int int7 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
//        long long16 = property15.remainder();
//        java.lang.String str17 = property15.getAsShortText();
//        org.joda.time.LocalDate localDate19 = property15.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = localDate19.isSupported(dateTimeFieldType20);
//        org.joda.time.LocalDate localDate23 = localDate19.withEra(0);
//        int int24 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
//        try {
//            org.joda.time.LocalDate localDate26 = localDate19.withDayOfWeek((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000000L + "'", long16 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        try {
            org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
//        int int11 = offsetDateTimeField9.get(100L);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        int int28 = offsetDateTimeField26.get(100L);
//        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 15);
//        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.weekyear();
//        org.joda.time.DurationField durationField38 = iSOChronology35.months();
//        long long41 = durationField38.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField48 = iSOChronology47.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.weekyear();
//        org.joda.time.DurationField durationField50 = iSOChronology47.months();
//        long long53 = durationField50.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property55 = localDate54.yearOfCentury();
//        long long56 = property55.remainder();
//        java.lang.String str57 = property55.getAsShortText();
//        java.util.Locale locale58 = null;
//        int int59 = property55.getMaximumTextLength(locale58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property55.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(dateTimeField45, durationField50, dateTimeFieldType60, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, durationField38, dateTimeFieldType60);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType60, 3);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "hi!");
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = illegalFieldValueException67.getDateTimeFieldType();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "19" + "'", str20.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2682000000L) + "'", long41 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-2682000000L) + "'", long53 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 14256000000L + "'", long56 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19" + "'", str57.equals("19"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfWeek();
//        int int9 = localDate0.getCenturyOfEra();
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate0);
//        java.util.Locale locale12 = null;
//        try {
//            java.lang.String str13 = partial10.toString("T000000-0000", locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
        long long10 = dateTimeZone1.convertLocalToUTC(0L, false);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        java.lang.String str12 = copticChronology11.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CopticChronology[-01:00]" + "'", str12.equals("CopticChronology[-01:00]"));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        java.lang.String str11 = localDate10.toString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01" + "'", str11.equals("1970-01-01"));
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        org.joda.time.DurationField durationField10 = unsupportedDateTimeField9.getDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
//        int int18 = offsetDateTimeField16.get(100L);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        java.lang.String str21 = localDate19.toString();
//        org.joda.time.LocalDate localDate23 = localDate19.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.LocalDate localDate25 = localDate23.minus(readablePeriod24);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate25, locale26);
//        boolean boolean28 = offsetDateTimeField16.isSupported();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField16.getAsShortText((long) (-6), locale30);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField34 = iSOChronology33.years();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.weekyearOfCentury();
//        org.joda.time.Chronology chronology37 = iSOChronology33.withUTC();
//        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder39.appendEraText();
//        boolean boolean44 = iSOChronology33.equals((java.lang.Object) dateTimeFormatterBuilder43);
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology33);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate45, 52, locale47);
//        org.joda.time.LocalDate localDate50 = localDate45.minusYears(20);
//        java.util.Locale locale52 = null;
//        try {
//            java.lang.String str53 = unsupportedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate45, 1686, locale52);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 122 + "'", int18 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-06-15" + "'", str21.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "19" + "'", str27.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "121" + "'", str31.equals("121"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "52" + "'", str48.equals("52"));
//        org.junit.Assert.assertNotNull(localDate50);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.DurationField durationField4 = iSOChronology1.months();
        long long7 = durationField4.subtract((long) (-3600000), (int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = iSOChronology8.years();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.weekyearOfCentury();
        org.joda.time.Chronology chronology12 = iSOChronology8.withUTC();
        org.joda.time.DurationField durationField13 = iSOChronology8.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2682000000L) + "'", long7 == (-2682000000L));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int8 = offsetDateTimeField5.getOffset();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.LocalDate localDate13 = localDate9.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        boolean boolean15 = localDate9.isSupported(dateTimeFieldType14);
//        int int16 = localDate9.getWeekOfWeekyear();
//        int int17 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology19, dateTimeField21, (int) (short) 100);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology19);
//        java.util.Date date25 = localDate24.toDate();
//        org.joda.time.DateTime dateTime26 = localDate24.toDateTimeAtStartOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField28 = iSOChronology27.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.monthOfYear();
//        org.joda.time.DurationField durationField30 = iSOChronology27.months();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight32 = localDate31.toDateMidnight();
//        java.lang.String str33 = localDate31.toString();
//        org.joda.time.LocalDate localDate35 = localDate31.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        boolean boolean37 = localDate35.isSupported(dateTimeFieldType36);
//        long long39 = iSOChronology27.set((org.joda.time.ReadablePartial) localDate35, 0L);
//        org.joda.time.LocalDate localDate41 = localDate35.withYear(3);
//        boolean boolean42 = localDate24.isEqual((org.joda.time.ReadablePartial) localDate35);
//        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate35);
//        int int44 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate35);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 151 + "'", int17 == 151);
//        org.junit.Assert.assertNotNull(copticChronology19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-06-15" + "'", str33.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1557532800000L + "'", long39 == 1557532800000L);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 151 + "'", int44 == 151);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 17);
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear(0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(151);
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekyear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        java.lang.String str9 = property7.getAsString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeek(7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = iSOChronology9.years();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
//        int int16 = offsetDateTimeField14.get(100L);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight18 = localDate17.toDateMidnight();
//        java.lang.String str19 = localDate17.toString();
//        org.joda.time.LocalDate localDate21 = localDate17.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.LocalDate localDate23 = localDate21.minus(readablePeriod22);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate23, locale24);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField27 = iSOChronology26.years();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) '4');
//        int int33 = offsetDateTimeField31.get(100L);
//        long long35 = offsetDateTimeField31.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField31.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType36, 15);
//        org.joda.time.DurationField durationField39 = dividedDateTimeField38.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField41 = iSOChronology40.years();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.weekyear();
//        org.joda.time.DurationField durationField43 = iSOChronology40.months();
//        long long46 = durationField43.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField49 = iSOChronology48.years();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology47, dateTimeField50);
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField53 = iSOChronology52.years();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.weekyear();
//        org.joda.time.DurationField durationField55 = iSOChronology52.months();
//        long long58 = durationField55.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property60 = localDate59.yearOfCentury();
//        long long61 = property60.remainder();
//        java.lang.String str62 = property60.getAsShortText();
//        java.util.Locale locale63 = null;
//        int int64 = property60.getMaximumTextLength(locale63);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property60.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(dateTimeField50, durationField55, dateTimeFieldType65, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38, durationField43, dateTimeFieldType65);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType65, (java.lang.Number) (-86399900L), (java.lang.Number) 68, (java.lang.Number) 0.0d);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType65, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 122 + "'", int16 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15" + "'", str19.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 122 + "'", int33 == 122);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31536000000L + "'", long35 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2682000000L) + "'", long46 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2682000000L) + "'", long58 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 14256000000L + "'", long61 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "19" + "'", str62.equals("19"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear((-1), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfMinute(24, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter21.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendTwoDigitWeekyear((-6));
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatterBuilder30.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendTwoDigitWeekyear((-6));
        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatterBuilder41.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray45 = new org.joda.time.format.DateTimeParser[] { dateTimeParser33, dateTimeParser44 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder20.append(dateTimePrinter22, dateTimeParserArray45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder12.append(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeParser44);
        org.junit.Assert.assertNotNull(dateTimeParserArray45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        int int8 = skipUndoDateTimeField4.getDifference(31536000000L, (-210865896000000L));
        long long10 = skipUndoDateTimeField4.roundHalfFloor((long) 365);
        long long12 = skipUndoDateTimeField4.remainder((long) 1968);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2440942 + "'", int8 == 2440942);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1968L + "'", long12 == 1968L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = localDate0.isSupported(durationFieldType1);
        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtStartOfDay();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        java.lang.String str10 = skipUndoDateTimeField4.getAsShortText((long) 1959);
        int int11 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thu" + "'", str10.equals("Thu"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateMidnight5.getZone();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
//        java.lang.String str13 = gJChronology12.toString();
//        org.joda.time.Instant instant14 = gJChronology12.getGregorianCutover();
//        org.joda.time.DurationField durationField15 = gJChronology12.minutes();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str13.equals("GJChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((-6));
        org.joda.time.DateTime.Property property10 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(2000);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        try {
//            int int12 = unsupportedDateTimeField9.getMaximumValue(readablePartial11);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        long long32 = dividedDateTimeField29.roundFloor(0L);
//        int int33 = dividedDateTimeField29.getMinimumValue();
//        org.joda.time.DurationField durationField34 = dividedDateTimeField29.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-63158400000L) + "'", long32 == (-63158400000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNotNull(durationField34);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.LocalDate localDate5 = property3.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate6 = property3.roundCeilingCopy();
//        int int7 = property3.getMaximumValueOverall();
//        int int8 = property3.getLeapAmount();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str9 = dateTimeZone8.getID();
        int int11 = dateTimeZone8.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str14 = cachedDateTimeZone12.getNameKey((long) 151);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 0, chronology16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        java.lang.Class<?> wildcardClass21 = dateTime19.getClass();
        org.joda.time.Chronology chronology22 = dateTime19.getChronology();
        boolean boolean23 = cachedDateTimeZone12.equals((java.lang.Object) chronology22);
        int int25 = cachedDateTimeZone12.getStandardOffset((long) 15);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime33 = dateTime28.toDateTime(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusMillis(50);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12, (org.joda.time.ReadableInstant) dateTime33);
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(0, (-69), 5, 0, (int) (byte) 1, 6, (int) '4', (org.joda.time.Chronology) gJChronology36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-01:00" + "'", str9.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3600000) + "'", int11 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-3600000) + "'", int25 == (-3600000));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(gJChronology36);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        boolean boolean8 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendMinuteOfDay(122);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        int int33 = dividedDateTimeField29.getDifference((long) 10, 0L);
//        int int34 = dividedDateTimeField29.getDivisor();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear(0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(151);
        org.joda.time.ReadableInstant readableInstant13 = null;
        boolean boolean14 = dateTime10.isAfter(readableInstant13);
        org.joda.time.DateTime dateTime16 = dateTime10.withDayOfYear(50);
        org.joda.time.DateTime dateTime18 = dateTime10.withYear(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime20.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 0, chronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.toDateTime(dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        java.lang.Class<?> wildcardClass31 = dateTime29.getClass();
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime34 = dateTime24.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime37 = dateTime24.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime39 = dateTime24.plusMonths((int) (short) 100);
        int int40 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property41 = dateTime24.dayOfMonth();
        org.joda.time.DateTime dateTime42 = property41.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime44 = dateTime42.withYearOfCentury(10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-69) + "'", int40 == (-69));
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
        org.joda.time.DateTime dateTime5 = dateTime2.toDateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate8 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField59.getAsText(70, locale61);
//        long long64 = remainderDateTimeField59.roundHalfCeiling((long) 20);
//        long long66 = remainderDateTimeField59.remainder(3600001L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "70" + "'", str62.equals("70"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 3600001L + "'", long66 == 3600001L);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        long long62 = remainderDateTimeField59.roundHalfFloor((-86399900L));
//        long long65 = remainderDateTimeField59.addWrapField((long) 86399, 2000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 157766486399L + "'", long65 == 157766486399L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateMidnight5.getZone();
//        int int11 = dateMidnight5.getYear();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, chronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime10.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 0, chronology16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        java.lang.Class<?> wildcardClass21 = dateTime19.getClass();
        boolean boolean22 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime24 = dateTime14.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime.Property property25 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime27 = property25.setCopy("19691231");
        org.joda.time.DateTime dateTime28 = property25.withMinimumValue();
        try {
            org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime18 = dateTime11.minusMillis(5);
        org.joda.time.DateTime.Property property19 = dateTime18.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology3.years();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = gregorianChronology0.equals(obj12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
//        org.joda.time.LocalDate localDate18 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate19 = property17.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate20 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate22 = property17.addWrapFieldToCopy(69);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        int[] intArray27 = localDate25.getValues();
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate22, intArray27);
//        org.joda.time.LocalDate localDate30 = localDate22.minusMonths(99);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight32 = localDate31.toDateMidnight();
//        java.lang.String str33 = localDate31.toString();
//        org.joda.time.DateTime dateTime34 = localDate31.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateMidnight dateMidnight36 = localDate31.toDateMidnight(dateTimeZone35);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField38 = iSOChronology37.years();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.monthOfYear();
//        int int40 = dateMidnight36.get(dateTimeField39);
//        org.joda.time.DateTimeZone dateTimeZone41 = dateMidnight36.getZone();
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
//        org.joda.time.DateTime dateTime44 = localDate30.toDateTimeAtCurrentTime(dateTimeZone41);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-06-15" + "'", str33.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateMidnight36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
//        java.util.Locale locale24 = null;
//        int int25 = offsetDateTimeField5.getMaximumShortTextLength(locale24);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.LocalDate.Property property2 = localDate0.dayOfMonth();
        org.joda.time.Interval interval3 = localDate0.toInterval();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval3);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(interval3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "19691231" + "'", str7.equals("19691231"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 87);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField5.getAsShortText(14256000000L, locale11);
        long long15 = offsetDateTimeField5.add((long) (-3600000), (int) (short) 1);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField5.getMaximumTextLength(locale16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText(0, locale19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "122" + "'", str12.equals("122"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32050800000L + "'", long15 == 32050800000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(11, '#', (int) (byte) 100, (int) (byte) 0, (-292275054), true, 365);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("2019-06-15", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = localDate10.getFieldTypes();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        int int19 = offsetDateTimeField17.get(100L);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property21 = localDate20.yearOfCentury();
//        org.joda.time.LocalDate localDate23 = localDate20.minusYears((int) (short) 10);
//        org.joda.time.DateMidnight dateMidnight24 = localDate23.toDateMidnight();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight26 = localDate25.toDateMidnight();
//        java.lang.String str27 = localDate25.toString();
//        org.joda.time.LocalDate localDate29 = localDate25.minusDays((int) '#');
//        int[] intArray30 = localDate29.getValues();
//        int int31 = offsetDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate23, intArray30);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField33 = iSOChronology32.years();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.weekyearOfCentury();
//        org.joda.time.Chronology chronology36 = iSOChronology32.withUTC();
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology32);
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray11, intArray30, chronology37);
//        int int39 = partial38.size();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 122 + "'", int19 == 122);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019-06-15" + "'", str27.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 151 + "'", int31 == 151);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        java.lang.Class<?> wildcardClass17 = dateTime15.getClass();
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime15.getZone();
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print(3600052L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W014T010000.051-0000" + "'", str2.equals("1970W014T010000.051-0000"));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withMonthOfYear((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate5 = localDate0.minusDays(17);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone9.getID();
        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime4.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusYears(68);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (-1866237217199999L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        illegalFieldValueException2.prependMessage("Property[year]");
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology3.years();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = gregorianChronology0.equals(obj12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
//        org.joda.time.LocalDate localDate18 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate19 = property17.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate20 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate22 = property17.addWrapFieldToCopy(69);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        int[] intArray27 = localDate25.getValues();
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate22, intArray27);
//        org.joda.time.LocalDate localDate30 = localDate22.minusMonths(99);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str33 = dateTimeZone32.getID();
//        int int35 = dateTimeZone32.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) 151);
//        org.joda.time.DateTimeZone dateTimeZone39 = cachedDateTimeZone36.getUncachedZone();
//        org.joda.time.DateTime dateTime40 = localDate30.toDateTimeAtMidnight(dateTimeZone39);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-01:00" + "'", str33.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-3600000) + "'", int35 == (-3600000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.year();
//        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 0, chronology21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
//        java.lang.Class<?> wildcardClass26 = dateTime24.getClass();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight33 = localDate32.toDateMidnight();
//        java.lang.String str34 = localDate32.toString();
//        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateMidnight dateMidnight37 = localDate32.toDateMidnight(dateTimeZone36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.monthOfYear();
//        int int41 = dateMidnight37.get(dateTimeField40);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateMidnight37.getZone();
//        boolean boolean43 = fixedDateTimeZone31.equals((java.lang.Object) dateMidnight37);
//        java.lang.String str45 = fixedDateTimeZone31.getNameKey(0L);
//        org.joda.time.DateTime dateTime46 = dateTime24.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTime dateTime47 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019-06-15" + "'", str34.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "15" + "'", str45.equals("15"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology49);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str10 = dateTimeZone9.getID();
//        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
//        long long15 = dateTimeZone9.convertLocalToUTC(0L, false);
//        java.lang.String str16 = dateTimeZone9.toString();
//        long long18 = dateTimeZone9.convertUTCToLocal(2764800024L);
//        boolean boolean19 = dateMidnight7.equals((java.lang.Object) 2764800024L);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600000L + "'", long15 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-01:00" + "'", str16.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2761200024L + "'", long18 == 2761200024L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate5 = property3.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate6 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate8 = property3.addWrapFieldToCopy(69);
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText(1560638641245L);
//        boolean boolean13 = skipDateTimeField10.isSupported();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField17 = iSOChronology16.years();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '4');
//        int int23 = offsetDateTimeField21.get(100L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight25 = localDate24.toDateMidnight();
//        java.lang.String str26 = localDate24.toString();
//        org.joda.time.LocalDate localDate28 = localDate24.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.LocalDate localDate30 = localDate28.minus(readablePeriod29);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate30, locale31);
//        org.joda.time.DurationField durationField33 = offsetDateTimeField21.getLeapDurationField();
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight35 = localDate34.toDateMidnight();
//        java.lang.String str36 = localDate34.toString();
//        org.joda.time.LocalDate localDate38 = localDate34.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = localDate34.isSupported(dateTimeFieldType39);
//        int int41 = localDate34.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property42 = localDate34.yearOfCentury();
//        int[] intArray43 = new int[] {};
//        int int44 = offsetDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate34, intArray43);
//        try {
//            int[] intArray46 = skipDateTimeField10.set(readablePartial14, 2020, intArray43, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 122 + "'", int23 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019-06-15" + "'", str26.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "19" + "'", str32.equals("19"));
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertNotNull(dateMidnight35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019-06-15" + "'", str36.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 151 + "'", int44 == 151);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate5 = property3.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate6 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate8 = property3.addWrapFieldToCopy(69);
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property1.getAsText(locale7);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfWeek();
//        int int9 = localDate0.getCenturyOfEra();
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        try {
//            org.joda.time.Partial.Property property12 = partial10.property(dateTimeFieldType11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property7.getAsShortText(locale9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        java.util.Date date8 = dateTime6.toDate();
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withEra(12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateMidnight dateMidnight8 = dateTime2.toDateMidnight();
        org.joda.time.DateMidnight dateMidnight9 = dateTime2.toDateMidnight();
        int int10 = dateMidnight9.getMinuteOfHour();
        long long11 = dateMidnight9.getMillis();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
//        int int11 = offsetDateTimeField9.get(100L);
//        int int12 = offsetDateTimeField9.getOffset();
//        long long15 = offsetDateTimeField9.add((long) (byte) 0, (long) 1);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.LocalDate localDate20 = localDate16.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        boolean boolean22 = localDate16.isSupported(dateTimeFieldType21);
//        org.joda.time.LocalDate.Property property23 = localDate16.year();
//        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate16);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate16, locale25);
//        boolean boolean28 = offsetDateTimeField9.isLeap((long) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32054400000L + "'", long15 == 32054400000L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "19" + "'", str26.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        try {
//            long long12 = unsupportedDateTimeField9.remainder(24L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        boolean boolean10 = unsupportedDateTimeField9.isLenient();
//        try {
//            int int12 = unsupportedDateTimeField9.getMaximumValue(3600010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.LocalDate.Property property17 = localDate14.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(82200);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateMidnight dateMidnight8 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime2.minusDays((-69));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
//        org.joda.time.DurationField durationField3 = iSOChronology0.months();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
//        java.lang.String str6 = localDate4.toString();
//        org.joda.time.LocalDate localDate8 = localDate4.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        boolean boolean10 = localDate8.isSupported(dateTimeFieldType9);
//        long long12 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, 0L);
//        int int13 = localDate8.getYearOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1557532800000L + "'", long12 == 1557532800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        org.joda.time.LocalDate localDate10 = property8.withMinimumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.weekyearOfCentury();
//        boolean boolean15 = property8.equals((java.lang.Object) iSOChronology11);
//        org.joda.time.DurationField durationField16 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = iSOChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap16 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendTimeZoneShortName(strMap16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(strMap16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.util.Locale locale5 = null;
        int int6 = skipUndoDateTimeField4.getMaximumTextLength(locale5);
        java.lang.String str8 = skipUndoDateTimeField4.getAsText((-2682000000L));
        boolean boolean10 = skipUndoDateTimeField4.isLeap((-2034201600000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Sunday" + "'", str8.equals("Sunday"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology17.getZone();
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) ' ');
//        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight7 = localDate6.toDateMidnight();
//        java.lang.String str8 = localDate6.toString();
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = localDate6.isSupported(dateTimeFieldType11);
//        int int13 = localDate6.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property14 = localDate6.yearOfCentury();
//        int int15 = property5.compareTo((org.joda.time.ReadablePartial) localDate6);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.years();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) '4');
        int int13 = offsetDateTimeField11.get(100L);
        int int14 = offsetDateTimeField11.getOffset();
        long long17 = offsetDateTimeField11.add((long) (byte) 0, (long) 1);
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField11.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField11, (int) '4');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 122 + "'", int13 == 122);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32054400000L + "'", long17 == 32054400000L);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField5.getAsShortText((long) (-6), locale19);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField5.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "121" + "'", str20.equals("121"));
//        org.junit.Assert.assertNull(durationField21);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
//        long long9 = property8.remainder();
//        java.lang.String str10 = property8.getAsShortText();
//        org.joda.time.LocalDate localDate12 = property8.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology16);
//        int int18 = localDate17.getCenturyOfEra();
//        int[] intArray19 = localDate17.getValues();
//        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate12, intArray19);
//        org.joda.time.LocalDate.Property property21 = localDate12.centuryOfEra();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 14256000000L + "'", long9 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.years();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '4');
        int int12 = offsetDateTimeField10.get(100L);
        long long14 = offsetDateTimeField10.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField10.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType15, (int) (byte) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 122 + "'", int12 == 122);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31536000000L + "'", long14 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 99);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfEra(52);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-32));
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = localDate0.isSupported(dateTimeFieldType8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = localDate0.isSupported(dateTimeFieldType10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate13 = localDate0.plus(readablePeriod12);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(localDate13);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        int int6 = skipUndoDateTimeField4.getMaximumValue();
        long long8 = skipUndoDateTimeField4.roundCeiling(86400000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.util.Locale locale3 = null;
//        int int4 = property1.getMaximumTextLength(locale3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 0, chronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((int) (short) 10);
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfMonth();
//        java.util.Date date13 = dateTime11.toDate();
//        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.fromDateFields(date13);
//        int int15 = property1.compareTo((org.joda.time.ReadablePartial) localDate14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = localDate14.toString("[]", locale17);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[]" + "'", str18.equals("[]"));
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfWeek();
//        int int9 = localDate0.getCenturyOfEra();
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = partial10.getFieldTypes();
//        try {
//            int int13 = partial10.getValue(1686);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1686");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField59.getAsText(70, locale61);
//        int int64 = remainderDateTimeField59.get(99L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "70" + "'", str62.equals("70"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology3.years();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = gregorianChronology0.equals(obj12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
//        org.joda.time.LocalDate localDate18 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate19 = property17.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate20 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate22 = property17.addWrapFieldToCopy(69);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        int[] intArray27 = localDate25.getValues();
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate22, intArray27);
//        org.joda.time.LocalDate localDate30 = localDate22.minusMonths(99);
//        java.lang.String str31 = localDate30.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2011-03-14" + "'", str31.equals("2011-03-14"));
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
//        int int11 = offsetDateTimeField9.get(100L);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        int int28 = offsetDateTimeField26.get(100L);
//        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 15);
//        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.weekyear();
//        org.joda.time.DurationField durationField38 = iSOChronology35.months();
//        long long41 = durationField38.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField48 = iSOChronology47.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.weekyear();
//        org.joda.time.DurationField durationField50 = iSOChronology47.months();
//        long long53 = durationField50.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property55 = localDate54.yearOfCentury();
//        long long56 = property55.remainder();
//        java.lang.String str57 = property55.getAsShortText();
//        java.util.Locale locale58 = null;
//        int int59 = property55.getMaximumTextLength(locale58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property55.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(dateTimeField45, durationField50, dateTimeFieldType60, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, durationField38, dateTimeFieldType60);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType60, 3);
//        long long67 = remainderDateTimeField65.roundHalfFloor(32050800000L);
//        int int68 = remainderDateTimeField65.getDivisor();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "19" + "'", str20.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2682000000L) + "'", long41 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-2682000000L) + "'", long53 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 14256000000L + "'", long56 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19" + "'", str57.equals("19"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 32050800000L + "'", long67 == 32050800000L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("Mon");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField5.getLeapDurationField();
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
//        java.lang.String str20 = localDate18.toString();
//        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = localDate18.isSupported(dateTimeFieldType23);
//        int int25 = localDate18.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property26 = localDate18.yearOfCentury();
//        int[] intArray27 = new int[] {};
//        int int28 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate18, intArray27);
//        boolean boolean30 = offsetDateTimeField5.isLeap((long) 'a');
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property32 = localDate31.yearOfCentury();
//        long long33 = property32.remainder();
//        java.lang.String str34 = property32.getAsShortText();
//        org.joda.time.LocalDate localDate36 = property32.addWrapFieldToCopy(365);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) '4');
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight45 = localDate44.toDateMidnight();
//        java.lang.String str46 = localDate44.toString();
//        org.joda.time.LocalDate localDate48 = localDate44.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        boolean boolean50 = localDate44.isSupported(dateTimeFieldType49);
//        int int51 = localDate44.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property52 = localDate44.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.LocalDate localDate54 = localDate44.minus(readablePeriod53);
//        org.joda.time.Chronology chronology56 = null;
//        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology56);
//        int int58 = localDate57.getCenturyOfEra();
//        int[] intArray59 = localDate57.getValues();
//        int int60 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate44, intArray59);
//        int[] intArray62 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate36, (int) (byte) 0, intArray59, 0);
//        long long64 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-06-15" + "'", str20.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 151 + "'", int28 == 151);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 14256000000L + "'", long33 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "19" + "'", str34.equals("19"));
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateMidnight45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019-06-15" + "'", str46.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 19 + "'", int58 == 19);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((-86400000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendLiteral("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]");
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560638724414L + "'", long1 == 1560638724414L);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        int int18 = fixedDateTimeZone4.getOffset((long) 99);
//        int int20 = fixedDateTimeZone4.getOffset((long) 70);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getLeapDurationField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField4.getAsText((long) 6, locale9);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField4, 68, 12, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68 for dayOfWeek must be in the range [12,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thursday" + "'", str10.equals("Thursday"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) ' ');
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds(99);
        org.joda.time.DateTime.Property property7 = dateTime4.minuteOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.plusMillis(5);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendEraText();
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeFormatterBuilder10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendFractionOfSecond((int) '4', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTimeZoneOffset("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]", true, 20, 151);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.appendFractionOfSecond(7, 52);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-50));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
//        java.lang.String str13 = localDate11.toString();
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateMidnight dateMidnight16 = localDate11.toDateMidnight(dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.monthOfYear();
//        int int20 = dateMidnight16.get(dateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateMidnight16.getZone();
//        boolean boolean22 = fixedDateTimeZone10.equals((java.lang.Object) dateMidnight16);
//        java.lang.String str23 = fixedDateTimeZone10.getID();
//        org.joda.time.DateTime dateTime24 = dateTime4.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        long long27 = fixedDateTimeZone10.convertLocalToUTC(2761200024L, false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15" + "'", str13.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str23.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2761200025L + "'", long27 == 2761200025L);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) 'a', 292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField4, (int) (short) 100);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology2);
//        java.util.Date date8 = localDate7.toDate();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.monthOfYear();
//        int int18 = dateMidnight14.get(dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateMidnight14.getZone();
//        org.joda.time.DateTime dateTime20 = localDate7.toDateTimeAtCurrentTime(dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter0.withZone(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.monthOfYear();
//        int int18 = dateMidnight14.get(dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateMidnight14.getZone();
//        boolean boolean20 = fixedDateTimeZone8.equals((java.lang.Object) dateMidnight14);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
//        java.lang.String str23 = zonedChronology21.toString();
//        java.lang.String str24 = zonedChronology21.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str23.equals("ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]" + "'", str24.equals("ZonedChronology[ISOChronology[UTC], (\"org.joda.time.JodaTimePermission\" \"hi!\")]"));
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        java.util.Locale locale4 = null;
//        int int5 = property1.getMaximumTextLength(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property1.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
//        java.util.Locale locale10 = null;
//        try {
//            int int11 = unsupportedDateTimeField9.getMaximumTextLength(locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        org.joda.time.LocalDate localDate10 = property8.withMinimumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.weekyearOfCentury();
//        boolean boolean15 = property8.equals((java.lang.Object) iSOChronology11);
//        org.joda.time.DurationField durationField16 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology11.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        long long62 = remainderDateTimeField59.roundHalfFloor((-86399900L));
//        boolean boolean63 = remainderDateTimeField59.isSupported();
//        long long66 = remainderDateTimeField59.set((long) 1686, (int) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-31535998314L) + "'", long66 == (-31535998314L));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "19", "T������");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "2019198T000000-0000", "2019-07-17");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 99);
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        java.lang.String str3 = dateTimeZone2.getID();
//        int int5 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) 151);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 0, chronology10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
//        java.lang.Class<?> wildcardClass15 = dateTime13.getClass();
//        org.joda.time.Chronology chronology16 = dateTime13.getChronology();
//        boolean boolean17 = cachedDateTimeZone6.equals((java.lang.Object) chronology16);
//        long long19 = cachedDateTimeZone6.nextTransition((long) (short) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder20.appendFractionOfMinute(3, (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendFractionOfDay((int) 'a', 292278993);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder27.appendHourOfDay((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder27.appendHalfdayOfDayText();
//        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology34, dateTimeField36, (int) (short) 100);
//        long long41 = skipUndoDateTimeField38.add((long) 24, (long) ' ');
//        int int44 = skipUndoDateTimeField38.getDifference((long) 4, (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipUndoDateTimeField38.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder27.appendFraction(dateTimeFieldType45, (int) 'a', 50);
//        boolean boolean49 = cachedDateTimeZone6.equals((java.lang.Object) dateTimeFieldType45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType45, 0, 1686);
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight54 = localDate53.toDateMidnight();
//        java.lang.String str55 = localDate53.toString();
//        org.joda.time.DateTime dateTime56 = localDate53.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateMidnight dateMidnight58 = localDate53.toDateMidnight(dateTimeZone57);
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateMidnight dateMidnight60 = localDate53.toDateMidnight(dateTimeZone59);
//        org.joda.time.LocalDate.Property property61 = localDate53.dayOfMonth();
//        int int62 = property61.getMinimumValue();
//        org.joda.time.LocalDate localDate63 = property61.withMinimumValue();
//        org.joda.time.LocalDate.Property property64 = localDate63.monthOfYear();
//        org.joda.time.DurationField durationField65 = property64.getDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField67 = iSOChronology66.years();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.weekyear();
//        org.joda.time.DurationField durationField69 = iSOChronology66.months();
//        long long72 = durationField69.subtract((long) (-3600000), (int) (short) 1);
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField73 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType45, durationField65, durationField69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:00" + "'", str3.equals("-01:00"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-3600000) + "'", int5 == (-3600000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(copticChronology34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2764800024L + "'", long41 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateMidnight54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019-06-15" + "'", str55.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateMidnight58);
//        org.junit.Assert.assertNotNull(dateMidnight60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-2682000000L) + "'", long72 == (-2682000000L));
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getWeekOfWeekyear();
//        try {
//            org.joda.time.LocalDate localDate9 = localDate0.withMonthOfYear((-3600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3600000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
        org.joda.time.Instant instant6 = instant4.minus((-86399999L));
        org.joda.time.Chronology chronology7 = instant4.getChronology();
        org.joda.time.Instant instant8 = instant4.toInstant();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear((-1), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfMinute(24, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendDayOfYear(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("24", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"24\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.DurationField durationField4 = zonedChronology3.days();
        java.lang.String str5 = zonedChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -01:00]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], -01:00]"));
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.monthOfYear();
//        int int18 = dateMidnight14.get(dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateMidnight14.getZone();
//        boolean boolean20 = fixedDateTimeZone8.equals((java.lang.Object) dateMidnight14);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField28 = iSOChronology27.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        boolean boolean33 = dateTimeZone31.isStandardOffset((long) '#');
//        org.joda.time.Chronology chronology34 = iSOChronology27.withZone(dateTimeZone31);
//        org.joda.time.Chronology chronology35 = gregorianChronology24.withZone(dateTimeZone31);
//        long long39 = dateTimeZone31.convertLocalToUTC(1560638641245L, true, 11L);
//        org.joda.time.Chronology chronology40 = gJChronology23.withZone(dateTimeZone31);
//        org.joda.time.Chronology chronology41 = zonedChronology21.withZone(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560642241245L + "'", long39 == 1560642241245L);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(chronology41);
//    }
//}

