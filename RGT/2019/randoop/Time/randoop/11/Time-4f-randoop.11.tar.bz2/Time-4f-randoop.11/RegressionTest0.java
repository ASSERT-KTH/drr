import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        try {
            org.joda.time.LocalDate localDate4 = localDate2.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', (int) '4', (-1), (int) 'a', (int) '4', dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-15' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Positive hours must not have negative minutes: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        int int6 = dateMidnight5.getEra();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.withMinuteOfHour(0);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withDate((int) (short) 100, (int) (byte) 100, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        try {
            org.joda.time.LocalDate localDate4 = localDate2.withDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.Partial partial3 = new org.joda.time.Partial(dateTimeFieldType0, (int) (short) -1, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000233d + "'", double1 == 2440587.5000000233d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("2019-06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15\" is malformed at \"-06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19, (int) (short) 1, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) localDate3, (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        try {
            org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        boolean boolean4 = dateTime2.isBefore(35L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        try {
//            org.joda.time.LocalDate localDate5 = localDate0.withMonthOfYear(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) 3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = localDate0.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withTime((int) ' ', (int) (short) 0, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = dateTime7.toString("hi!", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 100, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) '#', 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate.Property property7 = localDate5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(10);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        int[] intArray8 = null;
        try {
            int[] intArray10 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localDate5, 100, intArray8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        org.joda.time.LocalDate localDate8 = localDate5.minusYears((int) (short) 10);
        int[] intArray14 = new int[] { (short) 0, 0, 2, (byte) 0 };
        java.util.Locale locale16 = null;
        try {
            int[] intArray17 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localDate8, 2, intArray14, "", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 1, (int) (short) 0, 0, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        try {
            long long12 = copticChronology1.getDateTimeMillis((long) 0, (int) 'a', (int) 'a', 3, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 24);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000278d + "'", double1 == 2440587.500000278d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 99);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        try {
//            org.joda.time.LocalDate localDate5 = property1.setCopy("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.LocalDate localDate3 = property1.roundHalfFloorCopy();
        try {
            org.joda.time.LocalDate localDate5 = property1.setCopy("Thursday");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Thursday\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (byte) 10, 0, (-1), 0, 99, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        java.lang.String str10 = property8.getAsString();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property8.getAsShortText(locale11);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "15" + "'", str10.equals("15"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "15" + "'", str12.equals("15"));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((int) ' ', 24, (int) (byte) -1, 122, 24, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 122 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (-3600000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -3600000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            int int4 = dateTime2.get(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = skipUndoDateTimeField4.getAsShortText(readablePartial7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100, 3, (int) (short) 100, (int) (byte) 10, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("19");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        boolean boolean6 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        int int2 = property1.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.LocalDate.Property property5 = localDate2.dayOfWeek();
//        org.joda.time.LocalDate localDate6 = property5.roundCeilingCopy();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight8 = localDate7.toDateMidnight();
//        java.lang.String str9 = localDate7.toString();
//        org.joda.time.LocalDate localDate11 = localDate7.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        boolean boolean13 = localDate7.isSupported(dateTimeFieldType12);
//        int int14 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate7);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15" + "'", str9.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        int int5 = dateTime2.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        int int6 = dateMidnight5.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
//        org.joda.time.Interval interval6 = property1.toInterval();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(interval6);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
//        org.joda.time.DateMidnight dateMidnight8 = dateTime2.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = iSOChronology9.years();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
//        int int15 = dateMidnight8.get(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 69 + "'", int15 == 69);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = localDate2.isSupported(durationFieldType3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 0, chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        try {
            boolean boolean11 = localDate2.isAfter((org.joda.time.ReadablePartial) localDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        int int6 = property5.getMaximumValueOverall();
        int int7 = property5.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime9 = property5.setCopy((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399 + "'", int6 == 86399);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (-1), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight18 = localDate17.toDateMidnight();
//        java.lang.String str19 = localDate17.toString();
//        org.joda.time.DateTime dateTime20 = localDate17.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight23 = localDate22.toDateMidnight();
//        java.lang.String str24 = localDate22.toString();
//        org.joda.time.LocalDate localDate26 = localDate22.minusDays((int) '#');
//        int[] intArray27 = localDate26.getValues();
//        java.util.Locale locale29 = null;
//        try {
//            int[] intArray30 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate17, 0, intArray27, "Thursday", locale29);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Thursday\" for weekyearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15" + "'", str19.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019-06-15" + "'", str24.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray27);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            int int7 = localDate5.get(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime2.toMutableDateTime(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology3);
        int int5 = localDate4.getCenturyOfEra();
        int[] intArray6 = localDate4.getValues();
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod3, (long) 10, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate4.minus(readablePeriod5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        java.lang.String str8 = localDate6.toString(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "T������" + "'", str8.equals("T������"));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendSecondOfDay((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.year();
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        boolean boolean10 = localDate0.isSupported(durationFieldType9);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight8 = localDate7.toDateMidnight();
//        java.lang.String str9 = localDate7.toString();
//        org.joda.time.DateTime dateTime10 = localDate7.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateMidnight dateMidnight12 = localDate7.toDateMidnight(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate7.toDateMidnight(dateTimeZone13);
//        org.joda.time.LocalDate.Property property15 = localDate7.dayOfWeek();
//        int int16 = localDate7.getCenturyOfEra();
//        int[] intArray21 = new int[] { ' ', 19, (-1) };
//        try {
//            int[] intArray23 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) localDate7, (int) ' ', intArray21, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15" + "'", str9.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
//        org.junit.Assert.assertNotNull(intArray21);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int8 = offsetDateTimeField5.getOffset();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.LocalDate localDate13 = localDate9.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        boolean boolean15 = localDate9.isSupported(dateTimeFieldType14);
//        int int16 = localDate9.getWeekOfWeekyear();
//        int int17 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.LocalDate localDate19 = localDate9.plus(readablePeriod18);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 151 + "'", int17 == 151);
//        org.junit.Assert.assertNotNull(localDate19);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone1.getName(32054400000L, locale7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-01:00" + "'", str8.equals("-01:00"));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int9 = offsetDateTimeField5.get((long) 2);
//        int int10 = offsetDateTimeField5.getMaximumValue();
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
//        java.lang.String str13 = localDate11.toString();
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.LocalDate localDate15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.LocalDate localDate20 = localDate16.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        boolean boolean22 = localDate16.isSupported(dateTimeFieldType21);
//        int int23 = localDate15.compareTo((org.joda.time.ReadablePartial) localDate16);
//        int[] intArray29 = new int[] { 1, (-6), (short) 0, (short) 0 };
//        java.util.Locale locale31 = null;
//        try {
//            int[] intArray32 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate15, 99, intArray29, "Thursday", locale31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Thursday\" for weekyearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 151 + "'", int10 == 151);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15" + "'", str13.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(intArray29);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("CopticChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        int int10 = offsetDateTimeField5.get(3600000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 122 + "'", int10 == 122);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime6.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField5.getMaximumValue(readablePartial12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 151 + "'", int13 == 151);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str9 = dateTimeZone8.getID();
        int int11 = dateTimeZone8.getOffsetFromLocal((long) (short) 10);
        long long14 = dateTimeZone8.convertLocalToUTC(0L, false);
        java.lang.String str15 = dateTimeZone8.toString();
        long long17 = dateTimeZone8.convertUTCToLocal(2764800024L);
        org.joda.time.DateTime dateTime18 = localDate6.toDateTimeAtStartOfDay(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-01:00" + "'", str9.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3600000) + "'", int11 == (-3600000));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-01:00" + "'", str15.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2761200024L + "'", long17 == 2761200024L);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
//        java.lang.String str5 = localDate3.toString();
//        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateMidnight dateMidnight8 = localDate3.toDateMidnight(dateTimeZone7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = iSOChronology9.years();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.monthOfYear();
//        int int12 = dateMidnight8.get(dateTimeField11);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateMidnight8);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateMidnight8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-15" + "'", str5.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560582000000L + "'", long13 == 1560582000000L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-3600000), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.LocalDate localDate3 = property1.roundHalfFloorCopy();
        java.util.Locale locale4 = null;
        int int5 = property1.getMaximumShortTextLength(locale4);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod3, 14256000000L, 3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter4, dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int8 = skipUndoDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(10.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560638641245L + "'", long0 == 1560638641245L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560582000000L, 1560638641245L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3121220641245L + "'", long2 == 3121220641245L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
//        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
//        long long5 = dateMidnight1.getMillis();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560582000000L + "'", long5 == 1560582000000L);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.LocalDate localDate6 = localDate4.plusWeeks(19);
//        int int7 = localDate4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
        org.joda.time.DateMidnight dateMidnight22 = dateTime19.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime19.plusMonths((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime19.withMillisOfSecond((int) 'a');
        boolean boolean27 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        int int10 = property8.get();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        int[] intArray5 = localDate4.getValues();
//        org.joda.time.LocalDate.Property property6 = localDate4.weekOfWeekyear();
//        int int7 = localDate4.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight8 = localDate7.toDateMidnight();
//        java.lang.String str9 = localDate7.toString();
//        org.joda.time.LocalDate localDate11 = localDate7.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        boolean boolean13 = localDate7.isSupported(dateTimeFieldType12);
//        int int14 = localDate7.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property15 = localDate7.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.LocalDate localDate17 = localDate7.minus(readablePeriod16);
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        int[] intArray22 = localDate20.getValues();
//        int int23 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate7, intArray22);
//        try {
//            org.joda.time.Partial partial24 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15" + "'", str9.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(10);
        int int8 = dateTime4.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("15");
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int8 = offsetDateTimeField5.getOffset();
//        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = localDate12.isSupported(dateTimeFieldType17);
//        org.joda.time.LocalDate.Property property19 = localDate12.year();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight28 = localDate27.toDateMidnight();
//        java.lang.String str29 = localDate27.toString();
//        org.joda.time.LocalDate localDate31 = localDate27.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        boolean boolean33 = localDate27.isSupported(dateTimeFieldType32);
//        int int34 = localDate27.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property35 = localDate27.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.LocalDate localDate37 = localDate27.minus(readablePeriod36);
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology39);
//        int int41 = localDate40.getCenturyOfEra();
//        int[] intArray42 = localDate40.getValues();
//        int int43 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate27, intArray42);
//        java.util.Locale locale45 = null;
//        try {
//            int[] intArray46 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate12, 1969, intArray42, "CopticChronology[America/Los_Angeles]", locale45);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[America/Los_Angeles]\" for weekyearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateMidnight28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019-06-15" + "'", str29.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 19 + "'", int41 == 19);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        boolean boolean8 = skipUndoDateTimeField4.isLeap((long) 15);
        try {
            long long11 = skipUndoDateTimeField4.set((long) 365, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [2,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        int int2 = dateTimeFormatter1.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("Thursday", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Thursday\" is malformed at \"hursday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.years();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(86399, 0, (int) '4', 1, 1, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        int int18 = fixedDateTimeZone4.getOffset((long) 99);
//        long long20 = fixedDateTimeZone4.previousTransition((long) 24);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24L + "'", long20 == 24L);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        boolean boolean10 = dateTimeZone6.isStandardOffset((long) (short) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        long long13 = offsetDateTimeField5.roundHalfCeiling((long) 151);
        org.joda.time.DurationField durationField14 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, durationField14, dateTimeFieldType15, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 2440942);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight7 = dateTime4.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        java.util.Locale locale3 = null;
        try {
            org.joda.time.LocalDate localDate4 = property1.setCopy("", locale3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(3, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.DateTime dateTime8 = dateTime2.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear(0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:00" + "'", str7.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        try {
            long long10 = skipUndoDateTimeField4.set((long) 86399, 151);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 151 for dayOfWeek must be in the range [2,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        int int2 = dateMidnight1.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.LocalDate localDate5 = property3.roundHalfEvenCopy();
//        boolean boolean7 = property3.equals((java.lang.Object) "JulianChronology[America/Los_Angeles]");
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '19' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("T������", (int) (short) 1, (int) '#', 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for T������ must be in the range [35,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, 1, (int) (short) 1, (-1), (int) (short) 1, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
//        java.lang.String str6 = localDate4.toString();
//        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateMidnight dateMidnight9 = localDate4.toDateMidnight(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField11 = iSOChronology10.years();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.monthOfYear();
//        int int13 = dateMidnight9.get(dateTimeField12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateMidnight9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight21 = localDate20.toDateMidnight();
//        java.lang.String str22 = localDate20.toString();
//        org.joda.time.DateTime dateTime23 = localDate20.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateMidnight dateMidnight25 = localDate20.toDateMidnight(dateTimeZone24);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField27 = iSOChronology26.years();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.monthOfYear();
//        int int29 = dateMidnight25.get(dateTimeField28);
//        org.joda.time.DateTimeZone dateTimeZone30 = dateMidnight25.getZone();
//        boolean boolean31 = fixedDateTimeZone19.equals((java.lang.Object) dateMidnight25);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) long14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        try {
//            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) localDate0, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560560400000L + "'", long14 == 1560560400000L);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-06-15" + "'", str22.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateMidnight25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withFieldAdded(durationFieldType3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getWeekOfWeekyear();
//        int int8 = localDate0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.LocalDate localDate9 = localDate5.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = localDate5.isSupported(dateTimeFieldType10);
//        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            int int14 = localDate5.get(dateTimeFieldType13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYear(99);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
//        int int9 = property8.getMinimumValue();
//        java.lang.String str10 = property8.getAsString();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property8.getAsText(locale11);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "15" + "'", str10.equals("15"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "15" + "'", str12.equals("15"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withMonthOfYear((-3600000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 12, 0, 15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int8 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField9 = skipUndoDateTimeField4.getWrappedField();
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight11 = localDate10.toDateMidnight();
//        java.lang.String str12 = localDate10.toString();
//        org.joda.time.LocalDate localDate14 = localDate10.minusDays((int) '#');
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField17 = iSOChronology16.years();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '4');
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight23 = localDate22.toDateMidnight();
//        java.lang.String str24 = localDate22.toString();
//        org.joda.time.LocalDate localDate26 = localDate22.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        boolean boolean28 = localDate22.isSupported(dateTimeFieldType27);
//        int int29 = localDate22.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property30 = localDate22.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.LocalDate localDate32 = localDate22.minus(readablePeriod31);
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology34);
//        int int36 = localDate35.getCenturyOfEra();
//        int[] intArray37 = localDate35.getValues();
//        int int38 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) localDate22, intArray37);
//        try {
//            int[] intArray40 = skipUndoDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDate14, 1969, intArray37, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15" + "'", str12.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019-06-15" + "'", str24.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 52 + "'", int38 == 52);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2, 100, 11, 2000, 2440942, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 69, 365, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.LocalDate localDate7 = localDate2.minusYears(52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(100, 19, 20, (-1), 0, (int) '#', 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 0, chronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        java.lang.Class<?> wildcardClass7 = dateTime5.getClass();
        boolean boolean9 = dateTime5.isEqual(1L);
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        int int11 = dateTime5.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19691231" + "'", str10.equals("19691231"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("122");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"122\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime9.toLocalDateTime();
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        int int15 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean8 = dateTimeZone6.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology9 = iSOChronology2.withZone(dateTimeZone6);
        try {
            org.joda.time.Partial partial10 = new org.joda.time.Partial(dateTimeFieldType0, 52, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(2000, (int) (byte) -1, (int) (short) 10, 3, 4, 100, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis((int) (byte) 0, 0, (int) (short) -1, (int) (byte) 1, 1969, (int) ' ', 122);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(10);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeek(7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray16 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder8.append(dateTimePrinter9, dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        int int6 = property5.getMaximumValueOverall();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight8 = localDate7.toDateMidnight();
        java.lang.String str9 = localDate7.toString();
        org.joda.time.LocalDate localDate11 = localDate7.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate11.minus(readablePeriod12);
        try {
            int int14 = property5.compareTo((org.joda.time.ReadablePartial) localDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399 + "'", int6 == 86399);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
        java.lang.String str13 = localDate11.toString();
        org.joda.time.LocalDate localDate15 = localDate11.minusDays((int) '#');
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology17);
        int int19 = localDate18.getCenturyOfEra();
        org.joda.time.LocalDate localDate21 = localDate18.minusDays(19);
        int int22 = localDate11.compareTo((org.joda.time.ReadablePartial) localDate21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate11, (int) (byte) 1, locale24);
        int int26 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31" + "'", str13.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon" + "'", str25.equals("Mon"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, (int) ' ', (int) (short) 0, 4, 99, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Thursday");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Thursday\" is malformed at \"hursday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
        long long9 = property8.remainder();
        java.lang.String str10 = property8.getAsShortText();
        org.joda.time.LocalDate localDate12 = property8.addToCopy(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology16);
        int int18 = localDate17.getCenturyOfEra();
        int[] intArray19 = localDate17.getValues();
        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate12, intArray19);
        long long23 = skipUndoDateTimeField4.add((long) 6, 3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31449600000L + "'", long9 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 259200006L + "'", long23 == 259200006L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        java.lang.String str7 = localDate5.toString();
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = iSOChronology11.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
        int int14 = dateMidnight10.get(dateTimeField13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
        java.lang.String str17 = fixedDateTimeZone4.getID();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime20.minusMinutes((int) (short) 10);
        int int25 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 151 + "'", int10 == 151);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
        org.joda.time.LocalDate.Property property4 = localDate0.yearOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("T������");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T������\" is malformed at \"������\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(24L, locale6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
        int int4 = localDate3.getEra();
        int int5 = localDate3.getWeekyear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1959 + "'", int5 == 1959);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.withMinuteOfHour(0);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readablePeriod7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-6), (-3600000), 7, (int) (byte) 0, 52, 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(readableDuration8, 69);
        boolean boolean12 = dateTime4.isEqual((long) 12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        try {
            org.joda.time.DateTimeField dateTimeField8 = localDate6.getField(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        java.util.Date date7 = localDate6.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = iSOChronology8.years();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.weekyear();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean14 = dateTimeZone12.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology15 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.Interval interval16 = localDate6.toInterval(dateTimeZone12);
        int int17 = localDate6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(interval16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 17 + "'", int17 == 17);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(86399, 24, (int) (byte) 0, 0, 3, (int) '4', 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 0, chronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears(10);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateMidnight5, (org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate4.isSupported(dateTimeFieldType5);
        int int7 = localDate4.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19, 0, 0, 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("2019-06-15");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) -1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 6, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.era();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime1.toMutableDateTime();
//        java.lang.String str4 = dateTime1.toString();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T23:59:59.999-00:00:00.001" + "'", str4.equals("1969-12-31T23:59:59.999-00:00:00.001"));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.DateTime.Property property21 = dateTime11.property(dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-6), "hi!");
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("69");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"69/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        try {
            org.joda.time.LocalDate localDate4 = localDate0.withDayOfYear(2440942);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2440942 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
        boolean boolean11 = skipUndoDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        java.lang.String str10 = skipUndoDateTimeField4.getAsShortText((long) 1959);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = skipUndoDateTimeField4.getAsShortText(100, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thu" + "'", str10.equals("Thu"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
        java.lang.String str10 = localDate8.toString();
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
        boolean boolean17 = offsetDateTimeField5.isSupported();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
        int int21 = localDate20.getCenturyOfEra();
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
        int int25 = offsetDateTimeField5.getMinimumValue((long) '#');
        int int27 = offsetDateTimeField5.getMaximumValue((long) 1);
        java.lang.String str28 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 151 + "'", int27 == 151);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str28.equals("DateTimeField[weekyearOfCentury]"));
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
//        org.joda.time.DurationField durationField8 = property7.getLeapDurationField();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = property7.equals(obj9);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property7.getAsShortText(locale11);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Thu" + "'", str12.equals("Thu"));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        java.lang.String str7 = localDate5.toString();
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = iSOChronology11.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
        int int14 = dateMidnight10.get(dateTimeField13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
        int int18 = fixedDateTimeZone4.getOffset((long) 99);
        long long20 = fixedDateTimeZone4.previousTransition(32054400000L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32054400000L + "'", long20 == 32054400000L);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
//        int int7 = dateTime2.getYear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) date5, dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-210865896000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        int int17 = dateTime16.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime11.getZone();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 0, chronology17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime18.minusMinutes((int) (short) 10);
//        int int23 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology7 = iSOChronology0.withZone(dateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        int int8 = skipUndoDateTimeField4.getDifference(31536000000L, (-210865896000000L));
        try {
            long long11 = skipUndoDateTimeField4.set((long) 1970, "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2440942 + "'", int8 == 2440942);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
        long long12 = skipUndoDateTimeField4.roundHalfCeiling((long) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundCeiling((long) '#');
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight8 = localDate7.toDateMidnight();
        java.lang.String str9 = localDate7.toString();
        org.joda.time.LocalDate localDate11 = localDate7.minusDays((int) '#');
        int int12 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate7);
        boolean boolean14 = skipUndoDateTimeField4.isLeap((long) (short) -1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560638641245L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560638641245L + "'", long2 == 1560638641245L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(86399, 0, (int) (byte) 1, 15, 0, 122, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 122 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.DurationField durationField8 = property7.getLeapDurationField();
        java.lang.Object obj9 = null;
        boolean boolean10 = property7.equals(obj9);
        try {
            org.joda.time.LocalDate localDate12 = property7.setCopy((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        try {
            org.joda.time.Partial partial8 = new org.joda.time.Partial(dateTimeFieldType0, 19, chronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
        java.lang.String str10 = localDate8.toString();
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
        java.lang.String str20 = localDate18.toString();
        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        boolean boolean24 = localDate18.isSupported(dateTimeFieldType23);
        int int25 = localDate18.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property26 = localDate18.yearOfCentury();
        int[] intArray27 = new int[] {};
        int int28 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate18, intArray27);
        long long31 = offsetDateTimeField5.add(3600010L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 151 + "'", int28 == 151);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3600010L + "'", long31 == 3600010L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, (long) (-292275054));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 0, chronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        java.lang.Class<?> wildcardClass7 = dateTime5.getClass();
        org.joda.time.Chronology chronology8 = dateTime5.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology(chronology8);
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T23:59:59.999-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T23:59:59.999-00:00:00.001\" is malformed at \"T23:59:59.999-00:00:00.001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNull(durationField5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        try {
            long long8 = offsetDateTimeField5.set((long) 2000, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekyearOfCentury must be in the range [52,151]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(readableDuration8, 69);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
        java.lang.String str18 = localDate16.toString();
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = iSOChronology22.years();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
        int int25 = dateMidnight21.get(dateTimeField24);
        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
        int int29 = fixedDateTimeZone15.getOffset((long) 99);
        org.joda.time.DateTime dateTime30 = dateTime4.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        int int31 = dateTime30.getDayOfWeek();
        org.joda.time.DateTime dateTime33 = dateTime30.withSecondOfMinute((int) '#');
        try {
            org.joda.time.DateTime dateTime38 = dateTime30.withTime(0, 151, 2, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 151 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31" + "'", str18.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.minusYears((int) (short) 10);
        int int4 = localDate3.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeek(7);
        dateTimeFormatterBuilder5.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 0, chronology21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        java.lang.Class<?> wildcardClass26 = dateTime24.getClass();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight33 = localDate32.toDateMidnight();
        java.lang.String str34 = localDate32.toString();
        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateMidnight dateMidnight37 = localDate32.toDateMidnight(dateTimeZone36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField39 = iSOChronology38.years();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.monthOfYear();
        int int41 = dateMidnight37.get(dateTimeField40);
        org.joda.time.DateTimeZone dateTimeZone42 = dateMidnight37.getZone();
        boolean boolean43 = fixedDateTimeZone31.equals((java.lang.Object) dateMidnight37);
        java.lang.String str45 = fixedDateTimeZone31.getNameKey(0L);
        org.joda.time.DateTime dateTime46 = dateTime24.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.joda.time.DateTime dateTime47 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        java.util.TimeZone timeZone49 = fixedDateTimeZone31.toTimeZone();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(dateMidnight33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1969-12-31" + "'", str34.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateMidnight37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "15" + "'", str45.equals("15"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
        java.lang.String str10 = localDate8.toString();
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
        boolean boolean17 = offsetDateTimeField5.isSupported();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
        java.lang.String str20 = localDate18.toString();
        org.joda.time.LocalDate localDate22 = localDate18.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.minus(readablePeriod23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField26 = iSOChronology25.years();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) '4');
        int int32 = offsetDateTimeField30.get(100L);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight34 = localDate33.toDateMidnight();
        java.lang.String str35 = localDate33.toString();
        org.joda.time.LocalDate localDate37 = localDate33.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate39 = localDate37.minus(readablePeriod38);
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate39, locale40);
        org.joda.time.DurationField durationField42 = offsetDateTimeField30.getLeapDurationField();
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight44 = localDate43.toDateMidnight();
        java.lang.String str45 = localDate43.toString();
        org.joda.time.LocalDate localDate47 = localDate43.minusDays((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
        boolean boolean49 = localDate43.isSupported(dateTimeFieldType48);
        int int50 = localDate43.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property51 = localDate43.yearOfCentury();
        int[] intArray52 = new int[] {};
        int int53 = offsetDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) localDate43, intArray52);
        int int54 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate24, intArray52);
        int int57 = offsetDateTimeField5.getDifference(0L, (long) 12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 122 + "'", int32 == 122);
        org.junit.Assert.assertNotNull(dateMidnight34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969-12-31" + "'", str35.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "69" + "'", str41.equals("69"));
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateMidnight44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1969-12-31" + "'", str45.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 151 + "'", int53 == 151);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 52 + "'", int54 == 52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        long long2 = property1.remainder();
        java.lang.String str3 = property1.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property1.getMaximumTextLength(locale4);
        int int6 = property1.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31449600000L + "'", long2 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "69" + "'", str3.equals("69"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        int int10 = skipUndoDateTimeField4.getMaximumValue((long) 122);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = skipUndoDateTimeField4.getAsText((int) (short) 100, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("GJChronology[-01:00]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("121");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
        java.lang.String str13 = localDate11.toString();
        org.joda.time.LocalDate localDate15 = localDate11.minusDays((int) '#');
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology17);
        int int19 = localDate18.getCenturyOfEra();
        org.joda.time.LocalDate localDate21 = localDate18.minusDays(19);
        int int22 = localDate11.compareTo((org.joda.time.ReadablePartial) localDate21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate11, (int) (byte) 1, locale24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = iSOChronology28.years();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) '4');
        int int35 = offsetDateTimeField33.get(100L);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight37 = localDate36.toDateMidnight();
        java.lang.String str38 = localDate36.toString();
        org.joda.time.LocalDate localDate40 = localDate36.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate42 = localDate40.minus(readablePeriod41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale43);
        org.joda.time.DurationField durationField45 = offsetDateTimeField33.getLeapDurationField();
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight47 = localDate46.toDateMidnight();
        java.lang.String str48 = localDate46.toString();
        org.joda.time.LocalDate localDate50 = localDate46.minusDays((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        boolean boolean52 = localDate46.isSupported(dateTimeFieldType51);
        int int53 = localDate46.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property54 = localDate46.yearOfCentury();
        int[] intArray55 = new int[] {};
        int int56 = offsetDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray55);
        try {
            int[] intArray58 = skipUndoDateTimeField4.addWrapField(readablePartial26, 0, intArray55, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31" + "'", str13.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon" + "'", str25.equals("Mon"));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 122 + "'", int35 == 122);
        org.junit.Assert.assertNotNull(dateMidnight37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969-12-31" + "'", str38.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "69" + "'", str44.equals("69"));
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969-12-31" + "'", str48.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 151 + "'", int56 == 151);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(2764800024L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType5);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        java.lang.Class<?> wildcardClass17 = dateTime15.getClass();
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime15.getZone();
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime3.withMillis((long) (short) 0);
        org.joda.time.DateTime dateTime24 = dateTime3.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.append(dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology3);
        int int5 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = localDate4.minusDays(19);
        int int8 = localDate4.getMonthOfYear();
        int[] intArray10 = copticChronology0.get((org.joda.time.ReadablePartial) localDate4, 99L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray12 = null;
        try {
            copticChronology0.validate(readablePartial11, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = localDate7.indexOf(dateTimeFieldType8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate7.plus(readablePeriod10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate7, 100, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        boolean boolean8 = dateTime4.isEqual(1L);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str11 = dateTimeZone10.getID();
        int int13 = dateTimeZone10.getOffsetFromLocal((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(11);
        try {
            org.joda.time.DateTime dateTime18 = dateTime16.withDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-01:00" + "'", str11.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-3600000) + "'", int13 == (-3600000));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime6.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime.Property property17 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime19 = property17.setCopy("19691231");
        org.joda.time.Interval interval20 = property17.toInterval();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(interval20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        long long2 = property1.remainder();
        java.lang.String str3 = property1.getAsShortText();
        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = localDate5.isSupported(dateTimeFieldType6);
        org.joda.time.LocalDate localDate9 = localDate5.withEra(0);
        int int10 = localDate5.getDayOfYear();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType12 = localDate5.getFieldType(2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 2000");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2764800000L + "'", long2 == 2764800000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "70" + "'", str3.equals("70"));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime13.toDateMidnight();
        org.joda.time.DateTime dateTime18 = dateTime13.plusMonths((int) '#');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMillis((-6));
        org.joda.time.LocalTime localTime21 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime22 = localDate10.toDateTime(localTime21);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((long) (short) 100, 292278993, 9, (-3600000), 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1969, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfDay();
        try {
            long long9 = julianChronology0.getDateTimeMillis(365, 0, (int) (short) 1, (int) (byte) 100, 53, 365, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1969, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = iSOChronology1.set(readablePartial4, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property7 = localDate6.yearOfCentury();
        org.joda.time.LocalDate localDate9 = localDate6.plusMonths(0);
        boolean boolean10 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(52, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
        java.lang.String str10 = localDate8.toString();
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
        boolean boolean17 = offsetDateTimeField5.isSupported();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
        int int21 = localDate20.getCenturyOfEra();
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
        int int25 = offsetDateTimeField5.getLeapAmount((long) '#');
        java.lang.Object obj26 = null;
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int25, obj26);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-02-02" + "'", str10.equals("1970-02-02"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        try {
            long long10 = iSOChronology0.getDateTimeMillis(2764800000L, 3, 11, 12, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8, 20);
        java.util.Locale locale13 = null;
        try {
            long long14 = skipDateTimeField10.set(0L, "", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.util.Date date1 = localDate0.toDate();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
        org.joda.time.Instant instant5 = instant4.toInstant();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = localDate2.minusDays(19);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate2.getFields();
        try {
            org.joda.time.DateTimeField dateTimeField8 = localDate2.getField(86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 86399");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2440588L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2440588L + "'", long2 == 2440588L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight7 = dateTime4.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = iSOChronology8.years();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        int int15 = offsetDateTimeField13.get(100L);
        long long17 = offsetDateTimeField13.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField13.getType();
        boolean boolean19 = dateTime4.isSupported(dateTimeFieldType18);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType18, 2440942, (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2440942 for weekyearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 122 + "'", int15 == 122);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31536000000L + "'", long17 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        int int10 = dateTime9.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48 + "'", int10 == 48);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1560638641245L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
        java.lang.String str14 = localDate12.toString();
        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateMidnight dateMidnight17 = localDate12.toDateMidnight(dateTimeZone16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = iSOChronology18.years();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.monthOfYear();
        int int21 = dateMidnight17.get(dateTimeField20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateMidnight17.getZone();
        boolean boolean23 = fixedDateTimeZone11.equals((java.lang.Object) dateMidnight17);
        java.lang.String str25 = fixedDateTimeZone11.getNameKey(0L);
        org.joda.time.DateTime dateTime26 = dateTime4.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-02-02" + "'", str14.equals("1970-02-02"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "15" + "'", str25.equals("15"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        org.joda.time.LocalDate localDate3 = localDate0.plusMonths(0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = iSOChronology12.years();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
        int int19 = offsetDateTimeField17.get(100L);
        long long21 = offsetDateTimeField17.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField17.getType();
        boolean boolean23 = dateTime8.isSupported(dateTimeFieldType22);
        int int24 = localDate0.get(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 122 + "'", int19 == 122);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31536000000L + "'", long21 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 70 + "'", int24 == 70);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "19691231" + "'", str4.equals("19691231"));
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 151);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property3 = localDate2.yearOfCentury();
        long long4 = property3.remainder();
        java.lang.String str5 = property3.getAsShortText();
        java.util.Locale locale6 = null;
        int int7 = property3.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2678400000L + "'", long4 == 2678400000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "70" + "'", str5.equals("70"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        long long9 = offsetDateTimeField5.roundHalfFloor((long) 48);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        java.lang.Class<?> wildcardClass17 = dateTime15.getClass();
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime15.getZone();
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime3.withMillis((long) (short) 0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("CopticChronology[America/Los_Angeles]", "69", 19, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2000, (int) '#', 151, (int) (short) 100, 1, 1, 151);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
        java.lang.String str14 = localDate12.toString();
        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateMidnight dateMidnight17 = localDate12.toDateMidnight(dateTimeZone16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = iSOChronology18.years();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.monthOfYear();
        int int21 = dateMidnight17.get(dateTimeField20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateMidnight17.getZone();
        boolean boolean23 = fixedDateTimeZone11.equals((java.lang.Object) dateMidnight17);
        java.lang.String str25 = fixedDateTimeZone11.getNameKey(0L);
        org.joda.time.DateTime dateTime26 = dateTime4.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTime dateTime28 = dateTime4.plusMinutes((int) '4');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-02-01" + "'", str14.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "15" + "'", str25.equals("15"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime6.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime.Property property17 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime19 = property17.setCopy("19691231");
        org.joda.time.DateTime dateTime20 = property17.withMinimumValue();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 0, chronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime23.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 0, chronology29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.toDateTime(dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
        java.lang.Class<?> wildcardClass34 = dateTime32.getClass();
        boolean boolean35 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime37 = dateTime32.plus(readableDuration36);
        boolean boolean38 = property17.equals((java.lang.Object) dateTime37);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        java.util.Date date7 = localDate6.toDate();
        org.joda.time.DateTime dateTime8 = localDate6.toDateTimeAtStartOfDay();
        int int9 = dateTime8.getDayOfWeek();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) (short) 100);
        long long13 = skipUndoDateTimeField10.add((long) 24, (long) ' ');
        int int14 = skipUndoDateTimeField10.getMinimumValue();
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) 122);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 0);
        int int20 = skipDateTimeField18.get(1L);
        long long22 = skipDateTimeField18.roundHalfFloor((long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2764800024L + "'", long13 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 99");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) (short) 100);
        long long13 = skipUndoDateTimeField10.add((long) 24, (long) ' ');
        int int14 = skipUndoDateTimeField10.getMinimumValue();
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) 122);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 0);
        int int20 = skipDateTimeField18.get(1L);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology22, dateTimeField24, (int) (short) 100);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology22);
        java.util.Date date28 = localDate27.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = iSOChronology29.years();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.weekyear();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        boolean boolean35 = dateTimeZone33.isStandardOffset((long) '#');
        org.joda.time.Chronology chronology36 = iSOChronology29.withZone(dateTimeZone33);
        org.joda.time.Interval interval37 = localDate27.toInterval(dateTimeZone33);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField39 = iSOChronology38.years();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) '4');
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight45 = localDate44.toDateMidnight();
        java.lang.String str46 = localDate44.toString();
        org.joda.time.LocalDate localDate48 = localDate44.minusDays((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        boolean boolean50 = localDate44.isSupported(dateTimeFieldType49);
        int int51 = localDate44.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property52 = localDate44.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.LocalDate localDate54 = localDate44.minus(readablePeriod53);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology56);
        int int58 = localDate57.getCenturyOfEra();
        int[] intArray59 = localDate57.getValues();
        int int60 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate44, intArray59);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) (short) 0, chronology62);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = dateTime63.toDateTime(dateTimeZone64);
        org.joda.time.DateTime dateTime67 = dateTime63.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology69 = null;
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) (short) 0, chronology69);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.DateTime dateTime72 = dateTime70.toDateTime(dateTimeZone71);
        org.joda.time.DateTime.Property property73 = dateTime72.secondOfDay();
        java.lang.Class<?> wildcardClass74 = dateTime72.getClass();
        boolean boolean75 = dateTime67.isEqual((org.joda.time.ReadableInstant) dateTime72);
        org.joda.time.YearMonthDay yearMonthDay76 = dateTime72.toYearMonthDay();
        org.joda.time.chrono.CopticChronology copticChronology77 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology78.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField81 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology77, dateTimeField79, (int) (short) 100);
        long long83 = skipUndoDateTimeField81.roundHalfCeiling((long) (byte) 10);
        org.joda.time.LocalDate localDate84 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property85 = localDate84.yearOfCentury();
        long long86 = property85.remainder();
        java.lang.String str87 = property85.getAsShortText();
        org.joda.time.LocalDate localDate89 = property85.addToCopy(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType90 = null;
        boolean boolean91 = localDate89.isSupported(dateTimeFieldType90);
        org.joda.time.Chronology chronology93 = null;
        org.joda.time.LocalDate localDate94 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology93);
        int int95 = localDate94.getCenturyOfEra();
        int[] intArray96 = localDate94.getValues();
        int int97 = skipUndoDateTimeField81.getMinimumValue((org.joda.time.ReadablePartial) localDate89, intArray96);
        int int98 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay76, intArray96);
        int int99 = skipDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray96);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2764800024L + "'", long13 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(interval37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateMidnight45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1970-02-01" + "'", str46.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 19 + "'", int58 == 19);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(yearMonthDay76);
        org.junit.Assert.assertNotNull(copticChronology77);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 2678400000L + "'", long86 == 2678400000L);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "70" + "'", str87.equals("70"));
        org.junit.Assert.assertNotNull(localDate89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 19 + "'", int95 == 19);
        org.junit.Assert.assertNotNull(intArray96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 52 + "'", int98 == 52);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 7 + "'", int99 == 7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        java.util.Date date5 = dateTime2.toDate();
        int int6 = dateTime2.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1380 + "'", int6 == 1380);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        java.util.Locale locale2 = null;
        java.lang.String str3 = property1.getAsShortText(locale2);
        int int4 = property1.getMinimumValueOverall();
        org.joda.time.DurationField durationField5 = property1.getDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "70" + "'", str3.equals("70"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(10);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
        long long9 = property8.remainder();
        java.lang.String str10 = property8.getAsShortText();
        org.joda.time.LocalDate localDate12 = property8.addToCopy(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology16);
        int int18 = localDate17.getCenturyOfEra();
        int[] intArray19 = localDate17.getValues();
        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate12, intArray19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField22.getAsShortText(0, locale24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2678400000L + "'", long9 == 2678400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "70" + "'", str10.equals("70"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
        int int9 = property8.getMinimumValue();
        java.lang.String str10 = property8.getAsString();
        org.joda.time.LocalDate localDate11 = property8.withMaximumValue();
        org.joda.time.Interval interval12 = localDate11.toInterval();
        java.lang.Class<?> wildcardClass13 = localDate11.getClass();
        try {
            org.joda.time.LocalDate localDate15 = localDate11.withDayOfWeek(20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-02-01" + "'", str2.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(interval12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime9.toLocalDateTime();
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.DateTime dateTime16 = dateTime9.withFieldAdded(durationFieldType14, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.years();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
        int int9 = dateMidnight5.get(dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateMidnight5.getZone();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        java.lang.String str13 = gJChronology12.toString();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-02-01" + "'", str2.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GJChronology[-01:00]" + "'", str13.equals("GJChronology[-01:00]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        int int15 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 82200 + "'", int15 == 82200);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        boolean boolean2 = copticChronology0.equals((java.lang.Object) 9);
        try {
            long long10 = copticChronology0.getDateTimeMillis(19, 1970, 53, 1959, 1, 2, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1959 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
        java.lang.String str8 = dateTimeZone1.toString();
        long long12 = dateTimeZone1.convertLocalToUTC((long) 52, false, (long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-01:00" + "'", str8.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600052L + "'", long12 == 3600052L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime6.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime19 = dateTime6.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime21 = dateTime6.plusMonths((int) (short) 100);
        org.joda.time.DateTime dateTime23 = dateTime6.withCenturyOfEra(1959);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray15 = null;
        int[] intArray17 = offsetDateTimeField5.add(readablePartial13, 100, intArray15, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(intArray17);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((-6));
        org.joda.time.LocalTime localTime10 = dateTime7.toLocalTime();
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withDayOfMonth(151);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 151 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858379200000L) + "'", long1 == (-210858379200000L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        java.lang.String str2 = localDate0.toString();
        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
        org.joda.time.LocalDate.Property property8 = localDate0.dayOfMonth();
        int int9 = property8.getMinimumValue();
        org.joda.time.LocalDate localDate10 = property8.withMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = iSOChronology11.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.weekyearOfCentury();
        boolean boolean15 = property8.equals((java.lang.Object) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.minuteOfHour();
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-02-01" + "'", str2.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(10);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter0.printTo(writer4, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231" + "'", str5.equals("19691231"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight26 = localDate25.toDateMidnight();
        java.lang.String str27 = localDate25.toString();
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateMidnight dateMidnight30 = localDate25.toDateMidnight(dateTimeZone29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField32 = iSOChronology31.years();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.monthOfYear();
        int int34 = dateMidnight30.get(dateTimeField33);
        org.joda.time.DateTimeZone dateTimeZone35 = dateMidnight30.getZone();
        boolean boolean36 = fixedDateTimeZone24.equals((java.lang.Object) dateMidnight30);
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime19.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        try {
            org.joda.time.DateTime dateTime42 = dateTime19.withDate(0, 48, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateMidnight26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-02-01" + "'", str27.equals("1970-02-01"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int8 = offsetDateTimeField5.getOffset();
        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
        long long13 = offsetDateTimeField5.roundHalfCeiling((long) 151);
        try {
            long long16 = offsetDateTimeField5.add((long) (short) 0, 1560638641245L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560638641245");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        java.lang.Class<?> wildcardClass17 = dateTime15.getClass();
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime15.getZone();
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone19);
        int int21 = dateTime3.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 70);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(151);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMillis(1970);
        java.util.Locale locale19 = null;
        java.util.Calendar calendar20 = dateTime16.toCalendar(locale19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(calendar20);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        try {
//            long long25 = julianChronology17.getDateTimeMillis(7, 1969, (int) (byte) 1, 0, 4, (-292275054), (-6));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.dayOfWeek();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        try {
//            int int10 = property8.compareTo(readableInstant9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate2.toDateMidnight(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.monthOfYear();
//        int int11 = dateMidnight7.get(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateMidnight7.getZone();
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology0.era();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology0.dayOfMonth();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getLeapDurationField();
        java.lang.String str8 = skipUndoDateTimeField4.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfWeek" + "'", str8.equals("dayOfWeek"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology3);
        int int5 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = localDate4.minusDays(19);
        int int8 = localDate4.getMonthOfYear();
        int[] intArray10 = copticChronology0.get((org.joda.time.ReadablePartial) localDate4, 99L);
        org.joda.time.LocalDate.Property property11 = localDate4.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(2764800000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mon" + "'", str7.equals("Mon"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property4 = localDate3.yearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.minusYears((int) (short) 10);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime6.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime19 = dateTime6.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime21 = dateTime19.plus((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        try {
            long long9 = iSOChronology0.getDateTimeMillis(20, 292278993, 1969, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        java.lang.String str5 = skipUndoDateTimeField4.getName();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        long long8 = skipUndoDateTimeField4.remainder((long) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(15, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField9 = skipUndoDateTimeField4.getWrappedField();
        int int12 = skipUndoDateTimeField4.getDifference((long) (-1), (long) 69);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.LocalDate.Property property8 = localDate0.year();
//        java.util.Locale locale9 = null;
//        int int10 = property8.getMaximumShortTextLength(locale9);
//        org.joda.time.LocalDate localDate11 = property8.roundHalfEvenCopy();
//        int int12 = localDate11.size();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfDay(86399);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
//        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime6.minus((long) 151);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMillis((int) (short) 100);
        boolean boolean6 = dateTime5.isAfterNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime5.toCalendar(locale7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(calendar8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder5.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(17, 1, 52, 48, 151, 122, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfEra((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) (short) 100);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readableDuration16);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
//        int int8 = dateTime2.getMonthOfYear();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateMidnight14);
//        java.util.GregorianCalendar gregorianCalendar16 = dateTime2.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(gregorianCalendar16);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 50, (long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 14613949650");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        org.joda.time.DateMidnight dateMidnight7 = dateTime4.toDateMidnight();
        int int8 = dateMidnight7.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology3.years();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone7);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = gregorianChronology0.equals(obj12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight15 = localDate14.toDateMidnight();
//        java.lang.String str16 = localDate14.toString();
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
//        org.joda.time.LocalDate localDate18 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate19 = property17.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate20 = property17.roundCeilingCopy();
//        org.joda.time.LocalDate localDate22 = property17.addWrapFieldToCopy(69);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        int[] intArray27 = localDate25.getValues();
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate22, intArray27);
//        int int29 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate2.toDateMidnight(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.monthOfYear();
//        int int11 = dateMidnight7.get(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateMidnight7.getZone();
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone12);
//        long long17 = copticChronology0.add((long) (-1), (long) 10, 0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.getMinimumValue((long) (-6));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        long long9 = offsetDateTimeField5.roundCeiling((long) (short) 10);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property11 = localDate10.yearOfCentury();
        org.joda.time.LocalDate localDate13 = localDate10.minusYears((int) (short) 10);
        int int14 = localDate13.getEra();
        int int15 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31536000000L + "'", long9 == 31536000000L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 151 + "'", int15 == 151);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
//        int int8 = dateTime2.getMonthOfYear();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateMidnight14);
//        int int16 = dateMidnight14.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((java.lang.Object) "121");
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-292275054), 69, 52, 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime4.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
//        int int15 = offsetDateTimeField13.get(100L);
//        long long17 = offsetDateTimeField13.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField13.getType();
//        boolean boolean19 = dateTime4.isSupported(dateTimeFieldType18);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = copticChronology20.monthOfYear();
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight23 = localDate22.toDateMidnight();
//        java.lang.String str24 = localDate22.toString();
//        org.joda.time.DateTime dateTime25 = localDate22.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateMidnight dateMidnight27 = localDate22.toDateMidnight(dateTimeZone26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField29 = iSOChronology28.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.monthOfYear();
//        int int31 = dateMidnight27.get(dateTimeField30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateMidnight27.getZone();
//        org.joda.time.Chronology chronology33 = copticChronology20.withZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime4.withChronology(chronology33);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 122 + "'", int15 == 122);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31536000000L + "'", long17 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019-06-15" + "'", str24.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            long long16 = iSOChronology1.set(readablePartial14, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((int) (short) 100, 68, 292278993, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean8 = jodaTimePermission5.implies((java.security.Permission) jodaTimePermission7);
        java.lang.String str9 = jodaTimePermission7.getName();
        java.security.PermissionCollection permissionCollection10 = jodaTimePermission7.newPermissionCollection();
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology3);
        int int5 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = localDate4.minusDays(19);
        int int8 = localDate4.getMonthOfYear();
        int[] intArray10 = copticChronology0.get((org.joda.time.ReadablePartial) localDate4, 99L);
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-12-31");
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        int int10 = dateTime9.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) (short) 100);
        long long13 = skipUndoDateTimeField10.add((long) 24, (long) ' ');
        int int14 = skipUndoDateTimeField10.getMinimumValue();
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) 122);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 0);
        try {
            long long23 = iSOChronology0.getDateTimeMillis(50, (int) (short) 1, (-292275054), 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2764800024L + "'", long13 == 2764800024L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology4);
        int int6 = localDate5.getCenturyOfEra();
        int[] intArray7 = localDate5.getValues();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone9.getID();
        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
        long long15 = dateTimeZone9.convertLocalToUTC(0L, false);
        org.joda.time.DateTime dateTime16 = localDate5.toDateTimeAtCurrentTime(dateTimeZone9);
        long long18 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate5, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600000L + "'", long15 == 3600000L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-86400000L) + "'", long18 == (-86400000L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType2 = partial0.getFieldType((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        boolean boolean7 = localDate5.isSupported(dateTimeFieldType6);
//        org.joda.time.LocalDate localDate9 = localDate5.withEra(0);
//        int int10 = localDate5.getDayOfYear();
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        try {
//            int int12 = localDate5.compareTo(readablePartial11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14256000000L + "'", long2 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 166 + "'", int10 == 166);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear((-6));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.year();
//        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 0, chronology21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
//        java.lang.Class<?> wildcardClass26 = dateTime24.getClass();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight33 = localDate32.toDateMidnight();
//        java.lang.String str34 = localDate32.toString();
//        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateMidnight dateMidnight37 = localDate32.toDateMidnight(dateTimeZone36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.monthOfYear();
//        int int41 = dateMidnight37.get(dateTimeField40);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateMidnight37.getZone();
//        boolean boolean43 = fixedDateTimeZone31.equals((java.lang.Object) dateMidnight37);
//        java.lang.String str45 = fixedDateTimeZone31.getNameKey(0L);
//        org.joda.time.DateTime dateTime46 = dateTime24.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTime dateTime47 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        long long52 = fixedDateTimeZone31.convertLocalToUTC(0L, true, (long) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019-06-15" + "'", str34.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "15" + "'", str45.equals("15"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        int int9 = offsetDateTimeField5.get((long) 2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField5.getAsShortText(14256000000L, locale11);
        long long15 = offsetDateTimeField5.add((long) (-3600000), (int) (short) 1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText(99, locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "122" + "'", str12.equals("122"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32050800000L + "'", long15 == 32050800000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "99" + "'", str18.equals("99"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.DurationField durationField8 = property7.getLeapDurationField();
        java.lang.Object obj9 = null;
        boolean boolean10 = property7.equals(obj9);
        java.lang.String str11 = property7.getAsShortText();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Thu" + "'", str11.equals("Thu"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        int int5 = partial4.size();
        try {
            int int7 = partial4.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        int int5 = partial4.size();
        try {
            int int7 = partial4.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
//        int int3 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
//        java.lang.String str6 = localDate4.toString();
//        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateMidnight dateMidnight9 = localDate4.toDateMidnight(dateTimeZone8);
//        boolean boolean10 = localDate2.isBefore((org.joda.time.ReadablePartial) localDate4);
//        try {
//            org.joda.time.LocalDate localDate12 = localDate4.withDayOfMonth((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.years();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
//        int int11 = offsetDateTimeField9.get(100L);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = iSOChronology21.years();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        int int28 = offsetDateTimeField26.get(100L);
//        long long30 = offsetDateTimeField26.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField26.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 15);
//        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = iSOChronology35.years();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.weekyear();
//        org.joda.time.DurationField durationField38 = iSOChronology35.months();
//        long long41 = durationField38.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField48 = iSOChronology47.years();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.weekyear();
//        org.joda.time.DurationField durationField50 = iSOChronology47.months();
//        long long53 = durationField50.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property55 = localDate54.yearOfCentury();
//        long long56 = property55.remainder();
//        java.lang.String str57 = property55.getAsShortText();
//        java.util.Locale locale58 = null;
//        int int59 = property55.getMaximumTextLength(locale58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property55.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(dateTimeField45, durationField50, dateTimeFieldType60, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, durationField38, dateTimeFieldType60);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType60, 3);
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField67 = iSOChronology66.years();
//        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight69 = localDate68.toDateMidnight();
//        java.lang.String str70 = localDate68.toString();
//        org.joda.time.DateTime dateTime71 = localDate68.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateMidnight dateMidnight73 = localDate68.toDateMidnight(dateTimeZone72);
//        org.joda.time.DateTimeZone dateTimeZone74 = null;
//        org.joda.time.DateMidnight dateMidnight75 = localDate68.toDateMidnight(dateTimeZone74);
//        org.joda.time.LocalDate.Property property76 = localDate68.dayOfMonth();
//        int int77 = property76.getMinimumValue();
//        org.joda.time.LocalDate localDate78 = property76.withMinimumValue();
//        org.joda.time.LocalDate.Property property79 = localDate78.monthOfYear();
//        org.joda.time.DurationField durationField80 = property79.getDurationField();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField81 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType60, durationField67, durationField80);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "19" + "'", str20.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 122 + "'", int28 == 122);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31536000000L + "'", long30 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2682000000L) + "'", long41 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-2682000000L) + "'", long53 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 14256000000L + "'", long56 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19" + "'", str57.equals("19"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateMidnight69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2019-06-15" + "'", str70.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateMidnight73);
//        org.junit.Assert.assertNotNull(dateMidnight75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertNotNull(property79);
//        org.junit.Assert.assertNotNull(durationField80);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        java.lang.String str3 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        java.lang.String str5 = skipUndoDateTimeField4.getName();
//        boolean boolean6 = skipUndoDateTimeField4.isLenient();
//        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getLeapDurationField();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField4.getAsText((long) 6, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property12 = localDate11.yearOfCentury();
//        org.joda.time.LocalDate localDate14 = localDate11.minusYears((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate11.withWeekyear((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField19 = iSOChronology18.years();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '4');
//        int int25 = offsetDateTimeField23.get(100L);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight27 = localDate26.toDateMidnight();
//        java.lang.String str28 = localDate26.toString();
//        org.joda.time.LocalDate localDate30 = localDate26.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.LocalDate localDate32 = localDate30.minus(readablePeriod31);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = offsetDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale33);
//        boolean boolean35 = offsetDateTimeField23.isSupported();
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight37 = localDate36.toDateMidnight();
//        java.lang.String str38 = localDate36.toString();
//        org.joda.time.LocalDate localDate40 = localDate36.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.LocalDate localDate42 = localDate40.minus(readablePeriod41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
//        int int50 = offsetDateTimeField48.get(100L);
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight52 = localDate51.toDateMidnight();
//        java.lang.String str53 = localDate51.toString();
//        org.joda.time.LocalDate localDate55 = localDate51.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.LocalDate localDate57 = localDate55.minus(readablePeriod56);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = offsetDateTimeField48.getAsShortText((org.joda.time.ReadablePartial) localDate57, locale58);
//        org.joda.time.DurationField durationField60 = offsetDateTimeField48.getLeapDurationField();
//        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight62 = localDate61.toDateMidnight();
//        java.lang.String str63 = localDate61.toString();
//        org.joda.time.LocalDate localDate65 = localDate61.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = null;
//        boolean boolean67 = localDate61.isSupported(dateTimeFieldType66);
//        int int68 = localDate61.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property69 = localDate61.yearOfCentury();
//        int[] intArray70 = new int[] {};
//        int int71 = offsetDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDate61, intArray70);
//        int int72 = offsetDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localDate42, intArray70);
//        try {
//            int[] intArray74 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) localDate11, 68, intArray70, 48);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 68");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thursday" + "'", str10.equals("Thursday"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 122 + "'", int25 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019-06-15" + "'", str28.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "19" + "'", str34.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019-06-15" + "'", str38.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 122 + "'", int50 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019-06-15" + "'", str53.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "19" + "'", str59.equals("19"));
//        org.junit.Assert.assertNull(durationField60);
//        org.junit.Assert.assertNotNull(dateMidnight62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2019-06-15" + "'", str63.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 24 + "'", int68 == 24);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 151 + "'", int71 == 151);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 52 + "'", int72 == 52);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) '#', (-1), 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfHalfday(9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        int int60 = remainderDateTimeField59.getDivisor();
//        long long62 = remainderDateTimeField59.roundHalfFloor((-86399900L));
//        long long64 = remainderDateTimeField59.remainder(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 14256000000L + "'", long52 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy(82200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82200 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((-6));
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.withDayOfMonth(10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        try {
            org.joda.time.DateTime dateTime19 = dateTime11.withMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.years();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone9.getID();
        int int12 = dateTimeZone9.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology5.withZone(dateTimeZone9);
        jodaTimePermission3.checkGuard((java.lang.Object) iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-3600000) + "'", int12 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate0.isSupported(dateTimeFieldType5);
//        int int7 = localDate0.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property8 = localDate0.yearOfCentury();
//        org.joda.time.DurationField durationField9 = property8.getDurationField();
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("-01:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeFormatterBuilder11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 7, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
//        long long16 = property15.remainder();
//        java.lang.String str17 = property15.getAsShortText();
//        org.joda.time.LocalDate localDate19 = property15.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = localDate19.isSupported(dateTimeFieldType20);
//        org.joda.time.LocalDate localDate23 = localDate19.withEra(0);
//        int int24 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTime dateTime25 = localDate19.toDateTimeAtCurrentTime();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.LocalDate localDate27 = localDate19.minus(readablePeriod26);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000000L + "'", long16 == 14256000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDate27);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.LocalDate.Property property7 = localDate6.weekyear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendFractionOfHour(68, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendDayOfWeek(15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.Permission permission5 = null;
        boolean boolean6 = jodaTimePermission3.implies(permission5);
        java.lang.String str7 = jodaTimePermission3.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        int int7 = copticChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, chronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        int int14 = property13.getMinimumValue();
        boolean boolean15 = copticChronology1.equals((java.lang.Object) property13);
        org.joda.time.DurationField durationField16 = copticChronology1.minutes();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int8 = offsetDateTimeField5.getOffset();
//        long long11 = offsetDateTimeField5.add((long) (byte) 0, (long) 1);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate localDate16 = localDate12.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = localDate12.isSupported(dateTimeFieldType17);
//        org.joda.time.LocalDate.Property property19 = localDate12.year();
//        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate12, locale21);
//        int int23 = offsetDateTimeField5.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32054400000L + "'", long11 == 32054400000L);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendFractionOfHour(68, 3);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTimeZoneOffset("69", true, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 100, (org.joda.time.Chronology) copticChronology1);
        int int7 = copticChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, chronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        int int14 = property13.getMinimumValue();
        boolean boolean15 = copticChronology1.equals((java.lang.Object) property13);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        try {
            int[] intArray18 = copticChronology1.get(readablePeriod16, (long) 70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendLiteral("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]");
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 0, chronology11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime12.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 0, chronology18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
//        java.lang.Class<?> wildcardClass23 = dateTime21.getClass();
//        boolean boolean24 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime21.plus(readableDuration25);
//        org.joda.time.DateTime dateTime28 = dateTime26.plusMillis(1970);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField30 = iSOChronology29.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) '4');
//        int int36 = offsetDateTimeField34.get(100L);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight38 = localDate37.toDateMidnight();
//        java.lang.String str39 = localDate37.toString();
//        org.joda.time.LocalDate localDate41 = localDate37.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.LocalDate localDate43 = localDate41.minus(readablePeriod42);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = offsetDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) localDate43, locale44);
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField47 = iSOChronology46.years();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) '4');
//        int int53 = offsetDateTimeField51.get(100L);
//        long long55 = offsetDateTimeField51.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField51.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType56, 15);
//        int int59 = dateTime26.get(dateTimeFieldType56);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType56, (int) 'a', 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 122 + "'", int36 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019-06-15" + "'", str39.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "19" + "'", str45.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 122 + "'", int53 == 122);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31536000000L + "'", long55 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 69 + "'", int59 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 99);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        java.lang.String str6 = localDate2.toString("19691231");
//        boolean boolean7 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19691231" + "'", str6.equals("19691231"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate2.toDateMidnight(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.monthOfYear();
//        int int11 = dateMidnight7.get(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateMidnight7.getZone();
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.year();
        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime21 = dateTime11.withCenturyOfEra(4);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateMidnight5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
//        int int25 = dateMidnight21.get(dateTimeField24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
//        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) long10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime28.withDayOfYear((-69));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -69 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560560400000L + "'", long10 == 1560560400000L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology1);
//        int int3 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
//        java.lang.String str6 = localDate4.toString();
//        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateMidnight dateMidnight9 = localDate4.toDateMidnight(dateTimeZone8);
//        boolean boolean10 = localDate2.isBefore((org.joda.time.ReadablePartial) localDate4);
//        try {
//            org.joda.time.LocalDate localDate12 = localDate4.withEra((-69));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -69 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        java.lang.String str2 = julianChronology0.toString();
        try {
            long long10 = julianChronology0.getDateTimeMillis(100, (int) (short) 100, (int) (short) 0, (int) '4', 0, 2000, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[-01:00]" + "'", str1.equals("JulianChronology[-01:00]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[-01:00]" + "'", str2.equals("JulianChronology[-01:00]"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        java.lang.String str8 = dateTimeZone6.getID();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-01:00" + "'", str8.equals("-01:00"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("99");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"99\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.plus((long) (short) -1);
        int int19 = dateTime16.getEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(2764800024L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toStringList();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        java.io.Writer writer2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
//        java.lang.String str5 = localDate3.toString();
//        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateMidnight dateMidnight8 = localDate3.toDateMidnight(dateTimeZone7);
//        int int9 = dateMidnight8.getWeekOfWeekyear();
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateMidnight8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-07-17" + "'", str5.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 29 + "'", int9 == 29);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
//        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.year();
//        org.joda.time.DateTime dateTime19 = dateTime11.withYearOfCentury(0);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 0, chronology21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
//        java.lang.Class<?> wildcardClass26 = dateTime24.getClass();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight33 = localDate32.toDateMidnight();
//        java.lang.String str34 = localDate32.toString();
//        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateMidnight dateMidnight37 = localDate32.toDateMidnight(dateTimeZone36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = iSOChronology38.years();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.monthOfYear();
//        int int41 = dateMidnight37.get(dateTimeField40);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateMidnight37.getZone();
//        boolean boolean43 = fixedDateTimeZone31.equals((java.lang.Object) dateMidnight37);
//        java.lang.String str45 = fixedDateTimeZone31.getNameKey(0L);
//        org.joda.time.DateTime dateTime46 = dateTime24.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTime dateTime47 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.DateTime dateTime49 = dateTime47.withYearOfEra(365);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019-07-17" + "'", str34.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 7 + "'", int41 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "15" + "'", str45.equals("15"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime20.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 0, chronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.toDateTime(dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        java.lang.Class<?> wildcardClass31 = dateTime29.getClass();
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime34 = dateTime24.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime37 = dateTime24.withDurationAdded((-2682000000L), 122);
        org.joda.time.DateTime dateTime39 = dateTime24.plusMonths((int) (short) 100);
        int int40 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        java.lang.String str41 = property17.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-69) + "'", int40 == (-69));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Property[weekyear]" + "'", str41.equals("Property[weekyear]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime(dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, 5, 151, 12, 17, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 151 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateMidnight1.isSupported(dateTimeFieldType2);
        org.joda.time.Instant instant4 = dateMidnight1.toInstant();
        org.joda.time.Instant instant6 = instant4.minus((-86399999L));
        org.joda.time.Instant instant8 = instant4.plus(0L);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(3121220641245L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 99);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(99);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime11.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        boolean boolean17 = offsetDateTimeField5.isSupported();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology19);
//        int int21 = localDate20.getCenturyOfEra();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate20, locale22);
//        int int25 = offsetDateTimeField5.getLeapAmount((long) '#');
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight27 = localDate26.toDateMidnight();
//        java.lang.String str28 = localDate26.toString();
//        org.joda.time.DateTime dateTime29 = localDate26.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateMidnight dateMidnight31 = localDate26.toDateMidnight(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateMidnight dateMidnight33 = localDate26.toDateMidnight(dateTimeZone32);
//        org.joda.time.LocalDate.Property property34 = localDate26.dayOfMonth();
//        int int35 = property34.getMinimumValue();
//        org.joda.time.LocalDate localDate36 = property34.withMinimumValue();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate36, 2, locale38);
//        long long41 = offsetDateTimeField5.roundHalfFloor((long) 82200);
//        org.joda.time.DurationField durationField42 = offsetDateTimeField5.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-07-17" + "'", str10.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019-07-17" + "'", str28.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2" + "'", str39.equals("2"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertNull(durationField42);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        java.lang.String str2 = julianChronology0.toString();
        try {
            long long8 = julianChronology0.getDateTimeMillis((long) 19, 82200, 1959, 1, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[-01:00]" + "'", str1.equals("JulianChronology[-01:00]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[-01:00]" + "'", str2.equals("JulianChronology[-01:00]"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        boolean boolean8 = dateTime4.isEqual(1L);
        int int9 = dateTime4.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = iSOChronology5.years();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '4');
//        int int12 = offsetDateTimeField10.get(100L);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight14 = localDate13.toDateMidnight();
//        java.lang.String str15 = localDate13.toString();
//        org.joda.time.LocalDate localDate17 = localDate13.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.LocalDate localDate19 = localDate17.minus(readablePeriod18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate19, locale20);
//        boolean boolean22 = offsetDateTimeField10.isSupported();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology24);
//        int int26 = localDate25.getCenturyOfEra();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate25, locale27);
//        int int30 = offsetDateTimeField10.getMinimumValue((long) '#');
//        int int32 = offsetDateTimeField10.getMaximumValue((long) 1);
//        jodaTimePermission3.checkGuard((java.lang.Object) offsetDateTimeField10);
//        long long36 = offsetDateTimeField10.addWrapField((long) (-3600000), 151);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 122 + "'", int12 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-07-17" + "'", str15.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "19" + "'", str21.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "69" + "'", str28.equals("69"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 151 + "'", int32 == 151);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1546304400000L) + "'", long36 == (-1546304400000L));
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate0.toDateMidnight(dateTimeZone6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = localDate0.isSupported(dateTimeFieldType8);
//        org.joda.time.LocalDate localDate11 = localDate0.plusMonths(17);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology13);
//        int int15 = localDate14.getCenturyOfEra();
//        org.joda.time.LocalDate localDate17 = localDate14.minusDays(19);
//        boolean boolean18 = localDate11.isEqual((org.joda.time.ReadablePartial) localDate17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField20 = iSOChronology19.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        int int26 = offsetDateTimeField24.get(100L);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight28 = localDate27.toDateMidnight();
//        java.lang.String str29 = localDate27.toString();
//        org.joda.time.LocalDate localDate31 = localDate27.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.LocalDate localDate33 = localDate31.minus(readablePeriod32);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDate33, locale34);
//        boolean boolean36 = offsetDateTimeField24.isSupported();
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight38 = localDate37.toDateMidnight();
//        java.lang.String str39 = localDate37.toString();
//        org.joda.time.LocalDate localDate41 = localDate37.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.LocalDate localDate43 = localDate41.minus(readablePeriod42);
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField45 = iSOChronology44.years();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology44.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) '4');
//        int int51 = offsetDateTimeField49.get(100L);
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight53 = localDate52.toDateMidnight();
//        java.lang.String str54 = localDate52.toString();
//        org.joda.time.LocalDate localDate56 = localDate52.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.LocalDate localDate58 = localDate56.minus(readablePeriod57);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField49.getAsShortText((org.joda.time.ReadablePartial) localDate58, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField49.getLeapDurationField();
//        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight63 = localDate62.toDateMidnight();
//        java.lang.String str64 = localDate62.toString();
//        org.joda.time.LocalDate localDate66 = localDate62.minusDays((int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = null;
//        boolean boolean68 = localDate62.isSupported(dateTimeFieldType67);
//        int int69 = localDate62.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property70 = localDate62.yearOfCentury();
//        int[] intArray71 = new int[] {};
//        int int72 = offsetDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localDate62, intArray71);
//        int int73 = offsetDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) localDate43, intArray71);
//        boolean boolean74 = localDate17.equals((java.lang.Object) intArray71);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 122 + "'", int26 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019-07-17" + "'", str29.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19" + "'", str35.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateMidnight38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019-07-17" + "'", str39.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 122 + "'", int51 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019-07-17" + "'", str54.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "19" + "'", str60.equals("19"));
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateMidnight63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2019-07-17" + "'", str64.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 29 + "'", int69 == 29);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 151 + "'", int72 == 151);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 52 + "'", int73 == 52);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str3 = dateTimeZone2.getID();
        int int5 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) 151);
        int int10 = cachedDateTimeZone6.getOffset((long) 69);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((-86399900L), (org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:00" + "'", str3.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-3600000) + "'", int5 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-3600000) + "'", int10 == (-3600000));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate localDate4 = localDate0.minusDays((int) '#');
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology6);
//        int int8 = localDate7.getCenturyOfEra();
//        org.joda.time.LocalDate localDate10 = localDate7.minusDays(19);
//        int int11 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology12, dateTimeField14, (int) (short) 100);
//        long long19 = skipUndoDateTimeField16.add((long) 24, (long) ' ');
//        int int22 = skipUndoDateTimeField16.getDifference((long) 4, (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField16.getType();
//        int int24 = localDate10.indexOf(dateTimeFieldType23);
//        org.joda.time.DurationFieldType durationFieldType25 = null;
//        try {
//            org.joda.time.LocalDate localDate27 = localDate10.withFieldAdded(durationFieldType25, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2764800024L + "'", long19 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        int int9 = offsetDateTimeField7.get(100L);
        int int11 = offsetDateTimeField7.get((long) 2);
        boolean boolean12 = gJChronology0.equals((java.lang.Object) 2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 122 + "'", int11 == 122);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
//        long long7 = skipUndoDateTimeField4.add((long) 24, (long) ' ');
//        int int10 = skipUndoDateTimeField4.getDifference((long) 4, (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipUndoDateTimeField4.getType();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight13 = localDate12.toDateMidnight();
//        java.lang.String str14 = localDate12.toString();
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.LocalDate localDate16 = property15.roundCeilingCopy();
//        org.joda.time.LocalDate localDate17 = property15.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate18 = property15.roundCeilingCopy();
//        org.joda.time.LocalDate localDate20 = property15.addWrapFieldToCopy(69);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property23 = localDate22.yearOfCentury();
//        long long24 = property23.remainder();
//        java.lang.String str25 = property23.getAsShortText();
//        org.joda.time.LocalDate localDate27 = property23.addToCopy(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
//        boolean boolean29 = localDate27.isSupported(dateTimeFieldType28);
//        org.joda.time.LocalDate localDate31 = localDate27.withEra(0);
//        int[] intArray32 = localDate31.getValues();
//        java.util.Locale locale34 = null;
//        try {
//            int[] intArray35 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localDate20, (-292275054), intArray32, "UTC", locale34);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2764800024L + "'", long7 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-07-17" + "'", str14.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 17020800000L + "'", long24 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray32);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        java.lang.String str7 = localDate5.toString();
//        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateMidnight dateMidnight10 = localDate5.toDateMidnight(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
//        int int14 = dateMidnight10.get(dateTimeField13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateMidnight10.getZone();
//        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateMidnight10);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        try {
//            int[] intArray22 = julianChronology17.get(readablePeriod19, 86400000L, (long) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-07-17" + "'", str7.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeek(9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter1.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
//        java.lang.String str11 = localDate9.toString();
//        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateMidnight dateMidnight14 = localDate9.toDateMidnight(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = iSOChronology15.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.monthOfYear();
//        int int18 = dateMidnight14.get(dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateMidnight14.getZone();
//        boolean boolean20 = fixedDateTimeZone8.equals((java.lang.Object) dateMidnight14);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone22);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-07-17" + "'", str11.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        int int17 = offsetDateTimeField5.getOffset();
//        long long19 = offsetDateTimeField5.roundFloor(32054400000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-07-17" + "'", str10.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000000L + "'", long19 == 31536000000L);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField3);
//        long long7 = skipUndoDateTimeField4.getDifferenceAsLong(10L, 0L);
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology8, dateTimeField10, (int) (short) 100);
//        long long15 = skipUndoDateTimeField12.add((long) 24, (long) ' ');
//        int int18 = skipUndoDateTimeField12.getDifference((long) 4, (long) 'a');
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        java.lang.String str21 = localDate19.toString();
//        org.joda.time.LocalDate localDate23 = localDate19.minusDays((int) '#');
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((java.lang.Object) (-1L), chronology25);
//        int int27 = localDate26.getCenturyOfEra();
//        org.joda.time.LocalDate localDate29 = localDate26.minusDays(19);
//        int int30 = localDate19.compareTo((org.joda.time.ReadablePartial) localDate29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate19, (int) (byte) 1, locale32);
//        int int34 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate19);
//        int int35 = skipUndoDateTimeField4.getMaximumValue();
//        long long38 = skipUndoDateTimeField4.set(2678400000L, 9);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2764800024L + "'", long15 == 2764800024L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-07-17" + "'", str21.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Mon" + "'", str33.equals("Mon"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292275054) + "'", int34 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 292278993 + "'", int35 == 292278993);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61880457600000L) + "'", long38 == (-61880457600000L));
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "19691231");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateMidnight5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "15", (-1), 69);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
//        java.lang.String str18 = localDate16.toString();
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateMidnight dateMidnight21 = localDate16.toDateMidnight(dateTimeZone20);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = iSOChronology22.years();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.monthOfYear();
//        int int25 = dateMidnight21.get(dateTimeField24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateMidnight21.getZone();
//        boolean boolean27 = fixedDateTimeZone15.equals((java.lang.Object) dateMidnight21);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) long10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.DateMidnight dateMidnight29 = dateTime28.toDateMidnight();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear(10);
//        org.joda.time.Chronology chronology33 = dateTimeFormatter30.getChronolgy();
//        java.lang.String str34 = dateMidnight29.toString(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1563321600001L + "'", long10 == 1563321600001L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-07-17" + "'", str18.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateMidnight29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNull(chronology33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "T000000-0000" + "'", str34.equals("T000000-0000"));
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("1");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(readableDuration8, 69);
        int int11 = dateTime4.getYearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime4.withDurationAdded(14256000000L, 1959);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime14.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeOfDay15);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear((-1), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour(1, 19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        long long2 = property1.remainder();
//        java.lang.String str3 = property1.getAsShortText();
//        org.joda.time.LocalDate localDate5 = property1.addToCopy(10);
//        int int6 = property1.getMinimumValueOverall();
//        org.joda.time.LocalDate localDate7 = property1.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17020800000L + "'", long2 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(localDate7);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        int int9 = offsetDateTimeField5.get((long) 2);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField5.getAsShortText(14256000000L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight14 = localDate13.toDateMidnight();
//        java.lang.String str15 = localDate13.toString();
//        org.joda.time.DateTime dateTime16 = localDate13.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateMidnight dateMidnight18 = localDate13.toDateMidnight(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateMidnight dateMidnight20 = localDate13.toDateMidnight(dateTimeZone19);
//        org.joda.time.LocalDate.Property property21 = localDate13.dayOfWeek();
//        int int22 = localDate13.getCenturyOfEra();
//        int int23 = localDate13.getYearOfCentury();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate13, (int) (byte) 1, locale25);
//        java.util.Locale locale27 = null;
//        int int28 = offsetDateTimeField5.getMaximumShortTextLength(locale27);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 122 + "'", int9 == 122);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "122" + "'", str12.equals("122"));
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-07-17" + "'", str15.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        int int7 = offsetDateTimeField5.get(100L);
        long long9 = offsetDateTimeField5.roundCeiling((long) (short) 10);
        long long12 = offsetDateTimeField5.addWrapField(0L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31536000000L + "'", long9 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfMinute(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendLiteral("JulianChronology[(\"org.joda.time.JodaTimePermission\" \"hi!\")]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField2, (int) (short) 100);
        long long6 = skipUndoDateTimeField4.roundHalfCeiling((long) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendYear((int) ' ', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTimeZoneShortName(strMap17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = iSOChronology19.years();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        int int26 = offsetDateTimeField24.get(100L);
        long long28 = offsetDateTimeField24.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType29, (int) (short) 100);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType29, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 122 + "'", int26 == 122);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31536000000L + "'", long28 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        int int4 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        long long7 = dateTimeZone1.convertLocalToUTC(0L, false);
        long long10 = dateTimeZone1.convertLocalToUTC(0L, false);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology13, dateTimeField15, (int) (short) 100);
        long long19 = skipUndoDateTimeField17.roundHalfCeiling((long) (byte) 10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology11, (org.joda.time.DateTimeField) skipUndoDateTimeField17, 82200);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3600000L + "'", long7 == 3600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 20, dateTimeZone1);
        try {
            java.lang.String str4 = localDate2.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (short) 100, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 6);
        boolean boolean8 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendMinuteOfDay(122);
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(99);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateTime dateTime11 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        long long4 = dateTimeZone1.adjustOffset(14256000000L, true);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, 1560642241245L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 14256000000L + "'", long4 == 14256000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560678241246L + "'", long7 == 1560678241246L);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.LocalDate.Property property3 = localDate0.dayOfWeek();
//        org.joda.time.LocalDate.Property property4 = localDate0.era();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 0, chronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((int) (short) 10);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 0, chronology13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
//        java.lang.Class<?> wildcardClass18 = dateTime16.getClass();
//        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime21 = dateTime16.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
//        try {
//            int int23 = property4.getDifference((org.joda.time.ReadableInstant) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
//        int int7 = offsetDateTimeField5.get(100L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
//        java.lang.String str10 = localDate8.toString();
//        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate14 = localDate12.minus(readablePeriod13);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = iSOChronology17.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        int int24 = offsetDateTimeField22.get(100L);
//        long long26 = offsetDateTimeField22.roundCeiling((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 15);
//        org.joda.time.DurationField durationField30 = dividedDateTimeField29.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
//        org.joda.time.DurationField durationField34 = iSOChronology31.months();
//        long long37 = durationField34.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.years();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField41);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = iSOChronology43.years();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyear();
//        org.joda.time.DurationField durationField46 = iSOChronology43.months();
//        long long49 = durationField46.subtract((long) (-3600000), (int) (short) 1);
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property51 = localDate50.yearOfCentury();
//        long long52 = property51.remainder();
//        java.lang.String str53 = property51.getAsShortText();
//        java.util.Locale locale54 = null;
//        int int55 = property51.getMaximumTextLength(locale54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, durationField46, dateTimeFieldType56, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField29, durationField34, dateTimeFieldType56);
//        try {
//            long long62 = remainderDateTimeField59.set((long) 2440942, 292278993);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for yearOfCentury must be in the range [0,14]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 122 + "'", int7 == 122);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-07-17" + "'", str10.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 122 + "'", int24 == 122);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2682000000L) + "'", long37 == (-2682000000L));
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2682000000L) + "'", long49 == (-2682000000L));
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 17020800000L + "'", long52 == 17020800000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19" + "'", str53.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight3 = localDate2.toDateMidnight();
//        java.lang.String str4 = localDate2.toString();
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateMidnight dateMidnight7 = localDate2.toDateMidnight(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = iSOChronology8.years();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.monthOfYear();
//        int int11 = dateMidnight7.get(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateMidnight7.getZone();
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology0.era();
//        org.joda.time.DateTimeField dateTimeField15 = null;
//        try {
//            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-07-17" + "'", str4.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField5 = iSOChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateMidnight dateMidnight1 = localDate0.toDateMidnight();
//        java.lang.String str2 = localDate0.toString();
//        org.joda.time.DateTime dateTime3 = localDate0.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateMidnight dateMidnight5 = localDate0.toDateMidnight(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.years();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.monthOfYear();
//        int int9 = dateMidnight5.get(dateTimeField8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.lang.String str11 = dateMidnight5.toString(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-07-17" + "'", str2.equals("2019-07-17"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019198T000000-0000" + "'", str11.equals("2019198T000000-0000"));
//    }
//}

